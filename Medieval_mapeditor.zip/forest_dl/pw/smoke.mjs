import { chromium } from 'playwright';

const url = process.argv[2] || 'http://127.0.0.1:8017/';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });

const errors = [];
const warnings = [];
page.on('console', m => {
  if (m.type() === 'error') errors.push(m.text());
  if (m.type() === 'warning') warnings.push(m.text());
});
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

const forestTextures = new Set();
page.on('response', r => {
  const u = r.url();
  if (u.includes('assets/forest/')) forestTextures.add(u.split('/').pop() + ':' + r.status());
});

await page.goto(url, { waitUntil: 'load', timeout: 30000 });
// let the renderer + textures settle
await page.waitForTimeout(7000);

const stats = await page.evaluate(() => {
  const s = document.getElementById('stats');
  return s ? s.textContent : '(no #stats)';
});

const canvas = await page.evaluate(() => {
  const c = document.querySelector('canvas');
  return c ? { w: c.width, h: c.height } : null;
});

await page.screenshot({ path: '/home/user/village/smoke.png' });

console.log('STATS:', stats);
console.log('CANVAS:', JSON.stringify(canvas));
console.log('FOREST TEX RESPONSES:', [...forestTextures].sort().join(', ') || '(none)');
console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
console.log('WARNINGS:', warnings.length ? warnings.slice(0, 10).join('\n') : '(none)');

await browser.close();
