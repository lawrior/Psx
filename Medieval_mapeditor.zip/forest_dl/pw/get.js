const { chromium } = require('playwright');
const fs = require('fs');

const BASE = 'https://starkcrafts.itch.io/psx-forest-asset-collection-by-starkcrafts';
const UPLOAD_ID = '5967787'; // PSX_Forest_Level_byStarkCrafts.zip

(async () => {
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({
    userAgent: 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
    acceptDownloads: true,
  });
  const page = await ctx.newPage();

  const jsonResponses = [];
  page.on('response', async (res) => {
    const ct = (res.headers()['content-type'] || '');
    if (ct.includes('json')) {
      try {
        const body = await res.text();
        if (body.includes('"url"') || body.includes('errors')) {
          jsonResponses.push({ url: res.url(), status: res.status(), body: body.slice(0, 500) });
        }
      } catch (e) {}
    }
  });

  const downloadPromise = new Promise((resolve) => {
    page.on('download', async (dl) => {
      const p = '/home/user/forest_dl/forest.zip';
      await dl.saveAs(p);
      console.log('DOWNLOAD saved:', p, 'suggested filename:', dl.suggestedFilename());
      resolve();
    });
  });

  // 1. game page
  await page.goto(BASE, { waitUntil: 'domcontentloaded' });

  // 2. claim download via the same fetch the site uses
  const signed = await page.evaluate(async () => {
    const csrf = document.querySelector('meta[name="csrf_token"]').content;
    const res = await fetch(window.location.origin + '/psx-forest-asset-collection-by-starkcrafts/download_url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'csrf_token=' + encodeURIComponent(csrf),
    });
    return await res.json();
  });
  console.log('download_url ->', signed);

  // 3. open the download (interstitial) page
  await page.goto(signed.url, { waitUntil: 'domcontentloaded' });

  // 4. click the Download button for the forest upload
  const btn = page.locator(`a.download_btn[data-upload_id="${UPLOAD_ID}"]`);
  console.log('found download btn:', (await btn.count()) > 0);
  await btn.first().click();

  // 5. wait for either a download event or a JSON url response
  await Promise.race([
    downloadPromise,
    page.waitForTimeout(15000),
  ]);

  console.log('--- captured JSON responses ---');
  for (const j of jsonResponses) console.log(j.status, j.url, j.body);

  await page.waitForTimeout(1500);
  await browser.close();
  process.exit(0);
})().catch((e) => { console.error('ERR', e); process.exit(1); });
