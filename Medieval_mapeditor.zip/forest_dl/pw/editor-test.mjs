import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);

const S = 800 / 60;                       // px per world unit (draw cam)
const sx = x => 640 + x * S, sy = z => 400 + z * S;
const stats = () => page.locator('#stats').textContent();
const selInfo = () => page.evaluate(() => document.querySelector('#editorMenu span').textContent);

await page.click('#tabDraw');
await page.waitForTimeout(300);
console.log('menu visible:', await page.locator('#editorMenu').isVisible() ? 'YES' : 'NO');
console.log('btnFinish label:', await page.locator('#btnFinish').textContent());

// --- street A: 2 segments (x -20..24 at z=-6), finish with Enter ---
for (const [x, z] of [[-20, -6], [2, -6], [24, -6]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
// --- street B: 2 segments (x -18..24 at z=8), finish with the renamed button ---
for (const [x, z] of [[-18, 8], [4, 8], [24, 8]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.click('#btnFinish');
await page.waitForTimeout(300);
console.log('after 2 streets:', (await stats()).trim());

// --- select mode: tools appear ---
await page.click('#modeToggle');
await page.waitForTimeout(250);
console.log('tools visible:', await page.locator('#tool-seg').isVisible() ? 'YES' : 'NO');

// --- whole-line tool (default): select line 1, make it brown ---
await page.mouse.click(sx(-9), sy(-6));
await page.waitForTimeout(200);
console.log('line sel:', await selInfo());
await page.click('#color-brown');
await page.waitForTimeout(400);
console.log('after brown:', (await stats()).trim());

// --- segment tool: pick segment 2 of line 1, make it red ---
await page.click('#tool-seg');
await page.waitForTimeout(250);
await page.mouse.click(sx(13), sy(-6));
await page.waitForTimeout(200);
console.log('seg sel:', await selInfo());
await page.click('#color-red');
await page.waitForTimeout(400);
console.log('seg sel after red:', await selInfo());
console.log('after red seg:', (await stats()).trim());

// --- rectangle tool: marquee drag around all of line B -> green ---
await page.click('#tool-rect');
await page.waitForTimeout(250);
await page.mouse.move(sx(-20), sy(4));
await page.mouse.down();
await page.mouse.move(sx(26), sy(12), { steps: 8 });
console.log('marquee visible mid-drag:', await page.evaluate(() => document.getElementById('marquee').style.display));
await page.mouse.up();
await page.waitForTimeout(200);
console.log('rect sel:', await selInfo());
await page.click('#color-green');
await page.waitForTimeout(500);
console.log('after green rect:', (await stats()).trim());

// --- closed loop -> whole line -> green: fills the inside ---
await page.click('#modeToggle');          // back to draw
await page.waitForTimeout(250);
const loop = [[-12, 12], [16, 12], [16, 24], [-12, 24], [-12, 12]];
for (const [x, z] of loop) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(400);
await page.click('#modeToggle');          // select
await page.waitForTimeout(250);
await page.click('#tool-line');           // back to whole-line tool (rect was active)
await page.waitForTimeout(250);
await page.mouse.click(sx(2), sy(12));    // on the loop's top edge
await page.waitForTimeout(200);
console.log('loop sel:', await selInfo());
await page.click('#color-green');
await page.waitForTimeout(600);
console.log('after green loop:', (await stats()).trim());

// --- Escape clears the selection ---
await page.keyboard.press('Escape');
await page.waitForTimeout(150);
console.log('after Escape:', await selInfo());

await page.screenshot({ path: '/home/user/village/editor.png' });
console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
