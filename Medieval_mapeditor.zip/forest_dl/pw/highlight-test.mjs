import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);

const S = 800 / 60;
const sx = x => 640 + x * S, sy = z => 400 + z * S;
const selInfo = () => page.evaluate(() => document.querySelector('#editorMenu span').textContent);
const ed = () => page.evaluate(() => window.__editor());

await page.click('#tabDraw');
await page.waitForTimeout(300);
// two streets
for (const [x, z] of [[-20, -6], [0, -6], [20, -6]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter'); await page.waitForTimeout(300);
for (const [x, z] of [[-18, 8], [4, 8], [20, 8]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter'); await page.waitForTimeout(300);

// select mode, whole-line tool
await page.click('#modeToggle'); await page.waitForTimeout(250);
const kidsBase = (await ed()).overlayKids;

// 1) click street A (slightly off-center, like a human) -> highlight rails
await page.mouse.click(sx(-8.5), sy(-5.4));
await page.waitForTimeout(250);
let st = await ed();
console.log('1) line tool click ->', await selInfo(), '| extra meshes:', st.overlayKids - kidsBase, st.overlayKids > kidsBase ? '(HIGHLIGHT ✓)' : '(NO HIGHLIGHT!)');

// 2) segment tool click
await page.click('#tool-seg'); await page.waitForTimeout(200);
await page.mouse.click(sx(12), sy(-6));
await page.waitForTimeout(250);
st = await ed();
console.log('2) seg tool click  ->', await selInfo(), '| extra meshes:', st.overlayKids - kidsBase, st.overlayKids > kidsBase ? '(HIGHLIGHT ✓)' : '(NO HIGHLIGHT!)');

// 3) point tool: click directly on a point
await page.click('#tool-point'); await page.waitForTimeout(200);
await page.mouse.click(sx(0), sy(-6));
await page.waitForTimeout(250);
st = await ed();
console.log('3) point on node   ->', await selInfo(), '| selPoint:', JSON.stringify(st.selPoint), st.selPoint ? '(SELECTED ✓)' : '(NOT SELECTED!)');

// 4) point tool: click the MIDDLE of a street (no node there) -> nearest endpoint
await page.mouse.click(sx(12), sy(-6));
await page.waitForTimeout(250);
st = await ed();
console.log('4) point mid-street->', await selInfo(), '| selPoint:', JSON.stringify(st.selPoint), st.selPoint ? '(fallback ✓)' : '(NOTHING!)');

// 5) rect tool marquee -> highlight
await page.click('#tool-rect'); await page.waitForTimeout(200);
await page.mouse.move(sx(-22), sy(-9));
await page.mouse.down();
await page.mouse.move(sx(22), sy(-3), { steps: 6 });
await page.mouse.up();
await page.waitForTimeout(250);
st = await ed();
console.log('5) rect marquee    ->', await selInfo(), '| extra meshes:', st.overlayKids - kidsBase, st.overlayKids > kidsBase ? '(HIGHLIGHT ✓)' : '(NO HIGHLIGHT!)');

// 6) whole-line again for the screenshot (bold rails)
await page.click('#tool-line'); await page.waitForTimeout(200);
await page.mouse.click(sx(-8.5), sy(-5.4));
await page.waitForTimeout(250);
console.log('6) final           ->', await selInfo());
await page.screenshot({ path: '/home/user/village/highlight-shot.png' });

console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
