import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);

const S = 800 / 60;
const sx = x => 640 + x * S, sy = z => 400 + z * S;
const stats = () => page.locator('#stats').textContent();
const ed = () => page.evaluate(() => window.__editor());

/* sharpest (smallest) interior angle of a polyline in degrees */
function sharpest(pts) {
  let worst = 999;
  for (let i = 1; i < pts.length - 1; i++) {
    const [ax, az] = pts[i - 1], [bx, bz] = pts[i], [cx, cz] = pts[i + 1];
    const v1 = [ax - bx, az - bz], v2 = [cx - bx, cz - bz];
    const d = (v1[0] * v2[0] + v1[1] * v2[1]) / (Math.hypot(...v1) * Math.hypot(...v2));
    worst = Math.min(worst, Math.acos(Math.max(-1, Math.min(1, d))) * 180 / Math.PI);
  }
  return worst;
}

await page.click('#tabDraw');
await page.waitForTimeout(300);

// --- V-shaped street with a sharp corner at (0,-6) ---
for (const [x, z] of [[-10, -14], [0, -6], [10, -14]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
let st = await ed();
const before = sharpest(st.customStreets[0].points);
console.log('street points:', st.customStreets[0].points.length, '| sharpest angle:', before.toFixed(1) + '°');

// --- point tool + curve mode ---
await page.click('#modeToggle'); await page.waitForTimeout(200);
await page.click('#tool-point'); await page.waitForTimeout(200);
console.log('gizmo bar visible:', await page.evaluate(() => document.getElementById('gizmoBar').style.display));
await page.click('#gizmo-curve'); await page.waitForTimeout(200);
console.log('mode after click:', (await ed()).gizmoMode);

// select the corner point
await page.mouse.click(sx(0), sy(-6));
await page.waitForTimeout(200);
st = await ed();
console.log('selPoint:', JSON.stringify(st.selPoint), '| curve handle shown (via click next)');

/* max deviation from straight (180°) across interior vertices */
const maxDev = pts => 180 - sharpest(pts);

// click the curve arc -> one smoothing step per click (re-aimed each time,
// the gizmo follows the sharpest remaining joint of the corner region)
const clickSelPoint = async () => {
  const e2 = await ed();
  const [wx, wz] = e2.customStreets[e2.selPoint.s].points[e2.selPoint.p];
  await page.mouse.click(sx(wx), sy(wz));
  await page.waitForTimeout(400);
};
const dev0 = maxDev((await ed()).customStreets[0].points);
const n0 = (await ed()).customStreets[0].points.length;
for (let k = 1; k <= 3; k++) {
  await clickSelPoint();
  st = await ed();
  const p = st.customStreets[0].points;
  console.log(`click ${k}: points ${p.length} | max deviation: ${maxDev(p).toFixed(1)}°`);
}
st = await ed();
const devF = maxDev(st.customStreets[0].points);
const nF = st.customStreets[0].points.length;
console.log('smoothing verdict:', nF > n0 && devF < dev0 * 0.6
  ? `(points ${n0}→${nF}, deviation ${dev0.toFixed(1)}°→${devF.toFixed(1)}° ✓ SMOOTHER)`
  : '(NOT SMOOTHER!)');
console.log('village rebuilt:', (await stats()).trim());

// --- switch back to move mode: drag still works ---
await page.click('#gizmo-move'); await page.waitForTimeout(200);
await page.mouse.click(sx(-10), sy(-14)); await page.waitForTimeout(200);
await page.mouse.move(sx(-10), sy(-14));
await page.mouse.down();
await page.mouse.move(sx(-16), sy(-14), { steps: 5 });
await page.mouse.up();
await page.waitForTimeout(500);
st = await ed();
console.log('move mode after curve:', st.gizmoMode, '| p0:', JSON.stringify(st.customStreets[0].points[0]),
  Math.abs(st.customStreets[0].points[0][0] + 16) < 0.01 ? '(drag ✓)' : '(DRAG BROKEN!)');

// --- closed loop: curve-smooth a corner, stays closed, green still fills ---
await page.click('#modeToggle'); await page.waitForTimeout(200);
for (const [x, z] of [[-12, 10], [-2, 16], [8, 10]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.mouse.move(sx(-11.1), sy(9.1), { steps: 3 });
await page.waitForTimeout(100);
await page.mouse.click(sx(-11.1), sy(9.1));
await page.waitForTimeout(150);
await page.keyboard.press('Enter'); await page.waitForTimeout(350);
st = await ed();
const loopIdx = st.customStreets.length - 1;
const loopBefore = st.customStreets[loopIdx].points;
console.log('loop points:', loopBefore.length, '| closed:', Math.hypot(loopBefore[0][0] - loopBefore[loopBefore.length - 1][0], loopBefore[0][1] - loopBefore[loopBefore.length - 1][1]) < 0.01 ? 'yes' : 'no');

await page.click('#modeToggle'); await page.waitForTimeout(200);
await page.click('#tool-point'); await page.waitForTimeout(150);
await page.click('#gizmo-curve'); await page.waitForTimeout(150);
await page.mouse.click(sx(-12), sy(10));   // select loop corner (point 0)
await page.waitForTimeout(200);
st = await ed();
console.log('loop selPoint:', JSON.stringify(st.selPoint));
await page.mouse.click(sx(-12), sy(10));   // click the curve arc
await page.waitForTimeout(400);
st = await ed();
const lp = st.customStreets[loopIdx].points;
const stillClosed = Math.hypot(lp[0][0] - lp[lp.length - 1][0], lp[0][1] - lp[lp.length - 1][1]) < 0.01;
console.log('loop after curve: points', lp.length, '| closed:', stillClosed ? 'yes ✓' : 'NO!');

// green the loop -> foliage fill still works on the smoothed shape
await page.click('#tool-line'); await page.waitForTimeout(150);
await page.mouse.click(sx(-2), sy(16)); await page.waitForTimeout(150);
await page.click('#color-green'); await page.waitForTimeout(500);
console.log('green smoothed loop:', (await stats()).trim());

await page.screenshot({ path: '/home/user/village/curve-shot.png' });
console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
