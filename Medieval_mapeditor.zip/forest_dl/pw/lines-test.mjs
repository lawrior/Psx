import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);

const S = 800 / 60;
const sx = x => 640 + x * S, sy = z => 400 + z * S;
const stats = () => page.locator('#stats').textContent();
const selInfo = () => page.evaluate(() => document.querySelector('#editorMenu span').textContent);
const ed = () => page.evaluate(() => window.__editor());

await page.click('#tabDraw');
await page.waitForTimeout(300);

// --- draw street A: lines must SURVIVE Add street ---
for (const [x, z] of [[-20, -6], [0, -6], [20, -6]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
let st = await ed();
console.log('after Add street: overlay kids =', st.overlayKids, st.overlayKids > 0 ? '(lines kept ✓)' : '(LINES REMOVED!)');

// --- eye toggle OFF hides lines in draw mode ---
await page.click('#linesToggle');
await page.waitForTimeout(200);
st = await ed();
console.log('lines off (draw mode): overlay kids =', st.overlayKids, st.overlayKids === 0 ? '(hidden ✓)' : '(STILL VISIBLE!)');
// drawing still works with lines hidden
for (const [x, z] of [[-18, 8], [4, 8], [20, 8]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
st = await ed();
console.log('streets now:', st.customStreets.length, '| overlay kids still:', st.overlayKids);

// --- eye toggle ON brings them back ---
await page.click('#linesToggle');
await page.waitForTimeout(200);
st = await ed();
console.log('lines on again: overlay kids =', st.overlayKids, st.overlayKids > 0 ? '(visible ✓)' : '(HIDDEN!)');

// --- select mode: highlight rails appear around the selection ---
const kidsBefore = (await ed()).overlayKids;
await page.click('#modeToggle');
await page.waitForTimeout(250);
const kidsSelect = (await ed()).overlayKids;
await page.mouse.click(sx(-9), sy(-6));      // whole-line select street A
await page.waitForTimeout(250);
st = await ed();
const kidsSel = st.overlayKids;
console.log('select mode: kids', kidsBefore, '->', kidsSelect, '(guides) ->', kidsSel, 'after selecting Line 1');
console.log('selection info:', await selInfo(), '| highlight meshes added:', kidsSel - kidsSelect, kidsSel > kidsSelect ? '(highlight ✓)' : '(NO HIGHLIGHT!)');

// --- highlight disappears when deselected (Escape) ---
await page.keyboard.press('Escape');
await page.waitForTimeout(200);
st = await ed();
console.log('after Escape: kids =', st.overlayKids, '(back to guides)');

// --- back to draw mode: no stale highlight, lines visible ---
await page.click('#modeToggle');
await page.waitForTimeout(200);
st = await ed();
console.log('draw mode: kids =', st.overlayKids, '| selection empty:', st.selection.length === 0);

await page.screenshot({ path: '/home/user/village/lines-shot.png' });
console.log('stats:', (await stats()).trim());
console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
