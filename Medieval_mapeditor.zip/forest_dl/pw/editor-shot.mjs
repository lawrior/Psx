import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);
const S = 800/60, sx = x => 640 + x*S, sy = z => 400 + z*S;

await page.click('#tabDraw');
await page.waitForTimeout(300);
// poor (brown) street
for (const [x,z] of [[-20,-16],[2,-16],[20,-16]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(50); }
await page.keyboard.press('Enter'); await page.waitForTimeout(250);
// rich (red) street
for (const [x,z] of [[-20,-2],[2,-2],[20,-2]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(50); }
await page.keyboard.press('Enter'); await page.waitForTimeout(250);
// green foliage loop (snap-closed)
for (const [x,z] of [[-16,10],[14,10],[14,24],[-16,24]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(50); }
await page.mouse.move(sx(-15.1), sy(9.1), { steps: 4 });
await page.waitForTimeout(120);
await page.mouse.click(sx(-15.1), sy(9.1));
await page.waitForTimeout(150);
await page.keyboard.press('Enter'); await page.waitForTimeout(350);

// select mode: color the streets, then show the highlight rails on the loop
await page.click('#modeToggle'); await page.waitForTimeout(250);
await page.mouse.click(sx(-10), sy(-16)); await page.waitForTimeout(150);
await page.click('#color-brown'); await page.waitForTimeout(350);
await page.mouse.click(sx(-10), sy(-2)); await page.waitForTimeout(150);
await page.click('#color-red'); await page.waitForTimeout(350);
await page.mouse.click(sx(0), sy(10)); await page.waitForTimeout(200);
await page.click('#color-green'); await page.waitForTimeout(500);
// leave the whole loop selected -> rails visible around it
await page.screenshot({ path: '/home/user/village/editor.png' });
console.log('errors:', errors.join('\n') || '(none)');
console.log('stats:', (await page.locator('#stats').textContent()).trim());
await browser.close();
