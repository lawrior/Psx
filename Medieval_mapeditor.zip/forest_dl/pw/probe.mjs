import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(3500);
const S = 800 / 60, sx = x => 640 + x * S, sy = z => 400 + z * S;
const ed = () => page.evaluate(() => { const e = window.__editor(); return { mode: e.editorMode, tool: e.selTool, n: e.customStreets ? e.customStreets.length : 'null' }; });

await page.click('#tabDraw');
await page.waitForTimeout(200);
for (const [x, z] of [[-20, -6], [0, -6], [20, -6]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
console.log('after A:', await ed());

await page.click('#modeToggle'); await page.waitForTimeout(200);
await page.click('#tool-point'); await page.waitForTimeout(200);
await page.mouse.click(sx(-20), sy(-6)); await page.waitForTimeout(200);
console.log('point picked:', await ed());
await page.mouse.move(sx(-20), sy(-6));
await page.mouse.down();
await page.mouse.move(sx(-16), sy(-6), { steps: 6 });
await page.mouse.up();
await page.waitForTimeout(500);
console.log('after drag:', await ed());

await page.mouse.click(sx(20), sy(-6)); await page.waitForTimeout(200);
await page.mouse.move(sx(20), sy(-6));
await page.mouse.down();
await page.mouse.move(sx(20), sy(-2), { steps: 6 });
await page.mouse.up();
await page.waitForTimeout(500);
console.log('after xdrag:', await ed());

await page.click('#modeToggle'); await page.waitForTimeout(250);
console.log('after toggle:', await ed());
await page.mouse.click(sx(24), sy(8)); await page.waitForTimeout(120);
console.log('after click1:', await ed());
await page.mouse.click(sx(8), sy(8)); await page.waitForTimeout(120);
console.log('after click2:', await ed());
await page.keyboard.press('Enter'); await page.waitForTimeout(300);
console.log('after Enter:', await ed());
await browser.close();
