import { chromium } from 'playwright';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('console', m => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', e => errors.push('PAGEERROR: ' + e.message));

await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(4000);

const S = 800 / 60;
const sx = x => 640 + x * S, sy = z => 400 + z * S;
const stats = () => page.locator('#stats').textContent();
const selInfo = () => page.evaluate(() => document.querySelector('#editorMenu span').textContent);
const ed = () => page.evaluate(() => window.__editor());

await page.click('#tabDraw');
await page.waitForTimeout(300);

// menu compactness: single row, small fonts
const menuH = await page.evaluate(() => document.getElementById('editorMenu').getBoundingClientRect().height);
const toolFont = await page.evaluate(() => document.getElementById('tool-line').style.fontSize);
console.log('menu height:', menuH, '| tool font:', toolFont);

// --- street A ---
for (const [x, z] of [[-20, -6], [0, -6], [20, -6]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(60); }
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
console.log('after A:', (await stats()).trim());

// --- point tool: select point 1 of line A ---
await page.click('#modeToggle');
await page.waitForTimeout(200);
await page.click('#tool-point');
await page.waitForTimeout(200);
await page.mouse.click(sx(-20), sy(-6));
await page.waitForTimeout(200);
console.log('point sel:', await selInfo(), '| selPoint:', JSON.stringify((await ed()).selPoint));

// --- drag the gizmo center 4 units east: (-20,-6) -> (-16,-6) ---
await page.mouse.move(sx(-20), sy(-6));
await page.mouse.down();
await page.mouse.move(sx(-16), sy(-6), { steps: 6 });
await page.mouse.up();
await page.waitForTimeout(500);
const edAfterDrag = await ed();
console.log('point after drag:', JSON.stringify(edAfterDrag.customStreets[0].points[0]));
console.log('after move rebuild:', (await stats()).trim());

// --- axis-constrained drag: point 3 of line A along X only ---
await page.mouse.click(sx(20), sy(-6));
await page.waitForTimeout(200);
await page.mouse.move(sx(20), sy(-6));
await page.mouse.down();
await page.mouse.move(sx(20), sy(-2), { steps: 6 });   // mouse moves in Z, but X-arrow locks to X
await page.mouse.up();
await page.waitForTimeout(500);
const p3 = (await ed()).customStreets[0].points[2];
console.log('x-locked drag of point 3:', JSON.stringify(p3), Math.abs(p3[1] + 6) < 0.001 ? '(z locked OK)' : '(Z LEAKED!)');

// --- magnet snap while drawing: line B ends exactly on A's moved endpoint (20,-6) ---
await page.click('#modeToggle');   // back to draw
await page.waitForTimeout(200);
for (const [x, z] of [[24, 8], [8, 8]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(80); }
await page.mouse.move(sx(20.8), sy(-5.2), { steps: 4 });   // within snap radius of (20,-6)
await page.waitForTimeout(120);
await page.mouse.click(sx(20.8), sy(-5.2));
await page.waitForTimeout(150);
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
const bPts = (await ed()).customStreets[1].points;
console.log('B last point (snapped):', JSON.stringify(bPts[bPts.length - 1]));

// --- close a loop by snapping to its own first point, then green it ---
for (const [x, z] of [[-12, 14], [-2, 20], [8, 14]]) { await page.mouse.click(sx(x), sy(z)); await page.waitForTimeout(80); }
await page.mouse.move(sx(-11.1), sy(13.1), { steps: 4 });  // near C's own start point
await page.waitForTimeout(120);
await page.mouse.click(sx(-11.1), sy(13.1));
await page.waitForTimeout(150);
await page.keyboard.press('Enter');
await page.waitForTimeout(300);
const cPts = (await ed()).customStreets[2].points;
console.log('C points:', JSON.stringify(cPts));
const propsBefore = (await stats()).trim();
// whole-line select the loop -> green
await page.click('#modeToggle');
await page.waitForTimeout(200);
await page.click('#tool-line');
await page.waitForTimeout(150);
await page.mouse.click(sx(-2), sy(20));   // middle segment of C... use a point near an edge
await page.waitForTimeout(150);
console.log('loop sel:', await selInfo());
await page.click('#color-green');
await page.waitForTimeout(600);
console.log('before green:', propsBefore);
console.log('after green :', (await stats()).trim());

// --- Escape clears point/line selection ---
await page.keyboard.press('Escape');
await page.waitForTimeout(150);
console.log('after Escape:', await selInfo());

// --- screenshot: select a point to show the gizmo ---
await page.click('#tool-point');
await page.waitForTimeout(150);
await page.mouse.click(sx(-16), sy(-6));
await page.waitForTimeout(250);
await page.screenshot({ path: '/home/user/village/points-shot.png' });

console.log('ERRORS:', errors.length ? errors.join('\n') : '(none)');
await browser.close();
