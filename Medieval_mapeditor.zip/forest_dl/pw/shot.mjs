import { chromium } from 'playwright';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', e => errors.push(e.message));
await page.goto('http://127.0.0.1:8017/', { waitUntil: 'load' });
await page.waitForTimeout(6000);  // textures + first frames

// orbit: raise the camera and pull back to frame the village + forest ring
const cx = 640, cy = 400;
await page.mouse.move(cx, cy);
await page.mouse.down();
await page.mouse.move(cx, cy + 260, { steps: 20 });  // tilt up
await page.mouse.move(cx - 320, cy + 260, { steps: 20 });
await page.mouse.up();
// zoom out
for (let i = 0; i < 14; i++) await page.mouse.wheel(0, -120);
await page.waitForTimeout(800);

await page.screenshot({ path: '/home/user/village/village-forest.png' });
console.log('errors:', errors.join('\n') || '(none)');
await browser.close();
