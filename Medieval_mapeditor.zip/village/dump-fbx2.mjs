import * as THREE from 'three';
import { readFileSync } from 'fs';

if (typeof globalThis.window === 'undefined') globalThis.window = globalThis;
if (typeof globalThis.self === 'undefined') globalThis.self = globalThis;
if (!globalThis.navigator) globalThis.navigator = { userAgent: 'node' };
if (!globalThis.atob) globalThis.atob = (s) => Buffer.from(s, 'base64').toString('binary');
if (!globalThis.btoa) globalThis.btoa = (s) => Buffer.from(s, 'binary').toString('base64');
if (!globalThis.Blob) globalThis.Blob = class { constructor(parts, opts) { this.parts = parts; this.type = opts && opts.type; } };
if (!globalThis.URL) globalThis.URL = { createObjectURL: () => '' };
if (!globalThis.document) {
  function fakeEl() {
    return { src: '', onload: null, onerror: null, width: 0, height: 0, getContext: () => null, style: {}, setAttribute() {}, getAttribute() { return null; }, addEventListener() {}, removeEventListener() {}, crossOrigin: '' };
  }
  globalThis.document = { createElement: () => fakeEl(), createElementNS: (_ns, n) => fakeEl() };
}

const { FBXLoader } = await import('three/examples/jsm/loaders/FBXLoader.js');
const buf = readFileSync('/home/user/forest_dl/extracted/PSX_Forest_Level_byStarkCrafts/PSX_Forest_AssetCollection_byStarkCrafts.fbx');
const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
const loader = new FBXLoader();
const scene = loader.parse(ab, '');

function describeMat(m) {
  if (!m) return 'null';
  const parts = [];
  parts.push(m.type);
  if (m.color) parts.push('color=#' + m.color.getHexString());
  if (m.map) {
    const img = m.map.image;
    let src = '?';
    if (img && img.src) src = String(img.src).slice(0, 40);
    parts.push('map(src=' + src + ', name=' + (m.map.name || '') + ')');
  } else {
    parts.push('no-map');
  }
  if (m.alphaTest) parts.push('alphaTest=' + m.alphaTest);
  if (m.transparent) parts.push('transparent');
  if (m.side !== undefined && m.side !== THREE.FrontSide) parts.push('side=' + m.side);
  return parts.join(' | ');
}

for (const o of scene.children) {
  if (!o.isMesh) continue;
  const g = o.geometry;
  const attrs = Object.keys(g.attributes).join(',');
  const mats = Array.isArray(o.material) ? o.material : [o.material];
  console.log('==', o.name, '==');
  console.log('  attrs:', attrs);
  console.log('  groups:', g.groups.length, g.groups.map(gr => `[${gr.start}..${gr.start + gr.count}] mat=${gr.materialIndex}`).join(' '));
  mats.forEach((m, i) => console.log(`  mat[${i}]`, describeMat(m)));
  // vertex color presence
  const c = g.attributes.color;
  if (c) {
    let min = 1e9, max = -1e9;
    for (let i = 0; i < c.count; i++) { const v = c.getX(i); min = Math.min(min, v); max = Math.max(max, v); }
    console.log('  vertex color range:', min, '-', max);
  }
}
