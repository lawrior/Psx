// Detects coplanar, overlapping triangle pairs inside each building —
// the exact geometric condition that causes z-fighting.
import * as THREE from 'three';
import { makeHouse, houseParams, mulberry32, buildVillage } from './village.js';

function collectTriangles(group) {
  group.updateMatrixWorld(true);
  const tris = [];
  group.traverse(o => {
    if (!o.isMesh) return;
    const geom = o.geometry;
    const pos = geom.getAttribute('position');
    if (!pos) return;
    const idx = geom.getIndex();
    const m = o.matrixWorld;
    const v = new THREE.Vector3();
    const get = (i) => {
      v.fromBufferAttribute(pos, i).applyMatrix4(m);
      return { x: v.x, y: v.y, z: v.z };
    };
    const n = idx ? idx.count : pos.count;
    for (let k = 0; k < n; k += 3) {
      tris.push([get(idx ? idx.getX(k) : k), get(idx ? idx.getX(k + 1) : k + 1), get(idx ? idx.getX(k + 2) : k + 2)]);
    }
  });
  return tris;
}

function normalOf(t) {
  const ux = t[1].x - t[0].x, uy = t[1].y - t[0].y, uz = t[1].z - t[0].z;
  const vx = t[2].x - t[0].x, vy = t[2].y - t[0].y, vz = t[2].z - t[0].z;
  const nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
  const l = Math.hypot(nx, ny, nz);
  return l < 1e-12 ? null : { x: nx / l, y: ny / l, z: nz / l };
}
function norm(a) { const l = Math.hypot(a.x, a.y, a.z); return l < 1e-9 ? null : { x: a.x / l, y: a.y / l, z: a.z / l }; }
function cross(a, b) { return { x: a.y * b.z - a.z * b.y, y: a.z * b.x - a.x * b.z, z: a.x * b.y - a.y * b.x }; }
function dot3(p, a) { return p.x * a.x + p.y * a.y + p.z * a.z; }

/* 2D triangle-triangle overlap via separating axis, projected onto (u,v) */
function overlap2D(t1, t2, u, v) {
  const proj = (t) => t.map(p => ({ x: dot3(p, u), y: dot3(p, v) }));
  const P1 = proj(t1), P2 = proj(t2);
  const axes = [];
  for (const T of [P1, P2]) for (let i = 0; i < 3; i++) {
    const a = T[i], b = T[(i + 1) % 3];
    axes.push({ x: -(b.y - a.y), y: b.x - a.x });
  }
  for (const ax of axes) {
    let mn1 = Infinity, mx1 = -Infinity, mn2 = Infinity, mx2 = -Infinity;
    for (const p of P1) { const d = p.x * ax.x + p.y * ax.y; mn1 = Math.min(mn1, d); mx1 = Math.max(mx1, d); }
    for (const p of P2) { const d = p.x * ax.x + p.y * ax.y; mn2 = Math.min(mn2, d); mx2 = Math.max(mx2, d); }
    // require real area overlap (not just touching along an edge)
    if (mx1 - mn2 < 0.006 || mx2 - mn1 < 0.006) return false;
  }
  return true;
}

function countCoplanarOverlaps(group) {
  const tris = collectTriangles(group);
  const planes = new Map();
  for (const t of tris) {
    const n = normalOf(t);
    if (!n) continue;
    const d = n.x * t[0].x + n.y * t[0].y + n.z * t[0].z;
    const key = `${Math.round(n.x * 1000)},${Math.round(n.y * 1000)},${Math.round(n.z * 1000)},${Math.round(d * 1000)}`;
    if (!planes.has(key)) planes.set(key, []);
    planes.get(key).push(t);
  }
  let bad = 0;
  for (const list of planes.values()) {
    if (list.length < 2) continue;
    for (let i = 0; i < list.length; i++) {
      for (let j = i + 1; j < list.length; j++) {
        const t1 = list[i], t2 = list[j];
        const n = normalOf(t1);
        const u = norm({ x: t1[1].x - t1[0].x, y: t1[1].y - t1[0].y, z: t1[1].z - t1[0].z });
        if (!u) continue;
        const v = cross(n, u);
        if (overlap2D(t1, t2, u, v)) bad++;
      }
    }
  }
  return { triangles: tris.length, bad };
}

const types = ['hut', 'cottage', 'townhouse', 'stonehouse', 'barn', 'tavern', 'smithy', 'church', 'tower'];
let total = 0;
for (const type of types) {
  const r = mulberry32(42);
  const p = houseParams(type, r);
  const g = makeHouse(p, r);
  const res = countCoplanarOverlaps(g);
  total += res.bad;
  console.log(`${type.padEnd(11)} tris=${String(res.triangles).padStart(4)} coplanar-overlaps=${res.bad}`);
}

// whole default village (heuristic building detection)
{
  const { world } = buildVillage(2);
  let bldBad = 0, n = 0;
  world.traverse(o => {
    if (!o.isGroup) return;
    let meshes = 0;
    o.traverse(m => { if (m.isMesh) meshes++; });
    if (meshes > 20 && Math.abs(o.position.x) < 90) {
      const res = countCoplanarOverlaps(o);
      bldBad += res.bad; n++;
    }
  });
  console.log(`default village: ${n} buildings checked, coplanar-overlaps=${bldBad}`);
  total += bldBad;
}
console.log(total === 0 ? 'CLEAN — no coplanar overlaps' : `FOUND ${total} coplanar overlaps`);
