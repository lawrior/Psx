import * as THREE from 'three';
import { readFileSync, writeFileSync, readdirSync } from 'fs';

// --- browser polyfills for FBXLoader in Node ---
const capturedBlobs = [];
if (typeof globalThis.window === 'undefined') globalThis.window = globalThis;
if (typeof globalThis.self === 'undefined') globalThis.self = globalThis;
if (!globalThis.navigator) globalThis.navigator = { userAgent: 'node' };
if (!globalThis.atob) globalThis.atob = (s) => Buffer.from(s, 'base64').toString('binary');
if (!globalThis.btoa) globalThis.btoa = (s) => Buffer.from(s, 'binary').toString('base64');
// Node already has native Blob/URL — override unconditionally so we can capture
// the embedded texture bytes that FBXLoader turns into object URLs.
globalThis.Blob = class { constructor(parts, opts) { this.parts = parts; this.type = opts && opts.type; } };
globalThis.URL = { createObjectURL: (blob) => { capturedBlobs.push(blob); return 'blob:' + (capturedBlobs.length - 1); } };
if (!globalThis.document) {
  function fakeEl() {
    const listeners = {};
    const el = {
      style: {}, crossOrigin: '', width: 0, height: 0,
      getContext: () => null,
      setAttribute() {}, getAttribute() { return null; },
      addEventListener(ev, fn) { (listeners[ev] = listeners[ev] || []).push(fn); },
      removeEventListener() {},
      _src: '',
    };
    Object.defineProperty(el, 'src', {
      set(v) { el._src = v; (listeners['load'] || []).forEach(fn => fn.call(el)); },
      get() { return el._src; },
    });
    return el;
  }
  globalThis.document = { createElement: () => fakeEl(), createElementNS: (_ns, n) => fakeEl() };
}

const { FBXLoader } = await import('three/examples/jsm/loaders/FBXLoader.js');

const FBX_PATH = '/home/user/forest_dl/extracted/PSX_Forest_Level_byStarkCrafts/PSX_Forest_AssetCollection_byStarkCrafts.fbx';
const TEX_DIR = '/home/user/village/assets/forest';
const OUT = '/home/user/village/forest-assets.js';

// target heights (world units) per asset kind
const KIND = {
  'PSX_Tree1': { kind: 'tree', h: 7.5 },
  'PSX_Tree2': { kind: 'tree', h: 7.5 },
  'PSX_Tree3': { kind: 'tree', h: 7.5 },
  'PSX_Tree4': { kind: 'tree', h: 7.5 },
  'PSX_Treetrunk': { kind: 'tree', h: 4.6 },
  'PSX_Rock': { kind: 'rock', h: 1.5 },
  'PSX_Grass': { kind: 'foliage', h: 1.0 },
  'PSX_Reed': { kind: 'foliage', h: 1.9 },
  'PSX_Dandelion': { kind: 'foliage', h: 0.8 },
  'PSX_Lavender_': { kind: 'foliage', h: 0.9 },
  'PSX_PineConre': { kind: 'foliage', h: 0.45 },
};

// ---- 1. saved png bytes for matching ----
const pngFiles = readdirSync(TEX_DIR).filter(f => f.endsWith('.png')).sort();
const pngBytes = pngFiles.map(f => readFileSync(`${TEX_DIR}/${f}`));

function blobToBytes(blob) {
  const parts = blob.parts;
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = Buffer.alloc(total);
  let off = 0;
  for (const p of parts) { Buffer.from(p).copy(out, off); off += p.length; }
  return out;
}
function matchPng(bytes) {
  for (let i = 0; i < pngBytes.length; i++) {
    if (pngBytes[i].length === bytes.length && pngBytes[i].equals(bytes)) return i;
  }
  return -1;
}

// ---- 2. parse ----
const buf = readFileSync(FBX_PATH);
const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
const loader = new FBXLoader();
const scene = loader.parse(ab, '');

// ---- 3. material table (dedupe, map texture by captured blob bytes) ----
const materialDefs = [];
const materialIndexByKey = new Map();

function registerMaterial(m) {
  let src = '';
  let texFile = null;
  if (m.map && m.map.image) {
    src = String(m.map.image.src || '');
    if (src.startsWith('blob:')) {
      const idx = parseInt(src.slice(5), 10);
      if (!isNaN(idx) && capturedBlobs[idx]) {
        const bytes = blobToBytes(capturedBlobs[idx]);
        const pngIdx = matchPng(bytes);
        texFile = pngIdx >= 0 ? `assets/forest/${pngFiles[pngIdx]}` : null;
      }
    } else if (src.startsWith('data:')) {
      const comma = src.indexOf(',');
      const bytes = Buffer.from(src.slice(comma + 1), 'base64');
      const pngIdx = matchPng(bytes);
      texFile = pngIdx >= 0 ? `assets/forest/${pngFiles[pngIdx]}` : null;
    }
  }
  const key = `${texFile}|${m.color ? m.color.getHexString() : 'cccccc'}|${m.transparent ? 1 : 0}|${m.side || 0}|${m.alphaTest || 0}`;
  if (materialIndexByKey.has(key)) return materialIndexByKey.get(key);
  const def = {
    tex: texFile,
    color: m.color ? '#' + m.color.getHexString() : '#cccccc',
    transparent: !!m.transparent,
    side: m.side || 0,
    alphaTest: m.alphaTest || 0,
  };
  const i = materialDefs.length;
  materialDefs.push(def);
  materialIndexByKey.set(key, i);
  return i;
}

// ---- 4. bake geometry (normalized height, base at y=0, centered) ----
const assets = [];

for (const o of scene.children) {
  if (!o.isMesh) continue;
  const geo = o.geometry;
  const pos = geo.attributes.position;
  const nor = geo.attributes.normal;
  const uv = geo.attributes.uv;
  const index = geo.index;
  const kd = KIND[o.name] || { kind: 'foliage', h: 1.0 };
  const targetH = kd.h;

  // rotation only, to measure natural size & orientation
  const R = new THREE.Matrix4().makeRotationFromQuaternion(o.quaternion.clone());
  const nrm = new THREE.Matrix3().getNormalMatrix(R);

  // measure natural bbox under rotation
  const box = new THREE.Box3();
  const tv = new THREE.Vector3();
  for (let i = 0; i < pos.count; i++) {
    tv.fromBufferAttribute(pos, i).applyMatrix4(R);
    box.expandByPoint(tv);
  }
  const naturalH = Math.max(1e-6, box.max.y - box.min.y);
  const s = targetH / naturalH;
  const cx = (box.min.x + box.max.x) / 2;
  const cz = (box.min.z + box.max.z) / 2;
  const minY = box.min.y;

  // final transform: p' = T(-s*cx, -s*minY, -s*cz) * S(s) * R * p
  // (translations must be applied in the scaled frame)
  const M = new THREE.Matrix4().makeTranslation(-cx * s, -minY * s, -cz * s)
    .multiply(new THREE.Matrix4().makeScale(s, s, s))
    .multiply(R);

  const groups = [];
  const applyGroup = (start, count, matIndex) => {
    const P = [], N = [], U = [];
    const v0 = new THREE.Vector3(), v1 = new THREE.Vector3(), v2 = new THREE.Vector3();
    const n0 = new THREE.Vector3(), n1 = new THREE.Vector3(), n2 = new THREE.Vector3();
    for (let i = start; i < start + count; i += 3) {
      const a = index ? index.getX(i) : i;
      const b = index ? index.getX(i + 1) : i + 1;
      const c = index ? index.getX(i + 2) : i + 2;
      v0.fromBufferAttribute(pos, a).applyMatrix4(M);
      v1.fromBufferAttribute(pos, b).applyMatrix4(M);
      v2.fromBufferAttribute(pos, c).applyMatrix4(M);
      if (nor) {
        n0.fromBufferAttribute(nor, a).applyMatrix3(nrm).normalize();
        n1.fromBufferAttribute(nor, b).applyMatrix3(nrm).normalize();
        n2.fromBufferAttribute(nor, c).applyMatrix3(nrm).normalize();
      } else { n0.set(0, 1, 0); n1.set(0, 1, 0); n2.set(0, 1, 0); }
      for (const p of [v0, v1, v2]) P.push(p.x, p.y, p.z);
      for (const nn of [n0, n1, n2]) N.push(nn.x, nn.y, nn.z);
      if (uv) {
        U.push(uv.getX(a), uv.getY(a), uv.getX(b), uv.getY(b), uv.getX(c), uv.getY(c));
      }
    }
    groups.push({ pos: P, nor: N, uv: U, mat: matIndex, tris: (count / 3) | 0 });
  };

  const mats = Array.isArray(o.material) ? o.material : [o.material];
  if (geo.groups.length) {
    for (const gr of geo.groups) {
      const matIndex = registerMaterial(mats[gr.materialIndex]);
      applyGroup(gr.start, gr.count, matIndex);
    }
  } else {
    const matIndex = registerMaterial(mats[0]);
    applyGroup(0, index ? index.count : pos.count, matIndex);
  }

  // ground-footprint radius: max horizontal extent of base
  let r2max = 0;
  for (let i = 0; i < groups[0].pos.length; i += 3) {
    const x = groups[0].pos[i], z = groups[0].pos[i + 2];
    r2max = Math.max(r2max, x * x + z * z);
  }
  assets.push({
    name: o.name, kind: kd.kind, height: targetH,
    radius: +Math.sqrt(r2max).toFixed(3),
    groups,
  });
  console.log(`${o.name}: kind=${kd.kind} naturalH=${naturalH.toFixed(2)} -> target=${targetH} radius=${Math.sqrt(r2max).toFixed(2)}`);
}

// ---- 5. serialize ----
function b64(f32) {
  return Buffer.from(new Float32Array(f32).buffer).toString('base64');
}
const outAssets = assets.map(a => ({
  name: a.name, kind: a.kind, height: a.height, radius: a.radius,
  groups: a.groups.map(g => ({
    pos: b64(g.pos), nor: b64(g.nor), uv: g.uv.length ? b64(g.uv) : '', mat: g.mat, tris: g.tris,
  })),
}));

const js = `// Auto-generated from Stark Crafts PSX Forest Asset Collection (FBX bake).
// Regenerate with: node bake-forest.mjs
// Raw triangle geometry + material table. Textures live in assets/forest/.
export const FOREST_MATERIALS = ${JSON.stringify(materialDefs, null, 1)};

export const FOREST_ASSETS = ${JSON.stringify(outAssets)};

export function decodeF32(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Float32Array(bytes.buffer);
}
`;

writeFileSync(OUT, js);
console.log('---');
console.log('materials:');
materialDefs.forEach((m, i) => console.log(`  ${i}: ${m.tex ? m.tex.split('/').pop() : 'NO-TEX'}${m.transparent ? ' (transparent)' : ''} side=${m.side} alphaTest=${m.alphaTest}`));
console.log('wrote', OUT, js.length, 'bytes');
