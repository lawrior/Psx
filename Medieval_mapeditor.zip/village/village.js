/*
 * Procedural Medieval Village — modular asset generator (Three.js)
 *
 * Everything is built from a small set of snap-together modular parts:
 *   - stone foundation plinth
 *   - half-timbered wall frames (sill / top-plate / corner posts / studs / braces)
 *   - gable end walls with triangular tops
 *   - two-pitch roofs (ridge, slopes, bargeboards, ridge cap)
 *   - doors, windows, shutters, chimneys
 * These parts share one consistent unit system (metres) and common
 * reference planes so they always fit together correctly.
 */
import * as THREE from 'three';
import { FOREST_ASSETS, FOREST_MATERIALS, decodeF32 } from './forest-assets.js';

/* Stark Crafts forest textures load once; the same Texture objects are
   reused across rebuilds, so they swap in automatically once decoded. */
const FOREST_TEXTURES = {};
if (typeof document !== 'undefined') {
  const texLoader = new THREE.TextureLoader();
  for (const m of FOREST_MATERIALS) {
    if (m.tex && !(m.tex in FOREST_TEXTURES)) FOREST_TEXTURES[m.tex] = texLoader.load(m.tex);
  }
}

/* ------------------------------------------------------------------ */
/* 1. RNG                                                              */
/* ------------------------------------------------------------------ */
export function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* ------------------------------------------------------------------ */
/* 2. Canvas textures (procedural, no external files)                  */
/* ------------------------------------------------------------------ */
const noopCtx = new Proxy({}, { get: () => () => {}, set: () => true });

function makeCanvas(w, h) {
  if (typeof document === 'undefined') {
    return { width: w, height: h, getContext: () => noopCtx };
  }
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  return c;
}

const HAS_REAL_CANVAS = typeof document !== 'undefined' && typeof document.createElement === 'function';

/* ------------------------------------------------------------------ */
/* PSX helpers — ordered dithering + palette quantization              */
/* ------------------------------------------------------------------ */
const BAYER4 = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]];

/* snap every pixel to a `levels`-per-channel palette (32 = PS1 15-bit)
   using a 4x4 Bayer matrix, which produces the classic dithered banding */
function quantizeCanvas(c, levels = 32, dither = 1.0) {
  if (!HAS_REAL_CANVAS) return;
  const ctx = c.getContext('2d');
  const img = ctx.getImageData(0, 0, c.width, c.height);
  const d = img.data;
  for (let y = 0; y < c.height; y++) {
    for (let x = 0; x < c.width; x++) {
      const i = (y * c.width + x) * 4;
      const b = BAYER4[y % 4][x % 4] / 16 - 0.5;
      for (let ch = 0; ch < 3; ch++) {
        const v = d[i + ch] / 255;
        const q = Math.max(0, Math.min(levels - 1, Math.round(v * (levels - 1) + b * dither)));
        d[i + ch] = Math.round((q / (levels - 1)) * 255);
      }
    }
  }
  ctx.putImageData(img, 0, 0);
}

function finalizeTexture(t, psx) {
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  if (psx) {
    /* PS1 style: nearest sampling, no mipmaps → shimmering texels */
    t.magFilter = THREE.NearestFilter;
    t.minFilter = THREE.NearestFilter;
    t.generateMipmaps = false;
    t.anisotropy = 1;
  } else {
    t.magFilter = THREE.LinearFilter;
    t.minFilter = THREE.LinearMipmapLinearFilter;
    t.generateMipmaps = true;
    t.anisotropy = 4;
  }
  return t;
}

function canvasTexture(size, painter, psx = false, levels = 32) {
  const c = makeCanvas(size, size);
  const ctx = c.getContext('2d');
  painter(ctx, size);
  if (psx) quantizeCanvas(c, levels);
  return finalizeTexture(new THREE.CanvasTexture(c), psx);
}

function speckle(ctx, size, count, colors, alpha = 0.12) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[(Math.random() * colors.length) | 0];
    ctx.globalAlpha = alpha * (0.4 + Math.random() * 0.6);
    const s = 1 + Math.random() * 2.5;
    ctx.fillRect(Math.random() * size, Math.random() * size, s, s);
  }
  ctx.globalAlpha = 1;
}

/* 1-pixel speckle for low-res PSX textures */
function psxSpeckle(ctx, size, count, colors) {
  for (let i = 0; i < count; i++) {
    ctx.fillStyle = colors[(Math.random() * colors.length) | 0];
    ctx.fillRect((Math.random() * size) | 0, (Math.random() * size) | 0, 1, 1);
  }
}

const TEX = {};

/* ----- modern (high-res) painters ----- */
function makeModernTextures() {
  // plaster — warm off-white with stains + faint horizontal joints
  TEX.plaster = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#e7ddc4'; ctx.fillRect(0, 0, s, s);
    speckle(ctx, s, 900, ['#d8ccae', '#efe8d2', '#cbbfa0'], 0.16);
    ctx.strokeStyle = 'rgba(150,135,100,0.10)';
    for (let y = 0; y < s; y += 32) { ctx.beginPath(); ctx.moveTo(0, y + 0.5); ctx.lineTo(s, y + 0.5); ctx.stroke(); }
  });
  TEX.timber = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#6a4a2c'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 40; i++) {
      const x = Math.random() * s;
      ctx.strokeStyle = Math.random() < 0.5 ? 'rgba(40,24,10,0.35)' : 'rgba(150,110,70,0.25)';
      ctx.lineWidth = 0.8 + Math.random() * 1.6;
      ctx.beginPath(); ctx.moveTo(x, 0);
      ctx.bezierCurveTo(x + (Math.random() * 8 - 4), s / 3, x + (Math.random() * 8 - 4), 2 * s / 3, x + (Math.random() * 6 - 3), s);
      ctx.stroke();
    }
    speckle(ctx, s, 400, ['#54371f', '#7c5a38'], 0.12);
  });
  TEX.timberDark = canvasTexture(128, (ctx, s) => {
    ctx.fillStyle = '#4a3018'; ctx.fillRect(0, 0, s, s);
    speckle(ctx, s, 300, ['#39240f', '#5c3d20'], 0.2);
  });
  TEX.door = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#5b3b22'; ctx.fillRect(0, 0, s, s);
    for (let x = 0; x < s; x += 64) {
      ctx.fillStyle = 'rgba(0,0,0,0.25)'; ctx.fillRect(x - 2, 0, 4, s);
      ctx.fillStyle = Math.random() < 0.5 ? 'rgba(90,60,35,0.3)' : 'rgba(160,120,80,0.2)';
      ctx.fillRect(x + 8, 0, 44, s);
    }
    speckle(ctx, s, 300, ['#3f2812', '#6d4a28'], 0.15);
  });
  TEX.thatch = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#c8a15c'; ctx.fillRect(0, 0, s, s);
    for (let y = 0; y < s; y += 5) {
      ctx.strokeStyle = Math.random() < 0.5 ? 'rgba(90,65,25,0.25)' : 'rgba(235,205,150,0.3)';
      ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(0, y + Math.random() * 3);
      ctx.lineTo(s, y + Math.random() * 3); ctx.stroke();
    }
    speckle(ctx, s, 500, ['#9c7a3e', '#e0c188'], 0.18);
  });
  TEX.shingle = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#8a4b32'; ctx.fillRect(0, 0, s, s);
    const rowH = 26;
    for (let row = 0; row < s / rowH; row++) {
      const off = (row % 2) * 32;
      for (let x = -64; x < s + 64; x += 64) {
        ctx.fillStyle = ['#9a5638', '#7d4129', '#a5623f', '#74402b'][(Math.random() * 4) | 0];
        const y = row * rowH;
        roundRect(ctx, x + off + 4, y + 3, 56, rowH - 5, 7); ctx.fill();
      }
    }
  });
  TEX.slate = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#6e7075'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 140; i++) {
      ctx.fillStyle = ['#7c7f85', '#5f6166', '#85878d', '#66686d'][(Math.random() * 4) | 0];
      const x = Math.random() * s, y = Math.random() * s;
      ctx.fillRect(x, y, 22 + Math.random() * 18, 14 + Math.random() * 10);
    }
    speckle(ctx, s, 200, ['#55565b', '#84868c'], 0.15);
  });
  TEX.stone = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#8f8f86'; ctx.fillRect(0, 0, s, s);
    const rows = 8, rh = s / rows;
    for (let r = 0; r < rows; r++) {
      const off = (r % 2) * 0.5;
      let x = -0.5;
      while (x < s) {
        const bw = 50 + Math.random() * 40;
        ctx.fillStyle = ['#9a9a90', '#86867d', '#a4a499', '#7d7d74'][(Math.random() * 4) | 0];
        ctx.fillRect(x + off * 40 + 2, r * rh + 2, bw - 2, rh - 4);
        x += bw;
      }
    }
    speckle(ctx, s, 400, ['#6f6f66', '#a9a99e'], 0.14);
  });
  TEX.cobble = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#8b8b81'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 90; i++) {
      ctx.fillStyle = ['#96968b', '#7e7e74', '#a09f94', '#85857b'][(Math.random() * 4) | 0];
      const x = Math.random() * s, y = Math.random() * s, r = 12 + Math.random() * 15;
      ctx.beginPath(); ctx.ellipse(x, y, r, r * (0.6 + Math.random() * 0.5), Math.random() * 3.14, 0, 6.29); ctx.fill();
    }
  });
  TEX.grass = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#7fae58'; ctx.fillRect(0, 0, s, s);
    speckle(ctx, s, 1600, ['#6f9c4c', '#8fbf66', '#5e8a41'], 0.2);
  });
  TEX.dirt = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#9c7f58'; ctx.fillRect(0, 0, s, s);
    speckle(ctx, s, 1200, ['#8a6f4b', '#b08f63', '#7a6040'], 0.22);
  });
  TEX.stripes = canvasTexture(256, (ctx, s) => {
    ctx.fillStyle = '#c8433c'; ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#f2ead8';
    for (let x = 0; x < s; x += 64) ctx.fillRect(x, 0, 32, s);
  });
}

/* ----- PSX painters: chunky low-res pixel art, then 15-bit quantized ----- */
function makePSXTextures() {
  TEX.plaster = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#e6dcc3'; ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#c7bc9f';
    for (let y = 16; y < s; y += 16) ctx.fillRect(0, y, s, 1);
    psxSpeckle(ctx, s, 120, ['#d6cba8', '#efe6cd', '#c3b894']);
  }, true);
  TEX.timber = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#6b4a2b'; ctx.fillRect(0, 0, s, s);
    for (let i = 0; i < 34; i++) {
      ctx.fillStyle = ['#4a3018', '#7c5a38', '#5c3d20'][(Math.random() * 3) | 0];
      ctx.fillRect((Math.random() * s) | 0, 0, 1 + ((Math.random() * 2) | 0), s);
    }
    psxSpeckle(ctx, s, 80, ['#54371f', '#7c5a38']);
  }, true);
  TEX.timberDark = canvasTexture(32, (ctx, s) => {
    ctx.fillStyle = '#4a3018'; ctx.fillRect(0, 0, s, s);
    psxSpeckle(ctx, s, 60, ['#39240f', '#5c3d20']);
  }, true);
  TEX.door = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#5b3b22'; ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#3f2812';
    for (let x = 0; x < s; x += 16) ctx.fillRect(x, 0, 2, s);
    ctx.fillStyle = '#6d4a28';
    for (let x = 4; x < s; x += 16) ctx.fillRect(x, 0, 10, s);
    psxSpeckle(ctx, s, 60, ['#4a3018', '#7a5430']);
  }, true);
  TEX.thatch = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#c8a15c'; ctx.fillRect(0, 0, s, s);
    for (let y = 0; y < s; y += 4) {
      ctx.fillStyle = ['#9c7a3e', '#e0c188', '#b08a4a'][(Math.random() * 3) | 0];
      ctx.fillRect(0, y, s, 2);
    }
    psxSpeckle(ctx, s, 80, ['#8f6f36', '#d9b878']);
  }, true);
  TEX.shingle = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#6e3f2a'; ctx.fillRect(0, 0, s, s);
    const rowH = 16;
    for (let row = 0; row < s / rowH; row++) {
      const off = (row % 2) * 16;
      for (let x = -16; x < s + 16; x += 32) {
        ctx.fillStyle = ['#9a5638', '#7d4129', '#a5623f', '#74402b'][(Math.random() * 4) | 0];
        ctx.fillRect(x + off + 2, row * rowH + 2, 28, rowH - 4);
      }
    }
  }, true);
  TEX.slate = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#57595e'; ctx.fillRect(0, 0, s, s);
    const cols = ['#7c7f85', '#5f6166', '#85878d', '#66686d'];
    for (let y = 0; y < s; y += 16) {
      for (let x = 0; x < s; x += 16) {
        ctx.fillStyle = cols[(Math.random() * 4) | 0];
        ctx.fillRect(x + 1, y + 1, 14, 14);
      }
    }
  }, true);
  TEX.stone = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#6f6f66'; ctx.fillRect(0, 0, s, s);
    const cols = ['#9a9a90', '#86867d', '#a4a499', '#7d7d74'];
    const bh = 16;
    for (let row = 0; row < s / bh; row++) {
      const off = (row % 2) * 16;
      for (let x = -16; x < s + 16; x += 32) {
        ctx.fillStyle = cols[(Math.random() * 4) | 0];
        ctx.fillRect(x + off + 1, row * bh + 1, 30, bh - 2);
      }
    }
  }, true);
  TEX.cobble = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#7e7e74'; ctx.fillRect(0, 0, s, s);
    const cols = ['#96968b', '#8b8b81', '#a09f94', '#85857b'];
    for (let i = 0; i < 30; i++) {
      ctx.fillStyle = cols[(Math.random() * 4) | 0];
      const x = (Math.random() * s) | 0, y = (Math.random() * s) | 0;
      ctx.beginPath();
      ctx.ellipse(x, y, 5 + Math.random() * 5, 4 + Math.random() * 4, Math.random() * 3, 0, 6.29);
      ctx.fill();
    }
  }, true);
  TEX.grass = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#7fae58'; ctx.fillRect(0, 0, s, s);
    psxSpeckle(ctx, s, 220, ['#6f9c4c', '#8fbf66', '#5e8a41']);
  }, true);
  TEX.dirt = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#9c7f58'; ctx.fillRect(0, 0, s, s);
    psxSpeckle(ctx, s, 200, ['#8a6f4b', '#b08f63', '#7a6040']);
  }, true);
  TEX.stripes = canvasTexture(64, (ctx, s) => {
    ctx.fillStyle = '#c8433c'; ctx.fillRect(0, 0, s, s);
    ctx.fillStyle = '#efe7d8';
    for (let x = 0; x < s; x += 32) ctx.fillRect(x, 0, 16, s);
  }, true);
}

function buildTextures(style) {
  if (style === 'psx') makePSXTextures();
  else makeModernTextures();
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

const signCache = {};
function signTexture(label) {
  if (signCache[label]) return signCache[label];
  const psx = activeStyle === 'psx';
  const size = psx ? 160 : 256;
  const t = canvasTexture(size, (ctx, s) => {
    ctx.fillStyle = '#6a4a2c'; ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = '#3f2812';
    ctx.lineWidth = psx ? 8 : 10;
    ctx.strokeRect(psx ? 5 : 8, psx ? 5 : 8, s - (psx ? 10 : 16), s - (psx ? 10 : 16));
    ctx.fillStyle = '#f4ecd9';
    ctx.font = psx ? 'bold 38px "Courier New", monospace' : 'bold 44px Georgia, serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(label, s / 2, s / 2 + (psx ? 3 : 0));
  }, psx);
  signCache[label] = t;
  return t;
}

/* ------------------------------------------------------------------ */
/* 3. Materials                                                        */
/* ------------------------------------------------------------------ */
const MAT = {};
const allMaterials = [];

function std(map, opts = {}) {
  const m = new THREE.MeshStandardMaterial(Object.assign({ map, roughness: 0.9, metalness: 0.02 }, opts));
  allMaterials.push(m);
  return m;
}
function cloneTint(base, color) {
  const m = base.clone();
  m.color = new THREE.Color(color);
  allMaterials.push(m);
  return m;
}

let activeStyle = 'psx';

function buildMaterials() {
  if (MAT.plaster && MAT._style === activeStyle) return;
  for (const k of Object.keys(TEX)) delete TEX[k];
  for (const k of Object.keys(MAT)) delete MAT[k];
  for (const k of Object.keys(signCache)) delete signCache[k];
  allMaterials.length = 0;
  buildTextures(activeStyle);
  TEX.plaster.repeat.set(3, 2);
  TEX.stone.repeat.set(2.5, 2);
  TEX.timberDark.repeat.set(1, 1);

  MAT.plaster = std(TEX.plaster, { roughness: 0.96 });
  MAT.timber = std(TEX.timber, { roughness: 0.85 });
  MAT.timberDark = std(TEX.timberDark, { roughness: 0.9 });
  // frame/detail timber renders slightly in front of the surfaces it sits on
  MAT.timberDark.polygonOffset = true;
  MAT.timberDark.polygonOffsetFactor = 0;
  MAT.timberDark.polygonOffsetUnits = -1;
  // brace material renders slightly in front of the studs it crosses
  MAT.brace = std(TEX.timber, { roughness: 0.85 });
  MAT.brace.polygonOffset = true;
  MAT.brace.polygonOffsetFactor = 0;
  MAT.brace.polygonOffsetUnits = -1;
  MAT.door = std(TEX.door, { roughness: 0.8 });
  MAT.stone = std(TEX.stone, { roughness: 0.92 });
  MAT.stoneDark = std(TEX.stone, { roughness: 0.92, color: 0x8a8a82 });
  MAT.thatch = std(TEX.thatch, { roughness: 1.0 });
  MAT.shingle = std(TEX.shingle, { roughness: 0.85 });
  MAT.slate = std(TEX.slate, { roughness: 0.8 });
  MAT.cobble = std(TEX.cobble, { roughness: 0.95 });
  MAT.grass = std(TEX.grass, { roughness: 1.0 });
  MAT.dirt = std(TEX.dirt, { roughness: 1.0 });
  MAT.stripes = std(TEX.stripes, { roughness: 0.8, side: THREE.DoubleSide });

  MAT.glass = new THREE.MeshStandardMaterial({ color: 0x9cc3d8, roughness: 0.15, metalness: 0.1 });
  // glass always renders in front of frames / braces it sits over
  MAT.glass.polygonOffset = true;
  MAT.glass.polygonOffsetFactor = 0;
  MAT.glass.polygonOffsetUnits = -2;
  MAT.water = new THREE.MeshStandardMaterial({ color: 0x4a86a8, roughness: 0.2, metalness: 0.05 });
  MAT.metal = new THREE.MeshStandardMaterial({ color: 0x3a3a3e, roughness: 0.5, metalness: 0.6 });
  MAT.lantern = new THREE.MeshStandardMaterial({ color: 0xffd9a0, emissive: 0xffb45e, emissiveIntensity: 1.4, roughness: 0.6 });
  MAT.leaf = std(null, { color: 0x69a24c, roughness: 0.95 });
  MAT.leafDark = std(null, { color: 0x4e8337, roughness: 0.95 });
  MAT.trunk = std(TEX.timber, { roughness: 0.9 });
  MAT.hay = std(null, { color: 0xd6b26b, roughness: 1.0 });
  MAT.crate = std(TEX.timber, { roughness: 0.9, color: 0x9a7448 });
  MAT.barrel = std(TEX.door, { roughness: 0.85 });
  MAT.red = std(null, { color: 0xb03a30, roughness: 0.9, side: THREE.DoubleSide });
  MAT.blue = std(null, { color: 0x3a5aa0, roughness: 0.9, side: THREE.DoubleSide });
  MAT.gold = std(null, { color: 0xd9b23a, roughness: 0.5, metalness: 0.4 });
  allMaterials.push(MAT.glass, MAT.water, MAT.metal, MAT.lantern, MAT.leaf, MAT.leafDark, MAT.trunk,
    MAT.hay, MAT.crate, MAT.barrel, MAT.red, MAT.blue, MAT.gold);
  MAT._style = activeStyle;
}

/* ------------------------------------------------------------------ */
/* 4. Geometry helpers                                                 */
/* ------------------------------------------------------------------ */
const boxCache = new Map();
function boxGeo(w, h, d) {
  const k = `${w.toFixed(3)},${h.toFixed(3)},${d.toFixed(3)}`;
  if (!boxCache.has(k)) boxCache.set(k, new THREE.BoxGeometry(w, h, d));
  return boxCache.get(k);
}

function quadGeo(p0, p1, p2, p3, uvScale = [1, 1], faceUp = true) {
  const pos = new Float32Array([
    p0.x, p0.y, p0.z, p1.x, p1.y, p1.z,
    p2.x, p2.y, p2.z, p3.x, p3.y, p3.z,
  ]);
  const uv = new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]);
  for (let i = 0; i < 4; i++) { uv[i * 2] *= uvScale[0]; uv[i * 2 + 1] *= uvScale[1]; }
  let idx = [0, 1, 2, 0, 2, 3];
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex(idx);
  g.computeVertexNormals();
  if (faceUp) {
    const n = g.getAttribute('normal');
    if (n.getY(0) < 0) { g.setIndex([0, 2, 1, 0, 3, 2]); g.computeVertexNormals(); }
  }
  return g;
}

function triGeo(p0, p1, p2, uvScale = 1, faceX = 1) {
  const _a = new THREE.Vector3().subVectors(p1, p0);
  const _b = new THREE.Vector3().subVectors(p2, p0);
  const n = new THREE.Vector3().crossVectors(_a, _b).normalize();
  const pts = (n.x * faceX < 0) ? [p0, p2, p1] : [p0, p1, p2];
  const pos = new Float32Array([
    pts[0].x, pts[0].y, pts[0].z,
    pts[1].x, pts[1].y, pts[1].z,
    pts[2].x, pts[2].y, pts[2].z,
  ]);
  const len1 = pts[0].distanceTo(pts[1]) || 1;
  const len2 = pts[0].distanceTo(pts[2]) || 1;
  const uv = new Float32Array(3 * 2);
  for (let i = 0; i < 3; i++) {
    const d1 = pts[i].distanceTo(pts[0]) / len1;
    const d2 = pts[i].distanceTo(pts[0]) / len2;
    uv[i * 2] = d1 * uvScale; uv[i * 2 + 1] = d2 * uvScale;
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  g.setAttribute('uv', new THREE.BufferAttribute(uv, 2));
  g.setIndex([0, 1, 2]);
  g.computeVertexNormals();
  return g;
}

function mesh(geo, mat, x = 0, y = 0, z = 0, rx = 0, ry = 0, rz = 0) {
  const m = new THREE.Mesh(geo, mat);
  m.position.set(x, y, z);
  m.rotation.set(rx, ry, rz);
  m.castShadow = true;
  m.receiveShadow = true;
  return m;
}

/* ------------------------------------------------------------------ */
/* 5. Modular dimensions (the "snap" constants)                        */
/* ------------------------------------------------------------------ */
const PLINTH_H = 0.35;   // stone foundation height
const WALL_T = 0.16;     // infill (plaster) thickness
const POST = 0.24;       // corner post
const STUD = 0.18;       // stud (proud of plaster)
const SILL = 0.22;       // sill / top plate
const FLOOR_H = 2.6;

/* ------------------------------------------------------------------ */
/* 6. Modular wall / roof parts                                        */
/* ------------------------------------------------------------------ */
function wallFace(timber) {
  return (timber ? WALL_T : WALL_T * 1.5) / 2;   // distance from wall centre plane to outer face
}

function buildWalls(g, o) {
  const { w, d, h, y0, roofH, timber, wallMat, timberMat } = o;
  const ridgeY = y0 + h + roofH;
  const zc = d / 2, xc = w / 2;
  const face = wallFace(timber);

  if (!timber) {
    /* solid stone walls (no framing) */
    for (const s of [1, -1]) {
      g.add(mesh(boxGeo(w, h, WALL_T * 1.5), wallMat, 0, y0 + h / 2, s * zc));
    }
    for (const s of [1, -1]) {
      const p0 = new THREE.Vector3(0, y0 + h, -zc);
      const p1 = new THREE.Vector3(0, y0 + h, zc);
      const p2 = new THREE.Vector3(0, ridgeY, 0);
      g.add(mesh(triGeo(p0, p2, p1, Math.max(d / 2, roofH), s), wallMat, s * (xc + face), 0, 0, 0, s > 0 ? 0 : Math.PI, 0));
    }
    return;
  }

  /* ---- timber frame (half-timbered) ----
     Framing (posts/sill/plate/studs) is POST deep, proud of the WALL_T-thin
     plaster infill, and every member is inset so that no two same-facing
     surfaces are ever coplanar — this is what kills corner z-fighting.   */
  for (const s of [1, -1]) {
    const z = s * zc;                       // front/back wall plane
    // plaster infill, inset between corner posts
    g.add(mesh(boxGeo(w - 2 * POST, h - 2 * SILL, WALL_T), wallMat, 0, y0 + h / 2, z));
    // sill + top plate, inset so their faces never coincide with the posts
    g.add(mesh(boxGeo(w - 2 * POST, SILL, POST), timberMat, 0, y0 + SILL / 2, z));
    g.add(mesh(boxGeo(w - 2 * POST, SILL, POST), timberMat, 0, y0 + h - SILL / 2, z));
    // corner posts — the ONLY posts (shared with the gable end walls)
    g.add(mesh(boxGeo(POST, h, POST), timberMat, -xc + POST / 2, y0 + h / 2, z));
    g.add(mesh(boxGeo(POST, h, POST), timberMat, xc - POST / 2, y0 + h / 2, z));
    // studs at full frame depth (proud of the plaster, flush with sills)
    for (let x = -xc + POST + 0.15; x < xc - POST - 0.15; x += 0.85) {
      g.add(mesh(boxGeo(STUD, h - 2 * SILL, POST), timberMat, x, y0 + SILL + (h - 2 * SILL) / 2, z));
    }
    // corner braces (front wall only, for character) — proud of the studs,
    // and depth-ordered (via polygon offset) above them where they cross
    if (s === 1) {
      const blen = Math.hypot(0.85, h - 2 * SILL - 0.1);
      const ang = Math.atan2(h - 2 * SILL - 0.1, 0.85);
      for (const bs of [1, -1]) {
        const bx = bs * (xc - POST - 0.3);
        const m = mesh(boxGeo(0.16, blen, 0.26), MAT.brace, bx, y0 + h / 2, z + 0.01);
        m.rotation.z = -bs * ang;
        g.add(m);
      }
    }
  }

  /* gable end walls (along Z, facing ±X) — no separate corner posts */
  for (const s of [1, -1]) {
    const x = s * (xc + face);
    const baseY = y0 + h;
    const p0 = new THREE.Vector3(0, baseY, -zc + POST);
    const p1 = new THREE.Vector3(0, baseY, zc - POST);
    const p2 = new THREE.Vector3(0, ridgeY, 0);
    g.add(mesh(boxGeo(WALL_T, h - 2 * SILL, d - 2 * POST), wallMat, x, y0 + h / 2, 0));
    g.add(mesh(boxGeo(POST, SILL, d - 2 * POST), timberMat, x, y0 + SILL / 2, 0));
    g.add(mesh(boxGeo(POST, SILL, d - 2 * POST), timberMat, x, y0 + h - SILL / 2, 0));
    g.add(mesh(triGeo(p0, p2, p1, Math.max(d / 2, roofH), s), wallMat, x, 0, 0, 0, s > 0 ? 0 : Math.PI, 0));
    // diagonal rafters, fully proud of the gable triangle + end-wall frame
    const dz = zc - POST / 2, dh = roofH;
    const len = Math.hypot(dz, dh), ang = Math.atan2(dz, dh);
    for (const zs of [1, -1]) {
      const m = mesh(boxGeo(POST * 0.8, len, POST * 0.8), timberMat, x + s * 0.14, baseY + dh / 2, zs * (dz / 2));
      m.rotation.x = -zs * ang;
      g.add(m);
    }
  }
}

function buildRoof(g, o) {
  const { w, d, h, y0, roofH, mat, timberMat } = o;
  const eaveY = y0 + h, ridgeY = eaveY + roofH;
  const eo = 0.32, go = 0.42;                 // eave & gable overhang
  const planeW = w + 2 * go;
  const hd = d / 2 + eo;
  const slope = Math.hypot(roofH, hd);

  for (const s of [1, -1]) {
    const A = new THREE.Vector3(-planeW / 2, ridgeY, 0);
    const B = new THREE.Vector3(planeW / 2, ridgeY, 0);
    const C = new THREE.Vector3(planeW / 2, eaveY, s * hd);
    const D = new THREE.Vector3(-planeW / 2, eaveY, s * hd);
    g.add(mesh(quadGeo(A, B, C, D, [planeW / 1.5, slope / 1.5]), mat));
  }
  // ridge cap (shortened so its ends stay behind the bargeboards)
  g.add(mesh(boxGeo(planeW - 0.12, 0.14, 0.16), mat, 0, ridgeY + 0.03, 0));
  // bargeboards at the gable overhangs
  for (const s of [1, -1]) {
    const x = s * (w / 2 + go);
    const q0 = new THREE.Vector3(0, eaveY, -hd);
    const q1 = new THREE.Vector3(0, eaveY, hd);
    const q2 = new THREE.Vector3(0, ridgeY, 0);
    g.add(mesh(triGeo(q0, q2, q1, 1, s), timberMat, x, 0, 0, 0, s > 0 ? 0 : Math.PI, 0));
  }
}

function buildChimney(g, p, r) {
  const y0 = PLINTH_H;
  const h = p.h;
  const ridgeY = y0 + h + p.roofH;
  const big = p.smithy;
  const cw = big ? 0.85 : 0.55, cd = big ? 0.85 : 0.55;
  const chH = ridgeY + (big ? 1.5 : 1.0) - y0;
  const x = THREE.MathUtils.clamp((r() * 2 - 1) * (p.w / 2 - 1), -(p.w / 2 - 1.2), p.w / 2 - 1.2);
  const z = THREE.MathUtils.clamp((r() * 2 - 1) * (p.d / 2 - 1), -(p.d / 2 - 1.2), p.d / 2 - 1.2);
  g.add(mesh(boxGeo(cw, chH, cd), big ? MAT.stoneDark : MAT.stone, x, y0 + chH / 2, z));
  // cap sits on top: its top face clears the chimney top so they never z-fight
  g.add(mesh(boxGeo(cw + 0.14, 0.2, cd + 0.14), MAT.stoneDark, x, y0 + chH + 0.08, z));
}

function buildDoor(g, p, r) {
  const y0 = PLINTH_H;
  const dbl = p.tavern || p.barn || p.church;
  const forge = p.smithy;
  const dw = forge ? 2.4 : (dbl ? 1.9 : 1.0);
  const dh = p.tall ? 2.3 : 2.0;
  const x = 0;
  const face = wallFace(p.wall === 'timber');
  const z = p.d / 2 + face;                 // outer face of the front wall
  // frame
  g.add(mesh(boxGeo(0.14, dh + 0.14, 0.16), MAT.timberDark, x - dw / 2 - 0.07, y0 + dh / 2, z + 0.02));
  g.add(mesh(boxGeo(0.14, dh + 0.14, 0.16), MAT.timberDark, x + dw / 2 + 0.07, y0 + dh / 2, z + 0.02));
  g.add(mesh(boxGeo(dw + 0.3, 0.16, 0.2), forge ? MAT.stone : MAT.timberDark, x, y0 + dh + 0.09, z + 0.02));
  if (!forge) {
    g.add(mesh(boxGeo(dw, dh, 0.08), MAT.door, x, y0 + dh / 2, z + 0.05));
    if (dbl) g.add(mesh(boxGeo(0.04, dh - 0.3, 0.09), MAT.timberDark, x, y0 + dh / 2, z + 0.09));
  } else {
    g.add(mesh(boxGeo(dw - 0.1, 0.1, 0.1), MAT.metal, x, y0 + 0.3, z + 0.05)); // forge shelf
  }
  g.add(mesh(boxGeo(dw + 0.55, 0.16, 0.5), MAT.stone, x, 0.08, p.d / 2 + 0.2)); // step
}

function buildWindow(g, x, y, zSign, p, r, narrow) {
  const ww = narrow ? 0.55 : 0.64, wh = narrow ? 0.7 : 0.8;
  const face = wallFace(p.wall === 'timber');
  const z = zSign * (p.d / 2 + face);        // outer face of the wall
  g.add(mesh(boxGeo(ww, wh, 0.1), MAT.timberDark, x, y, z + zSign * 0.02));
  g.add(mesh(boxGeo(ww - 0.18, wh - 0.18, 0.06), MAT.glass, x, y, z + zSign * 0.06)); // proud of the frame → no coplanar z-fight
  g.add(mesh(boxGeo(ww + 0.12, 0.08, 0.22), MAT.timber, x, y - wh / 2 - 0.07, z + zSign * 0.02));
  if (!narrow && r() < 0.55) {
    const sx = ww / 2 + 0.17;
    g.add(mesh(boxGeo(0.3, wh, 0.05), MAT.timberDark, x - sx, y, z + zSign * 0.07));
    g.add(mesh(boxGeo(0.3, wh, 0.05), MAT.timberDark, x + sx, y, z + zSign * 0.07));
  }
}

function windowXs(n, w, avoidX, avoidR, r) {
  const xs = [];
  const minGap = 1.35;                    // frame 0.64 + both shutters must not touch
  const lim = w / 2 - 0.8;                // keep clear of the wall corners
  const doorZone = avoidR > 10 ? 0 : avoidR + 0.35;   // keep clear of the door
  let guard = 0;
  while (xs.length < n && guard++ < 400) {
    const x = (r() * 2 - 1) * lim;
    if (Math.abs(x - avoidX) < doorZone) continue;
    if (xs.some(px => Math.abs(px - x) < minGap)) continue;
    xs.push(x);
  }
  xs.sort((a, b) => a - b);
  return xs;
}

function addWindows(g, p, r) {
  const narrow = p.wall === 'stone';
  const y1 = PLINTH_H + 1.25;
  const y2 = PLINTH_H + 1.25 + FLOOR_H;
  const avoidR = p.tavern || p.barn || p.church ? 1.5 : 1.05;
  const front = windowXs(Math.max(1, p.win), p.w, 0, avoidR, r);
  for (const x of front) buildWindow(g, x, y1, 1, p, r, narrow);
  // back wall
  const back = windowXs(Math.max(0, p.win - 1), p.w, 999, 1, r);
  for (const x of back) buildWindow(g, x, y1, -1, p, r, narrow);
  // second floor
  if (p.floors === 2) {
    for (const x of windowXs(p.win - 1, p.w, 999, 1, r)) buildWindow(g, x, y2, 1, p, r, narrow);
    for (const x of windowXs(Math.max(0, p.win - 2), p.w, 999, 1, r)) buildWindow(g, x, y2, -1, p, r, narrow);
  }
  // gable peek window for barns / townhouses
  if (p.barn || (p.floors === 2 && r() < 0.4)) {
    const s = r() < 0.5 ? 1 : -1;
    const wy = PLINTH_H + p.h - 0.7;
    const face = wallFace(p.wall === 'timber');
    g.add(mesh(new THREE.CircleGeometry(0.28, 14), MAT.glass, s * (p.w / 2 + face + 0.03), wy, 0, 0, s > 0 ? Math.PI / 2 : -Math.PI / 2, 0));
    g.add(mesh(new THREE.TorusGeometry(0.3, 0.045, 6, 16), MAT.timberDark, s * (p.w / 2 + face + 0.05), wy, 0, 0, s > 0 ? Math.PI / 2 : -Math.PI / 2, 0));
  }
}

function addFloorBand(g, p) {
  const y = PLINTH_H + FLOOR_H;
  // front/back bands: inset in Z so they stay inside the wall thickness
  const zIns = (p.wall === 'stone' ? WALL_T * 1.5 : WALL_T) / 2 + POST / 2 + 0.02;
  g.add(mesh(boxGeo(p.w - 2 * POST, 0.16, POST), MAT.timberDark, 0, y, p.d / 2 - zIns));
  g.add(mesh(boxGeo(p.w - 2 * POST, 0.16, POST), MAT.timberDark, 0, y, -(p.d / 2 - zIns)));
  // gable-end bands: inset in X and shortened in Z so their ends never meet
  // the gable-end wall faces
  g.add(mesh(boxGeo(POST, 0.16, p.d - 2 * POST - 0.1), MAT.timberDark, p.w / 2 - zIns, y, 0));
  g.add(mesh(boxGeo(POST, 0.16, p.d - 2 * POST - 0.1), MAT.timberDark, -(p.w / 2 - zIns), y, 0));
}

function addSign(g, label, p) {
  const face = wallFace(p.wall === 'timber');
  const z = p.d / 2 + face;
  const y = PLINTH_H + (p.tall ? 2.9 : 2.5);
  const x = p.w * 0.28;
  g.add(mesh(boxGeo(1.3, 0.08, 0.08), MAT.timberDark, x, y + 0.28, z + 0.1));
  g.add(mesh(boxGeo(0.05, 0.55, 0.05), MAT.timberDark, x - 0.52, y - 0.1, z + 0.14));
  g.add(mesh(boxGeo(0.05, 0.55, 0.05), MAT.timberDark, x + 0.52, y - 0.1, z + 0.14));
  const sm = new THREE.MeshStandardMaterial({ map: signTexture(label), roughness: 0.8 });
  allMaterials.push(sm);
  g.add(mesh(boxGeo(1.5, 0.85, 0.07), sm, x, y - 0.48, z + 0.2));
}

function addChurchExtras(g, p) {
  const y0 = PLINTH_H;
  const ridgeY = y0 + p.h + p.roofH;
  const face = wallFace(false);   // stone
  // rose window on the +X gable
  g.add(mesh(new THREE.CircleGeometry(0.62, 22), MAT.glass, p.w / 2 + face + 0.03, y0 + 2.5, 0, 0, Math.PI / 2, 0));
  g.add(mesh(new THREE.TorusGeometry(0.66, 0.07, 6, 22), MAT.stone, p.w / 2 + face + 0.05, y0 + 2.5, 0, 0, Math.PI / 2, 0));
  // fanlight over the door
  g.add(mesh(new THREE.CircleGeometry(0.62, 18, 0, Math.PI), MAT.glass, 0, y0 + 2.4, p.d / 2 + face + 0.03, 0, 0, 0));
  // bell tower on the -X gable
  const tw = 2.3, td = 2.3;
  const tH = ridgeY + 2.4 - y0;
  const tx = -(p.w / 2 + tw / 2 - 0.3);
  g.add(mesh(boxGeo(tw, tH, td), MAT.stone, tx, y0 + tH / 2, 0));
  // bell chamber: a darker band that protrudes past the tower walls; its top
  // is kept just below the tower top so the two top faces never coincide
  g.add(mesh(boxGeo(tw + 0.16, 1.5, td + 0.16), MAT.stoneDark, tx, y0 + tH - 0.81, 0));
  // louvre slats on the front/back faces of the chamber
  g.add(mesh(boxGeo(0.5, 1.1, 0.1), MAT.timberDark, tx, y0 + tH - 0.81, td / 2 + 0.09));
  g.add(mesh(boxGeo(0.5, 1.1, 0.1), MAT.timberDark, tx, y0 + tH - 0.81, -(td / 2 + 0.09)));
  // spire (4-sided pyramid) + cross
  g.add(mesh(new THREE.ConeGeometry(1.45, 3.4, 4), MAT.slate, tx, y0 + tH + 1.7, 0, Math.PI / 4, 0, 0));
  const top = y0 + tH + 3.4;
  g.add(mesh(boxGeo(0.08, 0.8, 0.08), MAT.timberDark, tx, top + 0.4, 0));
  g.add(mesh(boxGeo(0.42, 0.08, 0.08), MAT.timberDark, tx, top + 0.66, 0.05));
  // cross on the ridge (opposite end)
  g.add(mesh(boxGeo(0.08, 0.55, 0.08), MAT.timberDark, p.w / 2 - 0.5, ridgeY + 0.5, 0));
  g.add(mesh(boxGeo(0.3, 0.07, 0.07), MAT.timberDark, p.w / 2 - 0.5, ridgeY + 0.72, 0.05));
}

function addTowerTop(g, p) {
  const y0 = PLINTH_H;
  const topY = y0 + p.h;
  // coping slab raised so its top clears the wall tops (no coplanar top faces)
  g.add(mesh(boxGeo(p.w + 0.2, 0.18, p.d + 0.2), MAT.stone, 0, topY + 0.09, 0));
  const mw = 0.26, mh = 0.5, mdeep = 0.26;
  const half = p.w / 2;
  const face = wallFace(false);
  for (const s of [-1, 1]) {
    for (let t = -half + 0.1; t <= half - 0.1; t += 0.62) {
      g.add(mesh(boxGeo(mw, mh, mdeep), MAT.stone, s * (half + face / 2), topY + 0.18 + mh / 2, t));
      g.add(mesh(boxGeo(mw, mh, mdeep), MAT.stone, t, topY + 0.18 + mh / 2, s * (half + face / 2)));
    }
  }
  // flag
  g.add(mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.6, 6), MAT.timberDark, 0, topY + 0.8, 0));
  g.add(mesh(triGeo(
    new THREE.Vector3(0, topY + 1.45, 0),
    new THREE.Vector3(0, topY + 1.0, 0.7),
    new THREE.Vector3(0, topY + 1.22, 0),
    1, 1), MAT.red, 0.09, 0, 0));
}

/* ------------------------------------------------------------------ */
/* 7. House parameter + builder                                        */
/* ------------------------------------------------------------------ */
export function houseParams(type, r) {
  const rr = (a, b) => a + r() * (b - a);
  switch (type) {
    case 'hut': return { type, w: rr(2.6, 3.2), d: rr(2.4, 3.0), floors: 1, wall: 'timber', roof: 'thatch', roofH: rr(1.0, 1.25), win: 1, chimney: r() < 0.4 };
    case 'cottage': return { type, w: rr(3.6, 4.6), d: rr(3.0, 3.8), floors: 1, wall: 'timber', roof: r() < 0.7 ? 'thatch' : 'shingle', roofH: rr(1.25, 1.5), win: 2, chimney: r() < 0.6 };
    case 'townhouse': return { type, w: rr(4.2, 6.0), d: rr(3.6, 4.6), floors: 2, wall: 'timber', roof: r() < 0.8 ? 'shingle' : 'thatch', roofH: rr(1.6, 1.9), win: r() < 0.5 ? 4 : 5, chimney: r() < 0.8 };
    case 'stonehouse': return { type, w: rr(4.0, 5.4), d: rr(3.2, 4.2), floors: r() < 0.5 ? 1 : 2, wall: 'stone', roof: r() < 0.5 ? 'shingle' : 'slate', roofH: rr(1.3, 1.7), win: 2, chimney: r() < 0.6 };
    case 'tavern': return { type, w: rr(6.0, 7.2), d: rr(4.4, 5.2), floors: 1, tall: true, wall: 'timber', roof: 'thatch', roofH: rr(1.6, 1.9), win: 4, chimney: true };
    case 'smithy': return { type, w: rr(5.0, 5.8), d: rr(3.8, 4.4), floors: 1, tall: true, wall: 'stone', roof: 'shingle', roofH: rr(1.2, 1.5), win: 2, chimney: true };
    case 'church': return { type, w: 5.0, d: 6.2, floors: 1, tall: true, wall: 'stone', roof: 'slate', roofH: 2.4, win: 2, chimney: false };
    case 'barn': return { type, w: rr(5.0, 6.2), d: rr(3.6, 4.6), floors: 1, tall: true, wall: 'timber', roof: r() < 0.6 ? 'thatch' : 'shingle', roofH: rr(1.4, 1.7), win: 0, chimney: false };
    case 'tower': return { type, w: rr(3.2, 3.6), d: rr(3.2, 3.6), floors: 2, tower: true, wall: 'stone', roof: 'none', roofH: 0, win: 0, chimney: false };
    default: return houseParams('cottage', r);
  }
}

export function makeHouse(p, r) {
  buildMaterials();
  const g = new THREE.Group();
  const y0 = PLINTH_H;
  p.h = p.tower ? 5.6 : (p.tall ? 3.3 : p.floors * FLOOR_H);
  const h = p.h;
  const timber = p.wall === 'timber';

  const wallMat = timber
    ? cloneTint(MAT.plaster, new THREE.Color().setHSL(0.115 + r() * 0.02, 0.28 + r() * 0.08, 0.88 + r() * 0.06))
    : cloneTint(MAT.stone, new THREE.Color().setHSL(0.08 + r() * 0.03, 0.05, 0.82 + r() * 0.1));
  const roofMat = p.roof === 'thatch' ? MAT.thatch : p.roof === 'shingle' ? MAT.shingle : MAT.slate;

  // foundation
  g.add(mesh(boxGeo(p.w + 0.3, PLINTH_H, p.d + 0.3), MAT.stone, 0, PLINTH_H / 2, 0));
  // walls
  buildWalls(g, { w: p.w, d: p.d, h, y0, roofH: p.roofH, timber, wallMat, timberMat: MAT.timber });
  if (p.floors === 2) addFloorBand(g, p);
  // roof
  if (p.roof !== 'none') buildRoof(g, { w: p.w, d: p.d, h, y0, roofH: p.roofH, mat: roofMat, timberMat: MAT.timberDark });
  // chimney
  if (p.chimney) buildChimney(g, p, r);
  // door + windows
  buildDoor(g, p, r);
  if (p.win > 0) addWindows(g, p, r);
  // tower: arrow slits + battlement top
  if (p.tower) {
    const face = wallFace(false);
    for (const s of [1, -1]) {
      g.add(mesh(boxGeo(0.07, 0.75, 0.07), MAT.timberDark, s * (p.w / 2 + face + 0.01), y0 + 2.4, 0));
      g.add(mesh(boxGeo(0.07, 0.75, 0.07), MAT.timberDark, 0, y0 + 2.4, s * (p.d / 2 + face + 0.01)));
    }
    addTowerTop(g, p);
  }
  // per-type extras
  if (p.type === 'tavern') addSign(g, 'TAVERN', p);
  if (p.type === 'smithy') addSign(g, 'SMITHY', p);
  if (p.type === 'church') addChurchExtras(g, p);
  return g;
}

/* ------------------------------------------------------------------ */
/* 8. Props                                                            */
/* ------------------------------------------------------------------ */
function makeBarrel() {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.27, 0.27, 0.72, 10), MAT.barrel, 0, 0.36, 0));
  g.add(mesh(new THREE.CylinderGeometry(0.29, 0.29, 0.06, 10), MAT.metal, 0, 0.22, 0));
  g.add(mesh(new THREE.CylinderGeometry(0.29, 0.29, 0.06, 10), MAT.metal, 0, 0.5, 0));
  return g;
}

function makeCrate() {
  const g = new THREE.Group();
  g.add(mesh(boxGeo(0.68, 0.68, 0.68), MAT.crate, 0, 0.34, 0));
  g.add(mesh(boxGeo(0.72, 0.1, 0.1), MAT.timberDark, 0, 0.34, 0));
  return g;
}

function makeHay() {
  const g = new THREE.Group();
  g.add(mesh(boxGeo(0.95, 0.55, 0.7), MAT.hay, 0, 0.28, 0));
  return g;
}

function makeLamp() {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.05, 0.09, 2.7, 6), MAT.timberDark, 0, 1.35, 0));
  g.add(mesh(boxGeo(0.4, 0.34, 0.34), MAT.metal, 0, 2.72, 0));
  g.add(mesh(boxGeo(0.26, 0.24, 0.26), MAT.lantern, 0, 2.72, 0));
  g.add(mesh(new THREE.ConeGeometry(0.26, 0.24, 4), MAT.metal, 0, 2.98, 0));
  return g;
}

function makeStall(r) {
  const g = new THREE.Group();
  const w = 2.3, d = 1.5, th = 0.85;
  g.add(mesh(boxGeo(w, 0.08, d), MAT.timber, 0, th, 0));
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) {
    g.add(mesh(boxGeo(0.09, 2.1, 0.09), MAT.timberDark, sx * (w / 2 - 0.06), 1.05, sz * (d / 2 - 0.06)));
  }
  const aw = w + 0.5, ad = d + 0.5, ay = 2.12;
  const A = new THREE.Vector3(-aw / 2, ay, -ad / 2);
  const B = new THREE.Vector3(aw / 2, ay, -ad / 2);
  const C = new THREE.Vector3(aw / 2, ay, ad / 2);
  const D = new THREE.Vector3(-aw / 2, ay, ad / 2);
  g.add(mesh(quadGeo(A, B, C, D, [aw / 1.4, ad / 1.4]), MAT.stripes));
  // goods
  g.add(mesh(boxGeo(0.5, 0.28, 0.4), MAT.crate, -0.55, th + 0.18, 0.1));
  g.add(mesh(boxGeo(0.42, 0.34, 0.42), MAT.crate, 0.55, th + 0.21, -0.05));
  const fruit = r() < 0.5 ? MAT.red : MAT.gold;
  for (let i = 0; i < 3; i++) g.add(mesh(new THREE.IcosahedronGeometry(0.12, 0), fruit, -0.55 + i * 0.16, th + 0.36, 0.1));
  return g;
}

function makeWell() {
  const g = new THREE.Group();
  g.add(mesh(new THREE.CylinderGeometry(0.78, 0.85, 0.85, 10), MAT.stone, 0, 0.42, 0));
  g.add(mesh(new THREE.CylinderGeometry(0.62, 0.62, 0.08, 14), MAT.water, 0, 0.86, 0));
  for (const s of [-1, 1]) g.add(mesh(boxGeo(0.11, 1.7, 0.11), MAT.timberDark, s * 0.72, 1.7, 0));
  const A = new THREE.Vector3(-1.1, 2.55, 0), B = new THREE.Vector3(1.1, 2.55, 0);
  const C = new THREE.Vector3(1.1, 2.2, 0.75), D = new THREE.Vector3(-1.1, 2.2, 0.75);
  const E = new THREE.Vector3(1.1, 2.2, -0.75), F = new THREE.Vector3(-1.1, 2.2, -0.75);
  g.add(mesh(quadGeo(A, B, C, D, [2.2, 0.9]), MAT.shingle));
  g.add(mesh(quadGeo(A, B, E, F, [2.2, 0.9]), MAT.shingle));
  g.add(mesh(boxGeo(2.3, 0.1, 0.12), MAT.timberDark, 0, 2.56, 0));
  return g;
}

/* ------------------------------------------------------------------ */
/* 8b. Stark Crafts forest (baked FBX assets + embedded textures)      */
/* ------------------------------------------------------------------ */
function buildForestMaterials(texMap) {
  const mats = [];
  for (const def of FOREST_MATERIALS) {
    const mat = new THREE.MeshStandardMaterial({ color: new THREE.Color(def.color), roughness: 0.95 });
    if (def.tex && texMap && texMap[def.tex]) {
      const tex = texMap[def.tex];
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.magFilter = activeStyle === 'psx' ? THREE.NearestFilter : THREE.LinearFilter;
      tex.minFilter = activeStyle === 'psx' ? THREE.NearestFilter : THREE.LinearMipmapLinearFilter;
      tex.generateMipmaps = activeStyle !== 'psx';
      mat.map = tex;
    }
    if (def.transparent) {
      mat.transparent = true;
      mat.alphaTest = 0.5;
      mat.side = THREE.DoubleSide;
    } else if (def.side === 2) {
      mat.side = THREE.DoubleSide;
    }
    mats.push(mat);
  }
  allMaterials.push(...mats);
  return mats;
}

function buildForestModels(texMap) {
  const mats = buildForestMaterials(texMap);
  return FOREST_ASSETS.map(a => {
    const group = new THREE.Group();
    group.name = a.name;
    let radius = 0;
    for (const g of a.groups) {
      const geo = new THREE.BufferGeometry();
      const pos = decodeF32(g.pos);
      geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
      geo.setAttribute('normal', new THREE.BufferAttribute(decodeF32(g.nor), 3));
      if (g.uv) geo.setAttribute('uv', new THREE.BufferAttribute(decodeF32(g.uv), 2));
      for (let i = 0; i < pos.length; i += 3) {
        radius = Math.max(radius, Math.hypot(pos[i], pos[i + 2]));
      }
      const m = new THREE.Mesh(geo, mats[g.mat]);
      m.castShadow = true;
      m.receiveShadow = true;
      group.add(m);
    }
    return { name: a.name, kind: a.kind, height: a.height, radius, group };
  });
}

function scatterForest(world, boxes, stats, r, models) {
  const trees = models.filter(m => m.kind === 'tree');
  const rocks = models.filter(m => m.kind === 'rock');
  const foliage = models.filter(m => m.kind === 'foliage');

  // trees ring the village, kept clear of streets / buildings / lamps
  for (let i = 0; i < 70; i++) {
    const x = -46 + r() * 92;
    const z = -29 + r() * 58;
    const m = trees[(r() * trees.length) | 0];
    const c = m.group.clone(true);
    c.position.set(x, 0, z);
    c.rotation.y = r() * Math.PI * 2;
    const sc = 0.85 + r() * 0.55;
    c.scale.setScalar(sc);
    const rr = Math.max(0.5, m.radius * sc * 0.55);
    const b = obbFromAABB(x - rr, x + rr, z - rr, z + rr);
    if (!collides(b, boxes, 0.6)) {
      world.add(c);
      boxes.push({ obb: b, label: 'tree' });
      stats.props++;
    }
  }

  // boulders
  for (let i = 0; i < 12; i++) {
    const x = -46 + r() * 92;
    const z = -29 + r() * 58;
    const m = rocks[(r() * rocks.length) | 0];
    const c = m.group.clone(true);
    c.position.set(x, 0, z);
    c.rotation.y = r() * Math.PI * 2;
    const sc = 0.8 + r() * 1.0;
    c.scale.setScalar(sc);
    const rr = Math.max(0.3, m.radius * sc * 0.7);
    const b = obbFromAABB(x - rr, x + rr, z - rr, z + rr);
    if (!collides(b, boxes, 0.3)) {
      world.add(c);
      boxes.push({ obb: b, label: 'rock' });
      stats.props++;
    }
  }

  // grass tufts, reeds, dandelions, lavender, pine cones
  for (let i = 0; i < 180; i++) {
    const x = -47 + r() * 94;
    const z = -29 + r() * 58;
    const m = foliage[(r() * foliage.length) | 0];
    const c = m.group.clone(true);
    c.position.set(x, 0, z);
    c.rotation.y = r() * Math.PI * 2;
    const sc = 0.7 + r() * 0.9;
    c.scale.setScalar(sc);
    const rr = Math.max(0.15, m.radius * sc * 0.6);
    const b = obbFromAABB(x - rr, x + rr, z - rr, z + rr);
    if (!collides(b, boxes, 0.15)) {
      world.add(c);
      boxes.push({ obb: b, label: 'foliage' });
      stats.props++;
    }
  }
}

/* ---- green "foliage" lines: fill a closed loop, or a strip along an
       open line, with Stark Crafts trees / rocks / undergrowth ---- */
function pointInPolygon2D(x, z, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i][0], zi = poly[i][1], xj = poly[j][0], zj = poly[j][1];
    if ((zi > z) !== (zj > z) && x < ((xj - xi) * (z - zi)) / (zj - zi) + xi) inside = !inside;
  }
  return inside;
}
function distToSegments2D(x, z, pts) {
  let d = Infinity;
  for (let i = 0; i < pts.length - 1; i++) {
    const ax = pts[i][0], az = pts[i][1], bx = pts[i + 1][0], bz = pts[i + 1][1];
    const dx = bx - ax, dz = bz - az, L2 = dx * dx + dz * dz;
    let t = L2 ? ((x - ax) * dx + (z - az) * dz) / L2 : 0;
    t = Math.max(0, Math.min(1, t));
    d = Math.min(d, Math.hypot(x - (ax + dx * t), z - (az + dz * t)));
  }
  return d;
}
function greenRegion(line) {
  const pts = line.points;
  const strip = (line.halfW || 2.5) + 3.5;   // foliage corridor half-width
  let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
  for (const [x, z] of pts) {
    minX = Math.min(minX, x); maxX = Math.max(maxX, x);
    minZ = Math.min(minZ, z); maxZ = Math.max(maxZ, z);
  }
  const closed = pts.length >= 3 &&
    Math.hypot(pts[0][0] - pts[pts.length - 1][0], pts[0][1] - pts[pts.length - 1][1]) <= 1.5;
  if (closed) {
    const poly = pts.slice(0, pts.length - 1);
    let area = 0;
    for (let i = 0; i < poly.length; i++) {
      const [x1, z1] = poly[i], [x2, z2] = poly[(i + 1) % poly.length];
      area += x1 * z2 - x2 * z1;
    }
    area = Math.abs(area) / 2;
    return { closed: true, poly, minX, maxX, minZ, maxZ, area };
  }
  let len = 0;
  for (let i = 0; i < pts.length - 1; i++) len += Math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1]);
  return { closed: false, pts, strip, minX, maxX, minZ, maxZ, area: len * strip * 2 };
}
function inGreenRegion(reg, x, z) {
  if (x < reg.minX || x > reg.maxX || z < reg.minZ || z > reg.maxZ) return false;
  return reg.closed ? pointInPolygon2D(x, z, reg.poly) : distToSegments2D(x, z, reg.pts) <= reg.strip;
}
function plantInRegion(world, boxes, stats, r, reg, pool, label, want, margin, rrScale, scMin, scMax) {
  for (let i = 0; i < want * 4; i++) {
    const x = reg.minX + r() * (reg.maxX - reg.minX);
    const z = reg.minZ + r() * (reg.maxZ - reg.minZ);
    if (!inGreenRegion(reg, x, z)) continue;
    const m = pool[(r() * pool.length) | 0];
    const c = m.group.clone(true);
    c.position.set(x, 0, z);
    c.rotation.y = r() * Math.PI * 2;
    const sc = scMin + r() * (scMax - scMin);
    c.scale.setScalar(sc);
    const rr = Math.max(0.15, m.radius * sc * rrScale);
    const b = obbFromAABB(x - rr, x + rr, z - rr, z + rr);
    if (!collides(b, boxes, margin)) {
      world.add(c);
      boxes.push({ obb: b, label });
      stats.props++;
    }
  }
}
function scatterGreenFoliage(world, boxes, stats, r, forest, greenLines) {
  const trees = forest.filter(m => m.kind === 'tree');
  const rocks = forest.filter(m => m.kind === 'rock');
  const foliage = forest.filter(m => m.kind === 'foliage');
  for (const line of greenLines) {
    const reg = greenRegion(line);
    if (!(reg.area > 0)) continue;
    const treeN = Math.min(150, Math.round(reg.area / 22));
    const rockN = Math.min(60, Math.round(reg.area / 45));
    const folN = Math.min(700, Math.round(reg.area / 3));
    plantInRegion(world, boxes, stats, r, reg, trees, 'tree', treeN, 0.6, 0.55, 0.85, 1.4);
    plantInRegion(world, boxes, stats, r, reg, rocks, 'rock', rockN, 0.3, 0.7, 0.8, 1.8);
    plantInRegion(world, boxes, stats, r, reg, foliage, 'foliage', folN, 0.15, 0.6, 0.7, 1.6);
  }
}

/* ------------------------------------------------------------------ */
/* 9. Village layout                                                   */
/* ------------------------------------------------------------------ */
const STREETS = [
  { axis: 'x', at: 0, halfW: 3.5, from: -40, to: 33, name: 'Main Street' },
  { axis: 'x', at: 15, halfW: 2.5, from: -28, to: 28, name: 'North Street' },
  { axis: 'x', at: -15, halfW: 2.5, from: -28, to: 28, name: 'South Street' },
  { axis: 'z', at: -14, halfW: 2.5, from: -28, to: 28, name: 'West Street' },
  { axis: 'z', at: 14, halfW: 2.5, from: -28, to: 28, name: 'East Street' },
];
const PLAZA = { minX: -40, maxX: -28, minZ: -10, maxZ: 10 };

/* ---- 2D oriented-bounding-box collision (footprints on the XZ plane) ---- */
function obb(x, z, hx, hz, ang) {
  const c = Math.cos(ang), s = Math.sin(ang);
  return { x, z, hx, hz, axX: c, axZ: -s, azX: s, azZ: c };
}
function obbFromAABB(minX, maxX, minZ, maxZ) {
  return { x: (minX + maxX) / 2, z: (minZ + maxZ) / 2,
    hx: (maxX - minX) / 2, hz: (maxZ - minZ) / 2,
    axX: 1, axZ: 0, azX: 0, azZ: 1 };
}
function obbFromSegment(ax, az, bx, bz, hw) {
  const dx = bx - ax, dz = bz - az;
  const len = Math.hypot(dx, dz) || 1;
  const ux = dx / len, uz = dz / len;
  return { x: (ax + bx) / 2, z: (az + bz) / 2, hx: len / 2, hz: hw,
    axX: ux, axZ: uz, azX: -uz, azZ: ux };
}

/* separating-axis test between two oriented rectangles */
export function obbOverlap(a, b, margin = 0) {
  const axes = [[a.axX, a.axZ], [a.azX, a.azZ], [b.axX, b.axZ], [b.azX, b.azZ]];
  for (const [vx, vz] of axes) {
    const ra = a.hx * Math.abs(a.axX * vx + a.axZ * vz) + a.hz * Math.abs(a.azX * vx + a.azZ * vz);
    const rb = b.hx * Math.abs(b.axX * vx + b.axZ * vz) + b.hz * Math.abs(b.azX * vx + b.azZ * vz);
    const dc = Math.abs((a.x - b.x) * vx + (a.z - b.z) * vz);
    if (dc > ra + rb + margin) return false;
  }
  return true;
}

/* axis-aligned OBB from any object's world bounding box (for small props) */
function boxOf(obj) {
  obj.updateMatrixWorld(true);
  const b = new THREE.Box3().setFromObject(obj);
  return obbFromAABB(b.min.x, b.max.x, b.min.z, b.max.z);
}
function collides(o, boxes, margin = 0.6) {
  for (const b of boxes) if (obbOverlap(o, b.obb, margin)) return true;
  return false;
}

const WEIGHTS = [['cottage', 28], ['townhouse', 22], ['stonehouse', 18], ['barn', 12], ['hut', 10], ['tower', 6]];
/* brown streets = poorer district: mostly huts & small cottages */
const WEIGHTS_POOR = [['hut', 46], ['cottage', 34], ['barn', 12], ['stonehouse', 5], ['townhouse', 3]];
/* red streets = richer district: townhouses, stone houses, the odd tower */
const WEIGHTS_RICH = [['townhouse', 40], ['stonehouse', 30], ['cottage', 13], ['tower', 10], ['barn', 7]];
const CAPS = { tower: 6, smithy: 1, tavern: 1, church: 1 };

function pickType(r, counts) {
  return pickTypeFor('yellow', r, counts);
}
function pickTypeFor(color, r, counts) {
  const w = color === 'brown' ? WEIGHTS_POOR : color === 'red' ? WEIGHTS_RICH : WEIGHTS;
  const total = w.reduce((s, x) => s + x[1], 0);
  let t = r() * total;
  let type = w[0][0];
  for (const [name, wt] of w) { t -= wt; if (t <= 0) { type = name; break; } }
  if (CAPS[type] && (counts[type] || 0) >= CAPS[type]) type = 'cottage';
  return type;
}

const SETBACK = 2.0;

function placeHouseAt(world, boxes, counts, stats, type, r, cx, cz, rotY) {
  const p = houseParams(type, r);
  // collision uses the oriented foundation footprint — exact for any yaw
  const o = obb(cx, cz, (p.w + 0.3) / 2, (p.d + 0.3) / 2, rotY);
  if (collides(o, boxes, 0.6)) return false;
  const g = makeHouse(p, r);
  g.position.set(cx, 0, cz);
  g.rotation.y = rotY;
  world.add(g);
  boxes.push({ obb: o, label: type });
  counts[type] = (counts[type] || 0) + 1;
  stats.houses++;
  stats.types[type] = (stats.types[type] || 0) + 1;
  return true;
}

/* try a house; if it doesn't fit, retry the same type (fresh random size),
   then fall back to smaller footprints so every lot still gets used */
function placeWithFallback(world, boxes, counts, stats, type, r, cx, cz, rotY) {
  for (let i = 0; i < 3; i++) {
    if (placeHouseAt(world, boxes, counts, stats, type, r, cx, cz, rotY)) return;
  }
  if (type !== 'cottage' && placeHouseAt(world, boxes, counts, stats, 'cottage', r, cx, cz, rotY)) return;
  if (type !== 'hut') placeHouseAt(world, boxes, counts, stats, 'hut', r, cx, cz, rotY);
}

/* convert the default axis-aligned spec into a polyline {points, halfW} */
function polylineFromSpec(s) {
  const pts = s.axis === 'x' ? [[s.from, s.at], [s.to, s.at]] : [[s.at, s.from], [s.at, s.to]];
  return { points: pts, halfW: s.halfW, name: s.name };
}

/* a flat ground "decal" (road / plaza) with a per-layer depth bias so that
   overlapping surfaces at crossings resolve deterministically instead of
   z-fighting — this is the correct fix for coplanar road intersections */
function decalMaterial(base, units) {
  const m = base.clone();
  m.polygonOffset = true;
  m.polygonOffsetFactor = 0;
  m.polygonOffsetUnits = units;
  return m;
}

/* street surface tint: brown = poorer district, red = richer, yellow = default */
function streetMaterial(color) {
  if (color === 'brown') return cloneTint(MAT.cobble, 0x9a6a4a);
  if (color === 'red') return cloneTint(MAT.cobble, 0xb2564a);
  return MAT.cobble;
}

/* effective color of segment j of a street: per-segment override, else street color */
function segColor(street, j) {
  return (street.segColors && street.segColors[j]) || street.color || 'yellow';
}

/* render the cobble quads + corner discs for one street polyline and
   register its collision boxes so houses never sit on top of it.
   Green segments are skipped (they are foliage strips, not road). */
function buildStreetVisual(world, street, boxes, idx, roadMats) {
  const pts = street.points;
  const hw = street.halfW;
  const yBase = 0.02;
  const matCache = {};   // color -> { quad, disc }, unique depth-bias per street
  function matsFor(color) {
    if (!matCache[color]) {
      const m = streetMaterial(color);
      matCache[color] = {
        quad: decalMaterial(m, -1 - 2 * idx),
        disc: decalMaterial(m, -2 - 2 * idx),
      };
      roadMats.push(matCache[color].quad, matCache[color].disc);
    }
    return matCache[color];
  }
  const isRoad = [];     // per segment: true if it gets cobble
  for (let i = 0; i < pts.length - 1; i++) isRoad.push(segColor(street, i) !== 'green');
  for (let i = 0; i < pts.length - 1; i++) {
    if (!isRoad[i]) continue;
    const ax = pts[i][0], az = pts[i][1];
    const bx = pts[i + 1][0], bz = pts[i + 1][1];
    const dx = bx - ax, dz = bz - az;
    const len = Math.hypot(dx, dz);
    if (len < 0.001) continue;
    const nx = -dz / len, nz = dx / len;      // right-hand perpendicular
    const A = new THREE.Vector3(ax - nx * hw, yBase, az - nz * hw);
    const B = new THREE.Vector3(bx - nx * hw, yBase, bz - nz * hw);
    const C = new THREE.Vector3(bx + nx * hw, yBase, bz + nz * hw);
    const D = new THREE.Vector3(ax + nx * hw, yBase, az + nz * hw);
    const { quad, disc } = matsFor(segColor(street, i));
    const road = new THREE.Mesh(quadGeo(A, B, C, D, [len / 2, hw]), quad);
    road.receiveShadow = true; road.castShadow = false;
    world.add(road);
    boxes.push({ obb: obbFromSegment(ax, az, bx, bz, hw), label: 'street' });
    // junction disc at the segment start (its color, only on road runs)
    const d0 = new THREE.Mesh(new THREE.CircleGeometry(hw, 20), disc);
    d0.rotation.x = -Math.PI / 2;
    d0.position.set(ax, yBase + 0.012, az);
    d0.receiveShadow = true; d0.castShadow = false;
    world.add(d0);
  }
  // closing disc at the very last node if the final segment is road
  if (isRoad[pts.length - 2]) {
    const { disc } = matsFor(segColor(street, pts.length - 2));
    const dN = new THREE.Mesh(new THREE.CircleGeometry(hw, 20), disc);
    dN.rotation.x = -Math.PI / 2;
    dN.position.set(pts[pts.length - 1][0], yBase + 0.012, pts[pts.length - 1][1]);
    dN.receiveShadow = true; dN.castShadow = false;
    world.add(dN);
  }
}

/* houses on BOTH sides of a polyline street, walking along every segment.
   Green segments are skipped — that stretch is foliage, not street. */
function fillStreet(world, boxes, counts, stats, r, street) {
  const pts = street.points;
  const hw = street.halfW;
  for (let i = 0; i < pts.length - 1; i++) {
    if (segColor(street, i) === 'green') continue;
    const ax = pts[i][0], az = pts[i][1];
    const bx = pts[i + 1][0], bz = pts[i + 1][1];
    const dx = bx - ax, dz = bz - az;
    const len = Math.hypot(dx, dz);
    if (len < 0.001) continue;
    const ux = dx / len, uz = dz / len;       // along the segment
    const nx = -uz, nz = ux;                  // across the segment
    let t = 1.0;
    while (t < len - 1.0) {
      let advance = 2.0;                       // fallback advance if nothing placed
      for (const side of [1, -1]) {
        if (r() < 0.06) continue;             // occasional empty lot
        const type = pickTypeFor(segColor(street, i), r, counts);
        const p = houseParams(type, r);
        // houses face the street: width runs along it, depth across it
        const off = hw + SETBACK + p.d / 2;
        const px = ax + ux * t, pz = az + uz * t;
        const cx = px + nx * side * off;
        const cz = pz + nz * side * off;
        // front (+Z local) faces the street centre line
        const rotY = Math.atan2(-nx * side, -nz * side);
        placeWithFallback(world, boxes, counts, stats, type, r, cx, cz, rotY);
        advance = Math.max(advance, p.w + 0.4);
      }
      t += advance + 0.8 + r() * 1.6;
    }
  }
}

/* street lamps along every street polyline */
function placeLamps(world, boxes, stats, r, streets) {
  for (const street of streets) {
    const pts = street.points;
    const hw = street.halfW;
    for (let i = 0; i < pts.length - 1; i++) {
      if (segColor(street, i) === 'green') continue;
      const ax = pts[i][0], az = pts[i][1];
      const bx = pts[i + 1][0], bz = pts[i + 1][1];
      const dx = bx - ax, dz = bz - az;
      const len = Math.hypot(dx, dz);
      if (len < 0.001) continue;
      const ux = dx / len, uz = dz / len;
      const nx = -uz, nz = ux;
      for (let t = 2.5; t < len - 1.5; t += 6) {
        for (const side of [1, -1]) {
          const lamp = makeLamp();
          lamp.position.set(ax + ux * t + nx * side * (hw + 1.1), 0, az + uz * t + nz * side * (hw + 1.1));
          const b = boxOf(lamp);
          if (!collides(b, boxes, 0.2)) { world.add(lamp); boxes.push({ obb: b, label: "lamp" }); stats.props++; }
        }
      }
    }
  }
}

/* a straight row of houses along X, fronts facing +z (face=1) or -z (face=-1) */
function fillRowX(world, boxes, counts, stats, r, zfront, fromX, toX, face) {
  let x = fromX + 0.5;
  while (x < toX - 0.5) {
    if (r() >= 0.06) {
      const type = pickType(r, counts);
      const p = houseParams(type, r);
      const cz = zfront + (face > 0 ? p.d / 2 : -p.d / 2);
      const rotY = face > 0 ? 0 : Math.PI;
      placeWithFallback(world, boxes, counts, stats, type, r, x, cz, rotY);
      x += p.w + 0.8 + r() * 1.8;
    } else {
      x += 1.8;
    }
  }
}

/* ------------------------------------------------------------------ */
/* 10. Full scene build                                                */
/* ------------------------------------------------------------------ */
export function buildVillage(seed = 2, opts = {}) {
  activeStyle = opts.psx === false ? 'modern' : 'psx';
  buildMaterials();
  const world = new THREE.Group();
  const r = mulberry32(seed);
  const stats = { houses: 0, types: {}, props: 0 };
  const counts = {};
  const boxes = [];   // everything placed (for collision)

  /* ---- ground ---- */
  const groundTex = MAT.grass.map;
  groundTex.repeat.set(95, 95);
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(320, 320), MAT.grass);
  ground.rotation.x = -Math.PI / 2;
  ground.receiveShadow = true;
  world.add(ground);

  /* ---- streets: drawn polylines, or the default layout ---- */
  const custom = opts.customStreets
    ? opts.customStreets.map(s => {
        const st = { points: s.points.map(p => [p[0], p[1]]), halfW: s.halfW || 2.5, color: s.color || 'yellow' };
        if (s.segColors && s.segColors.length) {
          st.segColors = st.points.slice(0, -1).map((_, j) => s.segColors[j] || st.color);
        }
        return st;
      })
    : null;
  /* green segments are foliage zones, not roads: they never get cobble,
     houses or lamps. A line whose segments are ALL green becomes one
     foliage region (closed loop → fill the inside; open → strip).
     Mixed lines stay roads: their green segments become separate strips. */
  const streets = [];
  const greenLines = [];
  if (custom) {
    for (const s of custom) {
      const n = s.points.length - 1;
      const allGreen = Array.from({ length: n }, (_, j) => segColor(s, j)).every(c => c === 'green');
      if (allGreen) {
        greenLines.push(s);
        continue;
      }
      for (let j = 0; j < n; j++) {
        if (segColor(s, j) === 'green') {
          greenLines.push({ points: [s.points[j], s.points[j + 1]], halfW: s.halfW });
        }
      }
      streets.push(s);
    }
  } else {
    for (const s of STREETS) streets.push(polylineFromSpec(s));
  }
  const isDefault = !custom;

  const roadMats = [];   // per-street decal materials (for wireframe toggle + depth bias)
  streets.forEach((s, i) => buildStreetVisual(world, s, boxes, i, roadMats));

  if (isDefault) {
    /* ---- market square (west end) ---- */
    const A = new THREE.Vector3(PLAZA.minX, 0.03, PLAZA.minZ);
    const B = new THREE.Vector3(PLAZA.maxX, 0.03, PLAZA.minZ);
    const C = new THREE.Vector3(PLAZA.maxX, 0.03, PLAZA.maxZ);
    const D = new THREE.Vector3(PLAZA.minX, 0.03, PLAZA.maxZ);
    const plazaMat = decalMaterial(MAT.cobble, -1);   // over the grass, under the streets
    roadMats.push(plazaMat);
    const plaza = new THREE.Mesh(quadGeo(A, B, C, D, [(PLAZA.maxX - PLAZA.minX) / 2, (PLAZA.maxZ - PLAZA.minZ) / 2]), plazaMat);
    plaza.receiveShadow = true; plaza.castShadow = false;
    world.add(plaza);
    boxes.push({ obb: obbFromAABB(PLAZA.minX, PLAZA.maxX, PLAZA.minZ, PLAZA.maxZ), label: 'street' });

    /* ---- special buildings ---- */
    const specials = [
      { type: 'church', cx: 37.5, cz: 0, rotY: -Math.PI / 2 },   // east end of Main St
      { type: 'tavern', cx: 0, cz: -8.6, rotY: 0 },               // south side of Main St
      { type: 'smithy', cx: 0, cz: 8.8, rotY: Math.PI },          // north side of Main St
      { type: 'tower', cx: -43.2, cz: 0, rotY: 0 },               // west gate
      { type: 'tower', cx: 0, cz: -21, rotY: 0 },                 // south gate
    ];
    for (const sp of specials) placeHouseAt(world, boxes, counts, stats, sp.type, r, sp.cx, sp.cz, sp.rotY);
  }

  /* ---- street filler (both sides) ---- */
  for (const s of streets) fillStreet(world, boxes, counts, stats, r, s);

  if (isDefault) {
    /* ---- plaza framing rows (just outside the square) ---- */
    fillRowX(world, boxes, counts, stats, r, 10 + SETBACK, -39, -29, 1);
    fillRowX(world, boxes, counts, stats, r, -(10 + SETBACK), -39, -29, -1);

    /* ---- well + market stalls in the square ---- */
    const well = makeWell();
    well.position.set(-34.2, 0, 0); world.add(well);
    boxes.push({ obb: boxOf(well), label: "well" });
    for (let i = 0; i < 6; i++) {
      const stall = makeStall(r);
      const sx = -38.5 + (i % 3) * 2.8;
      const sz = i < 3 ? -7.5 : 7.5;
      stall.position.set(sx, 0, sz);
      stall.rotation.y = i < 3 ? 0 : Math.PI;
      world.add(stall);
      boxes.push({ obb: boxOf(stall), label: "stall" });
      stats.props++;
    }
  }

  /* ---- lamps along every street ---- */
  placeLamps(world, boxes, stats, r, streets);

  /* ---- Stark Crafts forest: baked FBX trees / rocks / foliage ---- */
  const forest = buildForestModels(FOREST_TEXTURES);
  scatterForest(world, boxes, stats, r, forest);

  /* ---- green "foliage" lines: grow trees / rocks / undergrowth ---- */
  scatterGreenFoliage(world, boxes, stats, r, forest, greenLines);

  /* ---- scattered barrels / crates / hay near the streets ---- */
  for (let i = 0; i < 40; i++) {
    const x = -44 + r() * 88;
    const z = -27 + r() * 54;
    const obj = r() < 0.4 ? makeBarrel() : r() < 0.7 ? makeCrate() : makeHay();
    obj.position.set(x, 0, z);
    obj.rotation.y = r() * Math.PI;
    const b = boxOf(obj);
    if (!collides(b, boxes, 0.25)) { world.add(obj); boxes.push({ obb: b, label: "prop" }); stats.props++; }
  }

  let meshCount = 0;
  world.traverse(o => { if (o.isMesh) meshCount++; });
  stats.meshes = meshCount;
  stats.streets = streets.length;
  return { world, stats, boxes, materials: allMaterials.concat(roadMats) };
}
