// Headless smoke test for the village generator (run with node):
//   node test.js
import { buildVillage, obbOverlap } from './village.js';

function check(label, world, boxes, stats) {
  let bad = 0;
  world.traverse(o => {
    if (o.isMesh && (!isFinite(o.position.x) || !isFinite(o.position.y) || !isFinite(o.position.z))) bad++;
  });
  const isBld = l => !['street', 'tree', 'bush', 'lamp', 'prop', 'rock', 'well', 'stall', 'foliage'].includes(l);
  const isStreet = l => l === 'street';
  let bldOverlap = 0, onStreet = 0;
  for (let i = 0; i < boxes.length; i++) for (let j = i + 1; j < boxes.length; j++) {
    const a = boxes[i], b = boxes[j];
    const overlap = obbOverlap(a.obb, b.obb, 0);
    if (overlap && isBld(a.label) && isBld(b.label)) { bldOverlap++; console.log('  BLD OVERLAP', a.label, '<->', b.label); }
    if (overlap && isBld(a.label) && isStreet(b.label)) { onStreet++; console.log('  ON STREET', a.label, JSON.stringify(a.obb)); }
    if (overlap && isStreet(a.label) && isBld(b.label)) { onStreet++; console.log('  ON STREET', b.label, JSON.stringify(b.obb)); }
  }
  console.log(`[${label}] houses=${stats.houses} streets=${stats.streets} props=${stats.props} meshes=${stats.meshes} | non-finite=${bad} bldOverlaps=${bldOverlap} onStreet=${onStreet}`);
  return bad === 0 && bldOverlap === 0 && onStreet === 0;
}

let ok = true;

// 1) default layout
{
  const { world, stats, boxes } = buildVillage(2);
  ok = check('default', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 2) custom: a diagonal street
{
  const customStreets = [{ points: [[-20, -10], [0, 0], [20, 10]], halfW: 2.6 }];
  const { world, stats, boxes } = buildVillage(2, { customStreets });
  ok = check('diagonal', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 3) custom: an L-shaped street + a crossing one
{
  const customStreets = [
    { points: [[-25, 0], [25, 0]], halfW: 3.5 },
    { points: [[0, -20], [0, 20]], halfW: 2.2 },
  ];
  const { world, stats, boxes } = buildVillage(7, { customStreets });
  ok = check('cross', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 4) custom: a ring-ish multi-segment street
{
  const customStreets = [
    { points: [[-18, -14], [18, -14], [18, 14], [-18, 14], [-18, -14]], halfW: 2.4 },
  ];
  const { world, stats, boxes } = buildVillage(3, { customStreets });
  ok = check('ring', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 5) custom: empty array -> grass only (no streets)
{
  const { world, stats, boxes } = buildVillage(2, { customStreets: [] });
  ok = check('empty', world, boxes, stats) && ok;
}

// 6) colored streets: brown = poorer (huts/cottages), red = richer (townhouses/stone)
{
  const customStreets = [
    { points: [[-30, -12], [30, -12]], halfW: 2.6, color: 'brown' },
    { points: [[-30, 12], [30, 12]], halfW: 2.6, color: 'red' },
  ];
  const { world, stats, boxes } = buildVillage(5, { customStreets });
  ok = check('colored', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 7) green foliage lines: an open line (strip) + a closed loop (fill inside)
{
  const customStreets = [
    { points: [[-25, 0], [25, 0]], halfW: 2.6, color: 'green' },
    { points: [[-12, -12], [12, -12], [12, 12], [-12, 12], [-12, -12]], halfW: 2.6, color: 'green' },
  ];
  const { world, stats, boxes } = buildVillage(9, { customStreets });
  ok = check('foliage', world, boxes, stats) && ok;
  const foliageN = boxes.filter(b => ['tree', 'rock', 'foliage'].includes(b.label)).length;
  console.log('  foliage objects:', foliageN, '| streets:', stats.streets, '| houses:', stats.houses);
}

// 8) per-segment colors: one street, three segments brown/red/yellow
{
  const customStreets = [
    { points: [[-30, 0], [-10, 0], [10, 0], [30, 0]], halfW: 2.6, segColors: ['brown', 'red', 'yellow'] },
  ];
  const { world, stats, boxes } = buildVillage(5, { customStreets });
  ok = check('segcolors', world, boxes, stats) && ok;
  console.log('  types:', JSON.stringify(stats.types));
}

// 9) mixed green/yellow segments: road only on the yellow half, strip on the green half
{
  const customStreets = [
    { points: [[-24, 0], [0, 0], [24, 0]], halfW: 2.6, segColors: ['green', 'yellow'] },
  ];
  const { world, stats, boxes } = buildVillage(4, { customStreets });
  ok = check('mixedgreen', world, boxes, stats) && ok;
  const streetBoxes = boxes.filter(b => b.label === 'street');
  const badSide = streetBoxes.filter(b => b.obb.x < -1);   // nothing on the green half
  const foliageN = boxes.filter(b => ['tree', 'rock', 'foliage'].includes(b.label)).length;
  console.log('  street boxes:', streetBoxes.length, 'on green half:', badSide.length, '| foliage objects:', foliageN, '| houses:', stats.houses);
  if (badSide.length) { console.log('  FAIL: road/houses on green segment'); ok = false; }
  if (!foliageN) { console.log('  FAIL: no foliage along green segment'); ok = false; }
}

console.log(ok ? 'ALL OK' : 'FAILURES');