import * as THREE from 'three';
import { OrbitControls } from './lib/OrbitControls.js';
import { buildVillage } from './village.js';

const app = document.getElementById('app');

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
app.appendChild(renderer.domElement);

const scene = new THREE.Scene();

/* sky gradient dome */
const skyCanvas = document.createElement('canvas');
skyCanvas.width = 16; skyCanvas.height = 256;
const sctx = skyCanvas.getContext('2d');
const grad = sctx.createLinearGradient(0, 0, 0, 256);
grad.addColorStop(0.0, '#4a90d9');
grad.addColorStop(0.55, '#a8cbe8');
grad.addColorStop(0.75, '#dce8ec');
grad.addColorStop(1.0, '#e8e2d0');
sctx.fillStyle = grad; sctx.fillRect(0, 0, 16, 256);
const skyTex = new THREE.CanvasTexture(skyCanvas);
skyTex.colorSpace = THREE.SRGBColorSpace;
scene.background = new THREE.Color('#a8cbe8');
const sky = new THREE.Mesh(
  new THREE.SphereGeometry(260, 24, 12),
  new THREE.MeshBasicMaterial({ map: skyTex, side: THREE.BackSide, fog: false, depthWrite: false })
);
scene.add(sky);
scene.fog = new THREE.Fog('#c9d4d8', 110, 300);
const savedFog = scene.fog;

/* lights */
const hemi = new THREE.HemisphereLight('#cfe3ff', '#7a6a4e', 0.95);
scene.add(hemi);
const amb = new THREE.AmbientLight('#ffffff', 0.18);
scene.add(amb);
const sun = new THREE.DirectionalLight('#fff1d6', 2.4);
sun.position.set(55, 85, 40);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -85; sun.shadow.camera.right = 85;
sun.shadow.camera.top = 85; sun.shadow.camera.bottom = -85;
sun.shadow.camera.near = 10; sun.shadow.camera.far = 240;
sun.shadow.bias = -0.0004;
sun.shadow.normalBias = 0.02;
scene.add(sun);

/* ------------------------------------------------------------------ */
/* PSX pipeline: render to a low-res buffer, then nearest-upscale it   */
/* through a fullscreen pass that re-quantizes to 15-bit colour and    */
/* applies ordered (Bayer) dithering.                                  */
/* ------------------------------------------------------------------ */
const PSX_RES_SCALE = 1 / 3;

let psxMode = true;
let rt = null;
let quadScene = null, quadCam = null, quadMat = null;

function resizeRT() {
  const w = Math.max(2, Math.floor(window.innerWidth * PSX_RES_SCALE));
  const h = Math.max(2, Math.floor(window.innerHeight * PSX_RES_SCALE));
  if (rt) { rt.dispose(); rt = null; }
  rt = new THREE.WebGLRenderTarget(w, h, {
    minFilter: THREE.NearestFilter,
    magFilter: THREE.NearestFilter,
    generateMipmaps: false,
    depthBuffer: true,
  });
  rt.texture.colorSpace = THREE.SRGBColorSpace;
}

const QUAD_VERT = `
attribute vec2 position;
varying vec2 vUv;
void main() {
  vUv = position * 0.5 + 0.5;
  gl_Position = vec4(position, 0.0, 1.0);
}`;

const QUAD_FRAG = `
precision highp float;
uniform sampler2D tDiffuse;
uniform float uDither;
varying vec2 vUv;
float bayer4(vec2 p) {
  vec2 q = mod(p, 4.0);
  int x = int(q.x); int y = int(q.y); int v = 0;
  if (y == 0) { if (x == 0) v = 0; else if (x == 1) v = 8; else if (x == 2) v = 2; else v = 10; }
  else if (y == 1) { if (x == 0) v = 12; else if (x == 1) v = 4; else if (x == 2) v = 14; else v = 6; }
  else if (y == 2) { if (x == 0) v = 3; else if (x == 1) v = 11; else if (x == 2) v = 1; else v = 9; }
  else { if (x == 0) v = 15; else if (x == 1) v = 7; else if (x == 2) v = 13; else v = 5; }
  return float(v) / 16.0;
}
void main() {
  vec3 c = texture2D(tDiffuse, vUv).rgb;
  float levels = 32.0;
  float b = (bayer4(gl_FragCoord.xy) - 0.5) * uDither;
  vec3 q = clamp(floor(c * (levels - 1.0) + 0.5 + b) / (levels - 1.0), 0.0, 1.0);
  gl_FragColor = vec4(q, 1.0);
}`;

function setupQuad() {
  quadScene = new THREE.Scene();
  quadCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
  quadMat = new THREE.RawShaderMaterial({
    uniforms: { tDiffuse: { value: null }, uDither: { value: 1.1 } },
    vertexShader: QUAD_VERT,
    fragmentShader: QUAD_FRAG,
    depthTest: false,
    depthWrite: false,
  });
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 3, -1, -1, 3]), 2));
  // 2-component attribute: pre-seed a bounding sphere so computeBoundingSphere()
  // (which reads a 3rd component) is never invoked on this geometry.
  geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 0, 0), 2);
  const quad = new THREE.Mesh(geo, quadMat);
  quad.frustumCulled = false;   // fullscreen quad
  quadScene.add(quad);
}

function updatePipeline() {
  if (psxMode) {
    renderer.setPixelRatio(1);
    renderer.domElement.style.imageRendering = 'pixelated';
    if (!quadScene) setupQuad();
    resizeRT();
    sun.shadow.mapSize.set(512, 512);
  } else {
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.domElement.style.imageRendering = 'auto';
    sun.shadow.mapSize.set(2048, 2048);
  }
}

/* ------------------------------------------------------------------ */
/* village                                                             */
/* ------------------------------------------------------------------ */
let world, stats, materials, wireframeOn = false;
let currentSeed = 2;
let customStreets = null;   // null = default layout; [] or [streets] = drawn layout

const typeNames = { cottage: 'cottages', townhouse: 'townhouses', stonehouse: 'stone houses', hut: 'huts', barn: 'barns', tower: 'towers', tavern: 'tavern', smithy: 'smithy', church: 'church' };

function build(seed) {
  currentSeed = seed;
  if (world) { scene.remove(world); }
  const res = buildVillage(seed, { psx: psxMode, customStreets });
  world = res.world; stats = res.stats; materials = res.materials;
  scene.add(world);
  setWireframe(wireframeOn);
  updateStats();
}

function updateStats() {
  const statsEl = document.getElementById('stats');
  let breakdown = '';
  for (const [k, v] of Object.entries(stats.types)) breakdown += `${v} ${typeNames[k] || k}, `;
  let layout;
  if (customStreets === null) layout = 'default layout';
  else if (!customStreets.length) layout = 'empty plot';
  else {
    const isAllGreen = s => {
      const n = s.points.length - 1;
      for (let j = 0; j < n; j++) {
        if (((s.segColors && s.segColors[j]) || s.color || 'yellow') !== 'green') return false;
      }
      return true;
    };
    const streetN = customStreets.filter(s => !isAllGreen(s)).length;
    const greenN = customStreets.length - streetN;
    layout = `${streetN} street${streetN !== 1 ? 's' : ''}${greenN ? ` · ${greenN} foliage` : ''}`;
  }
  statsEl.textContent =
    `${stats.houses} buildings (${breakdown.replace(/, $/, '')}) · ` +
    `${stats.streets} streets · ${stats.props} props · ${stats.meshes} meshes · ` +
    `${psxMode ? 'PSX' : 'modern'} · ${layout}`;
}

build(currentSeed);
updatePipeline();

/* ------------------------------------------------------------------ */
/* cameras                                                             */
/* ------------------------------------------------------------------ */
const camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 500);
camera.position.set(44, 34, 46);
camera.lookAt(0, 0, -2);

const drawCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 400);
function fitDrawCam() {
  const aspect = window.innerWidth / window.innerHeight;
  const halfH = 30;
  const halfW = halfH * aspect;
  drawCam.left = -halfW; drawCam.right = halfW;
  drawCam.top = halfH; drawCam.bottom = -halfH;
  drawCam.position.set(0, 130, 0);
  drawCam.up.set(0, 0, -1);
  drawCam.lookAt(0, 0, 0);
  drawCam.updateProjectionMatrix();
}

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 1.5, -2);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.maxPolarAngle = 1.52;
controls.minDistance = 8;
controls.maxDistance = 150;
controls.update();

/* ------------------------------------------------------------------ */
/* draw-mode overlay (grid + preview line + markers)                   */
/* ------------------------------------------------------------------ */
const overlay = new THREE.Group();
scene.add(overlay);
const streetOverlay = new THREE.Group();   // drawn-street guides + selection highlight
overlay.add(streetOverlay);

const grid = new THREE.GridHelper(110, 55, 0xdddddd, 0x9a9a9a);
grid.position.y = 0.08;   // above the road surfaces so it never z-fights with them
grid.material.transparent = true;
grid.material.opacity = 0.22;
grid.material.depthWrite = false;
grid.visible = false;
overlay.add(grid);

const previewLine = new THREE.Line(
  new THREE.BufferGeometry(),
  new THREE.LineBasicMaterial({ color: 0xffd24a, depthTest: false, transparent: true, opacity: 0.95 })
);
previewLine.frustumCulled = false;
previewLine.renderOrder = 999;
previewLine.visible = false;
overlay.add(previewLine);

const markerGeo = new THREE.CircleGeometry(0.55, 20);
const markerMat = new THREE.MeshBasicMaterial({ color: 0xffd24a, depthTest: false, transparent: true, opacity: 0.95 });
const hoverMarker = new THREE.Mesh(markerGeo, markerMat);
hoverMarker.rotation.x = -Math.PI / 2;
hoverMarker.position.y = 0.05;
hoverMarker.renderOrder = 998;
hoverMarker.visible = false;
overlay.add(hoverMarker);
const pointMarkers = [];

/* ------------------------------------------------------------------ */
/* draw-mode state + interaction                                       */
/* ------------------------------------------------------------------ */
let drawMode = false;
let currentPoints = [];      // Vector3 on y=0
let hoverPoint = null;
let streetHalfW = 2.6;

const raycaster = new THREE.Raycaster();
const groundPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);

function groundPoint(e) {
  const ndc = new THREE.Vector2((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
  raycaster.setFromCamera(ndc, drawMode ? drawCam : camera);
  const hit = new THREE.Vector3();
  return raycaster.ray.intersectPlane(groundPlane, hit) ? hit : null;
}

function addPointMarker(p) {
  const m = new THREE.Mesh(markerGeo, markerMat);
  m.rotation.x = -Math.PI / 2;
  m.position.set(p.x, 0.05, p.z);
  m.renderOrder = 998;
  overlay.add(m);
  pointMarkers.push(m);
}
function clearMarkers() {
  for (const m of pointMarkers) overlay.remove(m);
  pointMarkers.length = 0;
}
function updatePreview() {
  const pts = [];
  for (const p of currentPoints) pts.push(p);
  if (hoverPoint && drawMode) pts.push(hoverPoint);
  const pos = new Float32Array(pts.length * 3);
  pts.forEach((p, i) => { pos[i * 3] = p.x; pos[i * 3 + 1] = 0.06; pos[i * 3 + 2] = p.z; });
  previewLine.geometry.dispose();
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  previewLine.geometry = g;
  previewLine.visible = pts.length >= 2;
}
function clearCurrentLine() {
  currentPoints.length = 0;
  hoverPoint = null;
  clearMarkers();
  previewLine.visible = false;
  hoverMarker.visible = false;
}
function addStreet() {
  if (currentPoints.length >= 2) {
    if (!customStreets) customStreets = [];
    customStreets.push({ points: currentPoints.map(p => [p.x, p.z]), halfW: streetHalfW, color: 'yellow' });
  }
  clearCurrentLine();
  build(currentSeed);
  redrawStreetOverlay();
  updateEditorMenu();
}
function undoPoint() {
  currentPoints.pop();
  clearMarkers();
  currentPoints.forEach(addPointMarker);
  updatePreview();
}

/* ------------------------------------------------------------------ */
/* tabs + panel wiring                                                 */
/* ------------------------------------------------------------------ */
const tabExplore = document.getElementById('tabExplore');
const tabDraw = document.getElementById('tabDraw');
const drawPanel = document.getElementById('drawPanel');

function setDrawMode(on) {
  drawMode = on;
  tabExplore.classList.toggle('active', !on);
  tabDraw.classList.toggle('active', on);
  drawPanel.style.display = on ? 'block' : 'none';
  editorMenu.style.display = on ? 'flex' : 'none';
  gizmoBar.style.display = 'none';
  controlsHint.style.display = on ? 'none' : 'block';
  if (on) {
    controls.enabled = false;
    scene.fog = null;
    fitDrawCam();
    grid.visible = true;
    renderer.domElement.style.cursor = editorMode === 'select' ? 'pointer' : 'crosshair';
    updatePreview();
  } else {
    controls.enabled = true;
    scene.fog = savedFog;
    grid.visible = false;
    renderer.domElement.style.cursor = 'grab';
    clearCurrentLine();
    selPoint = null; hoverPt = null; pointDrag = null; villageDirty = false;
    hidePointHelpers();
  }
}

const controlsHint = document.getElementById('controls');
/* small introspection hook (used by automated tests, harmless otherwise) */
window.__editor = () => ({
  editorMode, selTool, gizmoMode, snapOn, linesOn, selPoint, selection,
  overlayKids: streetOverlay.children.length,
  customStreets: customStreets ? JSON.parse(JSON.stringify(customStreets)) : null,
});

/* ------------------------------------------------------------------ */
/* street editor menu (bottom) + selection tool                        */
/* ------------------------------------------------------------------ */
const STREET_COLORS = {
  yellow: { label: 'Yellow', css: '#e6c15c', title: 'Normal street — mixed house types' },
  brown:  { label: 'Brown',  css: '#9a6a4a', title: 'Poorer houses along it' },
  red:    { label: 'Red',    css: '#c0483e', title: 'Richer houses along it' },
  green:  { label: 'Green',  css: '#5fae5a', title: 'Foliage instead of street (closed loop fills the inside)' },
};
let editorMode = 'draw';     // 'draw' | 'select'
let selTool = 'line';        // 'seg' | 'line' | 'rect' | 'point'
let selection = [];          // [{ s: streetIdx, g: segIdx }]   g = -1 → whole line
let hoverSel = null;         // { s, g } under the cursor in select mode
let rectDrag = null;         // marquee drag state (screen coords)
let selPoint = null;         // { s, p } selected point (point tool)
let hoverPt = null;          // { s, p } point under the cursor (point tool)
let pointDrag = null;        // { s, p, mode:'free'|'x'|'z', origX, origZ }
let villageDirty = false;    // point moved → rebuild village on release
let snapOn = true;           // magnet snapping for endpoints/points
let linesOn = true;          // eye icon: show street lines while in Draw mode
const SNAP_R = 1.7;          // snap radius (world units)

const editorMenu = document.createElement('div');
editorMenu.id = 'editorMenu';
editorMenu.style.cssText = 'position:fixed;bottom:12px;left:50%;transform:translateX(-50%);display:none;align-items:center;gap:8px;z-index:8;color:#f4ecd9;background:rgba(20,16,12,.74);backdrop-filter:blur(8px);border:1px solid rgba(244,236,217,.25);border-radius:12px;padding:5px 10px;font-size:11px;white-space:nowrap;max-width:98vw;';
const selBtn = document.createElement('button');
selBtn.id = 'modeToggle';
selBtn.textContent = '✥ Select lines';
selBtn.title = 'Toggle between drawing streets and selecting/coloring lines';
selBtn.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:5px 9px;border-radius:8px;font-size:10.5px;cursor:pointer;white-space:nowrap;';
selBtn.onclick = () => setEditorMode(editorMode === 'select' ? 'draw' : 'select');
const selInfo = document.createElement('span');
selInfo.style.cssText = 'opacity:.85;min-width:96px;text-align:center;font-size:10.5px;';
const toolRow = document.createElement('div');
toolRow.style.cssText = 'display:none;gap:5px;align-items:center;';
const TOOL_DEFS = [
  ['seg',   '▬ Segment',   'Select a single segment between two points'],
  ['line',  '─ Whole line', 'Select an entire line/street'],
  ['rect',  '▭ Rectangle', 'Drag a rectangle — select every segment inside it'],
  ['point', '● Point',     'Select a point, then drag the gizmo to move it'],
];
const toolButtons = {};
for (const [key, label, tip] of TOOL_DEFS) {
  const b = document.createElement('button');
  b.id = 'tool-' + key;
  b.textContent = label;
  b.title = tip;
  b.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:4px 8px;border-radius:8px;font-size:10.5px;cursor:pointer;white-space:nowrap;';
  b.onclick = () => setSelTool(key);
  toolButtons[key] = b;
  toolRow.appendChild(b);
}
/* magnet-snap toggle (works while drawing AND while dragging points) */
const snapBtn = document.createElement('button');
snapBtn.id = 'snapToggle';
snapBtn.textContent = '🧲 Snap';
snapBtn.title = 'Magnet snapping: while drawing or moving a point, nearby points pull the cursor in — click to close loops exactly';
snapBtn.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:4px 8px;border-radius:8px;font-size:10.5px;cursor:pointer;white-space:nowrap;';
snapBtn.onclick = () => { snapOn = !snapOn; if (!snapOn) snapRing.visible = false; updateEditorMenu(); };
/* eye icon: show/hide the drawn street lines while the Draw tab is active
   (in Select mode the lines always show, you need them to select) */
const linesBtn = document.createElement('button');
linesBtn.id = 'linesToggle';
linesBtn.textContent = '👁 Lines';
linesBtn.title = 'Show the street lines while drawing. When off, they are hidden in Draw mode (Select mode always shows them).';
linesBtn.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:4px 8px;border-radius:8px;font-size:10.5px;cursor:pointer;white-space:nowrap;';
linesBtn.onclick = () => { linesOn = !linesOn; redrawStreetOverlay(); updateEditorMenu(); };
/* gizmo mode bar: Move (drag the point) vs Curve (corner-cut smoothing) */
let gizmoMode = 'move';      // 'move' | 'curve'
const gizmoBar = document.createElement('div');
gizmoBar.id = 'gizmoBar';
gizmoBar.style.cssText = 'position:fixed;bottom:56px;left:50%;transform:translateX(-50%);display:none;gap:5px;align-items:center;z-index:8;color:#f4ecd9;background:rgba(20,16,12,.74);backdrop-filter:blur(8px);border:1px solid rgba(244,236,217,.25);border-radius:12px;padding:5px 10px;font-size:11px;white-space:nowrap;';
const gizmoBarLabel = document.createElement('span');
gizmoBarLabel.textContent = 'Gizmo:';
gizmoBarLabel.style.cssText = 'opacity:.7;font-size:10.5px;';
const gizmoModeButtons = {};
const GIZMO_MODES = [
  ['move',  '✥ Move',  'Drag the point (X / Z arrows or free center)'],
  ['curve', '⌅ Curve', 'Click the blue arc to smooth this corner — every click adds points and makes the curve smoother'],
];
for (const [key, label, tip] of GIZMO_MODES) {
  const b = document.createElement('button');
  b.id = 'gizmo-' + key;
  b.textContent = label;
  b.title = tip;
  b.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:4px 8px;border-radius:8px;font-size:10.5px;cursor:pointer;white-space:nowrap;';
  b.onclick = () => { gizmoMode = key; positionGizmo(); updateGizmoBar(); updateEditorMenu(); };
  gizmoModeButtons[key] = b;
  gizmoBar.append(b);
}
gizmoBar.prepend(gizmoBarLabel);
document.body.appendChild(gizmoBar);
function updateGizmoBar() {
  const show = drawMode && editorMode === 'select' && selTool === 'point';
  gizmoBar.style.display = show ? 'flex' : 'none';
  for (const [key, b] of Object.entries(gizmoModeButtons)) {
    b.style.borderColor = (gizmoMode === key) ? '#ffe27a' : 'rgba(244,236,217,.3)';
    b.style.background = (gizmoMode === key) ? 'rgba(255,226,122,.16)' : 'rgba(244,236,217,.10)';
  }
}
/* marquee rectangle overlay for the rectangle tool */
const marquee = document.createElement('div');
marquee.id = 'marquee';
marquee.style.cssText = 'position:fixed;display:none;border:1px dashed #ffe27a;background:rgba(255,226,122,.12);z-index:9;pointer-events:none;';
document.body.appendChild(marquee);
function updateMarquee() {
  if (!rectDrag) { marquee.style.display = 'none'; return; }
  marquee.style.display = 'block';
  marquee.style.left = Math.min(rectDrag.x0, rectDrag.x1) + 'px';
  marquee.style.top = Math.min(rectDrag.y0, rectDrag.y1) + 'px';
  marquee.style.width = Math.abs(rectDrag.x1 - rectDrag.x0) + 'px';
  marquee.style.height = Math.abs(rectDrag.y1 - rectDrag.y0) + 'px';
}

/* ---- point tool: move gizmo + snap / hover rings ---- */
function mkRing(inner, color, opacity) {
  const m = new THREE.Mesh(
    new THREE.RingGeometry(inner, inner + 0.35, 28),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity, depthTest: false, depthWrite: false, side: THREE.DoubleSide })
  );
  m.rotation.x = -Math.PI / 2;
  m.renderOrder = 999;
  m.visible = false;
  overlay.add(m);
  return m;
}
const snapRing = mkRing(0.7, 0xffe27a, 0.95);     // magnet target while drawing/dragging
const selPointRing = mkRing(1.35, 0xffffff, 0.95);  // selected point
const hoverPtRing = mkRing(0.75, 0xffffff, 0.6);   // point under cursor

const gizmo = new THREE.Group();
gizmo.visible = false;
const gizmoPickables = [];
function gizmoArrow(axis, color) {
  const alongX = axis === 'x';
  const mat = new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0.95, depthTest: false, depthWrite: false });
  const shaft = new THREE.Mesh(new THREE.BoxGeometry(alongX ? 5.6 : 0.06, 0.05, alongX ? 0.06 : 5.6), mat);
  const cone = new THREE.Mesh(new THREE.ConeGeometry(0.26, 0.66, 10), mat.clone());
  if (alongX) { cone.rotation.z = -Math.PI / 2; cone.position.x = 3.1; }
  else { cone.rotation.x = Math.PI / 2; cone.position.z = 3.1; }
  shaft.renderOrder = 1001; cone.renderOrder = 1001;
  /* fat invisible pick cylinder so the arrow is easy to grab */
  const pick = new THREE.Mesh(
    new THREE.CylinderGeometry(0.7, 0.7, 6.6, 8),
    new THREE.MeshBasicMaterial({ color, transparent: true, opacity: 0, depthWrite: false, depthTest: false })
  );
  if (alongX) pick.rotation.z = Math.PI / 2; else pick.rotation.x = Math.PI / 2;
  pick.userData.axis = axis;
  gizmo.add(shaft, cone, pick);
  gizmoPickables.push(pick);
}
gizmoArrow('x', 0xe6695e);
gizmoArrow('z', 0x5e9de6);
const gizmoCenter = new THREE.Mesh(
  new THREE.BoxGeometry(0.6, 0.14, 0.6),
  new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0.95, depthTest: false, depthWrite: false })
);
gizmoCenter.renderOrder = 1002;
const pickCenter = new THREE.Mesh(
  new THREE.BoxGeometry(1.4, 0.7, 1.4),
  new THREE.MeshBasicMaterial({ color: 0xffe27a, transparent: true, opacity: 0, depthWrite: false, depthTest: false })
);
pickCenter.userData.axis = 'free';
gizmo.add(gizmoCenter, pickCenter);
gizmoPickables.push(pickCenter);
overlay.add(gizmo);

/* curve gizmo: a blue arc on the selected corner — click it to smooth */
const curveHandle = new THREE.Group();
curveHandle.visible = false;
const curvePick = new THREE.Mesh(
  new THREE.CylinderGeometry(2.0, 2.0, 1.0, 12),
  new THREE.MeshBasicMaterial({ color: 0x7ec8ff, transparent: true, opacity: 0, depthWrite: false, depthTest: false })
);
curvePick.userData.curve = true;
curvePick.renderOrder = 1001;
const curveArc = new THREE.Mesh(
  new THREE.TorusGeometry(1.7, 0.12, 8, 40, Math.PI * 1.3),
  new THREE.MeshBasicMaterial({ color: 0x7ec8ff, transparent: true, opacity: 0.95, depthTest: false, depthWrite: false, side: THREE.DoubleSide })
);
curveArc.rotation.x = -Math.PI / 2;
curveArc.rotation.z = Math.PI * 0.35;
curveArc.renderOrder = 1001;
curveHandle.add(curvePick, curveArc);
overlay.add(curveHandle);

/* interior angle (degrees) at vertex i; handles closed loops */
function vertexAngleDeg(pts, i, closed) {
  const n = pts.length;
  const P = pts[i];
  let A, C;
  if (closed) {
    if (i === 0 || i === n - 1) { A = pts[n - 2]; C = pts[1]; }
    else { A = pts[i - 1]; C = pts[i + 1]; }
  } else {
    if (i <= 0 || i >= n - 1) return 180;
    A = pts[i - 1]; C = pts[i + 1];
  }
  const v1 = [A[0] - P[0], A[1] - P[1]], v2 = [C[0] - P[0], C[1] - P[1]];
  const l1 = Math.hypot(v1[0], v1[1]), l2 = Math.hypot(v2[0], v2[1]);
  if (!l1 || !l2) return 180;
  const d = (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2);
  return Math.acos(Math.max(-1, Math.min(1, d))) * 180 / Math.PI;
}
/* after a cut, jump the selection to the sharpest joint nearby so repeated
   clicks keep smoothing the same corner region */
function retargetSharpest(s, si, cands) {
  const pts = s.points, n = pts.length;
  const closed = n >= 4 && Math.hypot(pts[0][0] - pts[n - 1][0], pts[0][1] - pts[n - 1][1]) <= 1.5;
  let best = null, bestAng = 181;
  for (const i of cands) {
    if (i < 0 || i >= n) continue;
    if (!closed && (i === 0 || i === n - 1)) continue;
    const a = vertexAngleDeg(pts, i, closed);
    if (a < bestAng) { bestAng = a; best = i; }
  }
  if (best !== null) selPoint = { s: si, p: best };
}
/* neighbors of a point, or null if it is not a corner (endpoint) */
function pointCorner(s, pi) {
  const pts = s.points, n = pts.length;
  const closed = n >= 4 && Math.hypot(pts[0][0] - pts[n - 1][0], pts[0][1] - pts[n - 1][1]) <= 1.5;
  if (closed && (pi === 0 || pi === n - 1)) return { A: pts[n - 2], B: pts[0], C: pts[1], closed: true };
  if (pi > 0 && pi < n - 1) return { A: pts[pi - 1], B: pts[pi], C: pts[pi + 1], closed: false };
  return null;
}
/* one round of corner-cutting at a point: replaces the sharp corner B with
   two new points D,E (25% in from the corner along each edge) → +1 point,
   smoother curve. Repeating makes it smoother still. Returns true if applied. */
function smoothPointAt(si, pi) {
  const s = customStreets[si];
  if (!s) return false;
  const pts = s.points, n = pts.length;
  const corner = pointCorner(s, pi);
  if (!corner) return false;
  const cut = (P, Q) => [P[0] * 0.75 + Q[0] * 0.25, P[1] * 0.75 + Q[1] * 0.25];
  const col = j => (s.segColors && s.segColors[j]) || s.color || 'yellow';
  if (corner.closed) {
    /* loop corner (first == last): new loop D -> E -> P1 .. P(n-2) -> D */
    const B = pts[0];
    const D = cut(B, corner.A), E = cut(B, corner.C);
    const c0 = col(0), clast = col(n - 2);
    s.points = [D, E, ...pts.slice(1, n - 1), D];
    if (s.segColors) {
      s.segColors = [c0, c0, ...s.segColors.slice(1, n - 2), clast];
    }
    selPoint = { s: si, p: 0 };
    retargetSharpest(s, si, [0, 1, 2, s.points.length - 2]);
  } else {
    const D = cut(corner.B, corner.A), E = cut(corner.B, corner.C);
    const cPrev = col(pi - 1), cNext = col(pi);
    s.points = [...pts.slice(0, pi), D, E, ...pts.slice(pi + 1)];
    if (s.segColors) {
      s.segColors = [...s.segColors.slice(0, pi - 1), cPrev, cPrev, cNext, ...s.segColors.slice(pi + 1)];
    }
    /* keep pointing at the (new) corner point D, then jump to the sharpest joint */
    selPoint = { s: si, p: pi };
    retargetSharpest(s, si, [pi - 1, pi, pi + 1, pi + 2]);
  }
  /* remap stale per-segment selections on this line */
  const nSegs = s.points.length - 1;
  selection = selection.filter(e => e.s !== si || e.g === -1 || e.g < nSegs);
  hoverSel = null;
  return true;
}
function positionGizmo() {
  const sArr = (editorMode === 'select' && selTool === 'point' && selPoint &&
                customStreets && customStreets[selPoint.s]) ? customStreets[selPoint.s] : null;
  if (!sArr || selPoint.p >= sArr.points.length) {
    gizmo.visible = false;
    curveHandle.visible = false;
    selPointRing.visible = false;
    return;
  }
  const [px, pz] = sArr.points[selPoint.p];
  selPointRing.position.set(px, 0.07, pz);
  selPointRing.visible = true;
  if (gizmoMode === 'curve' && pointCorner(sArr, selPoint.p)) {
    gizmo.visible = false;
    curveHandle.position.set(px, 0.12, pz);
    curveHandle.visible = true;
  } else {
    curveHandle.visible = false;
    gizmo.position.set(px, 0.1, pz);
    gizmo.visible = true;
  }
}
function hidePointHelpers() {
  gizmo.visible = false;
  curveHandle.visible = false;
  selPointRing.visible = false;
  hoverPtRing.visible = false;
  snapRing.visible = false;
}
function setSelTool(key) {
  selTool = key;
  if (key === 'point') { selection = []; hoverSel = null; }
  else { selPoint = null; hoverPt = null; positionGizmo(); hoverPtRing.visible = false; }
  renderer.domElement.style.cursor = key === 'rect' ? 'crosshair' : 'pointer';
  redrawStreetOverlay();
  updateEditorMenu();
}
const colorRow = document.createElement('div');
colorRow.style.cssText = 'display:flex;gap:5px;align-items:center;';
const colorButtons = {};
for (const [key, meta] of Object.entries(STREET_COLORS)) {
  const b = document.createElement('button');
  b.id = 'color-' + key;
  const dot = document.createElement('span');
  dot.style.cssText = `display:inline-block;width:9px;height:9px;border-radius:50%;background:${meta.css};box-shadow:0 0 4px rgba(0,0,0,.5);`;
  b.appendChild(dot);
  b.appendChild(document.createTextNode(meta.label));
  b.title = meta.title;
  b.style.cssText = 'color:#f4ecd9;background:rgba(244,236,217,.10);border:1px solid rgba(244,236,217,.3);padding:4px 8px;border-radius:8px;font-size:10.5px;cursor:pointer;display:inline-flex;align-items:center;gap:5px;white-space:nowrap;';
  b.onclick = () => applyColor(key);
  colorButtons[key] = b;
  colorRow.appendChild(b);
}
editorMenu.append(selBtn, toolRow, snapBtn, linesBtn, selInfo, colorRow);
document.body.appendChild(editorMenu);

function setEditorMode(mode) {
  editorMode = mode;
  if (mode === 'select') {
    clearCurrentLine();
    hidePointHelpers();
    renderer.domElement.style.cursor = selTool === 'rect' ? 'crosshair' : 'pointer';
  } else {
    selection = [];
    hoverSel = null;
    selPoint = null;
    hoverPt = null;
    rectDrag = null;
    hidePointHelpers();
    updateMarquee();
    renderer.domElement.style.cursor = 'crosshair';
  }
  redrawStreetOverlay();
  updateEditorMenu();
}

/* ---- selection helpers ------------------------------------------------ */
function clearSelection() { selection = []; }
function isInSelection(s, g) {
  for (const e of selection) {
    if (e.s !== s) continue;
    if (e.g === -1 || e.g === g) return true;
  }
  return false;
}
function applyColor(color) {
  if (!selection.length || !customStreets) return;
  for (const e of selection) {
    const s = customStreets[e.s];
    if (!s) continue;
    if (e.g < 0) { s.color = color; delete s.segColors; continue; }
    const n = s.points.length - 1;
    if (!s.segColors) s.segColors = Array.from({ length: n }, () => s.color || 'yellow');
    s.segColors[e.g] = color;
    if (s.segColors.every(c => c === color)) { s.color = color; delete s.segColors; }
  }
  build(currentSeed);
  redrawStreetOverlay();
  updateEditorMenu();
}
function updateEditorMenu() {
  selBtn.style.borderColor = editorMode === 'select' ? '#ffe27a' : 'rgba(244,236,217,.3)';
  selBtn.textContent = editorMode === 'select' ? '✋ Stop selecting' : '✥ Select lines';
  toolRow.style.display = editorMode === 'select' ? 'flex' : 'none';
  for (const [key, b] of Object.entries(toolButtons)) {
    b.style.borderColor = (editorMode === 'select' && selTool === key) ? '#ffe27a' : 'rgba(244,236,217,.3)';
    b.style.background = (editorMode === 'select' && selTool === key) ? 'rgba(255,226,122,.16)' : 'rgba(244,236,217,.10)';
  }
  snapBtn.style.borderColor = snapOn ? '#ffe27a' : 'rgba(244,236,217,.3)';
  snapBtn.style.background = snapOn ? 'rgba(255,226,122,.16)' : 'rgba(244,236,217,.10)';
  snapBtn.style.opacity = snapOn ? '1' : '0.55';
  linesBtn.style.borderColor = linesOn ? '#ffe27a' : 'rgba(244,236,217,.3)';
  linesBtn.style.background = linesOn ? 'rgba(255,226,122,.16)' : 'rgba(244,236,217,.10)';
  linesBtn.style.opacity = linesOn ? '1' : '0.55';
  linesBtn.textContent = linesOn ? '👁 Lines on' : '👁 Lines off';
  /* selection summary */
  const canColor = selection.length > 0 && selTool !== 'point';
  if (editorMode === 'select' && selTool === 'point') {
    if (selPoint) selInfo.textContent = `Line ${selPoint.s + 1} · point ${selPoint.p + 1}`;
    else selInfo.textContent = (customStreets && customStreets.length) ? 'No point selected' : 'No lines drawn yet';
  } else if (!selection.length) {
    selInfo.textContent = (customStreets && customStreets.length) ? 'Nothing selected' : 'No lines drawn yet';
  } else if (selection.length === 1 && selection[0].g === -1) {
    const s = customStreets[selection[0].s];
    selInfo.textContent = `Line ${selection[0].s + 1} · ${STREET_COLORS[s ? (s.color || 'yellow') : 'yellow'].label}`;
  } else if (selection.length === 1) {
    const e = selection[0];
    const s = customStreets[e.s];
    const c = s ? ((s.segColors && s.segColors[e.g]) || s.color || 'yellow') : 'yellow';
    selInfo.textContent = `Line ${e.s + 1} · seg ${e.g + 1} · ${STREET_COLORS[c].label}`;
  } else {
    const lines = selection.filter(e => e.g === -1).length;
    const segs = selection.length - lines;
    const parts = [];
    if (lines) parts.push(`${lines} line${lines !== 1 ? 's' : ''}`);
    if (segs) parts.push(`${segs} segment${segs !== 1 ? 's' : ''}`);
    selInfo.textContent = parts.join(' + ') + ' selected';
  }
  /* active color = the one color shared by the whole selection, if any */
  let active = null;
  if (selection.length && customStreets && selTool !== 'point') {
    active = 'any';
    for (const e of selection) {
      const s = customStreets[e.s];
      if (!s) continue;
      const c = e.g < 0 ? (s.color || 'yellow') : ((s.segColors && s.segColors[e.g]) || s.color || 'yellow');
      if (active === 'any') active = c;
      else if (active !== c) { active = null; break; }
    }
    if (active === 'any') active = null;
  }
  for (const [k, b] of Object.entries(colorButtons)) {
    b.style.opacity = canColor ? '1' : '0.45';
    b.style.pointerEvents = canColor ? 'auto' : 'none';
    b.style.borderColor = (active === k) ? '#ffe27a' : 'rgba(244,236,217,.3)';
  }
  updateGizmoBar();
}

/* nearest drawn segment to a world-space XZ point (within a pick radius) */
function pickSeg(x, z) {
  if (!customStreets) return null;
  let best = null, bestD = 4.0;
  customStreets.forEach((s, si) => {
    const pts = s.points;
    for (let j = 0; j < pts.length - 1; j++) {
      const ax = pts[j][0], az = pts[j][1], bx = pts[j + 1][0], bz = pts[j + 1][1];
      const dx = bx - ax, dz = bz - az, L2 = dx * dx + dz * dz;
      let t = L2 ? ((x - ax) * dx + (z - az) * dz) / L2 : 0;
      t = Math.max(0, Math.min(1, t));
      const d = Math.hypot(x - (ax + dx * t), z - (az + dz * t));
      if (d < bestD) { bestD = d; best = { s: si, g: j }; }
    }
  });
  return best;
}
/* select every segment whose BOTH endpoints lie inside the world-space rect */
function selectInRect(ax, az, bx, bz) {
  const minX = Math.min(ax, bx), maxX = Math.max(ax, bx);
  const minZ = Math.min(az, bz), maxZ = Math.max(az, bz);
  selection = [];
  if (!customStreets) return;
  customStreets.forEach((s, si) => {
    for (let j = 0; j < s.points.length - 1; j++) {
      const [x1, z1] = s.points[j], [x2, z2] = s.points[j + 1];
      if (x1 >= minX && x1 <= maxX && z1 >= minZ && z1 <= maxZ &&
          x2 >= minX && x2 <= maxX && z2 >= minZ && z2 <= maxZ) {
        selection.push({ s: si, g: j });
      }
    }
  });
}
/* nearest drawn point to a world-space XZ point (point tool) */
function pickPoint(x, z) {
  if (!customStreets) return null;
  let best = null, bestD = 2.6;
  customStreets.forEach((s, si) => s.points.forEach(([px, pz], pi) => {
    const d = Math.hypot(x - px, z - pz);
    if (d < bestD) { bestD = d; best = { s: si, p: pi }; }
  }));
  return best;
}
/* magnet snapping: nearest point (of drawn lines and/or the line being
   drawn) within SNAP_R. exclude = {s,p} to skip the dragged point,
   extras = current in-progress line points, excludeExtraIdx skips the
   newest in-progress point (never snap to the point you just placed). */
function snapTarget(x, z, exclude, extras, excludeExtraIdx) {
  if (!snapOn) return null;
  let best = null, bestD = SNAP_R;
  if (customStreets) customStreets.forEach((s, si) => s.points.forEach(([px, pz], pi) => {
    if (exclude && exclude.s === si && exclude.p === pi) return;
    const d = Math.hypot(x - px, z - pz);
    if (d < bestD) { bestD = d; best = { x: px, z: pz, s: si, p: pi }; }
  }));
  if (extras) extras.forEach((c, i) => {
    if (i === excludeExtraIdx) return;
    const d = Math.hypot(x - c.x, z - c.z);
    if (d < bestD) { bestD = d; best = { x: c.x, z: c.z, extra: i }; }
  });
  return best;
}
/* flat ribbon strip along a polyline (used for guides + highlight) */
function ribbonGroup(pts, width, y, material) {
  const g = new THREE.Group();
  for (let i = 0; i < pts.length - 1; i++) {
    const ax = pts[i][0], az = pts[i][1], bx = pts[i + 1][0], bz = pts[i + 1][1];
    const dx = bx - ax, dz = bz - az, len = Math.hypot(dx, dz);
    if (len < 0.001) continue;
    const nx = -dz / len, nz = dx / len;
    const pos = new Float32Array([
      ax - nx * width, y, az - nz * width,
      bx - nx * width, y, bz - nz * width,
      bx + nx * width, y, bz + nz * width,
      ax + nx * width, y, az + nz * width,
    ]);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    geo.setIndex([0, 1, 2, 0, 2, 3]);
    /* the quads are wound for a top-down view of one orientation only —
       make them double-sided so the top-down draw camera always sees them */
    material.side = THREE.DoubleSide;
    const m = new THREE.Mesh(geo, material);
    m.renderOrder = 900;
    g.add(m);
  }
  return g;
}
function clearStreetOverlay() {
  for (const c of [...streetOverlay.children]) {
    streetOverlay.remove(c);
    c.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  }
}
function redrawStreetOverlay() {
  clearStreetOverlay();
  if (!customStreets || !customStreets.length) return;
  const selecting = editorMode === 'select';
  const showGuides = selecting || linesOn;   // eye toggle only affects Draw mode
  if (!showGuides) return;
  /* shared selection-highlight materials (disposed on clear) */
  const selFillMat = new THREE.MeshBasicMaterial({
    color: 0xfff6c8, transparent: true, opacity: 0.45, depthTest: false, depthWrite: false,
  });
  const selRailMat = new THREE.MeshBasicMaterial({
    color: 0xffdf5e, transparent: true, opacity: 1.0, depthTest: false, depthWrite: false,
  });
  /* one shared node-dot geometry for this pass (disposed on clear) */
  const dotGeo = markerGeo.clone();
  customStreets.forEach((s, si) => {
    const pts = s.points;
    /* per-segment colored guide ribbons */
    for (let j = 0; j < pts.length - 1; j++) {
      const c = segColorOf(s, j);
      const sel = selecting && isInSelection(si, j);
      const w = c === 'green' ? (s.halfW || 2.5) + 3.5 : 0.55;
      const guideMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(STREET_COLORS[c] ? STREET_COLORS[c].css : STREET_COLORS.yellow.css),
        transparent: true,
        opacity: c === 'green' ? 0.22 : (sel ? 0.95 : 0.55),
        depthTest: true, depthWrite: false,
      });
      streetOverlay.add(ribbonGroup([pts[j], pts[j + 1]], w, 0.055, guideMat));
    }
    /* bright center polyline + node dots (kept after Add street, too) */
    const linePos = new Float32Array(pts.length * 3);
    pts.forEach((p, i) => { linePos[i * 3] = p[0]; linePos[i * 3 + 1] = 0.07; linePos[i * 3 + 2] = p[1]; });
    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute('position', new THREE.BufferAttribute(linePos, 3));
    const line = new THREE.Line(lineGeo, new THREE.LineBasicMaterial({ color: 0xf4ecd9, transparent: true, opacity: 0.9 }));
    line.renderOrder = 901;
    streetOverlay.add(line);
    for (const p of pts) {
      const dot = new THREE.Mesh(dotGeo, markerMat);
      dot.rotation.x = -Math.PI / 2;
      dot.position.set(p[0], 0.05, p[1]);
      dot.renderOrder = 998;
      streetOverlay.add(dot);
    }
    if (!selecting) return;
    /* selection highlight: strong fill + thick yellow rails + end crossbars */
    for (let j = 0; j < pts.length - 1; j++) {
      if (!isInSelection(si, j)) continue;
      const c = segColorOf(s, j);
      const hw = c === 'green' ? (s.halfW || 2.5) + 3.5 : (s.halfW || 2.5);
      const [ax, az] = pts[j], [bx, bz] = pts[j + 1];
      const dx = bx - ax, dz = bz - az, len = Math.hypot(dx, dz);
      streetOverlay.add(ribbonGroup([pts[j], pts[j + 1]], hw, 0.12, selFillMat));
      if (len > 0.001) {
        const nx = -dz / len, nz = dx / len, off = Math.min(hw, 3.4) + 0.75;
        for (const side of [1, -1]) {
          streetOverlay.add(ribbonGroup(
            [[ax + nx * off * side, az + nz * off * side], [bx + nx * off * side, bz + nz * off * side]],
            0.5, 0.13, selRailMat));
        }
        /* crossbars at the open ends (skipped where the neighbour segment is selected too) */
        if (!isInSelection(si, j - 1)) {
          streetOverlay.add(ribbonGroup(
            [[ax + nx * off, az + nz * off], [ax - nx * off, az - nz * off]], 0.5, 0.13, selRailMat));
        }
        if (!isInSelection(si, j + 1)) {
          streetOverlay.add(ribbonGroup(
            [[bx + nx * off, bz + nz * off], [bx - nx * off, bz - nz * off]], 0.5, 0.13, selRailMat));
        }
      }
    }
    /* hover preview under the cursor */
    if (hoverSel && hoverSel.s === si) {
      const hoverSegs = hoverSel.g === -1
        ? Array.from({ length: pts.length - 1 }, (_, j) => j)
        : [hoverSel.g];
      for (const j of hoverSegs) {
        const c = segColorOf(s, j);
        const hw = c === 'green' ? (s.halfW || 2.5) + 3.5 : (s.halfW || 2.5);
        const hm = new THREE.MeshBasicMaterial({
          color: 0xffffff, transparent: true, opacity: 0.28,
          depthTest: false, depthWrite: false,
        });
        streetOverlay.add(ribbonGroup([pts[j], pts[j + 1]], hw, 0.11, hm));
      }
    }
  });
}
/* effective color of segment g — mirrors village.js segColor */
function segColorOf(s, g) {
  return (s.segColors && s.segColors[g]) || s.color || 'yellow';
}
updateEditorMenu();

tabExplore.addEventListener('click', () => setDrawMode(false));
tabDraw.addEventListener('click', () => setDrawMode(true));
document.getElementById('widthSel').addEventListener('change', e => { streetHalfW = parseFloat(e.target.value); });
document.getElementById('btnFinish').addEventListener('click', addStreet);
document.getElementById('btnUndo').addEventListener('click', undoPoint);
document.getElementById('btnClear').addEventListener('click', () => { customStreets = []; selection = []; hoverSel = null; selPoint = null; hoverPt = null; hidePointHelpers(); clearCurrentLine(); build(currentSeed); redrawStreetOverlay(); updateEditorMenu(); });
document.getElementById('btnDefault').addEventListener('click', () => { customStreets = null; selection = []; hoverSel = null; selPoint = null; hoverPt = null; hidePointHelpers(); clearCurrentLine(); build(currentSeed); redrawStreetOverlay(); updateEditorMenu(); });

renderer.domElement.addEventListener('pointerdown', e => {
  if (!drawMode || e.button !== 0) return;
  if (editorMode === 'select') {
    if (selTool === 'point') {
      const ndc = new THREE.Vector2((e.clientX / window.innerWidth) * 2 - 1, -(e.clientY / window.innerHeight) * 2 + 1);
      raycaster.setFromCamera(ndc, drawCam);
      /* curve gizmo: click the arc → smooth the corner one step */
      if (gizmoMode === 'curve' && curveHandle.visible && selPoint) {
        const curveHits = raycaster.intersectObjects([curvePick], false);
        if (curveHits.length) {
          smoothPointAt(selPoint.s, selPoint.p);
          build(currentSeed);
          positionGizmo();
          redrawStreetOverlay();
          updateEditorMenu();
          return;
        }
      }
      /* move gizmo handles take priority over picking a new point */
      if (gizmoMode === 'move' && gizmo.visible && selPoint) {
        const hits = raycaster.intersectObjects(gizmoPickables, false);
        if (hits.length) {
          const [px, pz] = customStreets[selPoint.s].points[selPoint.p];
          pointDrag = { s: selPoint.s, p: selPoint.p, mode: hits[0].object.userData.axis, origX: px, origZ: pz };
          return;
        }
      }
      const p = groundPoint(e);
      if (!p) return;
      selPoint = pickPoint(p.x, p.z);
      if (!selPoint) {
        /* clicked on a street rather than a node: grab the nearest endpoint
           of the nearest segment, so a click "on the street" still works */
        const seg = pickSeg(p.x, p.z);
        if (seg) {
          const sArr = customStreets[seg.s].points;
          const [ax, az] = sArr[seg.g], [bx, bz] = sArr[seg.g + 1];
          selPoint = Math.hypot(p.x - ax, p.z - az) <= Math.hypot(p.x - bx, p.z - bz)
            ? { s: seg.s, p: seg.g }
            : { s: seg.s, p: seg.g + 1 };
        }
      }
      positionGizmo();
      redrawStreetOverlay();
      updateEditorMenu();
      return;
    }
    if (selTool === 'rect') {
      rectDrag = { x0: e.clientX, y0: e.clientY, x1: e.clientX, y1: e.clientY, moved: false };
      updateMarquee();
      return;
    }
    const p = groundPoint(e);
    if (!p) return;
    const hit = pickSeg(p.x, p.z);
    if (!hit) {
      clearSelection();                       // clicked empty ground
    } else if (selTool === 'seg') {
      selection = [hit];
    } else {                                  // whole line
      selection = [{ s: hit.s, g: -1 }];
    }
    redrawStreetOverlay();
    updateEditorMenu();
    return;
  }
  const p = groundPoint(e);
  if (!p) return;
  /* magnet snap while placing points (never onto the point just placed) */
  const sn = snapTarget(p.x, p.z, null, currentPoints, currentPoints.length - 1);
  if (sn) { p.x = sn.x; p.z = sn.z; }
  currentPoints.push(p);
  addPointMarker(p);
  updatePreview();
});
renderer.domElement.addEventListener('pointermove', e => {
  if (!drawMode) { hoverMarker.visible = false; return; }
  if (editorMode === 'select') {
    if (pointDrag) {
      /* live point move: overlay updates instantly, village rebuilds on release */
      const p = groundPoint(e);
      if (p) {
        let nx = p.x, nz = p.z;
        if (pointDrag.mode === 'x') nz = pointDrag.origZ;
        if (pointDrag.mode === 'z') nx = pointDrag.origX;
        const sn = snapTarget(nx, nz, pointDrag, null, -1);
        if (sn) {
          if (pointDrag.mode === 'free') { nx = sn.x; nz = sn.z; }
          else if (pointDrag.mode === 'x') nx = sn.x;
          else nz = sn.z;
          snapRing.position.set(sn.x, 0.06, sn.z);
          snapRing.visible = true;
        } else snapRing.visible = false;
        customStreets[pointDrag.s].points[pointDrag.p] = [nx, nz];
        villageDirty = true;
        gizmo.position.set(nx, 0.1, nz);
        selPointRing.position.set(nx, 0.07, nz);
        redrawStreetOverlay();
      }
      return;
    }
    if (rectDrag) {
      rectDrag.x1 = e.clientX; rectDrag.y1 = e.clientY;
      if (Math.hypot(rectDrag.x1 - rectDrag.x0, rectDrag.y1 - rectDrag.y0) > 4) rectDrag.moved = true;
      updateMarquee();
      return;
    }
    const p = groundPoint(e);
    if (selTool === 'point') {
      hoverSel = null;
      hoverPt = p ? pickPoint(p.x, p.z) : null;
      if (hoverPt) {
        const [px, pz] = customStreets[hoverPt.s].points[hoverPt.p];
        hoverPtRing.position.set(px, 0.06, pz);
        hoverPtRing.visible = true;
      } else hoverPtRing.visible = false;
      hoverMarker.visible = false;
      return;
    }
    hoverPtRing.visible = false;
    /* hover preview of what would be picked */
    let h = p ? pickSeg(p.x, p.z) : null;
    if (h && selTool === 'line') h = { s: h.s, g: -1 };
    const changed = (h && (!hoverSel || hoverSel.s !== h.s || hoverSel.g !== h.g)) || (!h && hoverSel);
    hoverSel = h;
    hoverMarker.visible = false;
    if (changed) redrawStreetOverlay();
    return;
  }
  const p = groundPoint(e);
  /* magnet preview while drawing: pull the hover marker to nearby points */
  const sn = p ? snapTarget(p.x, p.z, null, currentPoints, currentPoints.length - 1) : null;
  if (sn) { p.x = sn.x; p.z = sn.z; snapRing.position.set(sn.x, 0.06, sn.z); snapRing.visible = true; }
  else snapRing.visible = false;
  hoverPoint = p;
  if (p) { hoverMarker.position.set(p.x, 0.05, p.z); hoverMarker.visible = true; }
  else hoverMarker.visible = false;
  updatePreview();
});
window.addEventListener('pointerup', e => {
  if (pointDrag) {
    pointDrag = null;
    snapRing.visible = false;
    if (villageDirty) {
      villageDirty = false;
      build(currentSeed);
      redrawStreetOverlay();
      updateEditorMenu();
    }
    return;
  }
  if (!rectDrag) return;
  const d = rectDrag;
  rectDrag = null;
  updateMarquee();
  if (!drawMode || editorMode !== 'select' || e.button !== 0) return;
  if (!d.moved || Math.hypot(d.x1 - d.x0, d.y1 - d.y0) < 6) {
    clearSelection();                         // plain click with rect tool: deselect
    redrawStreetOverlay();
    updateEditorMenu();
    return;
  }
  const a = groundPoint({ clientX: d.x0, clientY: d.y0 });
  const b = groundPoint({ clientX: d.x1, clientY: d.y1 });
  if (!a || !b) return;
  selectInRect(a.x, a.z, b.x, b.z);
  redrawStreetOverlay();
  updateEditorMenu();
});
renderer.domElement.addEventListener('dblclick', e => {
  if (!drawMode || editorMode !== 'draw') return;
  if (currentPoints.length > 0) { currentPoints.pop(); clearMarkers(); currentPoints.forEach(addPointMarker); }
  addStreet();
});
window.addEventListener('keydown', e => {
  if (!drawMode) return;
  if (editorMode === 'select') {
    if (e.key === 'Escape') {
      clearSelection(); hoverSel = null;
      selPoint = null; hoverPt = null;
      hidePointHelpers();
      redrawStreetOverlay(); updateEditorMenu();
    }
    return;
  }
  if (e.key === 'Enter') addStreet();
  else if (e.key === 'Escape') clearCurrentLine();
  else if (e.key === 'Backspace') { e.preventDefault(); undoPoint(); }
});

/* ------------------------------------------------------------------ */
/* top-right buttons                                                   */
/* ------------------------------------------------------------------ */
let autorotate = false;
function setWireframe(on) {
  materials.forEach(m => { if (m && m.isMeshStandardMaterial) m.wireframe = on; });
}
const btnRow = document.createElement('div');
btnRow.style.cssText = 'position:fixed;top:12px;right:12px;display:flex;gap:8px;z-index:6;';
function btn(label, fn) {
  const b = document.createElement('button');
  b.textContent = label;
  b.style.cssText = 'color:#f4ecd9;background:rgba(20,16,12,.55);border:1px solid rgba(244,236,217,.25);padding:7px 12px;border-radius:8px;font-size:12px;cursor:pointer;backdrop-filter:blur(6px);';
  b.onclick = fn;
  btnRow.appendChild(b);
  return b;
}
const pb = btn('PSX: ON', () => {
  psxMode = !psxMode;
  pb.textContent = 'PSX: ' + (psxMode ? 'ON' : 'OFF');
  updatePipeline();
  build(currentSeed);
});
const wb = btn('Wireframe', () => { wireframeOn = !wireframeOn; setWireframe(wireframeOn); wb.textContent = wireframeOn ? 'Solid' : 'Wireframe'; });
const nb = btn('New village', () => { build((Math.random() * 1e9) | 0); });
const rb = btn('Auto-rotate', () => { autorotate = !autorotate; rb.style.borderColor = autorotate ? '#d9b23a' : 'rgba(244,236,217,.25)'; });
document.body.appendChild(btnRow);

/* ------------------------------------------------------------------ */
/* resize + loop                                                       */
/* ------------------------------------------------------------------ */
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  if (psxMode) resizeRT();
  if (drawMode) fitDrawCam();
});

function animate() {
  requestAnimationFrame(animate);
  if (!drawMode) { controls.autoRotate = autorotate; controls.update(); }
  const cam = drawMode ? drawCam : camera;
  if (psxMode) {
    renderer.setRenderTarget(rt);
    renderer.render(scene, cam);
    renderer.setRenderTarget(null);
    quadMat.uniforms.tDiffuse.value = rt.texture;
    renderer.render(quadScene, quadCam);
  } else {
    renderer.render(scene, cam);
  }
}
animate();
