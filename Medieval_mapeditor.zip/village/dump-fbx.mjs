import * as THREE from 'three';
import { readFileSync } from 'fs';

// --- minimal browser polyfills for FBXLoader in Node ---
if (typeof globalThis.window === 'undefined') globalThis.window = globalThis;
if (typeof globalThis.self === 'undefined') globalThis.self = globalThis;
if (!globalThis.navigator) globalThis.navigator = { userAgent: 'node' };
if (!globalThis.atob) globalThis.atob = (s) => Buffer.from(s, 'base64').toString('binary');
if (!globalThis.btoa) globalThis.btoa = (s) => Buffer.from(s, 'binary').toString('base64');
if (!globalThis.Blob) globalThis.Blob = class { constructor(parts, opts) { this.parts = parts; this.type = opts && opts.type; } };
if (!globalThis.URL) globalThis.URL = { createObjectURL: () => '' };
if (!globalThis.document) {
  function fakeEl() {
    return { src: '', onload: null, onerror: null, width: 0, height: 0, getContext: () => null, style: {}, setAttribute() {}, getAttribute() { return null; }, addEventListener() {}, removeEventListener() {}, crossOrigin: '' };
  }
  globalThis.document = { createElement: () => fakeEl(), createElementNS: (_ns, n) => fakeEl() };
}

const { FBXLoader } = await import('three/examples/jsm/loaders/FBXLoader.js');

const buf = readFileSync('/home/user/forest_dl/extracted/PSX_Forest_Level_byStarkCrafts/PSX_Forest_AssetCollection_byStarkCrafts.fbx');
const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);

const loader = new FBXLoader();
let scene;
try {
  scene = loader.parse(ab, '');
} catch (e) {
  console.error('PARSE ERROR:', e.message);
  process.exit(1);
}

function fmt(v, d = 3) { return `${(+v.toFixed(d))}`; }
const box = new THREE.Box3();
const size = new THREE.Vector3();

function walk(o, depth) {
  const ind = '  '.repeat(depth);
  let info = '';
  if (o.isMesh) {
    o.updateMatrixWorld(true);
    const g = o.geometry;
    let gp = g.attributes.position ? g.attributes.position.count : 0;
    const mat = o.material;
    const mname = Array.isArray(mat) ? mat.map(m => m.name || m.type).join(',') : (mat ? (mat.name || mat.type) : 'none');
    const col = !Array.isArray(mat) && mat && mat.color ? '#' + mat.color.getHexString() : '';
    let msize = '';
    if (g.boundingBox) msize = ` bbox=[${fmt(g.boundingBox.min.x)},${fmt(g.boundingBox.min.y)},${fmt(g.boundingBox.min.z)}]-[${fmt(g.boundingBox.max.x)},${fmt(g.boundingBox.max.y)},${fmt(g.boundingBox.max.z)}]`;
    info = `MESH tris~${Math.round(gp / 3)} verts=${gp} mat="${mname}" ${col}${msize}`;
  } else if (o.isGroup) {
    info = `GROUP children=${o.children.length}`;
  } else if (o.isObject3D) {
    info = `OBJECT3D children=${o.children.length}`;
  } else {
    info = o.type;
  }
  const p = o.position, r = o.rotation, s = o.scale;
  const xf = `pos=(${fmt(p.x)},${fmt(p.y)},${fmt(p.z)}) rot=(${fmt(r.x,1)},${fmt(r.y,1)},${fmt(r.z,1)}) scl=(${fmt(s.x)},${fmt(s.y)},${fmt(s.z)})`;
  console.log(`${ind}${o.name || '(unnamed)'} [${o.type}] ${info} ${xf}`);
  for (const c of o.children) walk(c, depth + 1);
}
walk(scene, 0);
