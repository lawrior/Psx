extends StaticBody
class_name WitchCauldron

const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
const ItemTransferVisual = preload("res://characters/ItemTransferVisual.gd")

onready var liquid_mesh = $Liquid
onready var cauldron_belly = $Belly
onready var cauldron_rim = $Rim
onready var fire_embers = $FireEmbers
onready var overhead_label = $OverheadLabel

var ingredients : Array = []
const MAX_INGREDIENTS : int = 4

var default_liquid_col = Color(0.18, 0.85, 0.35)
var liquid_mat : SpatialMaterial = null
var bob_timer : float = 0.0

func _ready():
	add_to_group("witch_cauldron")
	setup_liquid_material()
	init_overhead_ui()
	update_overhead()

func init_overhead_ui():
	if ClassDB.class_exists("Label3D"):
		var lbl = Label3D.new()
		lbl.name = "CauldronLabel3D"
		lbl.billboard = SpatialMaterial.BILLBOARD_ENABLED
		lbl.pixel_size = 0.007
		lbl.translation = Vector3(0, 1.45, 0)
		var font_res = load("res://ui/KleintenDynFont.tres")
		if font_res:
			lbl.font = font_res
		add_child(lbl)
		overhead_label = lbl

func setup_liquid_material():
	liquid_mat = ItemMeshFactory.create_mat(default_liquid_col, 0.1, 0.25)
	liquid_mat.emission = default_liquid_col * 0.8
	liquid_mat.emission_energy = 0.9
	if liquid_mesh:
		liquid_mesh.material_override = liquid_mat

func _process(delta):
	bob_timer += delta * 4.0
	if liquid_mesh:
		liquid_mesh.translation.y = 0.74 + sin(bob_timer) * 0.015
		liquid_mesh.rotate_y(deg2rad(25.0) * delta)
		
	if fire_embers and fire_embers.material_override:
		var pulse = 0.7 + sin(bob_timer * 1.5) * 0.3
		fire_embers.material_override.emission_energy = pulse

func set_highlight(mode: int):
	# Apply highlight to cauldron rim and belly
	ItemMeshFactory.apply_highlight(self, mode)

func get_ingredients_summary() -> String:
	if ingredients.empty():
		return "Empty"
	var names = []
	for ing in ingredients:
		names.push_back(ing.get("name", "Ingredient"))
	return PoolStringArray(names).join(", ")

func update_overhead():
	if !overhead_label:
		return
	if ingredients.empty():
		overhead_label.text = "[ Witch's Cauldron ]\n(Bubbling Brew - Empty)\n[E] Add Fruit / Flower"
		overhead_label.modulate = Color(0.4, 0.9, 0.5, 0.9)
	else:
		var summary = get_ingredients_summary()
		overhead_label.text = "[ Witch's Cauldron ]\nContents (" + str(ingredients.size()) + "/" + str(MAX_INGREDIENTS) + "):\n" + summary + "\n[F] Stir & Cook!"
		overhead_label.modulate = Color(1.0, 0.85, 0.2, 1.0)

func can_add_ingredient() -> bool:
	return ingredients.size() < MAX_INGREDIENTS

func add_ingredient_from_player(item_data: Dictionary, player_node) -> bool:
	if ingredients.size() >= MAX_INGREDIENTS:
		if player_node:
			player_node.show_banner("⚠ Cauldron is already full! (" + str(MAX_INGREDIENTS) + "/" + str(MAX_INGREDIENTS) + ") Press [F] to cook!", Color(1.0, 0.6, 0.2, 1.0), 3.0)
		return false
		
	ingredients.push_back(item_data)
	
	# Mix liquid color
	blend_liquid_color(item_data)
	update_overhead()
	
	if player_node:
		var i_name = item_data.get("name", "Ingredient")
		player_node.show_banner("+ Added " + i_name + " to Cauldron! (" + str(ingredients.size()) + "/" + str(MAX_INGREDIENTS) + ")", Color(0.35, 1.0, 0.5, 1.0), 3.0)
		if player_node.pickup_info:
			player_node.pickup_info.add_custom_info("Added " + i_name + " into the Witch's Cauldron")
	return true

func blend_liquid_color(item_data: Dictionary):
	if !liquid_mat:
		return
	var id = item_data.get("id", "")
	
	var col = default_liquid_col
	if "poppy" in id or "apple" in id:
		col = Color(0.9, 0.18, 0.22) # Crimson / ruby
	elif "orchid" in id or "plum" in id:
		col = Color(0.65, 0.15, 0.9) # Purple / violet
	elif "marigold" in id or "pear" in id:
		col = Color(0.95, 0.78, 0.1) # Golden amber
	elif "frost" in id:
		col = Color(0.3, 0.85, 1.0) # Moonlit cyan
	else:
		col = Color(0.8, 0.4, 0.6)
		
	# Blend 50/50 with current color
	liquid_mat.albedo_color = liquid_mat.albedo_color.linear_interpolate(col, 0.5)
	liquid_mat.emission = liquid_mat.albedo_color * 0.85
	liquid_mat.emission_energy = 1.3

func cook(player_node):
	if ingredients.empty():
		if player_node:
			player_node.show_banner("⚠ The cauldron is empty! Pick fruits from trees or flowers first using [E]/[F]!", Color(1.0, 0.5, 0.2, 1.0), 3.5)
		return
		
	# Recipe Evaluation
	var recipe = evaluate_recipe()
	
	# Transfer visual: spawn cooked product flying from cauldron to player
	var cooked_item = {
		"name": recipe.name,
		"placeholder_id": recipe.placeholder_id,
		"desc": recipe.desc,
		"type": "cooked_dish",
		"start_pos": global_transform.origin + Vector3(0, 0.9, 0)
	}
	
	if player_node:
		var visual = ItemTransferVisual.new()
		get_tree().current_scene.add_child(visual)
		var cb = funcref(self, "on_cook_transfer_finished")
		visual.setup(cooked_item.start_pos, player_node, cooked_item, cb, false, null)
		
		# Add cooked item to inventory as consumable (effects applied when used)
		var inventory_key = get_inventory_key_for_recipe(recipe)
		if player_node.has_method("add_cooked_item"):
			player_node.add_cooked_item(inventory_key)
		
		# Small immediate reward (taste test bonus)
		if recipe.has("gold") and player_node.has_method("add_gold"):
			var taste_gold = int(recipe.gold * 0.2)  # 20% gold immediately
			player_node.add_gold(taste_gold)
		if recipe.has("heal") and player_node.has_method("heal"):
			var taste_heal = int(recipe.heal * 0.3)  # 30% heal immediately
			player_node.heal(taste_heal)
		
		player_node.show_banner("★ COOKED: " + recipe.name + "! (Added to Inventory - Press I to use)", Color(0.3, 1.0, 0.5, 1.0), 4.5)
		if player_node.pickup_info:
			player_node.pickup_info.add_custom_info("Brewed " + recipe.name + " - Use from Inventory [I] for full effects!")
			
	# Reset Cauldron
	ingredients.clear()
	reset_liquid()
	update_overhead()

func on_cook_transfer_finished(_item: Dictionary):
	pass

func get_inventory_key_for_recipe(recipe: Dictionary) -> String:
	# Map recipe names to inventory consumable keys
	var r_name = recipe.get("name", "")
	if "Grand Ambrosia" in r_name:
		return "ambrosia_stew"
	elif "Shadow Veil" in r_name:
		return "shadow_draught"
	elif "Sunfire" in r_name or "Haste" in r_name:
		return "haste_elixir"
	elif "Moonlit Frost" in r_name or "Frost" in r_name:
		return "frost_draught"
	elif "Vitality" in r_name:
		return "vitality_elixir"
	elif "Compote" in r_name:
		return "compote"
	else:
		# Default to vitality elixir for generic tonics
		return "vitality_elixir"

func reset_liquid():
	if liquid_mat:
		liquid_mat.albedo_color = default_liquid_col
		liquid_mat.emission = default_liquid_col * 0.8
		liquid_mat.emission_energy = 0.9

func evaluate_recipe() -> Dictionary:
	var count = ingredients.size()
	var has_fruit = false
	var has_flower = false
	var has_poppy = false
	var has_orchid = false
	var has_marigold = false
	var has_frost = false
	var has_apple = false
	var has_plum = false
	var has_pear = false
	
	for ing in ingredients:
		var id = ing.get("id", "")
		var cat = ing.get("category", "")
		if cat == "fruit": has_fruit = true
		if cat == "flower": has_flower = true
		if "poppy" in id: has_poppy = true
		if "orchid" in id: has_orchid = true
		if "marigold" in id: has_marigold = true
		if "frost" in id: has_frost = true
		if "apple" in id: has_apple = true
		if "plum" in id: has_plum = true
		if "pear" in id: has_pear = true
		
	# Recipe 1: 3+ Ingredients -> Grand Ambrosia Stew
	if count >= 3:
		return {
			"name": "Witch's Grand Ambrosia Stew",
			"placeholder_id": "stew",
			"desc": "Legendary mystical feast (+150 Gold, Full Heal, Max HP +30, Speed & Stealth Aura!)",
			"gold": 150,
			"heal": 100,
			"max_hp_bonus": 30,
			"speed_buff": true,
			"stealth_buff": true
		}
		
	# Recipe 2: Shadow Veil Draught (Violet Orchid or Plum)
	if has_orchid or (has_plum and has_flower):
		return {
			"name": "Shadow Veil Draught",
			"placeholder_id": "potion",
			"desc": "Mystic purple potion granting silent footsteps and elusive stealth (+60 Gold, Heals 40 HP)",
			"gold": 60,
			"heal": 40,
			"max_hp_bonus": 10,
			"stealth_buff": true
		}
		
	# Recipe 3: Sunfire Elixir of Haste (Sun Marigold or Pear)
	if has_marigold or (has_pear and has_flower):
		return {
			"name": "Sunfire Elixir of Haste",
			"placeholder_id": "potion",
			"desc": "Radiant golden draught boosting player speed (+70 Gold, Heals 45 HP)",
			"gold": 70,
			"heal": 45,
			"max_hp_bonus": 10,
			"speed_buff": true
		}
		
	# Recipe 4: Frost Lily Brew / Moonlit Frost Draught
	if has_frost:
		return {
			"name": "Moonlit Frost Draught",
			"placeholder_id": "potion",
			"desc": "Chilled celestial nectar granting protective barrier (+80 Gold, Heals 50 HP)",
			"gold": 80,
			"heal": 50,
			"max_hp_bonus": 15
		}
		
	# Recipe 5: Crimson Vitality Elixir (Apple + Poppy / Fruit + Flower)
	if (has_poppy and has_apple) or (has_fruit and has_flower):
		return {
			"name": "Witch's Vitality Elixir",
			"placeholder_id": "potion",
			"desc": "Potent restorative tonic (+50 Gold, Heals 65 HP, Max HP +20)",
			"gold": 50,
			"heal": 65,
			"max_hp_bonus": 20
		}
		
	# Recipe 6: 2 Fruits -> Sweet Orchard Compote
	if has_fruit and !has_flower and count >= 2:
		return {
			"name": "Sweet Orchard Fruit Compote",
			"placeholder_id": "stew",
			"desc": "Delicious caramel fruit dessert (+75 Gold, Heals 35 HP)",
			"gold": 75,
			"heal": 35,
			"max_hp_bonus": 10
		}
		
	# Recipe 7: 2 Flowers -> Floral Cleansing Tea
	if has_flower and !has_fruit and count >= 2:
		return {
			"name": "Floral Cleansing Herbal Tea",
			"placeholder_id": "potion",
			"desc": "Soothing aromatic infusion (+65 Gold, Heals 45 HP)",
			"gold": 65,
			"heal": 45,
			"max_hp_bonus": 10
		}
		
	# Recipe 8: Single ingredient simple cook
	var single_name = ingredients[0].get("name", "Ingredient")
	return {
		"name": "Simmered " + single_name + " Tonic",
		"placeholder_id": "potion",
		"desc": "Warm herbal infusion (+30 Gold, Heals 25 HP)",
		"gold": 30,
		"heal": 25,
		"max_hp_bonus": 5
	}

func apply_recipe_effects(recipe: Dictionary, player_node):
	if !is_instance_valid(player_node):
		return
		
	# Gold
	if recipe.has("gold") and player_node.has_method("add_gold"):
		player_node.add_gold(recipe.gold)
		
	# Heal
	if recipe.has("heal") and player_node.has_method("heal"):
		player_node.heal(recipe.heal)
		
	# Max HP bonus
	if recipe.has("max_hp_bonus") and recipe.max_hp_bonus > 0:
		if player_node.health_manager:
			player_node.health_manager.max_health += recipe.max_hp_bonus
			player_node.health_manager.cur_health = player_node.health_manager.max_health
			if player_node.pickup_manager:
				player_node.pickup_manager.max_player_health = player_node.health_manager.max_health
				
	# Speed buff
	if recipe.get("speed_buff", false) and player_node.has_method("apply_speed_buff"):
		player_node.apply_speed_buff(30.0) # 30 seconds speed boost!
		
	# Stealth veil
	if recipe.get("stealth_buff", false) and player_node.has_method("apply_stealth_buff"):
		player_node.apply_stealth_buff(40.0) # 40 seconds silent & hidden veil!
