extends KinematicBody

const ItemTransferVisual = preload("res://characters/ItemTransferVisual.gd")
const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
const DroppedLootItem = preload("res://characters/DroppedLootItem.gd")

var hotkeys = {
	KEY_1: 0,
	KEY_2: 1,
	KEY_3: 2,
	KEY_4: 3,
	KEY_5: 4,
	KEY_6: 5,
	KEY_7: 6,
	KEY_8: 7,
	KEY_9: 8,
}

export var mouse_sens = 0.5

onready var camera = $Camera
onready var character_mover = $CharacterMover
onready var health_manager = $HealthManager
onready var weapon_manager = $Camera/WeaponManager
onready var pickup_manager = $PickupManager
onready var stats_display = $CanvasLayer/StatsDisplay
onready var pickup_info = $CanvasLayer/PickupInfo

var dead = false

# Third-person system variables
var is_third_person = true
var character_model = null
var character_anim_player = null
var third_person_camera = null
var current_animation = "idle"
var character_rotation_target = 0.0

# Sneaking settings & state
const STAND_CAM_Y : float = 1.75
const CROUCH_CAM_Y : float = 0.95
const STAND_SPEED_SCALE : float = 1.0
const SNEAK_SPEED_SCALE : float = 0.4

var sneaking : bool = false
var noise_radius : float = 0.0
var gun_noise_timer : float = 0.0

# Gold, Tools, and Stolen Valuables
var gold : int = 0
var trinkets : Array = []
var tools_inventory : Array = []
var stolen_items_count : int = 0

# Harvested Ingredients (Fruits & Flowers) and Witch Buffs
var picked_ingredients : Array = []
var target_harvestable = null
var target_cauldron = null
var speed_buff_timer : float = 0.0
var stealth_buff_timer : float = 0.0

# Animal Form Transformation System
var form_manager = null

# Inventory System
var inventory_manager = null
var inventory_ui = null

# Merchant System
var merchant_manager = null
var merchant_ui = null

# Pickpocketing, Targeting & Interaction
var target_npc = null
var is_behind_target : bool = false
var interact_cooldown : float = 0.0

var target_item : Dictionary = {}
var target_item_node : Spatial = null
var is_item_focused : bool = false
var target_dropped_item = null

# UI elements for Pickpocket & Sneak feedback
var interact_label : Label = null
var interact_sublabel : Label = null
var banner_label : Label = null
var banner_bg : TextureRect = null
var banner_timer : float = 0.0

signal gold_changed(new_amount)

func _ready():
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	character_mover.init(self)
	
	pickup_manager.max_player_health = health_manager.max_health
	health_manager.connect("health_changed", pickup_manager, "update_player_health")
	pickup_manager.connect("got_pickup", weapon_manager, "get_pickup")
	pickup_manager.connect("got_pickup", health_manager, "get_pickup")
	health_manager.init()
	health_manager.connect("dead", self, "kill")
	weapon_manager.init($Camera/FirePoint, [self])
	weapon_manager.connect("weapon_fired", self, "on_weapon_fired")
	
	setup_custom_inputs()
	setup_hud_elements()
	update_stats_ui()
	ItemMeshFactory.warmup(self)
	
	# Initialize Animal Form Transformation System (Update 7)
	var FormManagerScript = preload("res://characters/AnimalFormManager.gd")
	form_manager = Spatial.new()
	form_manager.name = "AnimalFormManager"
	form_manager.set_script(FormManagerScript)
	add_child(form_manager)
	form_manager.init(self)
	
	# Initialize Inventory System (Update 8)
	var InventoryManagerScript = preload("res://characters/InventoryManager.gd")
	inventory_manager = Node.new()
	inventory_manager.name = "InventoryManager"
	inventory_manager.set_script(InventoryManagerScript)
	add_child(inventory_manager)
	
	var InventoryUIScript = preload("res://characters/InventoryUI.gd")
	inventory_ui = CanvasLayer.new()
	inventory_ui.name = "InventoryUI"
	inventory_ui.set_script(InventoryUIScript)
	add_child(inventory_ui)
	inventory_ui.init(inventory_manager)
	inventory_manager.connect("item_used", self, "_on_inventory_item_used")
	_sync_inventory()
	
	# Initialize Merchant System (Update 9)
	var MerchantManagerScript = preload("res://characters/MerchantManager.gd")
	merchant_manager = Node.new()
	merchant_manager.name = "MerchantManager"
	merchant_manager.set_script(MerchantManagerScript)
	add_child(merchant_manager)
	
	var MerchantUIScript = preload("res://characters/MerchantUI.gd")
	merchant_ui = CanvasLayer.new()
	merchant_ui.name = "MerchantUI"
	merchant_ui.set_script(MerchantUIScript)
	add_child(merchant_ui)
	merchant_ui.init(merchant_manager, self)
	
	# Initialize Third-Person Character (Update 9)
	setup_third_person_character()

func setup_third_person_character():
	# Load the girl character model
	var girl_scene = load("res://characters/girl_with_all_animations.glb")
	if !girl_scene:
		print("ERROR: Could not load girl character model")
		is_third_person = false
		return
	
	# Instance the character model
	character_model = girl_scene.instance()
	character_model.name = "CharacterModel"
	
	# Fix scale and orientation
	character_model.scale = Vector3(1.0, 1.0, 1.0)
	character_model.rotation_degrees = Vector3(0, 180, 0)  # Face forward
	
	add_child(character_model)
	
	# Find and set up AnimationPlayer from the GLB
	character_anim_player = null
	for child in character_model.get_children():
		if child is AnimationPlayer:
			character_anim_player = child
			break
	
	# If no AnimationPlayer found in children, search recursively
	if !character_anim_player:
		character_anim_player = _find_animation_player(character_model)
	
	if character_anim_player:
		print("Found AnimationPlayer with animations: ", character_anim_player.get_animation_list())
		# Start with idle animation
		if character_anim_player.has_animation("idle"):
			character_anim_player.play("idle")
			current_animation = "idle"
		elif character_anim_player.get_animation_list().size() > 0:
			# Play first available animation
			var first_anim = character_anim_player.get_animation_list()[0]
			character_anim_player.play(first_anim)
			current_animation = first_anim
	else:
		print("WARNING: No AnimationPlayer found in character model")
	
	# Hide first-person weapons
	var weapon_manager_node = get_node_or_null("Camera/WeaponManager")
	if weapon_manager_node:
		weapon_manager_node.visible = false
	
	# Set up third-person camera
	_setup_third_person_camera()
	
	is_third_person = true
	print("Third-person character loaded successfully")

func _find_animation_player(node):
	# Recursively search for AnimationPlayer
	for child in node.get_children():
		if child is AnimationPlayer:
			return child
		var found = _find_animation_player(child)
		if found:
			return found
	return null

func _setup_third_person_camera():
	# Create and attach ThirdPersonCamera
	var ThirdPersonCameraScript = preload("res://characters/player/ThirdPersonCamera.gd")
	
	# Disable existing camera
	var existing_camera = get_node_or_null("Camera")
	if existing_camera:
		existing_camera.current = false  # Disable as current camera
	
	# Create new third-person camera
	third_person_camera = Camera.new()
	third_person_camera.name = "ThirdPersonCamera"
	third_person_camera.set_script(ThirdPersonCameraScript)
	add_child(third_person_camera)
	
	# Configure camera settings BEFORE init
	third_person_camera.distance = 5.0
	third_person_camera.min_distance = 2.5
	third_person_camera.max_distance = 10.0
	third_person_camera.height_offset = 2.0
	third_person_camera.look_at_height = 1.5
	third_person_camera.pitch_min = -60.0
	third_person_camera.pitch_max = 60.0
	third_person_camera.mouse_sensitivity = 0.3
	third_person_camera.position_smoothing = 8.0
	third_person_camera.rotation_smoothing = 10.0
	
	# Initialize camera with player as target (after settings are configured)
	third_person_camera.init(self)
	
	# Make this the current camera
	third_person_camera.current = true
	
	# Update camera reference
	camera = third_person_camera
	
	print("Third-person camera set up successfully")

func setup_custom_inputs():
	if !InputMap.has_action("sneak"):
		InputMap.add_action("sneak")
		var ev_c = InputEventKey.new()
		ev_c.scancode = KEY_C
		InputMap.action_add_event("sneak", ev_c)
		var ev_ctrl = InputEventKey.new()
		ev_ctrl.scancode = KEY_CONTROL
		InputMap.action_add_event("sneak", ev_ctrl)
		var ev_shift = InputEventKey.new()
		ev_shift.scancode = KEY_SHIFT
		InputMap.action_add_event("sneak", ev_shift)

	if !InputMap.has_action("interact"):
		InputMap.add_action("interact")
		var ev_e = InputEventKey.new()
		ev_e.scancode = KEY_E
		InputMap.action_add_event("interact", ev_e)

	if !InputMap.has_action("steal"):
		InputMap.add_action("steal")
		var ev_f = InputEventKey.new()
		ev_f.scancode = KEY_F
		InputMap.action_add_event("steal", ev_f)

func setup_hud_elements():
	var canvas = $CanvasLayer
	var font_res = load("res://ui/KleintenDynFont.tres")
	
	# Adjust stats display size to fit gold, tools, stance, stealth
	if stats_display:
		stats_display.margin_right = 400.0
		stats_display.margin_bottom = 240.0
	
	# Interaction Prompt in Center
	var prompt_container = Control.new()
	prompt_container.name = "InteractPromptContainer"
	prompt_container.anchor_left = 0.5
	prompt_container.anchor_top = 0.65
	prompt_container.anchor_right = 0.5
	prompt_container.anchor_bottom = 0.65
	prompt_container.margin_left = -340.0
	prompt_container.margin_top = 0.0
	prompt_container.margin_right = 340.0
	prompt_container.margin_bottom = 85.0
	prompt_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(prompt_container)
	
	interact_label = Label.new()
	interact_label.name = "InteractLabel"
	interact_label.anchor_right = 1.0
	interact_label.margin_bottom = 35.0
	interact_label.align = Label.ALIGN_CENTER
	if font_res:
		interact_label.add_font_override("font", font_res)
	interact_label.text = ""
	prompt_container.add_child(interact_label)
	
	interact_sublabel = Label.new()
	interact_sublabel.name = "InteractSublabel"
	interact_sublabel.anchor_right = 1.0
	interact_sublabel.margin_top = 38.0
	interact_sublabel.margin_bottom = 75.0
	interact_sublabel.align = Label.ALIGN_CENTER
	interact_sublabel.modulate = Color(0.8, 0.8, 0.8, 0.9)
	interact_sublabel.text = ""
	prompt_container.add_child(interact_sublabel)

	# Action / Pickpocket Banner at Top Center
	var banner_container = Control.new()
	banner_container.name = "BannerContainer"
	banner_container.anchor_left = 0.5
	banner_container.anchor_top = 0.05
	banner_container.anchor_right = 0.5
	banner_container.anchor_bottom = 0.05
	banner_container.margin_left = -400.0
	banner_container.margin_top = 0.0
	banner_container.margin_right = 400.0
	banner_container.margin_bottom = 60.0
	banner_container.mouse_filter = Control.MOUSE_FILTER_IGNORE
	canvas.add_child(banner_container)
	
	banner_bg = TextureRect.new()
	banner_bg.name = "BannerBG"
	banner_bg.anchor_right = 1.0
	banner_bg.anchor_bottom = 1.0
	banner_bg.texture = load("res://ui/crypt_domino_1b.png")
	banner_bg.stretch_mode = TextureRect.STRETCH_TILE
	banner_bg.modulate = Color(0.1, 0.1, 0.1, 0.85)
	banner_bg.visible = false
	banner_container.add_child(banner_bg)
	
	banner_label = Label.new()
	banner_label.name = "BannerLabel"
	banner_label.anchor_right = 1.0
	banner_label.anchor_bottom = 1.0
	banner_label.align = Label.ALIGN_CENTER
	banner_label.valign = Label.VALIGN_CENTER
	if font_res:
		banner_label.add_font_override("font", font_res)
	banner_label.text = ""
	banner_label.visible = false
	banner_container.add_child(banner_label)

func show_banner(msg: String, color: Color = Color(1.0, 0.9, 0.2, 1.0), duration: float = 3.5):
	if !banner_label or !banner_bg:
		return
	banner_label.text = msg
	banner_label.modulate = color
	banner_bg.visible = true
	banner_label.visible = true
	banner_timer = duration

func on_weapon_fired():
	gun_noise_timer = 0.7

func _process(delta):
	if Input.is_action_just_pressed("exit"):
		get_tree().quit()
	if Input.is_action_just_pressed("restart"):
		get_tree().reload_current_scene()
	if dead:
		return
	
	# Update third-person character animations and rotation
	if is_third_person and character_model:
		_update_character_animation(delta)
		_update_character_rotation(delta)
		
	# Timers (always update)
	if gun_noise_timer > 0.0:
		gun_noise_timer -= delta
	if interact_cooldown > 0.0:
		interact_cooldown -= delta
	if banner_timer > 0.0:
		banner_timer -= delta
		if banner_timer <= 0.0:
			banner_bg.visible = false
			banner_label.visible = false
	if speed_buff_timer > 0.0:
		speed_buff_timer -= delta
		if speed_buff_timer <= 0.0:
			character_mover.set_speed_scale(SNEAK_SPEED_SCALE if sneaking else STAND_SPEED_SCALE)
			update_stats_ui()
	if stealth_buff_timer > 0.0:
		stealth_buff_timer -= delta
		if stealth_buff_timer <= 0.0:
			update_stats_ui()
	
	# Branch: Animal Form vs Human Form
	if form_manager and form_manager.is_transformed():
		# Animal form: camera and visuals handled by form_manager._process
		# Physics handled by form_manager._physics_process
		# Just update the form-specific HUD
		return
	
	# ===== HUMAN FORM LOGIC =====
	handle_sneak_input()
	update_sneak_physics(delta)
	
	# Movement input
	var move_vec = Vector3()
	if Input.is_action_pressed("move_forwards"):
		move_vec += Vector3.FORWARD
	if Input.is_action_pressed("move_backwards"):
		move_vec += Vector3.BACK
	if Input.is_action_pressed("move_left"):
		move_vec += Vector3.LEFT
	if Input.is_action_pressed("move_right"):
		move_vec += Vector3.RIGHT
		
	character_mover.set_move_vec(move_vec)
	if Input.is_action_just_pressed("jump"):
		if sneaking:
			# Stand up if crouching, or jump
			set_sneaking(false)
		character_mover.jump()
		
	# Weapon attack
	weapon_manager.attack(Input.is_action_just_pressed("attack"), Input.is_action_pressed("attack"))
	
	# Stealth scanning & Interactions
	scan_for_npcs()
	handle_interaction_input()
	update_stealth_state()

func handle_sneak_input():
	pass

func _input(event):
	# Form switching keys work in both human and animal form
	if event is InputEventKey and event.pressed:
		if form_manager:
			if event.scancode == KEY_Z:
				form_manager.transform_to(form_manager.FORM.FISH)
				return
			elif event.scancode == KEY_X:
				form_manager.transform_to(form_manager.FORM.BIRD)
				return
			elif event.scancode == KEY_V:
				form_manager.transform_to(form_manager.FORM.CAT)
				return
			elif event.scancode == KEY_B:
				form_manager.revert_to_human()
				return
	
	# If transformed, delegate all other input to form manager
	if form_manager and form_manager.is_transformed():
		form_manager._input_form(event)
		return
	
	# ===== HUMAN FORM INPUT =====
	if event is InputEventMouseMotion:
		# Don't rotate camera if inventory is open
		if inventory_ui and inventory_ui.is_open:
			return
		
		# In third-person mode, only rotate camera (not player body)
		if is_third_person:
			# Camera rotation is handled by ThirdPersonCamera._input
			# Don't rotate player body here
			pass
		else:
			# First-person mode: rotate player body and camera
			rotation_degrees.y -= mouse_sens * event.relative.x
			camera.rotation_degrees.x -= mouse_sens * event.relative.y
			camera.rotation_degrees.x = clamp(camera.rotation_degrees.x, -90, 90)
	if event is InputEventKey and event.pressed:
		if event.scancode in hotkeys:
			weapon_manager.switch_to_weapon_slot(hotkeys[event.scancode])
		# Toggle sneak with C
		if event.scancode == KEY_C:
			set_sneaking(!sneaking)
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == BUTTON_WHEEL_DOWN:
			weapon_manager.switch_to_next_weapon()
		if event.button_index == BUTTON_WHEEL_UP:
			weapon_manager.switch_to_last_weapon()

func set_sneaking(val: bool):
	sneaking = val
	if speed_buff_timer > 0.0:
		character_mover.set_speed_scale(1.45)
	else:
		character_mover.set_speed_scale(SNEAK_SPEED_SCALE if sneaking else STAND_SPEED_SCALE)

func is_sneaking() -> bool:
	return sneaking

func get_noise_radius() -> float:
	if stealth_buff_timer > 0.0:
		return 0.0 # Completely silent footsteps during shadow veil!
	if gun_noise_timer > 0.0:
		return 45.0
	if sneaking:
		return 0.0 # Completely silent footsteps while crouching!
	var spd = character_mover.velocity.length()
	if spd > 2.0 and character_mover.is_on_floor():
		return 7.5 # Footsteps audible within 7.5 meters
	return 0.0

func apply_speed_buff(duration: float):
	speed_buff_timer = duration
	character_mover.set_speed_scale(1.45)
	show_banner("⚡ SPEED SURGE: +45% Movement Speed for " + str(int(duration)) + "s!", Color(0.9, 0.9, 0.2, 1.0), 3.5)
	update_stats_ui()

func apply_stealth_buff(duration: float):
	stealth_buff_timer = duration
	show_banner("🌙 SHADOW VEIL: Silent Footsteps & Concealment for " + str(int(duration)) + "s!", Color(0.65, 0.4, 1.0, 1.0), 3.5)
	update_stats_ui()

func add_harvested_item(item: Dictionary):
	picked_ingredients.push_back(item)
	var cat = item.get("category", "ingredient")
	show_banner("★ HARVESTED: " + item.get("name", "Item") + "! (Added to Pantry)", Color(0.35, 1.0, 0.5, 1.0), 3.0)
	if pickup_info:
		pickup_info.add_custom_info("Harvested " + item.get("name", "Item") + " (" + cat.capitalize() + ")")
	update_stats_ui()
	# Sync to inventory
	if inventory_manager:
		var ing_name = item.get("name", "").to_lower()
		if "apple" in ing_name:
			inventory_manager.add_item("apple", 1)
		elif "plum" in ing_name:
			inventory_manager.add_item("plum", 1)
		elif "pear" in ing_name:
			inventory_manager.add_item("pear", 1)
		elif "poppy" in ing_name:
			inventory_manager.add_item("poppy", 1)
		elif "orchid" in ing_name:
			inventory_manager.add_item("orchid", 1)
		elif "marigold" in ing_name:
			inventory_manager.add_item("marigold", 1)
		elif "lily" in ing_name:
			inventory_manager.add_item("lily", 1)

func update_sneak_physics(delta):
	var target_cam_y = CROUCH_CAM_Y if sneaking else STAND_CAM_Y
	camera.translation.y = lerp(camera.translation.y, target_cam_y, 12.0 * delta)
	
	var col_shape = $CollisionShape
	if col_shape:
		var target_col_y = 0.55 if sneaking else 1.0
		col_shape.translation.y = lerp(col_shape.translation.y, target_col_y, 12.0 * delta)

# Pickpocket failure chance calculation:
# 1% base chance on 1st item, scaling up with every stolen item (e.g. 20% after 3 items)
func get_pickpocket_failure_chance() -> float:
	match stolen_items_count:
		0:
			return 0.01 # 1% base failure chance
		1:
			return 0.06 # 6%
		2:
			return 0.12 # 12%
		3:
			return 0.20 # 20% after 3 items
		4:
			return 0.30 # 30%
		5:
			return 0.42 # 42%
		_:
			return min(0.42 + (stolen_items_count - 5) * 0.12, 0.85)

func scan_for_npcs():
	var npcs = get_tree().get_nodes_in_group("npc")
	var cam_pos = camera.global_transform.origin
	var cam_forward = -camera.global_transform.basis.z
	var space_state = get_world().get_direct_space_state()
	
	target_npc = null
	target_item = {}
	target_item_node = null
	is_item_focused = false
	target_dropped_item = null
	target_harvestable = null
	target_cauldron = null
	
	# 0. Scan for nearby merchants (highest priority)
	var merchants = get_tree().get_nodes_in_group("merchant")
	for merchant in merchants:
		if is_instance_valid(merchant):
			var distance = global_transform.origin.distance_to(merchant.global_transform.origin)
			if distance <= 3.0:
				# Found a nearby merchant
				if merchant.has_method("get_interaction_prompt"):
					interact_label.text = merchant.get_interaction_prompt()
					interact_label.modulate = Color(1.0, 0.9, 0.4, 1.0)
					interact_sublabel.text = "Buy weapons, ammo, health packs, and tools"
				else:
					interact_label.text = "[E] Trade with Merchant"
					interact_label.modulate = Color(1.0, 0.9, 0.4, 1.0)
					interact_sublabel.text = "Buy weapons, ammo, health packs, and tools"
				target_npc = merchant  # Use target_npc to trigger interaction
				
				# Update merchant's pickpocket item highlights
				if merchant.has_method("update_pickpocket_highlights"):
					merchant.update_pickpocket_highlights(cam_pos, cam_forward)
				
				return
	
	# 1. Scan for nearby harvestable fruits & flowers (Fruit Trees & Flowerbeds)
	var harvestables = get_tree().get_nodes_in_group("pickable_harvest")
	var focused_harvest = null
	var best_harvest_dot = -1.0
	
	for h in harvestables:
		if !is_instance_valid(h):
			continue
		var h_pos = h.global_transform.origin
		var to_h = h_pos - cam_pos
		var h_dist = to_h.length()
		
		if h_dist <= 3.8:
			var dir_h = to_h.normalized()
			var dot_h = cam_forward.dot(dir_h)
			if dot_h > -0.1:
				var ray_h = space_state.intersect_ray(cam_pos, h_pos, [self, h], 1)
				if ray_h.empty():
					if dot_h >= 0.88 and dot_h > best_harvest_dot:
						best_harvest_dot = dot_h
						focused_harvest = h
					h.set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE)
				else:
					h.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			else:
				h.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
		else:
			h.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			
	if focused_harvest != null:
		target_harvestable = focused_harvest
		is_item_focused = true
		focused_harvest.set_highlight(ItemMeshFactory.HIGHLIGHT_FOCUSED) # GOLDEN EDGES!
		update_interact_prompt()
		return

	# 2. Scan for Witch's Cauldron
	var cauldrons = get_tree().get_nodes_in_group("witch_cauldron")
	var focused_cauldron = null
	for c in cauldrons:
		if !is_instance_valid(c):
			continue
		var c_pos = c.global_transform.origin + Vector3(0, 0.7, 0)
		var to_c = c_pos - cam_pos
		var c_dist = to_c.length()
		if c_dist <= 3.8:
			var dir_c = to_c.normalized()
			var dot_c = cam_forward.dot(dir_c)
			if dot_c > -0.1:
				var ray_c = space_state.intersect_ray(cam_pos, c_pos, [self, c], 1)
				if ray_c.empty():
					if dot_c >= 0.78:
						focused_cauldron = c
						c.set_highlight(ItemMeshFactory.HIGHLIGHT_FOCUSED)
					else:
						c.set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE)
				else:
					c.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			else:
				c.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
		else:
			c.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			
	if focused_cauldron != null:
		target_cauldron = focused_cauldron
		is_item_focused = true
		update_interact_prompt()
		return

	# 3. Scan for nearby dropped loot on the ground
	var dropped_items = get_tree().get_nodes_in_group("dropped_loot")
	var focused_drop = null
	var best_drop_dot = -1.0
	var nearest_drop = null
	var nearest_drop_dist = 4.0
	
	for d in dropped_items:
		if !is_instance_valid(d):
			continue
		var d_pos = d.global_transform.origin
		var to_d = d_pos - cam_pos
		var d_dist = to_d.length()
		
		if d_dist <= 3.8:
			var dir_d = to_d.normalized()
			var dot_d = cam_forward.dot(dir_d)
			
			if dot_d > -0.1:
				var ray_d = space_state.intersect_ray(cam_pos, d_pos, [self, d], 1)
				if ray_d.empty():
					# Line of sight clear! Check if player is aiming directly at it (dot >= 0.88)
					if dot_d >= 0.88 and dot_d > best_drop_dot:
						best_drop_dot = dot_d
						focused_drop = d
					if d_dist < nearest_drop_dist:
						nearest_drop_dist = d_dist
						nearest_drop = d
				else:
					d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			else:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
		else:
			d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
			
	# Apply highlights to dropped items:
	if focused_drop != null:
		target_dropped_item = focused_drop
		is_item_focused = true
		for d in dropped_items:
			if !is_instance_valid(d):
				continue
			if d == focused_drop:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_FOCUSED) # GOLDEN EDGES!
			elif global_transform.origin.distance_to(d.global_transform.origin) <= 3.8:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE) # White outline
			else:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
		update_interact_prompt()
		return
	elif nearest_drop != null and nearest_drop_dist <= 2.2:
		target_dropped_item = nearest_drop
		is_item_focused = false
		for d in dropped_items:
			if !is_instance_valid(d):
				continue
			if global_transform.origin.distance_to(d.global_transform.origin) <= 3.8:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE) # White outline
			else:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
		update_interact_prompt()
		return
	else:
		# If other dropped items exist within reach
		for d in dropped_items:
			if !is_instance_valid(d):
				continue
			if global_transform.origin.distance_to(d.global_transform.origin) <= 3.8:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE)
			else:
				d.set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
	
	# 4. Iterate through NPCs to collect reachable items and find closest NPC
	var reachable_items = []
	var closest_npc = null
	var closest_npc_dist = 3.6
	
	for npc in npcs:
		if !is_instance_valid(npc):
			continue
		var dist_npc = global_transform.origin.distance_to(npc.global_transform.origin)
		if dist_npc > 4.5:
			# NPC is far; turn off active highlights if set and skip heavy work
			if "visual_placeholders" in npc:
				for ph in npc.visual_placeholders:
					var node = ph.get("node", null)
					if is_instance_valid(node) and node.has_meta("hl_mode") and node.get_meta("hl_mode") != ItemMeshFactory.HIGHLIGHT_NONE:
						ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_NONE)
			continue
			
		if dist_npc < closest_npc_dist:
			closest_npc_dist = dist_npc
			closest_npc = npc
			
		var placeholders = []
		if "visual_placeholders" in npc:
			placeholders = npc.visual_placeholders
			
		for ph in placeholders:
			var node = ph.get("node", null)
			if !is_instance_valid(node):
				continue
			var item_pos = node.global_transform.origin
			var to_item = item_pos - cam_pos
			var dist = to_item.length()
			
			if dist <= 3.2:
				var dir = to_item.normalized()
				var dot = cam_forward.dot(dir)
				if dot > -0.1:
					var ray = space_state.intersect_ray(cam_pos, item_pos, [self, npc], 1)
					if ray.empty():
						if dot > 0.0:
							reachable_items.push_back({
								"item": ph.item,
								"node": node,
								"npc": npc,
								"dot": dot,
								"dist": dist
							})
						else:
							ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_CLOSE)
					else:
						ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_NONE)
				else:
					ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_NONE)
			else:
				ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_NONE)
				
	# 5. Pick the item closest to camera midpoint (highest dot product)
	var best_item_entry = null
	var max_dot = -1.0
	for entry in reachable_items:
		if entry.dot > max_dot:
			max_dot = entry.dot
			best_item_entry = entry
			
	if best_item_entry != null:
		target_item = best_item_entry.item
		target_item_node = best_item_entry.node
		target_npc = best_item_entry.npc
		# Focused precisely: dot >= 0.94 (roughly within 20 degrees of camera gaze midpoint)
		is_item_focused = (best_item_entry.dot >= 0.94)
	elif closest_npc != null and closest_npc_dist <= 3.2:
		target_npc = closest_npc
		is_item_focused = false
		
	# 6. Apply appropriate highlights to all reachable items
	for entry in reachable_items:
		var node = entry.node
		if node == target_item_node and is_item_focused:
			ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_FOCUSED)
		else:
			ItemMeshFactory.apply_highlight(node, ItemMeshFactory.HIGHLIGHT_CLOSE)
			
	# 7. If we have a target NPC, update prompt
	if target_npc:
		is_behind_target = target_npc.is_player_behind()
		update_interact_prompt()
	else:
		clear_interact_prompt()

func update_interact_prompt():
	if !interact_label:
		return
		
	if is_instance_valid(target_harvestable):
		var h_name = target_harvestable.get_item_name() if target_harvestable.has_method("get_item_name") else "Item"
		var h_desc = target_harvestable.get_item_desc() if target_harvestable.has_method("get_item_desc") else ""
		interact_label.text = "[ E / F ] Pick: " + h_name + " [GOLD FOCUS ★]"
		interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0)
		interact_sublabel.text = "Targeting: " + h_desc + " | Pantry: " + str(picked_ingredients.size()) + " items"
		return

	if is_instance_valid(target_cauldron):
		var in_cauldron = target_cauldron.get_ingredients_summary()
		if !picked_ingredients.empty():
			var next_ing = picked_ingredients[0].get("name", "Ingredient")
			interact_label.text = "[ E ] Add " + next_ing + " | [ F ] Stir & Cook [GOLD FOCUS ★]"
			interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0)
			interact_sublabel.text = "In Cauldron: " + in_cauldron + " (" + str(target_cauldron.ingredients.size()) + "/4) | Pantry: " + str(picked_ingredients.size()) + " items"
		elif target_cauldron.ingredients.size() > 0:
			interact_label.text = "[ F ] Stir & Cook Magical Concoction! [GOLD FOCUS ★]"
			interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0)
			interact_sublabel.text = "In Cauldron: " + in_cauldron + " (Ready to brew!)"
		else:
			interact_label.text = "[ Witch's Cauldron ] Empty | Add Fruits or Flowers!"
			interact_label.modulate = Color(0.4, 0.9, 0.6, 1.0)
			interact_sublabel.text = "Pick apples/plums from trees or flowers from the garden bed with [E]/[F]"
		return
		
	if is_instance_valid(target_dropped_item):
		var d_name = target_dropped_item.get_item_name() if target_dropped_item.has_method("get_item_name") else target_dropped_item.item_data.get("name", "Item")
		if is_item_focused:
			interact_label.text = "[ E / F ] Retrieve Dropped: " + d_name + " [GOLD FOCUS ★]"
			interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0)
			interact_sublabel.text = "Targeting dropped item on floor. Press [E] or [F] to pick up (or walk over it)"
		else:
			interact_label.text = "[ E / F ] Retrieve Dropped " + d_name
			interact_label.modulate = Color(0.3, 1.0, 0.5, 1.0)
			interact_sublabel.text = "Walk over or press [E]/[F] to pick up before being seen"
		return
		
	if !target_npc:
		return
		
	var n_name = target_npc.npc_name
	var pocket_count = target_npc.get_pocket_count()
	var visible_items = target_npc.get_visible_items_summary()
	var item_name = target_item.get("name", "") if !target_item.empty() else ""
	var item_desc = target_item.get("desc", "") if !target_item.empty() else ""
	var focus_tag = " [GOLD FOCUS ★]" if is_item_focused else ""
	
	var fail_pct = int(round(get_pickpocket_failure_chance() * 100.0))
	var succ_pct = 100 - fail_pct
	
	if target_npc.is_dead():
		if pocket_count > 0:
			if item_name != "":
				interact_label.text = "[ F ] Loot: " + item_name + focus_tag + " | [ E ] Inspect Body"
				interact_sublabel.text = "Targeting: " + item_desc + " (" + str(pocket_count) + " left on body)"
			else:
				interact_label.text = "[ F ] Loot " + n_name + "'s Body | [ E ] Inspect Body"
				interact_sublabel.text = "Items on body: " + visible_items + " (" + str(pocket_count) + " remaining)"
			interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0) if is_item_focused else Color(1.0, 0.9, 0.4, 1.0)
		else:
			interact_label.text = n_name + "'s body has no items left"
			interact_label.modulate = Color(0.6, 0.6, 0.6, 0.8)
			interact_sublabel.text = "[ E ] Inspect Body"
	elif target_npc.is_alerted():
		interact_label.text = "[ ! ] " + n_name + " is Alerted! [Guarding Items]"
		interact_label.modulate = Color(1.0, 0.3, 0.3, 1.0)
		interact_sublabel.text = "[ E ] Attempt to speak (Hostile) | [ F ] Cannot steal while noticed!"
	elif pocket_count == 0:
		interact_label.text = "[ E ] Talk to " + n_name + " | [All Items Stolen]"
		interact_label.modulate = Color(0.7, 0.7, 0.7, 0.8)
		interact_sublabel.text = "Pockets empty. Press [E] for normal conversation."
	elif is_behind_target:
		if sneaking:
			if item_name != "":
				interact_label.text = "[ F ] Steal: " + item_name + focus_tag + " (" + str(succ_pct) + "% Success [" + str(fail_pct) + "% Risk])"
				interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0) if is_item_focused else Color(0.25, 1.0, 0.35, 1.0)
				interact_sublabel.text = "[ E ] Tap Shoulder (Detects you!) | Target: " + item_desc + " | Stolen: " + str(stolen_items_count)
			else:
				interact_label.text = "[ F ] Steal from " + n_name + " (" + str(succ_pct) + "% Success [" + str(fail_pct) + "% Risk])"
				interact_label.modulate = Color(0.25, 1.0, 0.35, 1.0)
				interact_sublabel.text = "[ E ] Tap Shoulder (Detects you!) | Items: " + visible_items + " | Stolen: " + str(stolen_items_count)
		else:
			if item_name != "":
				interact_label.text = "[ F ] Steal: " + item_name + focus_tag + " (Standing - High Risk!)"
				interact_label.modulate = Color(1.0, 0.85, 0.15, 1.0) if is_item_focused else Color(1.0, 0.7, 0.2, 1.0)
				interact_sublabel.text = "[ E ] Tap Shoulder (Detects you!) | Crouch [C] to reduce risk | " + item_desc
			else:
				interact_label.text = "[ F ] Steal from " + n_name + " (Standing - High Risk!)"
				interact_label.modulate = Color(1.0, 0.85, 0.2, 1.0)
				interact_sublabel.text = "[ E ] Tap Shoulder (Detects you!) | Crouch [C] to reduce risk | Items: " + visible_items
	else:
		if item_name != "":
			interact_label.text = "[ E ] Talk to " + n_name + " | [ F ] Steal: " + item_name + " (Risky!)"
			interact_sublabel.text = "(Must sneak behind with [C] to steal unseen with [F]) | Looking at: " + item_name
		else:
			interact_label.text = "[ E ] Talk to " + n_name + " | [ F ] Steal (Risky from front!)"
			interact_sublabel.text = "(Must sneak behind with [C] to steal unseen with [F]) | Items: " + visible_items
		interact_label.modulate = Color(0.5, 0.85, 1.0, 1.0)

func clear_interact_prompt():
	if interact_label:
		interact_label.text = ""
	if interact_sublabel:
		interact_sublabel.text = ""
	target_item = {}
	target_item_node = null
	is_item_focused = false
	target_dropped_item = null
	target_harvestable = null
	target_cauldron = null

func handle_interaction_input():
	var has_target = target_npc or is_instance_valid(target_dropped_item) or is_instance_valid(target_harvestable) or is_instance_valid(target_cauldron)
	if !has_target or interact_cooldown > 0.0:
		return
		
	var steal_pressed = Input.is_action_just_pressed("steal") or (Input.is_key_pressed(KEY_F) and interact_cooldown <= 0.0)
	var interact_pressed = Input.is_action_just_pressed("interact") or (Input.is_key_pressed(KEY_E) and interact_cooldown <= 0.0)
	
	if steal_pressed:
		interact_cooldown = 0.35
		perform_steal_action()
	elif interact_pressed:
		interact_cooldown = 0.35
		perform_interact_action()

func perform_steal_action():
	# Check if picking fruit from tree or flower from bed
	if is_instance_valid(target_harvestable):
		target_harvestable.harvest(self)
		target_harvestable = null
		return

	# Check if stirring/cooking at Witch's Cauldron
	if is_instance_valid(target_cauldron):
		target_cauldron.cook(self)
		return

	# Check if retrieving dropped ground item
	if is_instance_valid(target_dropped_item):
		target_dropped_item.collect(self)
		target_dropped_item = null
		return
		
	if !target_npc:
		return
	var n_name = target_npc.npc_name
	var item_to_steal = null
	if !target_item.empty():
		item_to_steal = target_item
	
	# Looting a dead NPC
	if target_npc.is_dead():
		if target_npc.get_pocket_count() > 0:
			var stolen = target_npc.perform_pickpocket(self, item_to_steal)
			start_item_transfer(stolen, n_name, false)
		else:
			show_banner(n_name + "'s body has no items left to loot.", Color(0.7, 0.7, 0.7, 1.0))
		return
		
	# NPC is alerted: cannot steal
	if target_npc.is_alerted():
		show_banner("⚠ " + n_name + " is on guard! Hands off their belongings!", Color(1.0, 0.3, 0.3, 1.0))
		return
		
	# Pockets are empty
	if target_npc.get_pocket_count() == 0:
		show_banner("All items have already been stolen from " + n_name + "!", Color(0.7, 0.7, 0.7, 1.0))
		return
		
	# Player is in front of the NPC: attempting to steal to their face!
	if !is_behind_target:
		target_npc.catch_pickpocket(self)
		show_banner("⚠ CAUGHT STEALING TO THEIR FACE! " + n_name + " is furious!", Color(1.0, 0.2, 0.2, 1.0))
		if pickup_info:
			pickup_info.add_custom_info("CAUGHT stealing in front of " + n_name + "!")
		return
		
	# Player is behind the NPC
	# Calculate failure chance (1% base, +increases with every stolen item, 20% after 3 items)
	var failure_chance = get_pickpocket_failure_chance()
	var fail_roll = randf()
	
	# If standing, 50% additional risk of immediate catch
	if !sneaking and randf() < 0.5:
		target_npc.catch_pickpocket(self)
		show_banner("⚠ CAUGHT PICKPOCKETING! " + n_name + " noticed you while standing!", Color(1.0, 0.2, 0.2, 1.0))
		if pickup_info:
			pickup_info.add_custom_info("CAUGHT pickpocketing " + n_name + " while standing!")
		return
		
	if fail_roll < failure_chance:
		# FAILURE OCCURRED!
		# Mode 1 (~45%): Immediate detection without transfer starting
		# Mode 2 (~55%): Midway fumble (item slips, drops to ground, 50% detection check)
		var is_immediate = randf() < 0.45
		if is_immediate:
			target_npc.catch_pickpocket_immediate(self)
			show_banner("⚠ THEFT FAILED! " + n_name + " felt your hands before you could grab the item!", Color(1.0, 0.25, 0.2, 1.0))
			if pickup_info:
				pickup_info.add_custom_info("Caught by " + n_name + " before grabbing the item!")
			return
		else:
			# Midway drop failure: item detaches from NPC, flies halfway, drops to ground
			var stolen = target_npc.perform_pickpocket(self, item_to_steal)
			start_item_transfer(stolen, n_name, true) # is_fumble = true
			return
	else:
		# SUCCESS!
		var stolen = target_npc.perform_pickpocket(self, item_to_steal)
		start_item_transfer(stolen, n_name, false)
		var mode_desc = "Silent" if sneaking else "Lucky Standing"
		show_banner("★ STEALTH THEFT [F]: Pickpocketed " + stolen.name + "! (" + mode_desc + ")", Color(0.25, 1.0, 0.35, 1.0))

func perform_interact_action():
	# Check if picking fruit from tree or flower from bed
	if is_instance_valid(target_harvestable):
		target_harvestable.harvest(self)
		target_harvestable = null
		return

	# Check if adding ingredient to Witch's Cauldron
	if is_instance_valid(target_cauldron):
		if !picked_ingredients.empty():
			var ing = picked_ingredients.pop_front()
			var ok = target_cauldron.add_ingredient_from_player(ing, self)
			if !ok:
				picked_ingredients.push_front(ing)
			update_stats_ui()
		else:
			show_banner("Your pantry is empty! Pick fruits from trees or flowers from the flowerbed first.", Color(1.0, 0.65, 0.2, 1.0), 3.0)
		return

	# Check if retrieving dropped ground item
	if is_instance_valid(target_dropped_item):
		target_dropped_item.collect(self)
		target_dropped_item = null
		return
	
	# Check if interacting with merchant
	if is_instance_valid(target_npc) and target_npc.is_in_group("merchant"):
		open_merchant(target_npc)
		return
		
	if !target_npc:
		return
	var n_name = target_npc.npc_name
	
	if target_npc.is_dead():
		show_banner("Inspected " + n_name + "'s remains (" + str(target_npc.get_pocket_count()) + " items remain). Press [F] to loot.", Color(0.8, 0.8, 0.8, 1.0))
		return
		
	# Requirement 2: Button [E] interacts even if undetected, which detects the player!
	var was_behind = is_behind_target
	target_npc.interact_and_detect(self)
	
	if was_behind:
		show_banner("Tapped " + n_name + " on shoulder! [You have been detected!]", Color(1.0, 0.5, 0.2, 1.0))
		if pickup_info:
			pickup_info.add_custom_info("Interacted with " + n_name + " from behind - You are now DETECTED!")
	else:
		show_banner(n_name + ": \"" + target_npc.current_bark + "\"", Color(0.6, 0.9, 1.0, 1.0))

func start_item_transfer(stolen: Dictionary, n_name: String, is_fumble: bool = false):
	if stolen.empty():
		return
	var fallback_pos = global_transform.origin + Vector3.UP * 1.0
	if target_npc:
		fallback_pos = target_npc.global_transform.origin + Vector3.UP * 1.0
	var start_pos = stolen.get("start_pos", fallback_pos)
	
	var visual = ItemTransferVisual.new()
	get_tree().current_scene.add_child(visual)
	stolen["npc_source"] = n_name
	visual.setup(start_pos, self, stolen, funcref(self, "on_item_transfer_completed"), is_fumble, target_npc)

func on_item_transfer_completed(stolen: Dictionary):
	var n_name = stolen.get("npc_source", "NPC")
	stolen_items_count += 1
	apply_stolen_item(stolen, n_name)
	show_banner("★ ITEM TRANSFERRED: " + stolen.name + " (" + stolen.desc + ") -> Added to Main Character!", Color(0.3, 1.0, 0.4, 1.0), 3.5)

func apply_stolen_item(stolen: Dictionary, _n_name: String):
	if stolen.empty():
		return
	var item_type = stolen.get("type", "")
	var amount = stolen.get("amount", 0)
	
	match item_type:
		"gold":
			add_gold(amount)
			if pickup_info:
				pickup_info.add_custom_info("+" + str(amount) + " Gold Coins added to Main Character's purse")
		"tools":
			tools_inventory.push_back(stolen)
			add_gold(amount) # Tool value added to wealth
			if stats_display and stats_display.has_method("update_tools"):
				stats_display.update_tools(tools_inventory.size())
			if pickup_info:
				pickup_info.add_custom_info("Small Tools & Lockpicks equipped to Player belt! (+" + str(amount) + " Gold Value)")
			# Sync inventory
			if inventory_manager:
				inventory_manager.items["tools"].quantity = tools_inventory.size()
				inventory_manager.emit_signal("inventory_changed")
		"ammo":
			var ammo_type = stolen.get("ammo_type", Pickup.PICKUP_TYPES.MACHINE_GUN_AMMO)
			pickup_manager.emit_signal("got_pickup", ammo_type, amount)
			if pickup_info:
				pickup_info.add_custom_info("Transferred Ammo Pouch: +" + str(amount) + " rounds")
			# Sync inventory
			if inventory_manager:
				match ammo_type:
					Pickup.PICKUP_TYPES.MACHINE_GUN_AMMO:
						inventory_manager.add_item("machinegun_ammo", amount)
					Pickup.PICKUP_TYPES.SHOTGUN_AMMO:
						inventory_manager.add_item("shotgun_ammo", amount)
					Pickup.PICKUP_TYPES.ROCKET_AMMO:
						inventory_manager.add_item("rocket_ammo", amount)
		"health":
			heal(amount)
			if pickup_info:
				pickup_info.add_custom_info("Healed +" + str(amount) + " HP from " + stolen.name)
		"trinket":
			add_gold(amount)
			trinkets.push_back(stolen.name)
			if pickup_info:
				pickup_info.add_custom_info("Transferred Valuables: " + stolen.name + " (+" + str(amount) + " Gold)!")
			# Sync inventory
			if inventory_manager:
				inventory_manager.items["trinkets"].quantity = trinkets.size()
				inventory_manager.emit_signal("inventory_changed")

func add_cooked_item(item_key: String):
	# Called by WitchCauldron when cooking produces a consumable
	if inventory_manager:
		inventory_manager.add_item(item_key, 1)
		show_banner("★ COOKED: " + inventory_manager.items[item_key].name + " added to Inventory!", Color(0.8, 0.5, 1.0, 1.0), 3.5)

func update_stealth_state():
	var npcs = get_tree().get_nodes_in_group("npc")
	var is_detected = false
	var is_suspicious = false
	
	for npc in npcs:
		if !is_instance_valid(npc) or npc.is_dead():
			continue
		if npc.can_see_player():
			is_detected = true
			break
		if npc.cur_state == npc.STATES.SUSPICIOUS or npc.cur_state == npc.STATES.ALERTED:
			is_suspicious = true
			
	var stealth_text = "HIDDEN"
	if is_detected:
		stealth_text = "! DETECTED"
	elif is_suspicious:
		stealth_text = "? SUSPICIOUS"
		
	var stance_text = "CROUCHED" if sneaking else "STANDING"
	if stats_display and stats_display.has_method("update_stealth"):
		stats_display.update_stealth(stance_text, stealth_text)

func update_stats_ui():
	if stats_display:
		stats_display.update_gold(gold)
		if stats_display.has_method("update_tools"):
			stats_display.update_tools(tools_inventory.size())
		var buff_text = ""
		if speed_buff_timer > 0.0 and stealth_buff_timer > 0.0:
			buff_text = "HASTE + SHADOW"
		elif speed_buff_timer > 0.0:
			buff_text = "HASTE SPEED"
		elif stealth_buff_timer > 0.0:
			buff_text = "SHADOW VEIL"
		if stats_display.has_method("update_pantry"):
			stats_display.update_pantry(picked_ingredients.size(), buff_text)
		var stance_text = "CROUCHED" if sneaking else "STANDING"
		var stealth_text = "SHADOW VEIL" if stealth_buff_timer > 0.0 else "HIDDEN"
		if form_manager and form_manager.is_transformed():
			stance_text = form_manager.get_form_name().to_upper() + " FORM"
			stealth_text = "DISGUISED"
		stats_display.update_stealth(stance_text, stealth_text)

func on_form_changed(form):
	# Called by AnimalFormManager when form changes
	update_stats_ui()
	if form == 0:  # HUMAN
		show_banner("* Reverted to Human Form! [Z]Fish [X]Bird [V]Cat", Color(0.7, 0.9, 1.0, 1.0), 3.0)
	# Reset camera pitch when reverting
	if form == 0 and camera:
		camera.rotation_degrees.x = 0.0

func add_gold(amount: int):
	gold += amount
	if stats_display:
		stats_display.update_gold(gold)
	emit_signal("gold_changed", gold)
	# Sync inventory
	if inventory_manager:
		inventory_manager.items["gold"].quantity = gold
		inventory_manager.emit_signal("inventory_changed")

func hurt(damage, dir):
	health_manager.hurt(damage, dir)
	
func heal(amount):
	health_manager.heal(amount)
	
func kill():
	dead = true
	character_mover.freeze()

# =====================================================================
# INVENTORY SYSTEM INTEGRATION
# =====================================================================

func _sync_inventory():
	if !inventory_manager:
		return
	# Sync gold
	inventory_manager.items["gold"].quantity = gold
	# Sync tools
	inventory_manager.items["tools"].quantity = tools_inventory.size()
	# Sync trinkets
	inventory_manager.items["trinkets"].quantity = trinkets.size()
	# Sync ingredients from pantry
	for ing in picked_ingredients:
		var ing_name = ing.get("name", "").to_lower()
		if "apple" in ing_name:
			inventory_manager.add_item("apple", 1)
		elif "plum" in ing_name:
			inventory_manager.add_item("plum", 1)
		elif "pear" in ing_name:
			inventory_manager.add_item("pear", 1)
		elif "poppy" in ing_name:
			inventory_manager.add_item("poppy", 1)
		elif "orchid" in ing_name:
			inventory_manager.add_item("orchid", 1)
		elif "marigold" in ing_name:
			inventory_manager.add_item("marigold", 1)
		elif "lily" in ing_name:
			inventory_manager.add_item("lily", 1)
	inventory_manager.emit_signal("inventory_changed")

func _on_inventory_item_used(item_key: String):
	# Handle consumable effects when used from inventory
	match item_key:
		"vitality_elixir":
			heal(65)
			health_manager.max_health += 20
			add_gold(50)
			show_banner("★ USED: Vitality Elixir! +65 HP, +20 Max HP, +50 Gold", Color(0.9, 0.3, 0.4, 1.0), 4.0)
		"haste_elixir":
			heal(45)
			add_gold(70)
			apply_speed_buff(30.0)
			show_banner("★ USED: Sunfire Elixir! +45 HP, +70 Gold, HASTE!", Color(1.0, 0.8, 0.2, 1.0), 4.0)
		"shadow_draught":
			heal(40)
			add_gold(60)
			apply_stealth_buff(35.0)
			show_banner("★ USED: Shadow Veil! +40 HP, +60 Gold, STEALTH!", Color(0.4, 0.2, 0.6, 1.0), 4.0)
		"frost_draught":
			heal(50)
			health_manager.max_health += 15
			add_gold(80)
			show_banner("★ USED: Moonlit Frost! +50 HP, +15 Max HP, +80 Gold", Color(0.4, 0.7, 0.95, 1.0), 4.0)
		"compote":
			heal(35)
			add_gold(75)
			show_banner("★ USED: Orchard Compote! +35 HP, +75 Gold", Color(0.95, 0.6, 0.3, 1.0), 4.0)
		"ambrosia_stew":
			heal(100)
			health_manager.max_health += 30
			add_gold(150)
			apply_speed_buff(30.0)
			apply_stealth_buff(35.0)
			show_banner("★★ USED: Grand Ambrosia! +100 HP, +30 Max HP, +150 Gold, ALL BUFFS!", Color(0.95, 0.85, 0.4, 1.0), 5.0)

# =====================================================================
# MERCHANT INTERACTION
# =====================================================================

func open_merchant(merchant_node):
	if merchant_ui and merchant_manager:
		# Check if merchant has a trading penalty
		if merchant_node.has_method("can_trade_with"):
			if !merchant_node.can_trade_with(self):
				var penalty_time = merchant_node.get_penalty_time_remaining()
				show_banner("⚠ " + merchant_node.npc_name + " refuses to trade with you! Wait " + str(ceil(penalty_time)) + "s or leave and return.", Color(1.0, 0.3, 0.3, 1.0), 3.0)
				return
		merchant_manager.open_merchant(merchant_node)

func get_nearby_merchant():
	var merchants = get_tree().get_nodes_in_group("merchant")
	var closest_merchant = null
	var closest_distance = 3.0  # Interaction distance
	
	for merchant in merchants:
		if is_instance_valid(merchant):
			var distance = global_transform.origin.distance_to(merchant.global_transform.origin)
			if distance < closest_distance:
				closest_distance = distance
				closest_merchant = merchant
	
	return closest_merchant

# =====================================================================
# THIRD-PERSON CHARACTER ANIMATION & ROTATION
# =====================================================================

func _update_character_animation(delta):
	if !character_anim_player:
		return
	
	# Determine which animation should be playing based on state
	var target_animation = "idle"
	var speed = character_mover.velocity.length()
	
	if dead:
		target_animation = "dead" if character_anim_player.has_animation("dead") else "idle"
	elif sneaking:
		if speed > 0.5:
			target_animation = "sneak_walk" if character_anim_player.has_animation("sneak_walk") else "walk"
		else:
			target_animation = "sneak_idle" if character_anim_player.has_animation("sneak_idle") else "idle"
	elif !character_mover.is_on_floor():
		target_animation = "jump" if character_anim_player.has_animation("jump") else "idle"
	elif speed > 5.0:
		target_animation = "run" if character_anim_player.has_animation("run") else "walk"
	elif speed > 0.5:
		target_animation = "walk" if character_anim_player.has_animation("walk") else "idle"
	else:
		target_animation = "idle"
	
	# If animation needs to change, play it
	if target_animation != current_animation:
		if character_anim_player.has_animation(target_animation):
			character_anim_player.play(target_animation)
			current_animation = target_animation
		elif target_animation == "run" and character_anim_player.has_animation("walk"):
			# Fallback to walk if run doesn't exist
			character_anim_player.play("walk")
			current_animation = "walk"
		elif target_animation == "sneak_walk" and character_anim_player.has_animation("walk"):
			# Fallback to walk for sneak
			character_anim_player.play("walk")
			current_animation = "walk"
		elif character_anim_player.has_animation("idle"):
			# Ultimate fallback
			character_anim_player.play("idle")
			current_animation = "idle"

func _update_character_rotation(delta):
	if !character_model:
		return
	
	# Get movement direction in world space
	var move_vec = Vector3()
	if Input.is_action_pressed("move_forwards"):
		move_vec += Vector3.FORWARD
	if Input.is_action_pressed("move_backwards"):
		move_vec += Vector3.BACK
	if Input.is_action_pressed("move_left"):
		move_vec += Vector3.LEFT
	if Input.is_action_pressed("move_right"):
		move_vec += Vector3.RIGHT
	
	# If there's movement input, rotate character to face movement direction
	if move_vec.length() > 0.1:
		# Transform movement vector by camera rotation to get world direction
		var cam_basis = camera.global_transform.basis
		var world_move_dir = (cam_basis * move_vec).normalized()
		world_move_dir.y = 0  # Keep character upright
		
		# Calculate target rotation angle
		if world_move_dir.length() > 0.1:
			character_rotation_target = atan2(world_move_dir.x, world_move_dir.z)
	
	# Smoothly interpolate character rotation
	var current_rot = character_model.rotation.y
	character_model.rotation.y = lerp_angle(current_rot, character_rotation_target, 10.0 * delta)
