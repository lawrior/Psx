extends Camera

# =====================================================================
# THIRD PERSON CAMERA - Skyrim-style smooth follow camera
# =====================================================================

var target = null  # The player character
var camera_pivot = null  # Pivot point for camera rotation

# Camera settings
export var distance = 5.0  # Distance from target (increased from 4.0)
export var min_distance = 2.5  # Increased minimum distance
export var max_distance = 10.0  # Increased max distance
export var height_offset = 2.0  # Height above target's origin (increased from 1.5)
export var look_at_height = 1.5  # Height to look at on target (increased from 1.2)

# Rotation settings
export var pitch_min = -60.0  # Minimum vertical angle
export var pitch_max = 60.0  # Maximum vertical angle
export var mouse_sensitivity = 0.3

# Smoothing settings
export var position_smoothing = 8.0
export var rotation_smoothing = 10.0

# Collision settings
export var collision_mask = 1
export var collision_margin = 0.2

# Current camera state
var current_pitch = 0.0
var current_yaw = 0.0
var current_distance = 5.0
var target_position = Vector3.ZERO
var target_rotation = Quat()

func _ready():
	# Create a pivot point for camera rotation
	camera_pivot = Spatial.new()
	camera_pivot.name = "CameraPivot"
	get_parent().add_child(camera_pivot)
	
	# Reparent camera to pivot
	var old_transform = global_transform
	get_parent().remove_child(self)
	camera_pivot.add_child(self)
	global_transform = old_transform
	
	# Reset local transform (camera is now relative to pivot)
	transform = Transform.IDENTITY

func init(p_target):
	target = p_target
	current_distance = distance

func _input(event):
	if event is InputEventMouseMotion:
		# Rotate camera with mouse
		current_yaw -= event.relative.x * mouse_sensitivity
		current_pitch -= event.relative.y * mouse_sensitivity
		current_pitch = clamp(current_pitch, pitch_min, pitch_max)

func _process(delta):
	if !target:
		return
	
	# Update pivot position to follow target
	var target_pos = target.global_transform.origin + Vector3(0, height_offset, 0)
	camera_pivot.global_transform.origin = target_pos
	
	# Apply rotation to pivot
	camera_pivot.rotation_degrees = Vector3(current_pitch, current_yaw, 0)
	
	# Calculate desired camera position (BEHIND and above target)
	# Negative Z to put camera behind (positive Z is forward in Godot)
	var desired_pos = Vector3(0, 0, -current_distance)
	
	# Perform collision detection
	var space_state = get_world().direct_space_state
	var from = camera_pivot.global_transform.origin
	var to = camera_pivot.global_transform.origin + camera_pivot.global_transform.basis.z * current_distance
	
	var collision = space_state.intersect_ray(from, to, [target], collision_mask)
	if collision:
		# Camera hit something, move closer
		var collision_distance = from.distance_to(collision.position) - collision_margin
		desired_pos.z = -max(min_distance, collision_distance)
	else:
		desired_pos.z = -current_distance
	
	# Smoothly interpolate camera position
	transform.origin = transform.origin.linear_interpolate(desired_pos, position_smoothing * delta)
	
	# Make camera look at target
	var look_target = camera_pivot.global_transform.origin + Vector3(0, look_at_height - height_offset, 0)
	look_at(look_target, Vector3.UP)

func _physics_process(delta):
	# Additional physics-based smoothing if needed
	pass

# Adjust camera distance with scroll wheel
func _unhandled_input(event):
	if event is InputEventMouseButton:
		if event.button_index == BUTTON_WHEEL_UP:
			current_distance = max(min_distance, current_distance - 0.5)
		elif event.button_index == BUTTON_WHEEL_DOWN:
			current_distance = min(max_distance, current_distance + 0.5)
