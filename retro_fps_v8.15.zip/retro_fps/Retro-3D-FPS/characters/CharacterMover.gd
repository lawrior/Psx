extends Spatial


var body_to_move : KinematicBody = null

export var move_accel = 4
export var max_speed = 25
var drag = 0.0
export var jump_force = 30
export var gravity = 60

var pressed_jump = false
var move_vec : Vector3
var velocity : Vector3
var snap_vector : Vector3
export var ignore_rotation = false

signal movement_info

var frozen = false
var speed_scale = 1.0
var is_grounded = false

func _ready():
	drag = float(move_accel) / max_speed
	
func init(_body_to_move: KinematicBody):
	body_to_move = _body_to_move

func set_speed_scale(scale: float):
	speed_scale = max(0.05, scale)
	var eff_max_speed = max_speed * speed_scale
	drag = float(move_accel) / eff_max_speed

func get_speed_scale() -> float:
	return speed_scale

func is_on_floor() -> bool:
	return is_grounded

func jump():
	pressed_jump = true
	
func set_move_vec(_move_vec: Vector3):
	move_vec = _move_vec.normalized()
	
func _physics_process(_delta):
	if frozen or !body_to_move:
		return
	var cur_move_vec = move_vec
	if !ignore_rotation:
		cur_move_vec = cur_move_vec.rotated(Vector3.UP, body_to_move.rotation.y)
	velocity += move_accel * cur_move_vec - velocity * Vector3(drag, 0, drag) + gravity * Vector3.DOWN * _delta
	velocity = body_to_move.move_and_slide_with_snap(velocity, snap_vector, Vector3.UP)
	
	is_grounded = body_to_move.is_on_floor()
	if is_grounded:
		velocity.y = -0.01
	if is_grounded and pressed_jump:
		velocity.y = jump_force
		snap_vector = Vector3.ZERO
	else:
		snap_vector = Vector3.DOWN
	pressed_jump = false
	emit_signal("movement_info", velocity, is_grounded)
	
func freeze():
	frozen = true
	
func unfreeze():
	frozen = false

	
	
	
	
