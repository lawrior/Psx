extends Spatial

# =====================================================================
# ANIMAL FORM TRANSFORMATION SYSTEM
# Supports: Fish (swimming), Bird (flying), Cat (quadruped running)
# Each form uses a third-person camera with unique movement mechanics.
# =====================================================================

enum FORM { HUMAN, FISH, BIRD, CAT }

# --------------- State ---------------
var current_form = FORM.HUMAN
var player_ref = null
var original_camera = null
var tp_camera = null
var animal_visual = null

# Camera orbit
var cam_pitch : float = -15.0
var cam_distance : float = 4.0
var cam_height_offset : float = 1.5
var cam_target_offset : Vector3 = Vector3(0, 0.8, 0)

# Form physics
var form_velocity : Vector3 = Vector3.ZERO
var is_grounded : bool = false
var is_in_water : bool = false
var anim_time : float = 0.0
var was_flapping : bool = false

# Visual node references (for animation)
var wing_left = null
var wing_right = null
var tail_node = null
var leg_nodes : Array = []
var body_node = null

# HUD
var form_label : Label = null
var form_hint_label : Label = null

# Water detection cache
var _water_check_timer : float = 0.0

# =====================================================================
# INITIALISATION
# =====================================================================

func init(player):
	player_ref = player
	original_camera = player.camera
	_setup_hud()

func _setup_hud():
	var canvas = player_ref.get_node("CanvasLayer")
	var font_res = load("res://ui/KleintenDynFont.tres")
	
	form_label = Label.new()
	form_label.name = "FormLabel"
	form_label.anchor_left = 0.5
	form_label.anchor_top = 0.93
	form_label.anchor_right = 0.5
	form_label.anchor_bottom = 0.93
	form_label.margin_left = -360.0
	form_label.margin_top = 0.0
	form_label.margin_right = 360.0
	form_label.margin_bottom = 28.0
	form_label.align = Label.ALIGN_CENTER
	if font_res:
		form_label.add_font_override("font", font_res)
	form_label.text = ""
	canvas.add_child(form_label)
	
	form_hint_label = Label.new()
	form_hint_label.name = "FormHint"
	form_hint_label.anchor_left = 0.5
	form_hint_label.anchor_top = 0.06
	form_hint_label.anchor_right = 0.5
	form_hint_label.anchor_bottom = 0.06
	form_hint_label.margin_left = -340.0
	form_hint_label.margin_top = 60.0
	form_hint_label.margin_right = 340.0
	form_hint_label.margin_bottom = 88.0
	form_hint_label.align = Label.ALIGN_CENTER
	if font_res:
		form_hint_label.add_font_override("font", font_res)
	form_hint_label.text = "[Z] Fish  [X] Bird  [V] Cat  [B] Human"
	form_hint_label.modulate = Color(0.6, 0.85, 1.0, 0.7)
	canvas.add_child(form_hint_label)

# =====================================================================
# PUBLIC API
# =====================================================================

func is_transformed() -> bool:
	return current_form != FORM.HUMAN

func transform_to(form):
	if current_form == form:
		revert_to_human()
		return
	if current_form != FORM.HUMAN:
		_cleanup_form()
	current_form = form
	_setup_form()
	player_ref.on_form_changed(current_form)

func revert_to_human():
	if current_form == FORM.HUMAN:
		return
	_cleanup_form()
	current_form = FORM.HUMAN
	player_ref.on_form_changed(FORM.HUMAN)

func get_form_name() -> String:
	match current_form:
		FORM.FISH: return "Fish"
		FORM.BIRD: return "Bird"
		FORM.CAT: return "Cat"
		_: return "Human"

# =====================================================================
# FORM SETUP / CLEANUP
# =====================================================================

func _setup_form():
	# Freeze the human CharacterMover so it won't fight our physics
	player_ref.character_mover.freeze()
	player_ref.character_mover.velocity = Vector3.ZERO
	form_velocity = Vector3.ZERO
	anim_time = 0.0
	
	# Hide human-visible elements (weapons)
	_set_human_elements_visible(false)
	
	# Build animal visual
	animal_visual = Spatial.new()
	animal_visual.name = "AnimalVisual"
	player_ref.add_child(animal_visual)
	
	match current_form:
		FORM.FISH:
			_build_fish()
			cam_distance = 3.5
			cam_height_offset = 0.8
			cam_target_offset = Vector3(0, 0.3, 0)
			cam_pitch = -10.0
		FORM.BIRD:
			_build_bird()
			cam_distance = 6.0
			cam_height_offset = 2.8
			cam_target_offset = Vector3(0, 0.5, 0)
			cam_pitch = -18.0
		FORM.CAT:
			_build_cat()
			cam_distance = 4.0
			cam_height_offset = 1.4
			cam_target_offset = Vector3(0, 0.45, 0)
			cam_pitch = -12.0
	
	# Create third-person camera
	_setup_tp_camera()
	
	# Adjust player collision for the form
	_apply_form_collision()
	
	# Banner
	var names = {FORM.FISH: "FISH", FORM.BIRD: "BIRD", FORM.CAT: "CAT"}
	player_ref.show_banner("TRANSFORM: " + names.get(current_form, "") + " FORM!  [B] Revert to Human", Color(0.3, 0.9, 1.0, 1.0), 4.0)
	_update_form_hud()

func _cleanup_form():
	if animal_visual and is_instance_valid(animal_visual):
		animal_visual.queue_free()
	animal_visual = null
	
	if tp_camera and is_instance_valid(tp_camera):
		tp_camera.queue_free()
	tp_camera = null
	
	# Restore original FPS camera
	if original_camera and is_instance_valid(original_camera):
		original_camera.current = true
	
	_set_human_elements_visible(true)
	_restore_collision()
	
	# Unfreeze normal movement
	player_ref.character_mover.unfreeze()
	player_ref.character_mover.velocity = Vector3.ZERO
	
	wing_left = null
	wing_right = null
	tail_node = null
	leg_nodes = []
	body_node = null
	
	_update_form_hud()

func _set_human_elements_visible(vis: bool):
	var wm = player_ref.get_node_or_null("Camera/WeaponManager")
	if wm:
		wm.visible = vis

func _setup_tp_camera():
	tp_camera = Camera.new()
	tp_camera.name = "TPCamera"
	tp_camera.fov = 65.0
	tp_camera.near = 0.05
	tp_camera.far = 500.0
	player_ref.add_child(tp_camera)
	
	# Initialize camera position immediately to avoid jarring transition
	var body_pos = player_ref.global_transform.origin
	var body_rot_y = player_ref.rotation.y
	var pitch_rad = deg2rad(cam_pitch)
	var dist_h = cos(pitch_rad) * cam_distance
	var dist_v = sin(-pitch_rad) * cam_distance
	var offset = Vector3(0, dist_v + cam_height_offset, dist_h)
	offset = offset.rotated(Vector3.UP, body_rot_y)
	tp_camera.global_transform.origin = body_pos + offset
	
	var look_target = body_pos + cam_target_offset
	if tp_camera.global_transform.origin.distance_to(look_target) > 0.1:
		tp_camera.look_at(look_target, Vector3.UP)
	
	tp_camera.current = true
	if original_camera:
		original_camera.current = false

func _apply_form_collision():
	var col = player_ref.get_node_or_null("CollisionShape")
	if !col:
		return
	var shape = CapsuleShape.new()
	match current_form:
		FORM.FISH:
			shape.radius = 0.25
			shape.height = 0.8  # Total height
		FORM.BIRD:
			shape.radius = 0.2
			shape.height = 0.6  # Total height
		FORM.CAT:
			shape.radius = 0.3
			shape.height = 0.8  # Total height
	col.shape = shape
	# Adjust collision center height
	match current_form:
		FORM.FISH:
			col.translation.y = 0.4
		FORM.BIRD:
			col.translation.y = 0.3
		FORM.CAT:
			col.translation.y = 0.4

func _restore_collision():
	var col = player_ref.get_node_or_null("CollisionShape")
	if !col:
		return
	var shape = CapsuleShape.new()
	shape.radius = 0.5
	col.shape = shape
	col.translation.y = 1.0

# =====================================================================
# PROCEDURAL ANIMAL MESHES
# =====================================================================

func _make_mat(color: Color, metallic_v: float = 0.0, roughness_v: float = 0.8) -> SpatialMaterial:
	var m = SpatialMaterial.new()
	m.albedo_color = color
	m.metallic = metallic_v
	m.roughness = roughness_v
	return m

# ---- FISH ----
func _build_fish():
	var silver = _make_mat(Color(0.45, 0.6, 0.78, 1.0), 0.6, 0.25)
	var fin_mat = _make_mat(Color(0.3, 0.45, 0.7, 0.75), 0.3, 0.4)
	var dark = _make_mat(Color(0.05, 0.05, 0.1, 1.0))
	
	# Body
	var body_mi = MeshInstance.new()
	var bm = SphereMesh.new()
	bm.radius = 0.22; bm.height = 0.44
	body_mi.mesh = bm
	body_mi.material_override = silver
	body_mi.scale = Vector3(1.0, 0.75, 1.9)
	animal_visual.add_child(body_mi)
	body_node = body_mi
	
	# Tail
	var tail_pivot = Spatial.new()
	tail_pivot.translation = Vector3(0, 0, 0.38)
	animal_visual.add_child(tail_pivot)
	
	var tail_mi = MeshInstance.new()
	var tm = PrismMesh.new()
	tm.size = Vector3(0.32, 0.38, 0.12)
	tail_mi.mesh = tm
	tail_mi.material_override = fin_mat
	tail_mi.rotation_degrees = Vector3(0, 0, 90)
	tail_pivot.add_child(tail_mi)
	tail_node = tail_pivot
	
	# Dorsal fin
	var dorsal_mi = MeshInstance.new()
	var dm = PrismMesh.new()
	dm.size = Vector3(0.06, 0.14, 0.18)
	dorsal_mi.mesh = dm
	dorsal_mi.material_override = fin_mat
	dorsal_mi.translation = Vector3(0, -0.17, 0.0)
	animal_visual.add_child(dorsal_mi)
	
	# Pectoral fins
	for s in [-1, 1]:
		var f = MeshInstance.new()
		var fm = PrismMesh.new()
		fm.size = Vector3(0.14, 0.06, 0.1)
		f.mesh = fm
		f.material_override = fin_mat
		f.translation = Vector3(s * 0.18, 0.04, -0.05)
		f.rotation_degrees = Vector3(0, 0, s * 35.0)
		animal_visual.add_child(f)
	
	# Eyes
	for s in [-1, 1]:
		var e = MeshInstance.new()
		var em = SphereMesh.new()
		em.radius = 0.03; em.height = 0.06
		e.mesh = em
		e.material_override = dark
		e.translation = Vector3(s * 0.13, -0.04, -0.22)
		animal_visual.add_child(e)
	
	animal_visual.translation = Vector3(0, 0.5, 0)

# ---- BIRD ----
func _build_bird():
	var brown = _make_mat(Color(0.52, 0.34, 0.18, 1.0), 0.0, 0.85)
	var dark_brown = _make_mat(Color(0.35, 0.22, 0.1, 1.0))
	var beak_c = _make_mat(Color(0.92, 0.72, 0.12, 1.0), 0.1, 0.6)
	var dark = _make_mat(Color(0.08, 0.08, 0.05, 1.0))
	
	# Body
	var body_mi = MeshInstance.new()
	var bm = SphereMesh.new()
	bm.radius = 0.16; bm.height = 0.32
	body_mi.mesh = bm
	body_mi.material_override = brown
	body_mi.scale = Vector3(1.0, 0.8, 1.6)
	animal_visual.add_child(body_mi)
	body_node = body_mi
	
	# Head
	var head = MeshInstance.new()
	var hm = SphereMesh.new()
	hm.radius = 0.1; hm.height = 0.2
	head.mesh = hm
	head.material_override = brown
	head.translation = Vector3(0, -0.04, -0.26)
	animal_visual.add_child(head)
	
	# Beak
	var beak = MeshInstance.new()
	var bkm = CylinderMesh.new()
	bkm.top_radius = 0.0; bkm.bottom_radius = 0.04; bkm.height = 0.14
	beak.mesh = bkm
	beak.material_override = beak_c
	beak.translation = Vector3(0, -0.04, -0.38)
	beak.rotation_degrees = Vector3(90, 0, 0)
	animal_visual.add_child(beak)
	
	# Wings
	for s in [-1, 1]:
		var pivot = Spatial.new()
		pivot.translation = Vector3(s * 0.14, 0.02, 0.0)
		animal_visual.add_child(pivot)
		
		var wing = MeshInstance.new()
		var wm = PlaneMesh.new()
		wm.size = Vector2(0.65, 0.28)
		wing.mesh = wm
		var wmat = _make_mat(Color(0.42, 0.28, 0.14, 1.0), 0.0, 0.8)
		wmat.params_cull_mode = SpatialMaterial.CULL_DISABLED
		wing.material_override = wmat
		wing.translation = Vector3(s * 0.32, 0, 0)
		pivot.add_child(wing)
		
		# Wing tip darker
		var tip = MeshInstance.new()
		var tipm = PlaneMesh.new()
		tipm.size = Vector2(0.25, 0.18)
		tip.mesh = tipm
		var tipmat = _make_mat(Color(0.2, 0.15, 0.08, 1.0))
		tipmat.params_cull_mode = SpatialMaterial.CULL_DISABLED
		tip.material_override = tipmat
		tip.translation = Vector3(s * 0.25, 0.001, 0.02)
		wing.add_child(tip)
		
		if s == -1:
			wing_left = pivot
		else:
			wing_right = pivot
	
	# Tail feathers
	var tail_mi = MeshInstance.new()
	var tlm = PlaneMesh.new()
	tlm.size = Vector2(0.16, 0.22)
	tail_mi.mesh = tlm
	var tlmat = _make_mat(Color(0.35, 0.22, 0.1, 1.0))
	tlmat.params_cull_mode = SpatialMaterial.CULL_DISABLED
	tail_mi.material_override = tlmat
	tail_mi.translation = Vector3(0, 0.02, 0.28)
	tail_mi.rotation_degrees = Vector3(-25, 0, 0)
	animal_visual.add_child(tail_mi)
	tail_node = tail_mi
	
	# Eyes
	for s in [-1, 1]:
		var e = MeshInstance.new()
		var em = SphereMesh.new()
		em.radius = 0.022; em.height = 0.044
		e.mesh = em
		e.material_override = dark
		e.translation = Vector3(s * 0.07, -0.06, -0.31)
		animal_visual.add_child(e)
	
	animal_visual.translation = Vector3(0, 0.5, 0)

# ---- CAT ----
func _build_cat():
	var orange_fur = _make_mat(Color(0.88, 0.55, 0.18, 1.0), 0.0, 0.9)
	var dark_fur = _make_mat(Color(0.55, 0.32, 0.1, 1.0), 0.0, 0.9)
	var white_fur = _make_mat(Color(0.95, 0.92, 0.88, 1.0), 0.0, 0.85)
	var eye_green = _make_mat(Color(0.15, 0.72, 0.15, 1.0), 0.2, 0.3)
	var nose_pink = _make_mat(Color(0.85, 0.45, 0.5, 1.0))
	
	leg_nodes = []
	
	# Body (horizontal capsule)
	var body_mi = MeshInstance.new()
	var bm = CapsuleMesh.new()
	bm.radius = 0.14; bm.mid_height = 0.24
	body_mi.mesh = bm
	body_mi.material_override = orange_fur
	body_mi.rotation_degrees = Vector3(0, 0, 90)  # Rotate on Z instead of X
	body_mi.translation = Vector3(0, 0, 0.05)
	animal_visual.add_child(body_mi)
	body_node = body_mi
	
	# Head
	var head = MeshInstance.new()
	var hm = SphereMesh.new()
	hm.radius = 0.13; hm.height = 0.26
	head.mesh = hm
	head.material_override = orange_fur
	head.translation = Vector3(0, 0.04, -0.32)
	animal_visual.add_child(head)
	
	# Ears
	for s in [-1, 1]:
		var ear = MeshInstance.new()
		var em = CylinderMesh.new()
		em.top_radius = 0.0; em.bottom_radius = 0.05; em.height = 0.09
		ear.mesh = em
		ear.material_override = orange_fur
		ear.translation = Vector3(s * 0.08, 0.14, -0.34)  # Positive Y for ears on top
		animal_visual.add_child(ear)
		
		# Inner ear
		var inner = MeshInstance.new()
		var im = CylinderMesh.new()
		im.top_radius = 0.0; im.bottom_radius = 0.03; im.height = 0.06
		inner.mesh = im
		inner.material_override = nose_pink
		inner.translation = Vector3(s * 0.08, 0.13, -0.34)  # Positive Y
		animal_visual.add_child(inner)
	
	# Snout
	var snout = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.06; sm.height = 0.1
	snout.mesh = sm
	snout.material_override = white_fur
	snout.scale = Vector3(1.2, 0.7, 1.0)
	snout.translation = Vector3(0, 0.06, -0.42)
	animal_visual.add_child(snout)
	
	# Nose
	var nose = MeshInstance.new()
	var nm = SphereMesh.new()
	nm.radius = 0.02; nm.height = 0.03
	nose.mesh = nm
	nose.material_override = nose_pink
	nose.translation = Vector3(0, 0.04, -0.46)
	animal_visual.add_child(nose)
	
	# Legs (4)
	var leg_positions = [
		Vector3(-0.1, -0.18, -0.16),  # Negative Y for legs below body
		Vector3(0.1, -0.18, -0.16),
		Vector3(-0.1, -0.18, 0.2),
		Vector3(0.1, -0.18, 0.2),
	]
	for i in range(4):
		var pivot = Spatial.new()
		pivot.translation = leg_positions[i]
		animal_visual.add_child(pivot)
		
		var leg = MeshInstance.new()
		var lm = CylinderMesh.new()
		lm.top_radius = 0.04; lm.bottom_radius = 0.035; lm.height = 0.24
		leg.mesh = lm
		leg.material_override = orange_fur
		leg.translation = Vector3(0, 0.12, 0)
		pivot.add_child(leg)
		
		# Paw
		var paw = MeshInstance.new()
		var pm = SphereMesh.new()
		pm.radius = 0.04; pm.height = 0.06
		paw.mesh = pm
		paw.material_override = white_fur
		paw.scale = Vector3(1.0, 0.6, 1.2)
		paw.translation = Vector3(0, 0.24, -0.01)
		pivot.add_child(paw)
		
		leg_nodes.push_back(pivot)
	
	# Tail (animated pivot)
	var tail_pivot = Spatial.new()
	tail_pivot.translation = Vector3(0, -0.04, 0.3)
	animal_visual.add_child(tail_pivot)
	
	var tail_mi = MeshInstance.new()
	var tlm = CylinderMesh.new()
	tlm.top_radius = 0.02; tlm.bottom_radius = 0.04; tlm.height = 0.42
	tail_mi.mesh = tlm
	tail_mi.material_override = dark_fur
	tail_mi.translation = Vector3(0, -0.16, 0.1)
	tail_mi.rotation_degrees = Vector3(55, 0, 0)
	tail_pivot.add_child(tail_mi)
	tail_node = tail_pivot
	
	# Tail tip (darker)
	var tip = MeshInstance.new()
	var tipm = SphereMesh.new()
	tipm.radius = 0.03; tipm.height = 0.05
	tip.mesh = tipm
	tip.material_override = dark_fur
	tip.translation = Vector3(0, -0.3, 0.22)
	tail_pivot.add_child(tip)
	
	# Eyes (green)
	for s in [-1, 1]:
		var e = MeshInstance.new()
		var em = SphereMesh.new()
		em.radius = 0.025; em.height = 0.04
		e.mesh = em
		e.material_override = eye_green
		e.translation = Vector3(s * 0.06, 0.02, -0.42)
		animal_visual.add_child(e)
		
		# Pupil
		var pupil = MeshInstance.new()
		var pupm = SphereMesh.new()
		pupm.radius = 0.012; pupm.height = 0.02
		pupil.mesh = pupm
		pupil.material_override = _make_mat(Color(0.02, 0.02, 0.02, 1.0))
		pupil.translation = Vector3(s * 0.06, 0.02, -0.445)
		animal_visual.add_child(pupil)
	
	# Stripes on back
	for i in range(3):
		var stripe = MeshInstance.new()
		var strm = PlaneMesh.new()
		strm.size = Vector2(0.2, 0.04)
		stripe.mesh = strm
		var strmat = _make_mat(Color(0.5, 0.28, 0.08, 0.8))
		strmat.params_cull_mode = SpatialMaterial.CULL_DISABLED
		stripe.material_override = strmat
		stripe.translation = Vector3(0, -0.14, -0.08 + i * 0.12)
		stripe.rotation_degrees = Vector3(90, 0, 0)
		animal_visual.add_child(stripe)
	
	animal_visual.translation = Vector3(0, 0.32, 0)

# =====================================================================
# PHYSICS PROCESS (per-form movement)
# =====================================================================

func _physics_process(delta):
	if !is_transformed() or !player_ref:
		return
	
	anim_time += delta
	_water_check_timer -= delta
	
	match current_form:
		FORM.FISH:
			_physics_fish(delta)
		FORM.BIRD:
			_physics_bird(delta)
		FORM.CAT:
			_physics_cat(delta)

# ---- FISH PHYSICS ----
func _physics_fish(delta):
	if _water_check_timer <= 0.0:
		_check_water()
		_water_check_timer = 0.15
	
	var input_dir = Vector3.ZERO
	if Input.is_action_pressed("move_forwards"):
		input_dir += Vector3.FORWARD
	if Input.is_action_pressed("move_backwards"):
		input_dir += Vector3.BACK
	if Input.is_action_pressed("move_left"):
		input_dir += Vector3.LEFT
	if Input.is_action_pressed("move_right"):
		input_dir += Vector3.RIGHT
	
	input_dir = input_dir.rotated(Vector3.UP, player_ref.rotation.y)
	
	var swim_speed = 9.0 if is_in_water else 1.5
	var target_h = input_dir.normalized() * swim_speed
	
	if is_in_water:
		# Swimming: neutral buoyancy, full 3D control
		if Input.is_action_pressed("jump"):
			target_h.y = 5.0
		elif Input.is_key_pressed(KEY_C):
			target_h.y = -5.0
		else:
			target_h.y = form_velocity.y * 0.92
		form_velocity = form_velocity.linear_interpolate(target_h, 5.5 * delta)
	else:
		# Flopping on ground
		form_velocity.x = lerp(form_velocity.x, target_h.x, 3.0 * delta)
		form_velocity.z = lerp(form_velocity.z, target_h.z, 3.0 * delta)
		form_velocity.y -= 35.0 * delta
	
	var snap = Vector3.DOWN if !is_in_water else Vector3.ZERO
	form_velocity = player_ref.move_and_slide_with_snap(form_velocity, snap, Vector3.UP)
	is_grounded = player_ref.is_on_floor()
	if is_grounded and !is_in_water:
		form_velocity.y = -0.01
	
	# Animate
	if animal_visual:
		if tail_node:
			tail_node.rotation_degrees.y = sin(anim_time * 9.0) * 28.0
		if body_node:
			body_node.rotation_degrees.y = sin(anim_time * 7.0) * 4.0
		var pitch = clamp(-form_velocity.y * 4.5, -35.0, 35.0)
		animal_visual.rotation_degrees.x = lerp(animal_visual.rotation_degrees.x, pitch, 4.0 * delta)
		# Rolling when turning
		var local_input = input_dir.rotated(Vector3.UP, -player_ref.rotation.y)
		var roll = -local_input.x * 18.0
		animal_visual.rotation_degrees.z = lerp(animal_visual.rotation_degrees.z, roll, 4.0 * delta)

# ---- BIRD PHYSICS ----
func _physics_bird(delta):
	var input_dir = Vector3.ZERO
	if Input.is_action_pressed("move_forwards"):
		input_dir += Vector3.FORWARD
	if Input.is_action_pressed("move_backwards"):
		input_dir += Vector3.BACK
	if Input.is_action_pressed("move_left"):
		input_dir += Vector3.LEFT
	if Input.is_action_pressed("move_right"):
		input_dir += Vector3.RIGHT
	
	input_dir = input_dir.rotated(Vector3.UP, player_ref.rotation.y)
	
	var fly_speed = 15.0
	var target_h = input_dir.normalized() * fly_speed
	
	var is_flapping = Input.is_action_pressed("jump")
	
	if is_flapping:
		target_h.y = 9.0
	elif Input.is_key_pressed(KEY_C):
		target_h.y = -10.0
	else:
		# Gentle glide descent
		target_h.y = form_velocity.y - 8.0 * delta
	
	form_velocity = form_velocity.linear_interpolate(target_h, 4.5 * delta)
	form_velocity = player_ref.move_and_slide(form_velocity, Vector3.UP)
	is_grounded = player_ref.is_on_floor()
	if is_grounded:
		form_velocity.y = max(form_velocity.y, 0.0)
	
	# Animate wings
	var flap_spd = 14.0 if is_flapping else 2.5
	var flap_amp = 50.0 if is_flapping else 8.0
	var flap_angle = sin(anim_time * flap_spd) * flap_amp
	if wing_left:
		wing_left.rotation_degrees.z = flap_angle
	if wing_right:
		wing_right.rotation_degrees.z = -flap_angle
	
	# Body banking and pitch
	if animal_visual:
		var local_input = input_dir.rotated(Vector3.UP, -player_ref.rotation.y)
		var bank = -local_input.x * 25.0
		animal_visual.rotation_degrees.z = lerp(animal_visual.rotation_degrees.z, bank, 5.0 * delta)
		var pitch = clamp(-form_velocity.y * 2.8, -30.0, 30.0)
		animal_visual.rotation_degrees.x = lerp(animal_visual.rotation_degrees.x, pitch, 4.0 * delta)
	
	# Update HUD with altitude (throttled to avoid performance issues)
	if form_label and int(anim_time * 2) % 2 == 0:  # Update every 0.5 seconds
		var alt = int(player_ref.global_transform.origin.y)
		form_label.text = "[BIRD FORM] WASD Fly | Space Flap | C Dive | Alt: " + str(alt) + "m | [B] Human"

# ---- CAT PHYSICS ----
func _physics_cat(delta):
	var input_dir = Vector3.ZERO
	if Input.is_action_pressed("move_forwards"):
		input_dir += Vector3.FORWARD
	if Input.is_action_pressed("move_backwards"):
		input_dir += Vector3.BACK
	if Input.is_action_pressed("move_left"):
		input_dir += Vector3.LEFT
	if Input.is_action_pressed("move_right"):
		input_dir += Vector3.RIGHT
	
	input_dir = input_dir.rotated(Vector3.UP, player_ref.rotation.y)
	
	var run_speed = 18.0
	var accel = 35.0
	var drag_coeff = accel / run_speed
	
	form_velocity += input_dir.normalized() * accel - form_velocity * Vector3(drag_coeff, 0, drag_coeff) + Vector3.DOWN * 55.0 * delta
	form_velocity = player_ref.move_and_slide_with_snap(form_velocity, Vector3.DOWN, Vector3.UP)
	is_grounded = player_ref.is_on_floor()
	if is_grounded:
		form_velocity.y = -0.01
	
	# High cat jump
	if is_grounded and Input.is_action_just_pressed("jump"):
		form_velocity.y = 19.0
	
	# Animate legs (trotting gait)
	var move_spd = Vector2(form_velocity.x, form_velocity.z).length()
	var leg_amp = min(move_spd / 8.0, 1.0) * 35.0
	var leg_phase = anim_time * 13.0
	if leg_nodes.size() >= 4:
		leg_nodes[0].rotation_degrees.x = sin(leg_phase) * leg_amp
		leg_nodes[1].rotation_degrees.x = -sin(leg_phase) * leg_amp
		leg_nodes[2].rotation_degrees.x = -sin(leg_phase) * leg_amp
		leg_nodes[3].rotation_degrees.x = sin(leg_phase) * leg_amp
	
	# Tail sway
	if tail_node:
		tail_node.rotation_degrees.z = sin(anim_time * 2.8) * 18.0
		tail_node.rotation_degrees.x = sin(anim_time * 1.8) * 8.0
	
	# Body bob while running
	if body_node:
		var bob = sin(anim_time * 13.0) * min(move_spd / 10.0, 1.0) * 0.015
		body_node.translation.y = bob

# =====================================================================
# PROCESS (camera + visual animation)
# =====================================================================

func _process(delta):
	if !is_transformed() or !tp_camera or !player_ref:
		return
	_update_tp_camera(delta)

func _update_tp_camera(delta):
	var body_pos = player_ref.global_transform.origin
	var body_rot_y = player_ref.rotation.y
	var look_target = body_pos + cam_target_offset
	
	# Compute desired camera offset from orbit angles
	var pitch_rad = deg2rad(cam_pitch)
	var dist_h = cos(pitch_rad) * cam_distance
	var dist_v = sin(-pitch_rad) * cam_distance
	var offset = Vector3(0, dist_v + cam_height_offset, dist_h)
	offset = offset.rotated(Vector3.UP, body_rot_y)
	
	var desired_pos = body_pos + offset
	
	# Wall collision ray
	var space_state = player_ref.get_world().get_direct_space_state()
	if space_state:
		var result = space_state.intersect_ray(look_target, desired_pos, [player_ref], 1)
		if !result.empty():
			desired_pos = result.position + result.normal * 0.2
	
	# Smooth follow - reduced interpolation factor for smoother movement
	var smooth_factor = clamp(8.0 * delta, 0.0, 1.0)  # Lower factor, clamped to prevent overshooting
	tp_camera.global_transform.origin = tp_camera.global_transform.origin.linear_interpolate(desired_pos, smooth_factor)
	
	# Only update look_at if camera moved significantly to reduce jitter
	if tp_camera.global_transform.origin.distance_to(look_target) > 0.1:
		# Smooth rotation by interpolating the transform
		var target_transform = tp_camera.global_transform.looking_at(look_target, Vector3.UP)
		tp_camera.global_transform = tp_camera.global_transform.interpolate_with(target_transform, smooth_factor)

# =====================================================================
# INPUT HANDLING (delegated from Player._input when transformed)
# =====================================================================

func _input_form(event):
	if event is InputEventMouseMotion:
		player_ref.rotation_degrees.y -= player_ref.mouse_sens * event.relative.x
		cam_pitch -= player_ref.mouse_sens * event.relative.y
		cam_pitch = clamp(cam_pitch, -70.0, 70.0)

# =====================================================================
# WATER DETECTION
# =====================================================================

func _check_water():
	is_in_water = false
	var water_areas = get_tree().get_nodes_in_group("water")
	for area in water_areas:
		if !is_instance_valid(area):
			continue
		if area is Area:
			var bodies = area.get_overlapping_bodies()
			if player_ref in bodies:
				is_in_water = true
				return
	# Fallback: simple bounding check
	var ppos = player_ref.global_transform.origin
	for area in water_areas:
		if !is_instance_valid(area):
			continue
		var apos = area.global_transform.origin
		if abs(ppos.x - apos.x) < 6.0 and abs(ppos.z - apos.z) < 6.0 and ppos.y < apos.y + 2.0:
			is_in_water = true
			return

# =====================================================================
# HUD
# =====================================================================

func _update_form_hud():
	if !form_label:
		return
	if current_form == FORM.HUMAN:
		form_label.text = ""
		return
	var info = {
		FORM.FISH: "[FISH FORM] WASD Swim | Space Ascend | C Descend",
		FORM.BIRD: "[BIRD FORM] WASD Fly | Space Flap Up | C Dive",
		FORM.CAT: "[CAT FORM] WASD Run | Space High Jump",
	}
	form_label.text = info.get(current_form, "") + " | [B] Revert to Human"
	form_label.modulate = Color(0.4, 0.95, 1.0, 1.0)
