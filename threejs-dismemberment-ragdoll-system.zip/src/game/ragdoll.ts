import * as THREE from 'three';
import * as CANNON from 'cannon-es';

/**
 * Active-ragdoll built from the character skeleton.
 *
 * Each important bone gets a rigid body whose frame is the bone frame.  While the
 * character is alive the bodies are *blended* towards the animated world pose
 * (stiffness 1 == perfect animation, 0 == floppy corpse).  That means the walk
 * cycle keeps driving the body even after limbs have been shot off - the skeleton
 * keeps trying to walk, it just physically can't.
 */

export interface PartDef {
  bone: string;
  parent: string | null;
  /** bone this limb segment points at (defines length + orientation) */
  endChild?: string;
  /** used when there is no end child */
  len?: number;
  radius: number;
  mass: number;
  /** soft limits */
  angle?: number;
  twist?: number;
  /** how strongly this part follows the animation (0..1+) */
  tone?: number;
}

export const HUMANOID: PartDef[] = [
  { bone: 'hips', parent: null, endChild: 'spine', radius: 0.105, mass: 12, tone: 1 },
  { bone: 'spine', parent: 'hips', endChild: 'chest', radius: 0.1, mass: 6, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'chest', parent: 'spine', endChild: 'head', radius: 0.115, mass: 10, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'head', parent: 'chest', len: 0.19, radius: 0.105, mass: 5, angle: 2.9, twist: 1.8, tone: 1 },

  { bone: 'upperarml', parent: 'chest', endChild: 'lowerarml', radius: 0.045, mass: 2.2, angle: 2.9, twist: 1.8, tone: 0.9 },
  { bone: 'lowerarml', parent: 'upperarml', endChild: 'wristl', radius: 0.038, mass: 1.6, angle: 2.9, twist: 1.8, tone: 0.9 },
  { bone: 'handl', parent: 'lowerarml', endChild: 'handslotl', radius: 0.036, mass: 0.6, angle: 2.9, twist: 1.8, tone: 0.8 },
  { bone: 'upperarmr', parent: 'chest', endChild: 'lowerarmr', radius: 0.045, mass: 2.2, angle: 2.9, twist: 1.8, tone: 0.9 },
  { bone: 'lowerarmr', parent: 'upperarmr', endChild: 'wristr', radius: 0.038, mass: 1.6, angle: 2.9, twist: 1.8, tone: 0.9 },
  { bone: 'handr', parent: 'lowerarmr', endChild: 'handslotr', radius: 0.036, mass: 0.6, angle: 2.9, twist: 1.8, tone: 0.8 },

  { bone: 'upperlegl', parent: 'hips', endChild: 'lowerlegl', radius: 0.058, mass: 5, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'lowerlegl', parent: 'upperlegl', endChild: 'footl', radius: 0.048, mass: 3.2, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'footl', parent: 'lowerlegl', endChild: 'toesl', radius: 0.042, mass: 1, angle: 2.9, twist: 1.8, tone: 0.9 },
  { bone: 'upperlegr', parent: 'hips', endChild: 'lowerlegr', radius: 0.058, mass: 5, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'lowerlegr', parent: 'upperlegr', endChild: 'footr', radius: 0.048, mass: 3.2, angle: 2.9, twist: 1.8, tone: 1 },
  { bone: 'footr', parent: 'lowerlegr', endChild: 'toesr', radius: 0.042, mass: 1, angle: 2.9, twist: 1.8, tone: 0.9 },
];

export const GROUP = { GROUND: 1, BODY: 2, LIMB: 4, WALL: 8 };

export class RagdollPart {
  body!: CANNON.Body;
  constraint: CANNON.PointToPointConstraint | null = null;
  bone!: THREE.Bone;
  def!: PartDef;
  targetPos = new THREE.Vector3();
  targetQuat = new THREE.Quaternion();
  stiffness = 1;
  active = true;
  /** local (bone space) segment info used for hitboxes and stump placement */
  segCenter = new THREE.Vector3();
  segDir = new THREE.Vector3(0, 1, 0);
  segLen = 0.2;
}

export class Ragdoll {
  parts = new Map<string, RagdollPart>();
  container!: THREE.Object3D;

  constructor(
    public world: CANNON.World,
    public group: number,
    public mask: number,
  ) {}

  /** disable/enable ground collision for a set of bones */
  setGroundCollision(on: boolean, names?: string[]) {
    for (const [n, part] of this.parts) {
      if (names && !names.includes(n)) continue;
      part.body.collisionFilterMask = on ? this.mask : this.mask & ~GROUP.GROUND;
      part.body.wakeUp();
    }
  }

  /** bindWorld: bind pose world matrices by bone name */
  build(
    container: THREE.Object3D,
    bones: Map<string, THREE.Bone>,
    bindWorld: Map<string, THREE.Matrix4>,
    defs: PartDef[],
  ) {
    this.container = container;
    for (const def of defs) {
      const bone = bones.get(def.bone);
      if (!bone) continue;
      const part = new RagdollPart();
      part.bone = bone;
      part.def = def;
      part.stiffness = def.tone ?? 1;

      const bw = bindWorld.get(def.bone)!;
      const inv = bw.clone().invert();

      // segment direction + length in bone-local space
      let dir = new THREE.Vector3(0, 1, 0);
      let len = def.len ?? 0.15;
      if (def.endChild && bindWorld.has(def.endChild)) {
        const endPos = new THREE.Vector3().setFromMatrixPosition(bindWorld.get(def.endChild)!);
        const local = endPos.clone().applyMatrix4(inv);
        len = local.length();
        if (len > 1e-5) dir = local.normalize();
      }
      part.segDir.copy(dir);
      part.segLen = len;
      part.segCenter.copy(dir).multiplyScalar(len * 0.5);

      const r = def.radius;
      const half = new CANNON.Vec3(r, len * 0.5 + r * 0.6, r);
      const shape = new CANNON.Box(half);
      const offset = new CANNON.Vec3(part.segCenter.x, part.segCenter.y, part.segCenter.z);
      const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), dir);
      const orient = new CANNON.Quaternion(q.x, q.y, q.z, q.w);

      const p = new THREE.Vector3().setFromMatrixPosition(bw);
      const rq = new THREE.Quaternion().setFromRotationMatrix(bw);
      const body = new CANNON.Body({
        mass: def.mass,
        position: new CANNON.Vec3(p.x, p.y, p.z),
        quaternion: new CANNON.Quaternion(rq.x, rq.y, rq.z, rq.w),
        linearDamping: 0.02,
        angularDamping: 0.06,
        collisionFilterGroup: this.group,
        collisionFilterMask: this.mask,
      });
      body.addShape(shape, offset, orient);
      body.allowSleep = false;
      body.updateMassProperties();
      this.world.addBody(body);
      part.body = body;
      this.parts.set(def.bone, part);
    }

    // constraints
    for (const def of defs) {
      if (!def.parent) continue;
      const child = this.parts.get(def.bone);
      const parent = this.parts.get(def.parent);
      if (!child || !parent) continue;
      const cw = bindWorld.get(def.bone)!;
      const pw = bindWorld.get(def.parent)!;
      const joint = new THREE.Vector3().setFromMatrixPosition(cw);
      const localInParent = joint.clone().applyMatrix4(pw.clone().invert());
      // cone axis in the parent frame: parent origin -> child origin
      const axisA = localInParent.clone().normalize();
      const axisB = child.segDir.clone().normalize();
      const maxF = 500 * (parent.def.mass + child.def.mass);
      void axisA;
      void axisB;
      const c = new CANNON.PointToPointConstraint(
        parent.body,
        new CANNON.Vec3(localInParent.x, localInParent.y, localInParent.z),
        child.body,
        new CANNON.Vec3(0, 0, 0),
        maxF,
      );
      c.collideConnected = false;
      this.world.addConstraint(c);
      child.constraint = c;
    }
  }

  capture() {
    for (const part of this.parts.values()) {
      if (!part.active) continue;
      part.bone.matrixWorld.decompose(part.targetPos, part.targetQuat, _tmpScale);
    }
  }

  blend(stiffness: number, dt: number) {
    for (const part of this.parts.values()) {
      if (!part.active) continue;
      const a = Math.max(0, Math.min(1, stiffness * part.stiffness));
      if (a <= 0.0001) continue;
      const b = part.body;
      _v.set(b.position.x, b.position.y, b.position.z);
      _v.lerp(part.targetPos, 1 - Math.pow(1 - a, Math.max(0.2, dt * 60)));
      b.position.set(_v.x, _v.y, _v.z);
      _q.set(b.quaternion.x, b.quaternion.y, b.quaternion.z, b.quaternion.w);
      _q.slerp(part.targetQuat, 1 - Math.pow(1 - a, Math.max(0.2, dt * 60)));
      b.quaternion.set(_q.x, _q.y, _q.z, _q.w);
      const damp = Math.max(0, 1 - a * 0.9);
      b.velocity.scale(damp, b.velocity);
      b.angularVelocity.scale(damp, b.angularVelocity);
      const vl = b.velocity.length();
      if (vl > 45) b.velocity.scale(45 / vl, b.velocity);
      const al = b.angularVelocity.length();
      if (al > 45) b.angularVelocity.scale(45 / al, b.angularVelocity);
    }
  }

  /** write physics transforms back into the bones (each in its own parent's space) */
  sync() {
    // parts are stored in hierarchy order, so parents are always written first
    for (const part of this.parts.values()) {
      if (!part.active) continue;
      const b = part.body;
      _v.set(b.position.x, b.position.y, b.position.z);
      _q.set(b.quaternion.x, b.quaternion.y, b.quaternion.z, b.quaternion.w);
      _m2.compose(_v, _q, _one);
      const parent = part.bone.parent ?? this.container;
      parent.updateWorldMatrix(true, false);
      _m.copy(parent.matrixWorld).invert();
      _m2.premultiply(_m);
      _m2.decompose(part.bone.position, part.bone.quaternion, _tmpScale);
      part.bone.updateMatrix();
    }
  }

  impulse(boneName: string, dir: THREE.Vector3, amount: number, point?: THREE.Vector3) {
    const part = this.parts.get(boneName);
    if (!part || !part.active) return;
    const p = point
      ? new CANNON.Vec3(
          point.x - part.body.position.x,
          point.y - part.body.position.y,
          point.z - part.body.position.z,
        )
      : new CANNON.Vec3(0, 0, 0);
    part.body.applyImpulse(new CANNON.Vec3(dir.x * amount, dir.y * amount, dir.z * amount), p);
    part.body.wakeUp();
  }

  /** removes the bodies of a bone subtree from this ragdoll (used when a limb is cut off) */
  removeBones(names: Set<string>) {
    for (const name of names) {
      const part = this.parts.get(name);
      if (!part) continue;
      if (part.constraint) {
        this.world.removeConstraint(part.constraint);
        part.constraint = null;
      }
      this.world.removeBody(part.body);
      part.active = false;
      this.parts.delete(name);
    }
    // constraints of children pointing at removed parents
    for (const part of this.parts.values()) {
      if (part.constraint && (!part.def.parent || !this.parts.has(part.def.parent))) {
        this.world.removeConstraint(part.constraint);
        part.constraint = null;
      }
    }
  }

  dispose() {
    for (const part of this.parts.values()) {
      if (part.constraint) this.world.removeConstraint(part.constraint);
      this.world.removeBody(part.body);
    }
    this.parts.clear();
  }
}

const _v = new THREE.Vector3();
const _q = new THREE.Quaternion();
const _m = new THREE.Matrix4();
const _m2 = new THREE.Matrix4();
const _one = new THREE.Vector3(1, 1, 1);
const _tmpScale = new THREE.Vector3();
