import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';
import { Ragdoll, HUMANOID, GROUP } from './ragdoll';
import type { BloodSystem, Wound } from './blood';

export type CharState = 'walk' | 'stumble' | 'down' | 'dead';

export interface Severable {
  id: string;
  bone: string;
  parent: string;
  label: string;
  hp: number;
  lethal: boolean;
  bleed: number;
  radius: number;
  /** bones that fly off with this part */
  limb: string[];
}

const S = (): Severable[] => [
  { id: 'head', bone: 'head', parent: 'chest', label: 'HEAD', hp: 18, lethal: true, bleed: 1.0, radius: 0.1, limb: ['head'] },
  {
    id: 'waist', bone: 'chest', parent: 'spine', label: 'WAIST', hp: 60, lethal: true, bleed: 1.5, radius: 0.14,
    limb: ['chest', 'head', 'upperarml', 'lowerarml', 'handl', 'upperarmr', 'lowerarmr', 'handr'],
  },
  { id: 'upperarm_l', bone: 'upperarml', parent: 'chest', label: 'LEFT UPPER ARM', hp: 24, lethal: false, bleed: 0.5, radius: 0.06, limb: ['upperarml', 'lowerarml', 'handl'] },
  { id: 'lowerarm_l', bone: 'lowerarml', parent: 'upperarml', label: 'LEFT FOREARM', hp: 20, lethal: false, bleed: 0.45, radius: 0.05, limb: ['lowerarml', 'handl'] },
  { id: 'hand_l', bone: 'handl', parent: 'lowerarml', label: 'LEFT HAND', hp: 12, lethal: false, bleed: 0.3, radius: 0.05, limb: ['handl'] },
  { id: 'upperarm_r', bone: 'upperarmr', parent: 'chest', label: 'RIGHT UPPER ARM', hp: 24, lethal: false, bleed: 0.5, radius: 0.06, limb: ['upperarmr', 'lowerarmr', 'handr'] },
  { id: 'lowerarm_r', bone: 'lowerarmr', parent: 'upperarmr', label: 'RIGHT FOREARM', hp: 20, lethal: false, bleed: 0.45, radius: 0.05, limb: ['lowerarmr', 'handr'] },
  { id: 'hand_r', bone: 'handr', parent: 'lowerarmr', label: 'RIGHT HAND', hp: 12, lethal: false, bleed: 0.3, radius: 0.05, limb: ['handr'] },
  { id: 'upperleg_l', bone: 'upperlegl', parent: 'hips', label: 'LEFT THIGH', hp: 34, lethal: false, bleed: 0.8, radius: 0.08, limb: ['upperlegl', 'lowerlegl', 'footl'] },
  { id: 'lowerleg_l', bone: 'lowerlegl', parent: 'upperlegl', label: 'LEFT SHIN (KNEE)', hp: 26, lethal: false, bleed: 0.7, radius: 0.065, limb: ['lowerlegl', 'footl'] },
  { id: 'foot_l', bone: 'footl', parent: 'lowerlegl', label: 'LEFT FOOT', hp: 14, lethal: false, bleed: 0.35, radius: 0.055, limb: ['footl'] },
  { id: 'upperleg_r', bone: 'upperlegr', parent: 'hips', label: 'RIGHT THIGH', hp: 34, lethal: false, bleed: 0.8, radius: 0.08, limb: ['upperlegr', 'lowerlegr', 'footr'] },
  { id: 'lowerleg_r', bone: 'lowerlegr', parent: 'upperlegr', label: 'RIGHT SHIN (KNEE)', hp: 26, lethal: false, bleed: 0.7, radius: 0.065, limb: ['lowerlegr', 'footr'] },
  { id: 'foot_r', bone: 'footr', parent: 'lowerlegr', label: 'RIGHT FOOT', hp: 14, lethal: false, bleed: 0.35, radius: 0.055, limb: ['footr'] },
];

/** bone -> severable part (null = plain body damage) */
const SEVER_BY_BONE: Record<string, string | null> = {
  head: 'head',
  spine: 'waist',
  hips: null,
  chest: null,
  upperarml: 'upperarm_l',
  lowerarml: 'lowerarm_l',
  handl: 'hand_l',
  upperarmr: 'upperarm_r',
  lowerarmr: 'lowerarm_r',
  handr: 'hand_r',
  upperlegl: 'upperleg_l',
  lowerlegl: 'lowerleg_l',
  footl: 'foot_l',
  upperlegr: 'upperleg_r',
  lowerlegr: 'lowerleg_r',
  footr: 'foot_r',
};

export const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, '');

export interface CharEvent {
  type: 'sever' | 'death' | 'hit' | 'down';
  label?: string;
  id: number;
}

const UP = new THREE.Vector3(0, 1, 0);

export class Character {
  static uid = 0;
  /** global multipliers driven by the UI */
  static stiffnessScale = 1;
  static walkThrough = false;
  id = Character.uid++;

  root = new THREE.Group();
  scaled = new THREE.Group();
  pivot = new THREE.Group();
  model!: THREE.Object3D;
  bones = new Map<string, THREE.Bone>();
  skinned: THREE.SkinnedMesh[] = [];
  skeleton!: THREE.Skeleton;
  mixer!: THREE.AnimationMixer;
  actions = new Map<string, THREE.AnimationAction>();
  currentAction: THREE.AnimationAction | null = null;
  ragdoll!: Ragdoll;
  limbs: Ragdoll[] = [];
  hitboxes: THREE.Mesh[] = [];
  bindWorld = new Map<string, THREE.Matrix4>();
  severables = new Map<string, Severable>();
  severed = new Set<string>();
  limbDamage = new Map<string, number>();
  wounds: Wound[] = [];
  limbGroups: THREE.Group[] = [];

  health = 100;
  state: CharState = 'walk';
  impact = 0;
  deadTime = 0;
  stumbleTime = 0;
  severedCount = 0;
  private rootBone: THREE.Bone | null = null;
  private hitFlash = 0;

  onEvent: ((e: CharEvent) => void) | null = null;

  constructor(
    private scene: THREE.Scene,
    private world: CANNON.World,
    template: THREE.Object3D,
    clips: THREE.AnimationClip[],
    private blood: BloodSystem,
    spawn: THREE.Vector3,
    public speedScale = 1,
  ) {
    this.root.add(this.scaled);
    this.model = SkeletonUtils.clone(template) as THREE.Object3D;
    this.scaled.add(this.model);
    this.scaled.add(this.pivot);
    this.root.position.copy(spawn);

    for (const s of S()) this.severables.set(s.id, s);

    // collect + per-instance geometry
    this.model.traverse((o) => {
      if ((o as THREE.Bone).isBone) {
        this.bones.set(norm(o.name), o as THREE.Bone);
      }
      const m = o as THREE.SkinnedMesh;
      if (m.isSkinnedMesh) {
        m.geometry = m.geometry.clone();
        m.frustumCulled = false;
        m.castShadow = true;
        this.skinned.push(m);
        if (!this.skeleton) this.skeleton = m.skeleton;
      } else if ((o as THREE.Mesh).isMesh) {
        o.castShadow = true;
      }
    });

    this.rootBone = this.bones.get('root') ?? null;

    // detach the skeleton from the animated root so physics can own it
    const hips = this.bones.get('hips');
    if (hips && hips.parent) {
      hips.parent.remove(hips);
      this.pivot.add(hips);
    }

    this.mixer = new THREE.AnimationMixer(this.root);
    for (const clip of clips) {
      const a = this.mixer.clipAction(clip);
      this.actions.set(clip.name, a);
    }

    scene.add(this.root);

    // bind pose snapshot
    this.skeleton.pose();
    if (this.rootBone) {
      this.rootBone.position.set(0, 0, 0);
      this.rootBone.quaternion.set(0, 0, 0, 1);
    }
    this.root.updateMatrixWorld(true);
    for (const [name, bone] of this.bones) this.bindWorld.set(name, bone.matrixWorld.clone());

    this.ragdoll = new Ragdoll(world, GROUP.BODY, GROUP.GROUND | GROUP.LIMB | GROUP.WALL);
    this.ragdoll.build(this.pivot, this.bones, this.bindWorld, HUMANOID);

    this.buildHitboxes();
    this.play('Walking_A', 0.01);
  }

  private buildHitboxes() {
    const mat = new THREE.MeshBasicMaterial({ visible: false });
    for (const [name, part] of this.ragdoll.parts) {
      const bone = part.bone;
      const r = part.def.radius * 1.75;
      const len = part.segLen;
      const geo = new THREE.BoxGeometry(r * 2, len * 0.5 + r, r * 2);
      const m = new THREE.Mesh(geo, mat);
      m.position.copy(part.segCenter);
      m.quaternion.setFromUnitVectors(UP, part.segDir);
      m.userData.hit = { char: this, bone: name, sever: SEVER_BY_BONE[name] ?? null };
      m.userData.size = new THREE.Vector3(r * 2, len * 0.5 + r, r * 2);
      m.frustumCulled = false;
      bone.add(m);
      this.hitboxes.push(m);
    }
  }

  private collect(bone: THREE.Bone, out: Set<string>) {
    out.add(norm(bone.name));
    for (const c of bone.children) if ((c as THREE.Bone).isBone) this.collect(c as THREE.Bone, out);
  }

  private boneIndices(names: Set<string>): Set<number> {
    const out = new Set<number>();
    this.skeleton.bones.forEach((b, i) => {
      if (names.has(norm(b.name))) out.add(i);
    });
    return out;
  }

  private hasWeightsIn(geo: THREE.BufferGeometry, idx: Set<number>) {
    const si = geo.getAttribute('skinIndex');
    if (!si) return false;
    const a = si.array as ArrayLike<number>;
    for (let i = 0; i < a.length; i++) if (idx.has(a[i])) return true;
    return false;
  }

  /** zero out skin weights so a mesh only shows the bones in `idx` (keep) or none of them */
  private mask(geo: THREE.BufferGeometry, idx: Set<number>, keep: boolean) {
    const si = geo.getAttribute('skinIndex') as THREE.BufferAttribute;
    const sw = geo.getAttribute('skinWeight') as THREE.BufferAttribute;
    if (!si || !sw) return;
    const sia = si.array as unknown as number[];
    const swa = sw.array as unknown as number[];
    const n = swa.length / 4;
    for (let v = 0; v < n; v++) {
      let total = 0;
      for (let k = 0; k < 4; k++) {
        const i = v * 4 + k;
        const inside = idx.has(sia[i]);
        if (keep ? !inside : inside) {
          swa[i] = 0;
          sia[i] = 0;
        } else total += swa[i];
      }
      if (total > 1e-4) {
        const inv = 1 / total;
        for (let k = 0; k < 4; k++) swa[v * 4 + k] *= inv;
      }
    }
    si.needsUpdate = true;
    sw.needsUpdate = true;
  }

  // ---------------------------------------------------------------- severing
  sever(partId: string, hitPoint: THREE.Vector3, dir: THREE.Vector3, force: number): boolean {
    const def = this.severables.get(partId);
    if (!def || this.severed.has(partId)) return false;
    const bone = this.bones.get(def.bone);
    const parentBone = this.bones.get(def.parent);
    if (!bone || !parentBone) return false;

    this.root.updateMatrixWorld(true);

    const subtree = new Set<string>();
    this.collect(bone, subtree);
    for (const s of this.severables.values()) if (subtree.has(s.bone)) this.severed.add(s.id);
    const subIdx = this.boneIndices(subtree);

    const cutLocal = bone.position.clone();
    const outward = cutLocal.clone().normalize();

    // ---- separate geometry: one copy for the loose limb, one for the body
    const limbRoot = new THREE.Group();
    limbRoot.name = 'limb_' + partId;
    this.scene.add(limbRoot);
    this.limbGroups.push(limbRoot);

    for (const mesh of this.skinned) {
      if (!this.hasWeightsIn(mesh.geometry, subIdx)) continue;
      const limbGeo = mesh.geometry.clone();
      this.mask(limbGeo, subIdx, true);
      const lm = new THREE.SkinnedMesh(limbGeo, mesh.material);
      lm.frustumCulled = false;
      lm.castShadow = true;
      limbRoot.add(lm);
      lm.bind(this.skeleton, new THREE.Matrix4());
      this.mask(mesh.geometry, subIdx, false);
    }

    // ---- detach the bone subtree
    const world = bone.matrixWorld.clone();
    if (bone.parent) bone.parent.remove(bone);
    limbRoot.add(bone);
    world.decompose(bone.position, bone.quaternion, bone.scale);
    bone.updateMatrix();

    // ---- physics: remove from the body ragdoll, add a free limb ragdoll
    this.ragdoll.removeBones(subtree);
    const limbDefs = HUMANOID.filter((d) => subtree.has(d.bone));
    const limbRag = new Ragdoll(this.world, GROUP.LIMB, GROUP.GROUND | GROUP.LIMB | GROUP.BODY | GROUP.WALL);
    limbRag.build(limbRoot, this.bones, this.bindWorld, limbDefs);
    this.limbs.push(limbRag);
    limbRag.impulse(def.bone, dir, force * 0.55, hitPoint);
    const p = limbRag.parts.get(def.bone);
    if (p) {
      p.body.angularVelocity.set(
        (Math.random() - 0.5) * 12,
        (Math.random() - 0.5) * 12,
        (Math.random() - 0.5) * 12,
      );
    }

    // ---- stumps + blood
    this.addStump(parentBone, cutLocal, outward, def.radius, def.bleed);
    const limbPart = limbRag.parts.get(def.bone);
    const segDir = limbPart ? limbPart.segDir.clone() : UP.clone();
    this.addStump(bone, new THREE.Vector3(), segDir.negate(), def.radius, def.bleed * 0.8);

    const stumpWorld = hitPoint.clone();
    this.blood.burst(stumpWorld, dir.clone().negate(), 34, 4.5, 3.2);
    this.blood.burst(stumpWorld, new THREE.Vector3(0, 1, 0), 16, 2.6, 3.5);
    this.severedCount++;
    this.impact = 1;

    if (def.lethal) this.kill();
    else this.evaluateState(true);

    this.onEvent?.({ type: 'sever', label: def.label, id: this.id });
    return true;
  }

  private addStump(bone: THREE.Bone, localPos: THREE.Vector3, localDir: THREE.Vector3, r: number, severity: number) {
    const anchor = new THREE.Object3D();
    anchor.position.copy(localPos);
    anchor.quaternion.setFromUnitVectors(UP, localDir.clone().normalize());
    bone.add(anchor);

    const boneMat = new THREE.MeshStandardMaterial({ color: 0xd9d2bd, roughness: 0.85, metalness: 0.02 });
    const goreMat = new THREE.MeshStandardMaterial({ color: 0x4a0209, roughness: 0.35, metalness: 0.05 });

    const cap = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.95, r * 0.8, 0.05, 14), boneMat);
    cap.position.y = 0.012;
    anchor.add(cap);
    const gore = new THREE.Mesh(new THREE.SphereGeometry(r * 0.82, 14, 10), goreMat);
    gore.scale.set(1, 0.55, 1);
    anchor.add(gore);
    cap.castShadow = true;
    gore.castShadow = true;

    const wound: Wound = {
      getPos: (out) => anchor.getWorldPosition(out),
      getDir: (out) =>
        out.set(0, 1, 0).applyQuaternion(anchor.getWorldQuaternion(_q1)),
      severity,
      age: 0,
      pumping: this.state !== 'dead',
      dead: false,
      trail: false,
    };
    this.blood.addWound(wound);
    this.wounds.push(wound);
    return wound;
  }

  // ---------------------------------------------------------------- damage
  hit(boneName: string, severId: string | null, hitPoint: THREE.Vector3, dir: THREE.Vector3, damage: number, force: number): 'severed' | 'wound' | 'hit' | 'dead' {
    if (severId) {
      const def = this.severables.get(severId);
      if (def) {
        const d = (this.limbDamage.get(severId) ?? 0) + damage;
        if (d >= def.hp) {
          this.sever(severId, hitPoint, dir, force);
          return 'severed';
        }
        this.limbDamage.set(severId, d);
        this.ragdoll.impulse(boneName, dir, force * 0.35, hitPoint);
        this.blood.burst(hitPoint, dir.clone().negate(), 10, 3.0, 2.4);
        this.impact = 1;
        this.hitFlash = 1;
        this.evaluateState(false);
        return 'wound';
      }
    }
    // body damage
    this.health -= damage;
    this.ragdoll.impulse(boneName, dir, force * 0.35, hitPoint);
    this.blood.burst(hitPoint, dir.clone().negate(), 8, 2.4, 2.2);
    this.impact = 1;
    this.hitFlash = 1;
    if (this.health <= 0) {
      this.kill();
      return 'dead';
    }
    this.evaluateState(false);
    return 'hit';
  }

  kill() {
    if (this.state === 'dead') return;
    this.state = 'dead';
    this.deadTime = 0;
    for (const w of this.wounds) w.pumping = false;
    this.play('Death_A', 0.18, true, 1.1);
    this.onEvent?.({ type: 'death', id: this.id });
  }

  private legScore() {
    let s = 0;
    for (const side of ['l', 'r'] as const) {
      if (!this.severed.has('upperleg_' + side) && !this.severed.has('lowerleg_' + side)) {
        s += this.severed.has('foot_' + side) ? 0.55 : 1;
      }
    }
    return s;
  }

  private evaluateState(fromSever: boolean) {
    if (this.state === 'dead') return;
    const score = this.legScore();
    if (score >= 1.5) {
      if (this.state !== 'walk') {
        this.state = 'walk';
        this.play('Walking_A', 0.25);
      }
    } else if (score >= 0.5) {
      if (this.state !== 'stumble') {
        this.state = 'stumble';
        this.stumbleTime = 0;
        if (!fromSever) this.play('Walking_A', 0.2);
        else this.onEvent?.({ type: 'down', label: 'MOBILITY LOST', id: this.id });
      }
    } else if (Character.walkThrough) {
      if (this.state !== 'stumble') {
        this.state = 'stumble';
        this.stumbleTime = 0;
        this.play('Walking_A', 0.3, false, 0.8);
        this.onEvent?.({ type: 'down', label: 'DRAGGING ITSELF', id: this.id });
      }
    } else if (this.state !== 'down') {
      this.state = 'down';
      this.stumbleTime = 0;
      this.play('Skeletons_Awaken_Floor_Long', 0.4);
      this.onEvent?.({ type: 'down', label: 'CRAWLING', id: this.id });
    }
  }

  private play(name: string, fade = 0.25, once = false, timeScale = 1) {
    const next = this.actions.get(name);
    if (!next) return;
    if (this.currentAction === next) {
      next.timeScale = timeScale;
      return;
    }
    const prev = this.currentAction;
    next.reset();
    next.setLoop(once ? THREE.LoopOnce : THREE.LoopRepeat, Infinity);
    next.clampWhenFinished = once;
    next.timeScale = timeScale;
    next.enabled = true;
    next.play();
    if (prev && fade > 0) next.crossFadeFrom(prev, fade, false);
    this.currentAction = next;
  }

  private stiffness(): number {
    const imp = 1 - 0.45 * this.impact;
    const k = Character.stiffnessScale;
    switch (this.state) {
      case 'walk':
        return 0.96 * imp * k;
      case 'stumble':
        return 0.44 * imp * k;
      case 'down':
        return 0.72 * k;
      case 'dead':
        return Math.max(0.05, (0.75 - this.deadTime * 0.7) * k);
    }
  }

  // ---------------------------------------------------------------- per frame
  prePhysics(dt: number, targetPos: THREE.Vector3, targetVel: THREE.Vector3) {
    this.impact = Math.max(0, this.impact - dt * 2.2);
    this.hitFlash = Math.max(0, this.hitFlash - dt * 4);
    if (this.state === 'dead') this.deadTime += dt;

    const alive = this.state !== 'dead';
    let speed = 0;
    if (alive) {
      const to = _v1.copy(targetPos).sub(this.root.position);
      to.y = 0;
      const dist = to.length();
      const desired =
        this.state === 'walk' ? (dist > 9 ? 3.1 : 1.5) : this.state === 'stumble' ? 0.6 : 0.34;
      speed = dist > 1.7 ? desired * this.speedScale : 0;
      if (dist > 0.001) {
        to.normalize();
        const want = Math.atan2(to.x, to.z);
        let diff = want - this.root.rotation.y;
        while (diff > Math.PI) diff -= Math.PI * 2;
        while (diff < -Math.PI) diff += Math.PI * 2;
        const turnRate = this.state === 'walk' ? 3 : 1.6;
        this.root.rotation.y += Math.max(-turnRate * dt, Math.min(turnRate * dt, diff));
        this.root.position.addScaledVector(to, speed * dt);
      }
      // avoid running into the player
      if (dist < 1.7) {
        this.root.position.addScaledVector(targetVel, dt * 0.35);
      }
    }

    // clip management
    if (this.state === 'walk') {
      this.play(dist2(this.root.position, targetPos) > 9 ? 'Running_A' : 'Walking_A', 0.3);
    } else if (this.state === 'stumble') {
      this.stumbleTime += dt;
      this.play('Walking_A', 0.2, false, 0.75);
      if (this.stumbleTime > 2.4) this.evaluateState(false);
    } else if (this.state === 'down') {
      this.play('Skeletons_Awaken_Floor_Long', 0.35);
    }

    this.mixer.update(dt);
    if (this.rootBone) {
      this.rootBone.position.set(0, 0, 0);
      this.rootBone.quaternion.set(0, 0, 0, 1);
    }
    this.root.updateMatrixWorld(true);

    this.ragdoll.capture();

    // stumble: lean towards the missing leg so the walk cycle visibly fails
    const hips = this.ragdoll.parts.get('hips');
    if (hips && this.state === 'stumble') {
      const left = _v2.set(1, 0, 0).applyAxisAngle(UP, this.root.rotation.y);
      const side = this.severed.has('lowerleg_l') || this.severed.has('upperleg_l') ? 1 : -1;
      hips.targetPos.addScaledVector(left, side * 0.11);
      hips.targetPos.y -= 0.06;
      hips.targetQuat.multiply(_q2.setFromAxisAngle(_v3.set(0, 0, 1), side * 0.3));
    }
    if (hips && this.state === 'dead') {
      hips.targetPos.y -= 0.02;
    }

    this.ragdoll.blend(this.stiffness(), dt);
  }

  postPhysics() {
    this.ragdoll.sync();
    for (const l of this.limbs) l.sync();
  }

  dispose() {
    this.ragdoll.dispose();
    for (const l of this.limbs) l.dispose();
    for (const w of this.wounds) w.dead = true;
    for (const g of this.limbGroups) this.scene.remove(g);
    this.scene.remove(this.root);
    this.mixer.stopAllAction();
    this.mixer.uncacheRoot(this.root);
  }

  get isDead() {
    return this.state === 'dead';
  }

  get alive() {
    return this.state !== 'dead';
  }
}

function dist2(a: THREE.Vector3, b: THREE.Vector3) {
  return a.distanceTo(b);
}

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _q1 = new THREE.Quaternion();
const _q2 = new THREE.Quaternion();
