import * as THREE from 'three';

/**
 * Realistic-ish blood system:
 *  - GPU point sprites for droplets / mist / arterial spurts
 *  - Persistent floor decals + growing blood pools
 *  - Wound emitters with a heartbeat pulse (pressure decays over time)
 */

export interface Wound {
  /** world position of the open stump */
  getPos(out: THREE.Vector3): THREE.Vector3;
  /** world direction the blood sprays out of the stump */
  getDir(out: THREE.Vector3): THREE.Vector3;
  /** 0..1 how bad the bleeding is */
  severity: number;
  age: number;
  /** true while the heart is still pumping */
  pumping: boolean;
  dead: boolean;
  /** set for wounds that lie on the ground -> leaves a trail */
  trail: boolean;
}

const PARTICLE_VS = /* glsl */ `
attribute float aSize;
attribute float aAlpha;
attribute float aType;
varying float vAlpha;
varying float vType;
void main() {
  vAlpha = aAlpha;
  vType = aType;
  vec4 mv = modelViewMatrix * vec4(position, 1.0);
  gl_PointSize = aSize * (420.0 / max(0.001, -mv.z));
  gl_Position = projectionMatrix * mv;
}`;

const PARTICLE_FS = /* glsl */ `
varying float vAlpha;
varying float vType;
void main() {
  vec2 d = gl_PointCoord - vec2(0.5);
  float r = length(d);
  if (r > 0.5) discard;
  float edge = smoothstep(0.5, 0.28, r);
  vec3 blood = vec3(0.30, 0.015, 0.02);
  vec3 bloodBright = vec3(0.55, 0.04, 0.05);
  vec3 spark = vec3(1.0, 0.72, 0.32);
  vec3 col = mix(mix(blood, bloodBright, vAlpha * 0.6), spark, step(0.5, vType));
  gl_FragColor = vec4(col, vAlpha * edge);
}`;

function makeSplatTexture(): THREE.Texture {
  const s = 128;
  const c = document.createElement('canvas');
  c.width = c.height = s;
  const g = c.getContext('2d')!;
  g.clearRect(0, 0, s, s);
  const cx = s / 2;
  const cy = s / 2;
  // main blob
  const grad = g.createRadialGradient(cx, cy, 0, cx, cy, s * 0.36);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.55, 'rgba(255,255,255,0.95)');
  grad.addColorStop(0.85, 'rgba(255,255,255,0.35)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grad;
  g.beginPath();
  g.arc(cx, cy, s * 0.37, 0, Math.PI * 2);
  g.fill();
  // irregular satellite droplets
  for (let i = 0; i < 34; i++) {
    const a = Math.random() * Math.PI * 2;
    const d = s * (0.16 + Math.random() * 0.32);
    const r = s * (0.012 + Math.random() * 0.055);
    const x = cx + Math.cos(a) * d;
    const y = cy + Math.sin(a) * d;
    const gg = g.createRadialGradient(x, y, 0, x, y, r);
    gg.addColorStop(0, 'rgba(255,255,255,0.95)');
    gg.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gg;
    g.beginPath();
    g.arc(x, y, r, 0, Math.PI * 2);
    g.fill();
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

interface Decal {
  mesh: THREE.Mesh;
  life: number;
  maxLife: number;
  targetScale: number;
  scale: number;
  active: boolean;
  pool: boolean;
}

export class BloodSystem {
  scene: THREE.Scene;
  maxParticles: number;

  private pos: Float32Array;
  private vel: Float32Array;
  private sizeAttr: THREE.BufferAttribute;
  private alphaAttr: THREE.BufferAttribute;
  private typeAttr: THREE.BufferAttribute;
  private life: Float32Array;
  private maxLife: Float32Array;
  private drag: Float32Array;
  private kind: Float32Array;
  private cursor = 0;

  private geometry: THREE.BufferGeometry;
  private points: THREE.Points;

  private decals: Decal[] = [];
  private decalCursor = 0;
  private decalY = 0;
  private splatTex: THREE.Texture;
  private decalMaterials: THREE.MeshBasicMaterial[] = [];

  wounds: Wound[] = [];
  liters = 0;
  private beat = 0;

  settings = { amount: 1, decals: true, gravity: 22 };

  constructor(scene: THREE.Scene, maxParticles = 6000, decalCount = 260) {
    this.scene = scene;
    this.maxParticles = maxParticles;

    this.pos = new Float32Array(maxParticles * 3);
    this.vel = new Float32Array(maxParticles * 3);
    this.life = new Float32Array(maxParticles);
    this.maxLife = new Float32Array(maxParticles);
    this.drag = new Float32Array(maxParticles);
    this.kind = new Float32Array(maxParticles);

    this.geometry = new THREE.BufferGeometry();
    const position = new THREE.BufferAttribute(this.pos, 3);
    position.setUsage(THREE.DynamicDrawUsage);
    this.sizeAttr = new THREE.BufferAttribute(new Float32Array(maxParticles), 1);
    this.sizeAttr.setUsage(THREE.DynamicDrawUsage);
    this.alphaAttr = new THREE.BufferAttribute(new Float32Array(maxParticles), 1);
    this.alphaAttr.setUsage(THREE.DynamicDrawUsage);
    this.typeAttr = new THREE.BufferAttribute(this.kind, 1);
    this.typeAttr.setUsage(THREE.DynamicDrawUsage);
    this.geometry.setAttribute('position', position);
    this.geometry.setAttribute('aSize', this.sizeAttr);
    this.geometry.setAttribute('aAlpha', this.alphaAttr);
    this.geometry.setAttribute('aType', this.typeAttr);
    this.geometry.boundingSphere = new THREE.Sphere(new THREE.Vector3(), 1e6);

    const mat = new THREE.ShaderMaterial({
      vertexShader: PARTICLE_VS,
      fragmentShader: PARTICLE_FS,
      transparent: true,
      depthWrite: false,
    });
    this.points = new THREE.Points(this.geometry, mat);
    this.points.frustumCulled = false;
    this.points.renderOrder = 5;
    scene.add(this.points);

    this.splatTex = makeSplatTexture();
    const geo = new THREE.PlaneGeometry(1, 1);
    geo.rotateX(-Math.PI / 2);
    const colors = [0x6b0710, 0x5c060e, 0x7a0a12, 0x4d050b];
    for (let i = 0; i < 4; i++) {
      this.decalMaterials.push(
        new THREE.MeshBasicMaterial({
          map: this.splatTex,
          transparent: true,
          depthWrite: false,
          opacity: 0.9,
          color: colors[i],
        }),
      );
    }
    for (let i = 0; i < decalCount; i++) {
      const mesh = new THREE.Mesh(geo, this.decalMaterials[i % this.decalMaterials.length]);
      mesh.visible = false;
      mesh.renderOrder = 2;
      scene.add(mesh);
      this.decals.push({ mesh, life: 0, maxLife: 60, targetScale: 1, scale: 1, active: false, pool: false });
    }
    // hide all particles initially
    for (let i = 0; i < maxParticles; i++) this.pos[i * 3 + 1] = -1000;
    this.sizeAttr.array.fill(0);
  }

  spawn(
    x: number,
    y: number,
    z: number,
    vx: number,
    vy: number,
    vz: number,
    size: number,
    life: number,
    kind = 0,
    drag = 0.6,
  ) {
    const i = this.cursor;
    this.cursor = (this.cursor + 1) % this.maxParticles;
    this.pos[i * 3] = x;
    this.pos[i * 3 + 1] = y;
    this.pos[i * 3 + 2] = z;
    this.vel[i * 3] = vx;
    this.vel[i * 3 + 1] = vy;
    this.vel[i * 3 + 2] = vz;
    this.life[i] = life;
    this.maxLife[i] = life;
    this.drag[i] = drag;
    this.kind[i] = kind;
    this.sizeAttr.array[i] = size;
    this.alphaAttr.array[i] = 1;
  }

  /** burst of droplets, e.g. a hit or an arterial spray */
  burst(p: THREE.Vector3, dir: THREE.Vector3, count: number, speed: number, spread: number, kind = 0) {
    const n = Math.max(1, Math.round(count * this.settings.amount));
    for (let i = 0; i < n; i++) {
      const s = speed * (0.45 + Math.random() * 0.9);
      const sp = spread;
      this.spawn(
        p.x + (Math.random() - 0.5) * 0.05,
        p.y + (Math.random() - 0.5) * 0.05,
        p.z + (Math.random() - 0.5) * 0.05,
        dir.x * s + (Math.random() - 0.5) * sp,
        dir.y * s + (Math.random() - 0.5) * sp + speed * 0.25,
        dir.z * s + (Math.random() - 0.5) * sp,
        0.035 + Math.random() * 0.055,
        1.4 + Math.random() * 1.6,
        kind,
        0.35,
      );
    }
    this.liters += n * 0.0009;
  }

  sparks(p: THREE.Vector3, dir: THREE.Vector3, count = 10) {
    for (let i = 0; i < count; i++) {
      const s = 4 + Math.random() * 7;
      this.spawn(
        p.x,
        p.y,
        p.z,
        dir.x * s + (Math.random() - 0.5) * 5,
        dir.y * s + (Math.random() - 0.5) * 5 + 1,
        dir.z * s + (Math.random() - 0.5) * 5,
        0.02 + Math.random() * 0.03,
        0.22 + Math.random() * 0.25,
        1,
        1.2,
      );
    }
  }

  addDecal(x: number, z: number, size: number, pool = false) {
    if (!this.settings.decals) return;
    const d = this.decals[this.decalCursor];
    this.decalCursor = (this.decalCursor + 1) % this.decals.length;
    this.decalY = (this.decalY + 0.00035) % 0.02;
    d.mesh.visible = true;
    d.mesh.position.set(x, 0.006 + this.decalY, z);
    d.mesh.rotation.y = Math.random() * Math.PI * 2;
    d.scale = pool ? size * 0.35 : size * 0.8;
    d.targetScale = size;
    d.pool = pool;
    d.life = 0;
    d.maxLife = pool ? 90 : 60;
    d.active = true;
    d.mesh.scale.setScalar(d.scale);
    const m = d.mesh.material as THREE.MeshBasicMaterial;
    m.opacity = pool ? 0.85 : 0.9;
  }

  addWound(w: Wound) {
    this.wounds.push(w);
  }

  update(dt: number, time: number) {
    // ---- particles
    const g = this.settings.gravity;
    const pos = this.pos;
    const vel = this.vel;
    let dirty = false;
    for (let i = 0; i < this.maxParticles; i++) {
      if (this.life[i] <= 0) continue;
      dirty = true;
      this.life[i] -= dt;
      const i3 = i * 3;
      const d = 1 - this.drag[i] * dt;
      vel[i3] *= d;
      vel[i3 + 1] = vel[i3 + 1] * d - g * dt;
      vel[i3 + 2] *= d;
      pos[i3] += vel[i3] * dt;
      pos[i3 + 1] += vel[i3 + 1] * dt;
      pos[i3 + 2] += vel[i3 + 2] * dt;

      const isSpark = this.kind[i] > 0.5;
      const ground = isSpark ? -1000 : 0.02;
      if (pos[i3 + 1] < ground) {
        // hit the floor -> leave a mark
        if (!isSpark) {
          const r = Math.min(1, Math.abs(vel[i3 + 1]) / 8);
          if (Math.random() < 0.55 + r * 0.4) {
            const sz = 0.09 + Math.random() * 0.3 * r;
            this.addDecal(pos[i3], pos[i3 + 2], sz);
          }
        }
        this.life[i] = 0;
        pos[i3 + 1] = -1000;
        this.alphaAttr.array[i] = 0;
        this.sizeAttr.array[i] = 0;
        continue;
      }
      const t = this.life[i] / this.maxLife[i];
      if (isSpark) {
        this.alphaAttr.array[i] = Math.min(1, t * 2.2);
      } else {
        this.alphaAttr.array[i] = Math.min(1, t * 3.5) * 0.95;
      }
    }
    if (dirty) {
      (this.geometry.getAttribute('position') as THREE.BufferAttribute).needsUpdate = true;
      this.sizeAttr.needsUpdate = true;
      this.alphaAttr.needsUpdate = true;
      this.typeAttr.needsUpdate = true;
    }

    // ---- decals growth / fade
    for (const d of this.decals) {
      if (!d.active) continue;
      d.life += dt;
      if (d.pool) {
        d.scale += (d.targetScale - d.scale) * Math.min(1, dt * 1.6);
        d.mesh.scale.setScalar(d.scale);
      }
      if (d.life > d.maxLife) {
        const m = d.mesh.material as THREE.MeshBasicMaterial;
        m.opacity -= dt * 0.05;
        if (m.opacity <= 0) {
          d.active = false;
          d.mesh.visible = false;
          m.opacity = 0.9;
        }
      }
    }

    // ---- wounds (heartbeat driven)
    this.beat = time;
    for (const w of this.wounds) {
      if (w.dead) continue;
      w.age += dt;
      const pulse = w.pumping ? 0.45 + 0.55 * Math.max(0, Math.sin(this.beat * 7.2)) ** 3 : 0.18;
      const decay = Math.max(0, 1 - w.age / 26);
      const rate = w.severity * pulse * decay * 46 * this.settings.amount;
      w.trail = w.getPos(_tmpPos).y < 0.35;
      let n = rate * dt;
      while (n > 0) {
        if (Math.random() < Math.min(1, n)) {
          w.getPos(_tmpPos);
          w.getDir(_tmpDir);
          const spd = w.pumping ? 3.4 + Math.random() * 4.2 : 0.6 + Math.random() * 1.2;
          this.spawn(
            _tmpPos.x,
            _tmpPos.y,
            _tmpPos.z,
            _tmpDir.x * spd + (Math.random() - 0.5) * 1.4,
            _tmpDir.y * spd + Math.random() * 1.9,
            _tmpDir.z * spd + (Math.random() - 0.5) * 1.4,
            0.03 + Math.random() * 0.05,
            1.2 + Math.random() * 1.5,
            0,
            0.4,
          );
          this.liters += 0.0007;
        }
        n -= 1;
      }
      // pooling under a low wound
      if (w.trail && Math.random() < dt * 8 * this.settings.amount) {
        w.getPos(_tmpPos);
        this.addDecal(_tmpPos.x + (Math.random() - 0.5) * 0.15, _tmpPos.z + (Math.random() - 0.5) * 0.15, 0.35 + Math.random() * 0.5, true);
      }
    }
    this.wounds = this.wounds.filter((w) => !w.dead || w.age < 0);
  }
}

const _tmpPos = new THREE.Vector3();
const _tmpDir = new THREE.Vector3();
