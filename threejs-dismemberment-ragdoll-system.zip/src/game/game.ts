import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { Character, norm } from './character';
import { BloodSystem } from './blood';
import { GROUP } from './ragdoll';
import modelUrl from '../assets/skeleton_warrior.glb?url';

export interface GameSettings {
  blood: number;
  stiffness: number;
  gravity: number;
  timeScale: number;
  showHitboxes: boolean;
  spawnCount: number;
  gore: number;
  walkThrough: boolean;
}

export interface GameStats {
  fps: number;
  alive: number;
  total: number;
  kills: number;
  severed: number;
  blood: number;
  weapon: string;
  ammo: string;
  timeScale: number;
  locked: boolean;
}

interface Weapon {
  id: string;
  name: string;
  damage: number;
  force: number;
  pellets: number;
  spread: number;
  rate: number;
  auto: boolean;
  kick: number;
  mag: number;
}

const WEAPONS: Weapon[] = [
  { id: 'pistol', name: '.357 BONE SPLITTER', damage: 40, force: 60, pellets: 1, spread: 0.0, rate: 0.17, auto: false, kick: 1.5, mag: 8 },
  { id: 'shotgun', name: 'DOUBLE BARREL', damage: 17, force: 26, pellets: 10, spread: 0.055, rate: 0.72, auto: false, kick: 4.5, mag: 2 },
  { id: 'smg', name: 'BONE SHREDDER', damage: 16, force: 20, pellets: 1, spread: 0.014, rate: 0.075, auto: true, kick: 0.6, mag: 40 },
];

function floorTexture(): THREE.Texture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = c.height = s;
  const g = c.getContext('2d')!;
  g.fillStyle = '#2b2d33';
  g.fillRect(0, 0, s, s);
  // stone tiles
  const tiles = 4;
  const t = s / tiles;
  for (let y = 0; y < tiles; y++) {
    for (let x = 0; x < tiles; x++) {
      const v = 40 + Math.random() * 26;
      g.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
      g.fillRect(x * t + 3, y * t + 3, t - 6, t - 6);
      for (let i = 0; i < 60; i++) {
        const a = Math.random() * 0.09;
        g.fillStyle = `rgba(0,0,0,${a})`;
        g.fillRect(x * t + Math.random() * t, y * t + Math.random() * t, 3, 3);
      }
    }
  }
  g.strokeStyle = 'rgba(10,10,12,0.9)';
  g.lineWidth = 4;
  for (let i = 0; i <= tiles; i++) {
    g.beginPath(); g.moveTo(i * t, 0); g.lineTo(i * t, s); g.stroke();
    g.beginPath(); g.moveTo(0, i * t); g.lineTo(s, i * t); g.stroke();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(16, 16);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 8;
  return tex;
}

export class Game {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  world: CANNON.World;
  blood: BloodSystem;
  characters: Character[] = [];
  template: THREE.Object3D | null = null;
  clips: THREE.AnimationClip[] = [];
  settings: GameSettings = {
    blood: 1,
    stiffness: 1,
    gravity: 22,
    timeScale: 1,
    showHitboxes: false,
    spawnCount: 4,
    gore: 1,
    walkThrough: false,
  };
  onStats: ((s: GameStats) => void) | null = null;
  onToast: ((t: { text: string; kind: string }) => void) | null = null;
  onHitMarker: ((kind: string) => void) | null = null;
  onReady: (() => void) | null = null;

  private raycaster = new THREE.Raycaster();
  private aimBox: THREE.LineSegments;
  private hitboxList: THREE.Mesh[] = [];
  private keys = new Set<string>();
  private yaw = 0;
  private pitch = -0.05;
  private playerPos = new THREE.Vector3(0, 1.7, 10);
  private playerVel = new THREE.Vector3();
  private locked = false;
  private firing = false;
  private cooldown = 0;
  private weaponIndex = 0;
  private ammo = WEAPONS.map((w) => w.mag);
  private recoil = 0;
  private muzzle: THREE.PointLight;
  private gun: THREE.Group;
  private tracers: { mesh: THREE.Mesh; life: number }[] = [];
  private clock = new THREE.Clock();
  private time = 0;
  private frames = 0;
  private fpsTime = 0;
  private fps = 60;
  private statTime = 0;
  private kills = 0;
  private severedTotal = 0;
  private raf = 0;
  private disposed = false;
  private pendingShot = false;
  private spawnTimer = 0;

  constructor(private canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
    this.renderer.setSize(innerWidth, innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene.background = new THREE.Color(0x0a0b10);
    this.scene.fog = new THREE.FogExp2(0x0a0b10, 0.021);

    this.camera = new THREE.PerspectiveCamera(72, innerWidth / innerHeight, 0.05, 400);
    this.camera.rotation.order = 'YXZ';

    // ---------------- physics
    this.world = new CANNON.World({ gravity: new CANNON.Vec3(0, -this.settings.gravity, 0) });
    this.world.broadphase = new CANNON.SAPBroadphase(this.world);
    this.world.solver = new CANNON.GSSolver();
    (this.world.solver as CANNON.GSSolver).iterations = 12;
    (this.world.solver as CANNON.GSSolver).tolerance = 0.002;
    this.world.allowSleep = false;
    this.world.defaultContactMaterial.friction = 0.7;
    this.world.defaultContactMaterial.restitution = 0.08;

    // ---------------- lights
    const hemi = new THREE.HemisphereLight(0x556b9e, 0x101014, 0.5);
    this.scene.add(hemi);
    const dir = new THREE.DirectionalLight(0xcfe0ff, 1.5);
    dir.position.set(14, 24, 10);
    dir.castShadow = true;
    dir.shadow.mapSize.set(2048, 2048);
    dir.shadow.camera.left = -24;
    dir.shadow.camera.right = 24;
    dir.shadow.camera.top = 24;
    dir.shadow.camera.bottom = -24;
    dir.shadow.camera.far = 70;
    dir.shadow.bias = -0.0012;
    this.scene.add(dir);
    const rim = new THREE.DirectionalLight(0xff5a3c, 0.55);
    rim.position.set(-16, 8, -14);
    this.scene.add(rim);

    // ---------------- arena
    const floor = new THREE.Mesh(
      new THREE.PlaneGeometry(120, 120),
      new THREE.MeshStandardMaterial({ map: floorTexture(), roughness: 0.94, metalness: 0.02, color: 0x9aa0ab }),
    );
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    const groundBody = new CANNON.Body({
      mass: 0,
      shape: new CANNON.Plane(),
      collisionFilterGroup: GROUP.GROUND,
      collisionFilterMask: -1,
    });
    groundBody.quaternion.setFromAxisAngle(new CANNON.Vec3(1, 0, 0), -Math.PI / 2);
    this.world.addBody(groundBody);

    // pillars
    const pillarMat = new THREE.MeshStandardMaterial({ color: 0x4a4d57, roughness: 0.9 });
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      const r = 17;
      const h = 5 + (i % 3);
      const x = Math.cos(a) * r;
      const z = Math.sin(a) * r;
      const p = new THREE.Mesh(new THREE.BoxGeometry(1.2, h, 1.2), pillarMat);
      p.position.set(x, h / 2, z);
      p.castShadow = true;
      p.receiveShadow = true;
      this.scene.add(p);
      const b = new CANNON.Body({
        mass: 0,
        shape: new CANNON.Box(new CANNON.Vec3(0.6, h / 2, 0.6)),
        position: new CANNON.Vec3(x, h / 2, z),
        collisionFilterGroup: GROUP.WALL,
      });
      this.world.addBody(b);
      const torch = new THREE.PointLight(0xff7a30, 6, 16, 2);
      torch.position.set(x, h - 0.4, z);
      this.scene.add(torch);
    }

    this.blood = new BloodSystem(this.scene, 6000, 300);
    this.blood.settings.gravity = this.settings.gravity;

    // ---------------- aim helper
    this.aimBox = new THREE.LineSegments(
      new THREE.EdgesGeometry(new THREE.BoxGeometry(1, 1, 1)),
      new THREE.LineBasicMaterial({ color: 0xff3b30, transparent: true, opacity: 0.85 }),
    );
    this.aimBox.visible = false;
    this.aimBox.renderOrder = 10;
    this.scene.add(this.aimBox);

    // ---------------- view model
    this.gun = new THREE.Group();
    const gunMat = new THREE.MeshStandardMaterial({ color: 0x23262d, roughness: 0.45, metalness: 0.75 });
    const gunMat2 = new THREE.MeshStandardMaterial({ color: 0x51555f, roughness: 0.35, metalness: 0.9 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.11, 0.42), gunMat);
    this.gun.add(body);
    const barrel = new THREE.Mesh(new THREE.CylinderGeometry(0.021, 0.024, 0.3, 12), gunMat2);
    barrel.rotation.x = Math.PI / 2;
    barrel.position.set(0, 0.018, -0.33);
    this.gun.add(barrel);
    const grip = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.17, 0.1), gunMat);
    grip.position.set(0, -0.12, 0.11);
    grip.rotation.x = -0.28;
    this.gun.add(grip);
    const mag = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.16, 0.08), gunMat2);
    mag.position.set(0, -0.11, -0.02);
    this.gun.add(mag);
    this.gun.position.set(0.19, -0.17, -0.42);
    this.camera.add(this.gun);
    this.scene.add(this.camera);

    this.muzzle = new THREE.PointLight(0xffc27a, 0, 9, 2);
    this.muzzle.position.set(0, 0.02, -0.62);
    this.gun.add(this.muzzle);

    // tracer pool
    const tgeo = new THREE.CylinderGeometry(0.008, 0.008, 1, 6, 1, true);
    tgeo.rotateX(Math.PI / 2);
    tgeo.translate(0, 0, -0.5);
    for (let i = 0; i < 14; i++) {
      const m = new THREE.Mesh(
        tgeo,
        new THREE.MeshBasicMaterial({ color: 0xffd39a, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false }),
      );
      m.visible = false;
      m.frustumCulled = false;
      this.scene.add(m);
      this.tracers.push({ mesh: m, life: 0 });
    }

    this.bindEvents();
    void this.load();
  }

  private async load() {
    const loader = new GLTFLoader();
    const gltf = await loader.loadAsync(modelUrl);
    this.template = gltf.scene;
    this.clips = gltf.animations;
    this.template.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.isMesh) {
        m.castShadow = true;
        m.receiveShadow = false;
        const mats = Array.isArray(m.material) ? m.material : [m.material];
        for (const mat of mats) {
          const sm = mat as THREE.MeshStandardMaterial;
          if (sm.isMeshStandardMaterial) {
            sm.metalness = 0.05;
            sm.roughness = Math.min(0.95, sm.roughness ?? 0.8);
            sm.envMapIntensity = 0.5;
          }
        }
      }
    });
    for (let i = 0; i < this.settings.spawnCount; i++) this.spawn();
    this.onReady?.();
  }

  // ------------------------------------------------------------------ spawning
  spawn() {
    if (!this.template) return;
    const a = Math.random() * Math.PI * 2;
    const r = 11 + Math.random() * 6;
    const p = new THREE.Vector3(Math.cos(a) * r, 0, Math.sin(a) * r);
    if (p.distanceTo(this.playerPos) < 7) p.multiplyScalar(-1);
    const c = new Character(this.scene, this.world, this.template, this.clips, this.blood, p, 0.85 + Math.random() * 0.35);
    c.onEvent = (e) => this.handleEvent(e);
    this.characters.push(c);
    this.refreshHitboxes();
  }

  private refreshHitboxes() {
    this.hitboxList = [];
    for (const c of this.characters) this.hitboxList.push(...c.hitboxes);
  }

  private handleEvent(e: { type: string; label?: string; id: number }) {
    if (e.type === 'sever' && e.label) {
      this.severedTotal++;
      this.onToast?.({ text: `${e.label} SEVERED`, kind: 'sever' });
    } else if (e.type === 'death') {
      this.kills++;
      this.onToast?.({ text: 'SKELETON DESTROYED', kind: 'kill' });
    } else if (e.type === 'down' && e.label) {
      this.onToast?.({ text: e.label, kind: 'down' });
    }
  }

  reset() {
    for (const c of this.characters) c.dispose();
    this.characters = [];
    this.kills = 0;
    this.severedTotal = 0;
    this.blood.liters = 0;
    this.refreshHitboxes();
    for (let i = 0; i < this.settings.spawnCount; i++) this.spawn();
  }

  /** used by the UI: blow a random limb off every skeleton */
  severRandom() {
    const ids = ['lowerleg_l', 'lowerleg_r', 'upperarm_l', 'head', 'upperleg_l'];
    for (const c of this.characters) {
      const id = ids[Math.floor(Math.random() * ids.length)];
      const bone = c.severables.get(id);
      if (!bone) continue;
      const dir = new THREE.Vector3(Math.random() - 0.5, 0.4, Math.random() - 0.5).normalize();
      c.sever(id, new THREE.Vector3(c.root.position.x, 1, c.root.position.z), dir, 14);
    }
  }

  explode() {
    for (const c of this.characters) {
      const d = new THREE.Vector3(c.root.position.x - this.playerPos.x, 0.2, c.root.position.z - this.playerPos.z).normalize();
      for (const id of ['upperarm_l', 'upperarm_r', 'head', 'lowerleg_l', 'lowerleg_r']) {
        c.sever(id, new THREE.Vector3(c.root.position.x, 1.2, c.root.position.z), d, 22);
      }
      c.hit('hips', null, new THREE.Vector3(c.root.position.x, 1, c.root.position.z), d, 200, 40);
    }
  }

  // ------------------------------------------------------------------ input
  private bindEvents() {
    const c = this.canvas;
    c.addEventListener('click', () => {
      if (!this.locked) c.requestPointerLock();
    });
    document.addEventListener('pointerlockchange', () => {
      this.locked = document.pointerLockElement === c;
      this.firing = false;
      this.pushStats();
    });
    document.addEventListener('mousemove', (e) => {
      if (!this.locked) return;
      this.yaw -= e.movementX * 0.0022;
      this.pitch = Math.max(-1.45, Math.min(1.4, this.pitch - e.movementY * 0.0022));
    });
    document.addEventListener('mousedown', (e) => {
      if (!this.locked) return;
      if (e.button === 0) {
        this.firing = true;
        this.pendingShot = true;
      }
    });
    document.addEventListener('mouseup', (e) => {
      if (e.button === 0) this.firing = false;
    });
    document.addEventListener('keydown', (e) => {
      this.keys.add(e.code);
      if (e.code === 'Digit1') this.setWeapon(0);
      if (e.code === 'Digit2') this.setWeapon(1);
      if (e.code === 'Digit3') this.setWeapon(2);
      if (e.code === 'KeyR') this.ammo[this.weaponIndex] = WEAPONS[this.weaponIndex].mag;
      if (e.code === 'KeyF') this.settings.timeScale = this.settings.timeScale < 1 ? 1 : 0.18;
      if (e.code === 'KeyT') this.severRandom();
      if (e.code === 'KeyG') this.settings.showHitboxes = !this.settings.showHitboxes;
      if (e.code === 'KeyN') this.spawn();
      if (e.code === 'Space') e.preventDefault();
    });
    document.addEventListener('keyup', (e) => this.keys.delete(e.code));
    addEventListener('resize', () => this.resize());
  }

  setWeapon(i: number) {
    this.weaponIndex = Math.max(0, Math.min(WEAPONS.length - 1, i));
    this.cooldown = 0.25;
  }

  get weapon() {
    return WEAPONS[this.weaponIndex];
  }

  private resize() {
    this.camera.aspect = innerWidth / innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(innerWidth, innerHeight);
  }

  // ------------------------------------------------------------------ shooting
  private shoot() {
    const w = this.weapon;
    if (this.ammo[this.weaponIndex] <= 0) {
      this.ammo[this.weaponIndex] = w.mag;
    }
    this.ammo[this.weaponIndex]--;
    this.recoil = Math.min(1.6, this.recoil + w.kick * 0.28);
    this.muzzle.intensity = 14;
    this.blood.sparks(this.gunMuzzleWorld(_v1), _v2.set(0, 0, -1).applyQuaternion(this.camera.quaternion), 6);

    const origin = this.camera.getWorldPosition(new THREE.Vector3());
    const base = new THREE.Vector3(0, 0, -1).applyQuaternion(this.camera.quaternion);
    const muzzle = this.gunMuzzleWorld(new THREE.Vector3());

    for (let p = 0; p < w.pellets; p++) {
      const dir = base.clone();
      if (w.spread > 0) {
        dir.x += (Math.random() - 0.5) * w.spread * 2;
        dir.y += (Math.random() - 0.5) * w.spread * 2;
        dir.z += (Math.random() - 0.5) * w.spread * 2;
        dir.normalize();
      }
      this.raycaster.set(origin, dir);
      this.raycaster.far = 220;
      const hits = this.raycaster.intersectObjects(this.hitboxList, false);
      let end = origin.clone().addScaledVector(dir, 90);
      if (hits.length) {
        const h = hits[0];
        end = h.point.clone();
        const info = h.object.userData.hit as { char: Character; bone: string; sever: string | null };
        const forceDir = dir.clone();
        const res = info.char.hit(info.bone, info.sever, h.point, forceDir, w.damage * this.settings.gore, w.force);
        this.onHitMarker?.(res === 'severed' ? 'sever' : res === 'dead' ? 'kill' : 'hit');
      } else {
        // environment
        const floorHit = this.raycaster.ray.intersectPlane(_plane, _v3);
        if (floorHit) {
          end = _v3.clone();
          this.blood.sparks(end, dir.clone().negate(), 5);
          this.blood.addDecal(end.x, end.z, 0.12 + Math.random() * 0.1);
        }
      }
      this.tracer(muzzle, end);
    }
  }

  private gunMuzzleWorld(out: THREE.Vector3) {
    this.gun.updateWorldMatrix(true, false);
    return out.set(0, 0.02, -0.6).applyMatrix4(this.gun.matrixWorld);
  }

  private tracer(a: THREE.Vector3, b: THREE.Vector3) {
    const t = this.tracers.find((x) => x.life <= 0) ?? this.tracers[0];
    t.life = 0.07;
    t.mesh.visible = true;
    (t.mesh.material as THREE.MeshBasicMaterial).opacity = 0.9;
    t.mesh.position.copy(a);
    t.mesh.lookAt(b);
    t.mesh.scale.set(1, 1, a.distanceTo(b));
  }

  // ------------------------------------------------------------------ loop
  start() {
    this.clock.start();
    const loop = () => {
      if (this.disposed) return;
      this.raf = requestAnimationFrame(loop);
      this.frame();
    };
    this.raf = requestAnimationFrame(loop);
  }

  private frame() {
    const raw = Math.min(0.05, this.clock.getDelta());
    this.time += raw;
    this.frames++;
    this.fpsTime += raw;
    if (this.fpsTime > 0.5) {
      this.fps = this.frames / this.fpsTime;
      this.frames = 0;
      this.fpsTime = 0;
    }

    // ---- time scale (slow motion)
    const want = this.settings.timeScale;
    this.slowmo = this.slowmo || 0;
    this.slowmo += (want - this.slowmo) * Math.min(1, raw * 8);
    const dt = raw * this.slowmo;

    Character.stiffnessScale = this.settings.stiffness;
    Character.walkThrough = this.settings.walkThrough;
    this.world.gravity.set(0, -this.settings.gravity, 0);
    this.blood.settings.amount = this.settings.blood;
    this.blood.settings.gravity = this.settings.gravity;

    // ---- player
    this.updatePlayer(raw);

    // ---- shooting
    const w = this.weapon;
    this.cooldown -= raw;
    const wantsShot = w.auto ? this.firing : this.pendingShot;
    if (wantsShot && this.cooldown <= 0 && this.locked) {
      this.shoot();
      this.cooldown = w.rate;
    }
    this.pendingShot = false;
    this.recoil *= Math.pow(0.0025, raw);
    this.muzzle.intensity *= Math.pow(0.0001, raw);
    this.gun.position.set(0.19, -0.17, -0.42 + this.recoil * 0.09);
    this.gun.rotation.set(this.recoil * 0.35, 0, 0);

    // ---- characters + physics
    const pp = this.playerPos.clone();
    const pv = this.playerVel.clone();
    for (const c of this.characters) c.prePhysics(dt, pp, pv);
    this.world.step(1 / 60, Math.max(dt, 1e-4), 4);
    for (const c of this.characters) c.postPhysics();
    this.scene.updateMatrixWorld(true);

    // ---- aim highlight
    this.updateAim();

    // ---- blood
    this.blood.update(dt, this.time);

    // ---- keep the arena populated
    this.spawnTimer += raw;
    if (this.spawnTimer > 1.2) {
      this.spawnTimer = 0;
      const alive = this.characters.filter((c) => c.alive).length;
      if (alive < this.settings.spawnCount) this.spawn();
      if (this.characters.length > 14) {
        const dead = this.characters.find((c) => c.isDead);
        if (dead) {
          dead.dispose();
          this.characters.splice(this.characters.indexOf(dead), 1);
          this.refreshHitboxes();
        }
      }
    }

    this.renderer.render(this.scene, this.camera);

    this.statTime += raw;
    if (this.statTime > 0.12) {
      this.statTime = 0;
      this.pushStats();
    }
  }

  private slowmo = 1;

  private updateAim() {
    this.aimBox.visible = false;
    if (!this.locked && !this.pendingShot) {
      // still show it when not locked so users can see the system
    }
    const origin = this.camera.getWorldPosition(_v1);
    const dir = _v2.set(0, 0, -1).applyQuaternion(this.camera.quaternion);
    this.raycaster.set(origin, dir);
    this.raycaster.far = 200;
    const hits = this.raycaster.intersectObjects(this.hitboxList, false);
    for (const c of this.characters) {
      for (const h of c.hitboxes) (h.material as THREE.MeshBasicMaterial).visible = this.settings.showHitboxes;
    }
    if (hits.length) {
      const h = hits[0];
      const size = h.object.userData.size as THREE.Vector3;
      if (size) {
        this.aimBox.visible = true;
        h.object.matrixWorld.decompose(this.aimBox.position, this.aimBox.quaternion, _v3);
        this.aimBox.scale.copy(size).multiplyScalar(1.06);
      }
    }
  }

  private updatePlayer(dt: number) {
    const k = this.keys;
    const fwd = (k.has('KeyW') ? 1 : 0) - (k.has('KeyS') ? 1 : 0);
    const side = (k.has('KeyD') ? 1 : 0) - (k.has('KeyA') ? 1 : 0);
    const speed = k.has('ShiftLeft') || k.has('ShiftRight') ? 8.5 : 4.2;
    const dir = _v1.set(side, 0, -fwd);
    if (dir.lengthSq() > 0) dir.normalize().applyAxisAngle(_up, this.yaw);
    const desired = _v2.copy(dir).multiplyScalar(speed);
    this.playerVel.lerp(desired, 1 - Math.pow(0.0008, dt));
    this.playerPos.addScaledVector(this.playerVel, dt);
    if (k.has('Space')) this.playerPos.y += 5 * dt;
    if (k.has('KeyC') || k.has('ControlLeft')) this.playerPos.y -= 5 * dt;
    this.playerPos.y = Math.max(0.75, Math.min(14, this.playerPos.y));
    const r = Math.hypot(this.playerPos.x, this.playerPos.z);
    if (r > 22) {
      this.playerPos.x *= 22 / r;
      this.playerPos.z *= 22 / r;
    }
    this.camera.position.copy(this.playerPos);
    this.camera.rotation.set(this.pitch + this.recoil * 0.06, this.yaw, 0);
  }

  private pushStats() {
    this.onStats?.({
      fps: Math.round(this.fps),
      alive: this.characters.filter((c) => c.alive).length,
      total: this.characters.length,
      kills: this.kills,
      severed: this.severedTotal,
      blood: this.blood.liters,
      weapon: this.weapon.name,
      ammo: `${this.ammo[this.weaponIndex]}/${this.weapon.mag}`,
      timeScale: this.slowmo,
      locked: this.locked,
    });
  }

  dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.raf);
    for (const c of this.characters) c.dispose();
    this.renderer.dispose();
  }
}

const _v1 = new THREE.Vector3();
const _v2 = new THREE.Vector3();
const _v3 = new THREE.Vector3();
const _up = new THREE.Vector3(0, 1, 0);
const _plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
export { norm };
