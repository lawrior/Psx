/* Node harness: validates the real pipeline without a browser */
import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import * as SkeletonUtils from 'three/examples/jsm/utils/SkeletonUtils.js';
import * as fs from 'fs';
import { Character, norm } from './character';
import { HUMANOID } from './ragdoll';

// minimal browser stubs for the texture path
(globalThis as any).self = globalThis;
(globalThis as any).createImageBitmap = async () => ({ width: 4, height: 4, close: () => {} });
(globalThis as any).document = {
  createElement: () => ({ getContext: () => null, width: 0, height: 0 }),
};

async function main() {
  const buf = fs.readFileSync('src/assets/skeleton_warrior.glb');
  const ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  const loader = new GLTFLoader();
  const gltf = await loader.parseAsync(ab, '');
  const template = gltf.scene;
  console.log('parsed OK. animations:', gltf.animations.map((a) => a.name).join(', '));

  const bones: string[] = [];
  template.traverse((o: any) => {
    if (o.isBone) bones.push(o.name);
  });
  console.log('bones:', bones.join(','));
  const skinned: any[] = [];
  template.traverse((o: any) => {
    if (o.isSkinnedMesh) skinned.push(o.name);
  });
  console.log('skinned meshes:', skinned.join(','));

  // needed bones present?
  const need = ['root', 'hips', 'spine', 'chest', 'head', 'upperarml', 'lowerarml', 'wristl', 'handl', 'handslotl',
    'upperlegl', 'lowerlegl', 'footl', 'toesl', 'upperarmr', 'lowerarmr', 'wristr', 'handr', 'handslotr',
    'upperlegr', 'lowerlegr', 'footr', 'toesr'];
  const missing = need.filter((n) => !bones.some((b) => norm(b) === norm(n)));
  console.log('missing bones:', missing.length ? missing.join(',') : 'none');

  // bind pose sanity
  const scene = new THREE.Scene();
  const clone = SkeletonUtils.clone(template) as any;
  scene.add(clone);
  const hipsBone = clone.getObjectByName('hips')!;
  const parentOfHips = hipsBone.parent;
  parentOfHips.remove(hipsBone);
  const pivot = new THREE.Group();
  scene.add(pivot);
  pivot.add(hipsBone);
  const sk: THREE.SkinnedMesh[] = [];
  clone.traverse((o: any) => {
    if (o.isSkinnedMesh) {
      o.geometry = o.geometry.clone();
      o.frustumCulled = false;
      sk.push(o);
    }
  });
  const skeleton = sk[0].skeleton;
  skeleton.pose();
  scene.updateMatrixWorld(true);
  const headBone = scene.getObjectByName('head')!;
  const headPos = new THREE.Vector3().setFromMatrixPosition(headBone.matrixWorld);
  const footPos = new THREE.Vector3().setFromMatrixPosition(scene.getObjectByName('footl')!.matrixWorld);
  console.log('bind head y =', headPos.y.toFixed(3), ' foot y =', footPos.y.toFixed(3));

  // ---- ragdoll build on the real bind data
  const world = new CANNON.World({ gravity: new CANNON.Vec3(0, -22, 0) });
  const bindWorld = new Map<string, THREE.Matrix4>();
  const boneMap = new Map<string, THREE.Bone>();
  clone.traverse((o: any) => {
    if (o.isBone) {
      boneMap.set(norm(o.name), o);
      bindWorld.set(norm(o.name), o.matrixWorld.clone());
    }
  });
  const { Ragdoll, GROUP } = await import('./ragdoll');
  const rag = new Ragdoll(world, GROUP.BODY, GROUP.GROUND | GROUP.LIMB);
  rag.build(pivot, boneMap, bindWorld, HUMANOID);
  console.log('ragdoll parts:', [...rag.parts.keys()].join(','), 'constraints:', world.constraints.length);

  // ---- step the ragdoll with blending (active ragdoll)
  const mixer = new THREE.AnimationMixer(scene);
  const walk = gltf.animations.find((a) => a.name === 'Walking_A')!;
  const action = mixer.clipAction(walk, scene);
  action.play();
  let t = 0;
  for (let i = 0; i < 240; i++) {
    const dt = 1 / 60;
    t += dt;
    mixer.update(dt);
    scene.updateMatrixWorld(true);
    rag.capture();
    rag.blend(i > 60 ? 0.0 : 0.96, dt);
    world.step(1 / 60, dt, 4);
    rag.sync();
    scene.updateMatrixWorld(true);
  }
  const hipsAfter = new THREE.Vector3().setFromMatrixPosition(hipsBone.matrixWorld);
  console.log('after 4s of ragdoll (gravity on) hips y =', hipsAfter.y.toFixed(3), 'expected ~0.1-0.5 if it collapsed');

  // ---- focused ragdoll debug
  const bloodStub: any = {
    burst: () => {}, addWound: () => {}, addDecal: () => {}, sparks: () => {},
    liters: 0, settings: { amount: 1, gravity: 22, decals: true }, wounds: [], update: () => {},
  };
  const dbgScene = new THREE.Scene();
  const dbgWorld = new CANNON.World({ gravity: new CANNON.Vec3(0, -22, 0) });
  const dbg = new Character(dbgScene as any, dbgWorld, template, gltf.animations, bloodStub, new THREE.Vector3(0,0,0), 1);
  const tgt = new THREE.Vector3(0,0,10);
  for (let i = 0; i < 150; i++) {
    const dt = 1/60;
    dbg.prePhysics(dt, tgt, new THREE.Vector3());
    const hips = dbg.ragdoll.parts.get('hips')!;
    if (false) {
      const r = dbg.ragdoll;
      const pv = new THREE.Vector3().setFromMatrixPosition(r.container.matrixWorld);
      const row = ['hips','spine','chest','head'].map((n) => {
        const pt = r.parts.get(n)!;
        return n + '(bone ' + pt.bone.position.toArray().map((v) => v.toFixed(2)).join('/') + ' body ' + pt.body.position.toArray().map((v) => v.toFixed(2)).join('/') + ' tgt ' + pt.targetPos.toArray().map((v) => v.toFixed(2)).join('/') + ')';
      }).join(' ');
      console.log(' f' + i, 'rootPos', dbg.root.position.toArray().map((v) => v.toFixed(2)).join('/'), 'pivotW', pv.toArray().map((v) => v.toFixed(2)).join('/'), 'clip', dbg.currentAction?.getClip().name, '|', row);
    }
    if (i % 30 === 0) {
      const hp = dbg.ragdoll.parts.get('head')!;
      console.log(' f'+i, 'headBody', hp.body.position.y.toFixed(3), 'targetY', hp.targetPos.y.toFixed(3),
        'boneWorldY', new THREE.Vector3().setFromMatrixPosition(hp.bone.matrixWorld).y.toFixed(3),
        'headVel', hp.body.velocity.length().toFixed(2),
        'angVel', hp.body.angularVelocity.length().toFixed(2),
        'chestVel', dbg.ragdoll.parts.get('chest')!.body.velocity.length().toFixed(2));
    }
    if (i % 15 === 0) {
      let worst = 0, worstName = '';
      for (const [n, p] of dbg.ragdoll.parts) { const v = p.body.position.length(); if (v > worst) { worst = v; worstName = n; } }
      console.log(String(i).padStart(4), 'hipsBody', hips.body.position.y.toFixed(3), 'targetY', hips.targetPos.y.toFixed(3),
        'vel', hips.body.velocity.length().toFixed(2), '| worst', worstName, worst.toFixed(2),
        '| boneY', new THREE.Vector3().setFromMatrixPosition(hips.bone.matrixWorld).y.toFixed(3));
    }
    dbgWorld.step(1/60, dt, 4);
    dbg.postPhysics();
    dbgScene.updateMatrixWorld(true);
  }
  console.log('FINAL hips bone y', new THREE.Vector3().setFromMatrixPosition(dbg.bones.get('hips')!.matrixWorld).y.toFixed(3));
  dbg.dispose();

  // ================= multi character + dismemberment =================
  const scene2 = new THREE.Scene();
  const world2 = new CANNON.World({ gravity: new CANNON.Vec3(0, -22, 0) });
  const chars: Character[] = [];
  for (let i = 0; i < 3; i++) {
    chars.push(new Character(scene2 as any, world2, template, gltf.animations, bloodStub, new THREE.VectorVectorOrZero(), 1));
  }
  void chars;
}

main().catch((e) => { console.error('FAILED:', e); process.exit(1); });
