import { useEffect, useRef, useState } from 'react';
import { Game, type GameStats } from './game/game';

interface Toast {
  id: number;
  text: string;
  kind: string;
}

const defaultStats: GameStats = {
  fps: 0,
  alive: 0,
  total: 0,
  kills: 0,
  severed: 0,
  blood: 0,
  weapon: '',
  ammo: '',
  timeScale: 1,
  locked: false,
};

function Slider({
  label,
  value,
  min,
  max,
  step,
  fmt,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  fmt?: (v: number) => string;
  onChange: (v: number) => void;
}) {
  return (
    <label className="block select-none">
      <div className="flex items-baseline justify-between text-[10px] uppercase tracking-widest text-zinc-400">
        <span>{label}</span>
        <span className="font-mono text-[11px] text-red-400">{fmt ? fmt(value) : value.toFixed(2)}</span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="mt-1 h-1 w-full cursor-pointer appearance-none rounded bg-zinc-700 accent-red-500
                   [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:appearance-none
                   [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-red-500"
      />
    </label>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameRef = useRef<Game | null>(null);
  const [stats, setStats] = useState<GameStats>(defaultStats);
  const [ready, setReady] = useState(false);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [marker, setMarker] = useState<{ id: number; kind: string } | null>(null);
  const [panel, setPanel] = useState(true);
  const [cfg, setCfg] = useState({
    blood: 1,
    gore: 1,
    gravity: 22,
    stiffness: 1,
    timeScale: 1,
    spawnCount: 4,
    showHitboxes: false,
    walkThrough: false,
  });

  useEffect(() => {
    if (!canvasRef.current || gameRef.current) return;
    const game = new Game(canvasRef.current);
    gameRef.current = game;
    game.onStats = setStats;
    game.onReady = () => setReady(true);
    game.onHitMarker = (kind) => setMarker({ id: Math.random(), kind });
    game.onToast = (t) => {
      const id = Math.random();
      setToasts((prev) => [...prev.slice(-3), { id, text: t.text, kind: t.kind }]);
      setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 1900);
    };
    game.start();
    return () => {
      game.dispose();
      gameRef.current = null;
    };
  }, []);

  useEffect(() => {
    const g = gameRef.current;
    if (!g) return;
    g.settings.blood = cfg.blood;
    g.settings.gore = cfg.gore;
    g.settings.gravity = cfg.gravity;
    g.settings.stiffness = cfg.stiffness;
    g.settings.timeScale = cfg.timeScale;
    g.settings.spawnCount = cfg.spawnCount;
    g.settings.showHitboxes = cfg.showHitboxes;
    g.settings.walkThrough = cfg.walkThrough;
  }, [cfg, ready]);

  const g = gameRef.current;

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-black font-sans text-zinc-200">
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" />

      {/* vignette */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{ boxShadow: 'inset 0 0 220px 60px rgba(0,0,0,0.85)' }}
      />

      {/* ---------------- crosshair ---------------- */}
      <div className="pointer-events-none absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="relative h-8 w-8">
          <div className="absolute left-1/2 top-0 h-2.5 w-[2px] -translate-x-1/2 bg-red-500/80" />
          <div className="absolute bottom-0 left-1/2 h-2.5 w-[2px] -translate-x-1/2 bg-red-500/80" />
          <div className="absolute left-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-red-500/80" />
          <div className="absolute right-0 top-1/2 h-[2px] w-2.5 -translate-y-1/2 bg-red-500/80" />
          <div className="absolute left-1/2 top-1/2 h-[3px] w-[3px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-red-400" />
        </div>
        {marker && (
          <div key={marker.id} className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <div
              className="animate-[mark_0.45s_ease-out_forwards] text-2xl font-black leading-none"
              style={{ color: marker.kind === 'sever' ? '#ff2d2d' : marker.kind === 'kill' ? '#ff8a00' : '#ffffff88' }}
            >
              {marker.kind === 'sever' ? '✖' : marker.kind === 'kill' ? '☠' : '✕'}
            </div>
          </div>
        )}
      </div>

      {/* ---------------- toasts ---------------- */}
      <div className="pointer-events-none absolute left-1/2 top-24 flex -translate-x-1/2 flex-col items-center gap-1">
        {toasts.map((t) => (
          <div
            key={t.id}
            className="animate-[fade_1.9s_ease-out_forwards] border-l-2 bg-black/60 px-3 py-1 font-mono text-xs tracking-[0.2em] backdrop-blur-sm"
            style={{
              borderColor: t.kind === 'sever' ? '#ff2d2d' : t.kind === 'kill' ? '#ff8a00' : '#eab308',
              color: t.kind === 'sever' ? '#ff8a8a' : t.kind === 'kill' ? '#ffc178' : '#fde68a',
            }}
          >
            {t.text}
          </div>
        ))}
      </div>

      {/* ---------------- top left stats ---------------- */}
      <div className="pointer-events-none absolute left-4 top-4 select-none">
        <div className="flex items-center gap-2">
          <div className="h-6 w-1 bg-red-600" />
          <div>
            <h1 className="font-mono text-lg font-bold leading-none tracking-[0.22em] text-zinc-100">
              GORE<span className="text-red-500">LAB</span>
            </h1>
            <p className="font-mono text-[9px] uppercase tracking-[0.3em] text-zinc-500">
              dismemberment · active ragdoll · blood sim
            </p>
          </div>
        </div>
        <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-1 font-mono text-[11px]">
          <Stat label="FPS" value={String(stats.fps)} />
          <Stat label="TARGETS" value={`${stats.alive}/${stats.total}`} />
          <Stat label="KILLS" value={String(stats.kills)} color="text-orange-300" />
          <Stat label="LIMBS OFF" value={String(stats.severed)} color="text-red-400" />
          <Stat label="BLOOD" value={`${stats.blood.toFixed(2)} L`} color="text-red-500" />
          <Stat label="TIME" value={`${stats.timeScale.toFixed(2)}x`} color="text-sky-300" />
        </div>
      </div>

      {/* ---------------- settings panel ---------------- */}
      <div className="absolute right-4 top-4 w-72 select-none">
        <button
          onClick={() => setPanel((p) => !p)}
          className="mb-2 ml-auto flex items-center gap-2 border border-zinc-700 bg-black/70 px-3 py-1 font-mono text-[10px] uppercase tracking-[0.2em] text-zinc-300 backdrop-blur hover:border-red-600 hover:text-red-400"
        >
          {panel ? '× close' : '⚙ systems'}
        </button>
        {panel && (
          <div className="space-y-3 border border-zinc-800 bg-black/75 p-3 backdrop-blur-md">
            <div className="font-mono text-[10px] uppercase tracking-[0.25em] text-zinc-500">simulation</div>
            <Slider label="Blood volume" value={cfg.blood} min={0} max={3} step={0.05} onChange={(v) => setCfg({ ...cfg, blood: v })} />
            <Slider label="Damage / gore" value={cfg.gore} min={0.2} max={3} step={0.05} onChange={(v) => setCfg({ ...cfg, gore: v })} />
            <Slider label="Gravity" value={cfg.gravity} min={2} max={40} step={0.5} onChange={(v) => setCfg({ ...cfg, gravity: v })} fmt={(v) => `${v.toFixed(1)} m/s²`} />
            <Slider label="Muscle tone" value={cfg.stiffness} min={0} max={1.2} step={0.02} onChange={(v) => setCfg({ ...cfg, stiffness: v })} />
            <Slider label="Time scale" value={cfg.timeScale} min={0.05} max={1} step={0.05} onChange={(v) => setCfg({ ...cfg, timeScale: v })} fmt={(v) => `${v.toFixed(2)}x`} />
            <Slider label="Max skeletons" value={cfg.spawnCount} min={1} max={10} step={1} onChange={(v) => setCfg({ ...cfg, spawnCount: v })} fmt={(v) => String(v)} />

            <div className="grid grid-cols-2 gap-2 pt-1">
              <Toggle label="Hitboxes" on={cfg.showHitboxes} onClick={() => setCfg({ ...cfg, showHitboxes: !cfg.showHitboxes })} />
              <Toggle label="Zombie walk" on={cfg.walkThrough} onClick={() => setCfg({ ...cfg, walkThrough: !cfg.walkThrough })} />
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <Btn onClick={() => g?.spawn()}>Spawn</Btn>
              <Btn onClick={() => g?.severRandom()}>Amputate</Btn>
              <Btn onClick={() => g?.explode()} danger>
                Explode
              </Btn>
              <Btn onClick={() => g?.reset()}>Reset</Btn>
            </div>
          </div>
        )}
      </div>

      {/* ---------------- bottom: weapon + controls ---------------- */}
      <div className="pointer-events-none absolute bottom-4 left-4 select-none space-y-2">
        <div className="font-mono text-[10px] leading-relaxed tracking-widest text-zinc-500">
          <div>
            <Key>WASD</Key> move · <Key>SHIFT</Key> sprint · <Key>SPACE</Key>/<Key>C</Key> fly
          </div>
          <div>
            <Key>LMB</Key> shoot joint · <Key>1</Key>/<Key>2</Key>/<Key>3</Key> weapon · <Key>R</Key> reload
          </div>
          <div>
            <Key>F</Key> slow-mo · <Key>T</Key> amputate · <Key>G</Key> hitboxes · <Key>N</Key> spawn
          </div>
        </div>
      </div>

      <div className="pointer-events-none absolute bottom-4 right-4 select-none text-right">
        <div className="font-mono text-[9px] uppercase tracking-[0.3em] text-zinc-500">weapon</div>
        <div className="font-mono text-sm tracking-[0.15em] text-zinc-200">{stats.weapon}</div>
        <div className="font-mono text-xs text-red-400">{stats.ammo}</div>
      </div>

      {/* ---------------- start / loading overlay ---------------- */}
      {!stats.locked && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/55 backdrop-blur-[2px]">
          <div className="max-w-lg border border-zinc-800 bg-black/80 p-8 text-center">
            <h2 className="font-mono text-2xl font-bold tracking-[0.25em] text-zinc-100">
              GORE<span className="text-red-500">LAB</span>
            </h2>
            <p className="mt-2 font-mono text-[10px] uppercase leading-relaxed tracking-[0.2em] text-zinc-500">
              procedural dismemberment · active ragdoll · volumetric blood
            </p>
            <p className="mt-5 text-sm leading-relaxed text-zinc-400">
              Shoot a skeleton in the <span className="text-red-400">knee</span> and the shin detaches — the walk cycle
              keeps firing, but the body physically collapses and starts dragging itself towards you. Head, arms, feet
              and even the waist can all be separated. Every stump pumps blood on a heartbeat.
            </p>
            {!ready ? (
              <div className="mt-6 font-mono text-xs uppercase tracking-[0.3em] text-red-400">
                loading skeleton rig…
              </div>
            ) : (
              <button
                onClick={() => canvasRef.current?.requestPointerLock()}
                className="mt-6 border border-red-700 bg-red-950/60 px-8 py-3 font-mono text-xs uppercase tracking-[0.3em] text-red-300 transition hover:bg-red-800/60 hover:text-white"
              >
                click to enter
              </button>
            )}
            <p className="mt-4 font-mono text-[9px] uppercase tracking-[0.2em] text-zinc-600">
              model: KayKit Skeletons (CC0) by Kay Lousberg · physics: cannon-es
            </p>
          </div>
        </div>
      )}

      <style>{`
        @keyframes mark { 0% { transform: scale(2.4) rotate(0deg); opacity: 1 } 100% { transform: scale(0.7) rotate(35deg); opacity: 0 } }
        @keyframes fade { 0% { opacity: 0; transform: translateY(-6px) } 12% { opacity: 1; transform: translateY(0) } 75% { opacity: 1 } 100% { opacity: 0 } }
      `}</style>
    </div>
  );
}

function Stat({ label, value, color = 'text-zinc-200' }: { label: string; value: string; color?: string }) {
  return (
    <div className="flex items-baseline justify-between gap-3 border-b border-zinc-800/70 pb-0.5">
      <span className="text-[9px] uppercase tracking-[0.2em] text-zinc-500">{label}</span>
      <span className={color}>{value}</span>
    </div>
  );
}

function Key({ children }: { children: React.ReactNode }) {
  return (
    <span className="rounded border border-zinc-700 bg-zinc-900 px-1 py-[1px] text-[9px] text-zinc-300">{children}</span>
  );
}

function Btn({
  children,
  onClick,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  danger?: boolean;
}) {
  return (
    <button
      onClick={onClick}
      className={`border px-2 py-1.5 font-mono text-[10px] uppercase tracking-[0.15em] transition ${
        danger
          ? 'border-red-800 bg-red-950/50 text-red-300 hover:bg-red-900/60 hover:text-white'
          : 'border-zinc-700 bg-zinc-900/70 text-zinc-300 hover:border-zinc-500 hover:text-white'
      }`}
    >
      {children}
    </button>
  );
}

function Toggle({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-between border px-2 py-1.5 font-mono text-[10px] uppercase tracking-[0.12em] transition ${
        on ? 'border-red-600 bg-red-950/60 text-red-300' : 'border-zinc-700 bg-zinc-900/60 text-zinc-400'
      }`}
    >
      <span>{label}</span>
      <span className={`h-2 w-2 rounded-full ${on ? 'bg-red-500' : 'bg-zinc-600'}`} />
    </button>
  );
}
