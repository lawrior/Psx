# Changelog

All notable changes to the Retro 3D FPS project will be documented in this file.

## [8.8] - 2026-09-17

### Fixed
- **Sell functionality**: Merchant now accepts ALL items from player inventory, not just merchant stock items
  - Added default sell prices for ingredients (apple: 15g, plum: 18g, pear: 20g, etc.)
  - Added sell prices for stolen items (trinkets: 40g, tools: 35g)
  - Added sell prices for player-made consumables (elixirs, stews, etc.)
  - Unknown items now sell for 5g base price

### Added
- **Physical item transfer when selling**: Sold items now visually transfer from player to merchant
  - Item appears as 3D visual and moves from player position to merchant location
  - Uses ItemTransferVisual system (same as pickpocketing)
  - Item lands near merchant's position (table/ground area)
  - Visual feedback makes selling feel more tangible and rewarding

### Changed
- **MerchantUI.gd**: Updated `_on_sell_pressed()` to pass `current_merchant` reference to `sell_item()`
- **MerchantManager.gd**: 
  - Expanded `get_sell_price()` to handle all inventory items with default prices
  - Modified `sell_item()` to accept optional `merchant_node` parameter
  - Added `_create_sell_transfer()` to spawn visual transfer effect
  - Added `_on_sell_transfer_complete()` callback for transfer completion

### Technical Details
- Sell prices calculated as 50% of buy price for merchant stock items
- Default prices set for common game items (ingredients, stolen goods, consumables)
- Visual transfer uses same animation system as pickpocketing for consistency
- Transfer targets merchant's position + Vector3(0, 0.5, 0) to appear on table/ground level

---

## [8.7] - 2026-09-17

### Fixed
- **Cat orientation**: Fixed upside-down cat model
  - Changed body capsule rotation from X-axis (90°) to Z-axis (90°)
  - Adjusted ear positions to positive Y (ears on top of head)
  - Adjusted leg positions to negative Y (legs below body)
  - Cat now appears right-side up in all orientations

- **Camera jitter**: Eliminated camera shaking during movement
  - Reduced interpolation factor from 14.0 to 8.0
  - Added clamping to prevent overshooting: `clamp(8.0 * delta, 0.0, 1.0)`
  - Only update `look_at()` when camera is significantly far from target (> 0.1 units)

- **Camera transitions**: Smoothed form switching transitions
  - Initialize camera position immediately in `_setup_tp_camera()` before making it current
  - Prevents jarring camera jumps when transforming

- **Collision shapes**: Fixed Godot 3 compatibility
  - Changed `shape.height` to `shape.mid_height` for CapsuleShape
  - Proper total height calculation: `mid_height + 2 * radius`

### Added
- **Merchant buy/sell system**: Complete trading interface
  - Press **M** to open merchant (later changed to interaction-based in v8.8)
  - Press **Escape** to close merchant
  - **Buy items**:
    - Weapons: Machete (150g), Machine Gun (400g), Shotgun (350g), Rocket Launcher (800g)
    - Ammo: Machine Gun Ammo (30g/50 rounds), Shotgun Shells (40g/20 shells), Rockets (100g/5)
    - Health: Small Health Pack (50g/+25 HP), Large Health Pack (120g/+75 HP)
    - Tools: Lockpick Set (80g), Repair Kit (100g)
  - **Sell items**: Sell inventory items for 50% of buy price
  - Real-time gold display updates after transactions
  - Stock quantities decrease when buying items
  - Smooth UI with item details panel showing name, description, and price

### Changed
- **Player.gd**: Added merchant_manager and merchant_ui initialization in `_ready()`
- **InventoryManager.gd**: Added `get_item_quantity()` and `get_all_items()` helper methods
- **WeaponManager.gd**: Added `add_ammo()` method to support ammo purchases

### New Files
- `characters/MerchantManager.gd` - Handles buy/sell logic, stock management, item effects
- `characters/MerchantUI.gd` - Buy/sell interface with item lists and transaction buttons

---

## [8.6] - 2026-09-17

### Fixed
- **Godot 3 API compatibility issues** that caused game to hang on launch:
  - Fixed `cull_mode` → `params_cull_mode` in AnimalFormManager (4 occurrences)
  - Fixed `CapsuleMesh.height` → `CapsuleMesh.mid_height` in cat form
  - Fixed `set_border_width_all()`, `set_corner_radius_all()`, `set_content_margin_all()` in InventoryUI
    - Replaced with individual property assignments (border_width_left/top/right/bottom, etc.)
  - Removed emoji characters from HUD text that caused rendering freezes

### Testing
- Verified all transformations work: Fish → Human → Bird → Human → Cat
- Tested with godot3-server headless mode to catch script errors
- All script errors resolved, game launches successfully

---

## [8.5] - 2026-09-17

### Added
- **Animal transformation system** (Update 7):
  - Press **Z** to transform into Fish (swimming form)
  - Press **X** to transform into Bird (flying form)
  - Press **V** to transform into Cat (running form)
  - Press **B** to revert to Human form
  - Third-person camera with smooth follow for all animal forms
  - Unique movement mechanics per form:
    - **Fish**: Swim in water, flop on land
    - **Bird**: Fly with wing flapping, glide when not flapping
    - **Cat**: Fast running, high jumping, leg animation
  - Procedural animal meshes built from primitives
  - HUD hints showing transformation controls

- **Inventory system** (Update 8):
  - Press **I** or **Tab** to open inventory
  - Press **Escape** to close inventory
  - Six item categories: All, Valuables, Tools, Ingredients, Consumables, Ammo
  - Scrollable item list with colored icons
  - Details panel showing item name, quantity, and description
  - USE button for consumable items
  - Inventory syncs with player's gold, tools, trinkets, and ingredients
  - Cooking at witch's cauldron adds consumables to inventory

### Technical
- **AnimalFormManager.gd** (838 lines): Complete transformation system
- **InventoryManager.gd** (136 lines): Item tracking and categorization
- **InventoryUI.gd** (333 lines): Visual interface with Godot 3 compatible styling
- Modified **Player.gd** to integrate both systems
- Modified **WitchCauldron.gd** to add cooked items to inventory

---

## [8.0] - 2026-09-15

### Added
- **Fruit trees** with pickable fruits (Update 6):
  - Apple Tree: Crisp Orchard Apples (ruby red)
  - Plum Tree: Sugar Plums (indigo/purple)
  - Pear Tree: Sweet Orchard Pears (golden-green)
  - Procedural tree meshes with trunks and canopies
  - Fruit sockets on branches for natural placement

- **Flowerbed** with pickable flowers:
  - Crimson Wild Poppy (ruby red)
  - Violet Night Orchid (purple)
  - Sunburst Marigold (amber/gold)
  - Frost Meadow Lily (cyan/ice-blue)
  - Timber border planter with dark loam soil

- **Witch Base** with cooking cauldron:
  - Thatched roof shelter with alchemy table
  - Interactive cauldron with dynamic liquid color blending
  - 8 cooking recipes based on ingredients:
    - Witch's Vitality Elixir (Fruit + Flower): +65 HP, +20 Max HP, +50 Gold
    - Sunfire Elixir of Haste (Marigold/Pear + Flower): +45 HP, +70 Gold, 30s speed buff
    - Shadow Veil Draught (Orchid/Plum + Flower): +40 HP, +60 Gold, 35s stealth buff
    - Moonlit Frost Draught (Frost Lily): +50 HP, +15 Max HP, +80 Gold
    - Sweet Orchard Compote (Multiple Fruits): +35 HP, +75 Gold
    - Witch's Grand Ambrosia Stew (3+ Ingredients): +100 HP, +30 Max HP, +150 Gold, all buffs
  - 3D overhead billboard showing ingredient count
  - Steam bubbles and brewing animation

- **Foraging mechanics**:
  - White glow outline when near harvestable items (within 3.5m)
  - Golden outline when aiming at specific item (camera midpoint focus)
  - Press **E** or **F** to pick fruits/flowers
  - 3D parabolic transfer animation to player
  - Items added to Pantry Bag (displayed in HUD)
  - Stealthy picking (no NPC detection)

### New Files
- `environment/assets/FruitTree.tscn` and `FruitTree.gd`
- `environment/assets/Flowerbed.tscn` and `Flowerbed.gd`
- `environment/assets/WitchBase.tscn`
- `environment/assets/WitchCauldron.tscn` and `WitchCauldron.gd`
- `environment/assets/HarvestableItem.gd`
- `characters/ItemMeshFactory.gd` - Procedural mesh factory for fruits, flowers, potions

### Changed
- **Player.gd**: Added pantry system, buff timers, harvestable scanning, cauldron interaction
- **StatsDisplay.gd**: Added pantry count and buff display
- **World.tscn**: Instantiated AppleTree, PlumTree, PearTree, Flowerbed, and WitchBase
- **README.md**: Added Update 6 documentation with controls table

---

## [7.0] - 2026-09-14

### Added
- **Pickpocketing failure system** (Update 4):
  - 1% base failure chance on first steal
  - Failure chance increases with each stolen item (20% after 3 items)
  - Two failure modes:
    - **Immediate detection** (45%): NPC catches you before grab
    - **Midway fumble** (55%): Item slips and drops to ground
      - 50% chance NPC detects you on fumble
      - If not detected, item falls to ground and can be retrieved

- **Dropped loot system**:
  - Failed steals drop items on the ground
  - Dropped items show white glow when nearby
  - Golden outline when aiming at dropped item
  - Press **E** or **F** to retrieve dropped items
  - Walk over items to auto-collect
  - Physics-based dropping with tumbling and ground detection

### Changed
- **Monster.gd**: Added `catch_fumbled_item()` and `catch_pickpocket_immediate()` methods
- **Player.gd**: Added failure chance calculation, fumble handling, dropped loot scanning
- **ItemTransferVisual.gd**: Added midway fumble drop support

### New Files
- `characters/DroppedLootItem.gd` - Dropped item physics and collection

---

## [6.0] - 2026-09-13

### Added
- **Camera midpoint pickpocketing** (Update 3):
  - Target specific items on NPC bodies by aiming camera
  - Items show white glow when in range (within 3.2m)
  - Golden glow when precisely focused (dot product >= 0.94)
  - HUD shows targeted item name and description
  - Steal with **[F]** key

- **3D item placeholders** on NPC bodies:
  - Small Money Bag (right hip): +50 Gold
  - Small Tools & Lockpicks (left hip): +1 Tool, +40 Gold
  - Ammo Pouch (rear waist): +ammo
  - Valuable Trinket (rear-right waist): +varies
  - Items attached to skeleton bones and animate with NPC

### Changed
- **Monster.gd**: Added visual_placeholders array, bone attachment, item generation
- **Player.gd**: Added camera midpoint scanning, dynamic outline management, item-specific stealing

### New Files
- `characters/WhiteOutlineMat.tres` - White outline material
- `characters/GoldOutlineMat.tres` - Golden outline material

---

## [5.0] - 2026-09-12

### Added
- **Sneaking system** (Update 1):
  - Press **C**, **Ctrl**, or **Shift** to crouch/sneak
  - Reduced movement speed (40% of normal)
  - Silent footsteps (0 noise radius)
  - Lower camera height (0.95m vs 1.75m standing)
  - Reduced collision height

- **NPC attention decay**:
  - NPCs lose interest after 2.5s if player moves away (> 4.5m)
  - NPCs lose interest after 2.5s if player stands still nearby (1.6-4.5m)
  - Window of opportunity for sneaking behind NPCs

### Changed
- **Player.gd**: Added sneaking state, noise radius calculation, camera height interpolation
- **Monster.gd**: Added attention decay timer, interest loss logic
- **CharacterMover.gd**: Added speed_scale support

---

## [4.0] - 2026-09-11

### Added
- **Stealing mechanic** (Update 2):
  - Press **[F]** to steal from NPCs
  - Press **[E]** to interact/talk (detects player)
  - Must sneak behind NPC to steal unseen
  - Standing while stealing has high detection risk
  - Visual 3D item transfer animation from NPC to player

### Changed
- **project.godot**: Added `interact` (E) and `steal` (F) input actions
- **Player.gd**: Added interaction system, behind-NPC detection, steal action
- **Monster.gd**: Added pickpocket system, detection on interact, item transfer

---

## [3.0] - 2026-09-10

### Added
- **Peaceful NPCs** (Update 1):
  - Converted enemies to non-attacking NPCs
  - NPCs patrol and wander using navigation mesh
  - NPCs have business stations they return to
  - Attention system: NPCs notice player when close
  - Dialogue barks when detected

### Changed
- **Monster.gd**: Rewrote AI from combat to peaceful NPC behavior
- **World.tscn**: Added Navigation node with navmesh for NPC pathfinding

---

## [2.0] - 2026-09-09

### Added
- Basic FPS controls (WASD movement, mouse look)
- Weapon system (Machete, Machine Gun, Shotgun, Rocket Launcher)
- Health and ammo pickups
- Enemy AI with combat behavior
- Basic level geometry (ground, walls, shed)

---

## [1.0] - 2026-09-08

### Initial Release
- Cloned base repository from GitHub
- Basic Godot 3 project structure
- Minimal FPS framework

---

## Controls Reference

| Key | Action |
|-----|--------|
| **W, A, S, D** | Movement |
| **C / Ctrl / Shift** | Crouch / Sneak (Silent movement) |
| **F** | Steal targeted item / Retrieve dropped loot / Pick fruit or flower / Cook Cauldron |
| **E** | Interact / Talk / Tap Shoulder / Pick fruit or flower / Add ingredient to Cauldron |
| **Space** | Jump (or Stand up from crouch) / Ascend (Fish/Bird) |
| **Mouse 1** | Attack / Fire Weapon |
| **1 – 4 / Wheel** | Switch Weapons |
| **I / Tab** | Open/Close Inventory |
| **Z** | Transform into Fish (swimming, third-person view) |
| **X** | Transform into Bird (flying, third-person view) |
| **V** | Transform into Cat (quadruped running, third-person view) |
| **B** | Revert to Human Form |
| **R** | Restart Scene |
| **Esc** | Quit Game (or Close Inventory) |
