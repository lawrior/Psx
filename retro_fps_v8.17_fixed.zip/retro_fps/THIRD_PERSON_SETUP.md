# Third-Person Character System - Setup Guide

## What Was Implemented

### 1. **Third-Person Camera System (Skyrim-Style)**
- **File**: `characters/player/ThirdPersonCamera.gd`
- **Features**:
  - Smooth follow camera that orbits around the character
  - Collision detection (camera won't clip through walls)
  - Adjustable distance with mouse wheel (2-8 meters)
  - Vertical pitch control (-60° to +60°)
  - Smooth position and rotation interpolation
  - Camera looks at character's upper body (1.2m height)

### 2. **Character Model Integration**
- **File**: `characters/player/Player.gd`
- **Features**:
  - Loads girl character model from `girl_with_all_animations.glb`
  - Automatically finds and sets up AnimationPlayer
  - Character faces movement direction with smooth rotation
  - Proper scale (1.0) and orientation (180° rotation to face forward)
  - First-person weapons automatically hidden

### 3. **Animation State Management**
- **Features**:
  - Automatic animation transitions based on movement state
  - Supports: idle, walk, run, sneak_walk, sneak_idle, jump, dead
  - Fallback animations if specific animations don't exist
  - Smooth blending between animation states

### 4. **Movement Integration**
- Character rotates to face movement direction
- Smooth rotation interpolation (10.0 speed)
- Movement relative to camera direction
- All existing mechanics work (sneaking, stealing, merchant interaction, transformations)

## IMPORTANT: Required Setup Step

**The GLB file needs to be properly imported by Godot's editor before it will work correctly.**

### Steps to Complete Setup:

1. **Open the project in Godot Editor** (version 3.5 or 3.6)
   ```bash
   godot3 /path/to/Retro-3D-FPS
   ```

2. **Wait for import to complete**
   - Godot will automatically import `girl_with_all_animations.glb`
   - This may take 10-30 seconds depending on your system
   - You'll see import progress in the bottom panel

3. **Verify animations are available**
   - Select the girl character in the FileSystem dock
   - Check the AnimationPlayer node
   - You should see animations like: idle, walk, run, sneak, jump, etc.

4. **Test the game**
   - Press F5 or click Play
   - You should now see the girl character in third-person view
   - Use WASD to move, mouse to rotate camera
   - Mouse wheel to zoom in/out

## Current Status (Before Editor Import)

The game will run with a **placeholder model** (brickwall) until you import the GLB in the editor. All third-person systems are functional:

- ✓ Third-person camera works
- ✓ Camera orbits around character
- ✓ Character rotates to face movement
- ✓ First-person weapons hidden
- ✓ All game mechanics work
- ✗ Girl character model (needs import)
- ✗ Animations (needs import)

## Controls

### Third-Person Camera
- **Mouse Move**: Rotate camera around character
- **Mouse Wheel**: Zoom in/out (2-8 meters)
- **WASD**: Move character
- **C**: Sneak (crouch)
- **E**: Interact with NPCs/Merchant
- **F**: Steal from NPCs
- **Z/X/V/B**: Transform to Fish/Bird/Cat/Human

### Camera Settings (Configurable in Player.gd)
- `distance`: 4.0 (default camera distance)
- `min_distance`: 2.0 (closest zoom)
- `max_distance`: 8.0 (farthest zoom)
- `height_offset`: 1.5 (camera height above character)
- `look_at_height`: 1.2 (where camera looks on character)
- `pitch_min`: -60.0 (minimum vertical angle)
- `pitch_max`: 60.0 (maximum vertical angle)
- `mouse_sensitivity`: 0.3 (camera rotation speed)
- `position_smoothing`: 8.0 (camera position smoothing)
- `rotation_smoothing`: 10.0 (camera rotation smoothing)

## Technical Details

### Camera System
The ThirdPersonCamera uses a pivot-based system:
1. Camera pivot follows character position
2. Camera rotates around pivot based on mouse input
3. Collision detection prevents clipping through walls
4. Smooth interpolation for professional feel

### Animation System
The animation system automatically detects available animations and falls back gracefully:
- If "run" doesn't exist → uses "walk"
- If "sneak_walk" doesn't exist → uses "walk"
- If "jump" doesn't exist → uses "idle"
- Always has "idle" as ultimate fallback

### Character Rotation
Character rotation is calculated from:
1. Movement input direction (WASD)
2. Camera orientation (transformed to world space)
3. Smooth interpolation to target angle
4. Character model rotated independently of player body

## Files Modified

1. **characters/player/ThirdPersonCamera.gd** (NEW)
   - Skyrim-style third-person camera script
   - Collision detection and smooth follow

2. **characters/player/Player.gd** (MODIFIED)
   - Added `setup_third_person_character()` function
   - Added `_setup_third_person_camera()` function
   - Added `_update_character_animation()` function
   - Added `_update_character_rotation()` function
   - Added `_find_animation_player()` helper function
   - Replaced basic camera with ThirdPersonCamera
   - Integrated animation state management

3. **characters/girl_with_all_animations.glb** (NEW)
   - Girl character model with animations
   - Downloaded from: https://github.com/lawrior/Psx

## Troubleshooting

### "AnimationPlayer NOT found"
- **Cause**: GLB not imported yet
- **Solution**: Open project in Godot editor and wait for import

### "Character model NOT loaded"
- **Cause**: GLB file missing or corrupted
- **Solution**: Re-download the GLB file

### Camera not following character
- **Cause**: ThirdPersonCamera not initialized
- **Solution**: Check that `setup_third_person_character()` is called in `_ready()`

### Character facing wrong direction
- **Cause**: Rotation offset incorrect
- **Solution**: Adjust `rotation_degrees` in `setup_third_person_character()`

### Animations not playing
- **Cause**: Animation names don't match expected names
- **Solution**: Check available animations in AnimationPlayer and update animation names in `_update_character_animation()`

## Expected Animation Names

The system expects these animation names (with fallbacks):
- `idle` - Standing still (required)
- `walk` - Walking movement
- `run` - Running movement (falls back to walk)
- `sneak_walk` - Sneaking while moving (falls back to walk)
- `sneak_idle` - Sneaking while standing (falls back to idle)
- `jump` - Jumping/falling (falls back to idle)
- `dead` - Death animation (falls back to idle)

If your GLB has different animation names, update the `_update_character_animation()` function to match.

## Version History

- **v8.13**: Initial third-person implementation (basic)
- **v8.14**: Comprehensive third-person with Skyrim-style camera, animation system, and full integration
