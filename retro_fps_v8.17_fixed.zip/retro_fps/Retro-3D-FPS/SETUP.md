# Retro-3D-FPS — Fixed build (v8.15 → v8.16)

## Which Godot?

This is a **Godot 3.x** project (`config_version=4`, `Spatial` / `KinematicBody` /
`AnimationPlayer`). It does **not** run on Godot 4 — see `DEBUG_REPORT.md`.
Tested and verified on **Godot 3.5.3 stable** (3.6 should also work).

```bash
# open / run the project
godot3 --path Retro-3D-FPS

# or run it directly
godot3 --path Retro-3D-FPS --resolution 1280x720
```

## First run

The `character/girl_with_all_animations.glb` import cache in `.import/` has
been regenerated, so the character works straight away. If you ever see a
brick wall instead of the girl again, the cache has gone stale:

```bash
# safe fix: delete the model's cache entry, then open the project in the
# editor once and let Godot re-import the GLB
rm Retro-3D-FPS/.import/girl_with_all_animations.glb-*
godot3 -e --path Retro-3D-FPS      # wait for the import to finish, then close
```

Deleting the whole `.import/` folder and reopening the editor also works and is
guaranteed to produce a clean cache.

## Controls

| Action | Key |
|---|---|
| Move | `W A S D` (camera relative) |
| Look / orbit camera | Mouse |
| Zoom camera out / in | Mouse wheel |
| Jump | `Space` |
| Crouch / sneak (toggle) | `C` |
| Attack | Left mouse |
| Aim down sights (zoom) | Right mouse (hold) |
| Switch weapon | `1`–`9`, wheel in first person |
| Interact | `E` |
| Steal | `F` |
| Inventory | `I` or `Tab` |
| Merchant | `E` on the merchant |
| Transform: Fish / Bird / Cat / Human | `Z` / `X` / `V` / `B` |
| Restart | `R` |
| Quit | `Esc` |

## Automated verification

A headless test suite covers the character, the animations and the camera:

```bash
godot3 --path Retro-3D-FPS --no-window -s res://tests/test_third_person.gd
```

It prints a PASS/FAIL list and exits non-zero on failure (43 checks).

To render screenshots of the running game you need a display:

```bash
xvfb-run -a -s "-screen 0 1280x720x24" \
  godot3 --path Retro-3D-FPS -s res://tests/screenshot.gd
# PNGs land in ~/.local/share/godot/app_userdata/Retro-3D-FPS/shots/
```

## Tuning the character / camera

All exposed at the top of `characters/player/Player.gd`:

| Export | Default | Meaning |
|---|---|---|
| `character_model_height` | 1.72 | Target height in metres; the GLB is auto-scaled to this |
| `model_yaw_offset_degrees` | 0 | Set to 180 if the character ever walks backwards |
| `turn_speed` | 10.0 | How fast the body swings to face the movement direction |
| `aim_origin_height` | 1.45 | Height the weapon rig fires from |
| `run_anim_threshold` | 3.6 | Speed above which the run clip is used |
| `STAND_CAPSULE_MID_HEIGHT` | 1.0 | Standing capsule cylinder length (total 2.0 m with r=0.5) |
| `CROUCH_CAPSULE_MID_HEIGHT` | 0.2 | Crouched capsule cylinder (total ~1.2 m) |

Camera feel lives in `characters/player/ThirdPersonCamera.gd`
(`distance`, `shoulder_offset`, `anchor_height`, `mouse_sensitivity`,
`follow_smoothing`, `pitch_min/max`, `pitch_bias`), and the aim pose in
`aim_distance`, `aim_shoulder_offset`, `aim_fov`, `aim_speed`, `aim_mouse_scale`.

### Weapons on the character

`characters/player/CharacterWeaponRig.gd` hangs the weapon models off the
skeleton with `BoneAttachment` sockets:

| Table | What it controls |
|---|---|
| `HAND_BONE` / `BACK_BONE` | Which bones are the hand and the back socket |
| `WEAPON_LENGTH` | Real-world target length in metres; the model is scaled to fit |
| `WEAPON_AXES` | Which of each model's local axes is its barrel / blade |
| `HAND_OFFSET` | Grip position in the hand, in metres |
| `BACK_LAYOUT` | Per-weapon sling position, tilt and roll on the back |
| `STOWABLE` | Which weapons are drawn while holstered (`RocketLauncher` is not) |

`WEAPON_ROTATION`/`BACK_ROTATION` are gone: the rig solves the rotation from
the bone's actual world axes, so it survives the character being re-exported
or the model yaw offset being changed.

### Attack animation

`CharacterAnimator.play_attack(melee)` is called from the `weapon_attacked`
signal. The GLB has no sword swing, so the melee attack uses `Chop_Tree`
(a real two-handed overhead chop) trimmed to `melee_attack_trim = 0.62 s`;
guns use `Spell_Simple_Shoot`. Tune or disable via `ranged_attacks_enabled`.

## Tuning locomotion

`characters/CharacterMover.tscn` / `CharacterMover.gd`:

| Export | Default | Meaning |
|---|---|---|
| `max_speed` | 6.5 | m/s at normal speed (≈ Skyrim's walk/run band) |
| `move_accel` | 25.0 | m/s² ground acceleration |
| `jump_force` | 8.0 | m/s jump impulse (≈ 0.75 m hop) |
| `gravity` | 22.0 | m/s² gravity |
