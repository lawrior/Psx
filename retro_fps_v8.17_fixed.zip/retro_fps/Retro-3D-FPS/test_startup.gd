extends SceneTree

# Test script to check game startup

func _init():
	print("=== Game Startup Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	print("Loading World.tscn...")
	change_scene_to(world)
	
	# Wait for scene to be ready
	print("Waiting for scene to initialize...")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found: ", player.name)
	print("form_manager: ", player.form_manager != null)
	print("inventory_manager: ", player.inventory_manager != null)
	print("inventory_ui: ", player.inventory_ui != null)
	
	# Wait a bit more to ensure everything is stable
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	print("\n=== Game startup successful! ===")
	quit(0)
