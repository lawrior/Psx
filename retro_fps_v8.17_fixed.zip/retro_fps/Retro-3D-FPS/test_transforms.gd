extends SceneTree

# Test script to debug animal transformations

func _init():
	print("=== Animal Transformation Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found: ", player.name)
	
	# Check if form_manager exists
	if !player.form_manager:
		print("ERROR: form_manager is null!")
		quit(1)
		return
	
	print("form_manager found")
	print("Current form: ", player.form_manager.current_form)
	
	# Test Fish transformation
	print("\n--- Testing FISH transformation ---")
	player.form_manager.transform_to(player.form_manager.FORM.FISH)
	yield(self, "idle_frame")
	print("Fish form current_form: ", player.form_manager.current_form)
	print("Fish form is_transformed: ", player.form_manager.is_transformed())
	
	# Revert to human
	print("\n--- Reverting to HUMAN ---")
	player.form_manager.revert_to_human()
	yield(self, "idle_frame")
	print("Human form current_form: ", player.form_manager.current_form)
	
	# Test Bird transformation
	print("\n--- Testing BIRD transformation ---")
	player.form_manager.transform_to(player.form_manager.FORM.BIRD)
	yield(self, "idle_frame")
	print("Bird form current_form: ", player.form_manager.current_form)
	print("Bird form is_transformed: ", player.form_manager.is_transformed())
	
	# Revert to human
	print("\n--- Reverting to HUMAN ---")
	player.form_manager.revert_to_human()
	yield(self, "idle_frame")
	print("Human form current_form: ", player.form_manager.current_form)
	
	# Test Cat transformation
	print("\n--- Testing CAT transformation ---")
	player.form_manager.transform_to(player.form_manager.FORM.CAT)
	yield(self, "idle_frame")
	print("Cat form current_form: ", player.form_manager.current_form)
	print("Cat form is_transformed: ", player.form_manager.is_transformed())
	
	print("\n=== All transformations completed! ===")
	quit(0)
