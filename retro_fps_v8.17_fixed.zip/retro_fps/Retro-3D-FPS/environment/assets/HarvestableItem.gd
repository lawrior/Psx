extends Area
class_name HarvestableItem

const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
const ItemTransferVisual = preload("res://characters/ItemTransferVisual.gd")

var item_data : Dictionary = {}
var mesh_node : Spatial = null
var is_picked : bool = false
var col_shape : CollisionShape = null

func _ready():
	add_to_group("pickable_harvest")

func setup(p_item: Dictionary):
	item_data = p_item
	if !item_data.has("placeholder_id"):
		item_data["placeholder_id"] = item_data.get("id", "apple")
		
	mesh_node = ItemMeshFactory.create_mesh(item_data.placeholder_id)
	if mesh_node:
		add_child(mesh_node)
		
	col_shape = CollisionShape.new()
	var sphere = SphereShape.new()
	sphere.radius = 0.45
	col_shape.shape = sphere
	add_child(col_shape)
	
	add_to_group("pickable_harvest")

func set_highlight(mode: int):
	if is_instance_valid(mesh_node):
		ItemMeshFactory.apply_highlight(mesh_node, mode)

func get_item_name() -> String:
	return item_data.get("name", "Harvestable Item")

func get_item_desc() -> String:
	return item_data.get("desc", "A fresh ingredient")

func harvest(player_node):
	if is_picked:
		return
	is_picked = true
	set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
	
	if col_shape:
		col_shape.disabled = true
	remove_from_group("pickable_harvest")
	
	if is_instance_valid(player_node):
		# Start 3D parabolic transfer arc to player view
		var transfer = ItemTransferVisual.new()
		get_tree().current_scene.add_child(transfer)
		var cb = funcref(player_node, "add_harvested_item")
		transfer.setup(global_transform.origin, player_node, item_data, cb, false, null)
		
	# Hide and queue free
	visible = false
	queue_free()
