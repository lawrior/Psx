extends StaticBody

const HarvestableItemScript = preload("res://environment/assets/HarvestableItem.gd")
const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")

onready var flower_container = $FlowerContainer

func _ready():
	add_to_group("flowerbeds")
	spawn_flowers()

func spawn_flowers():
	for child in flower_container.get_children():
		child.queue_free()
		
	var flower_defs = [
		{
			"id": "crimson_poppy",
			"placeholder_id": "crimson_poppy",
			"name": "Crimson Wild Poppy",
			"category": "flower",
			"desc": "Vibrant red poppy brimming with vitality essence (Heals 15 HP)",
			"heal_amount": 15,
			"gold_value": 15,
			"pos": Vector3(-0.85, 0.22, -0.45)
		},
		{
			"id": "violet_orchid",
			"placeholder_id": "violet_orchid",
			"name": "Mystic Violet Orchid",
			"category": "flower",
			"desc": "Enchanting purple orchid with subtle shadow mist",
			"heal_amount": 15,
			"gold_value": 20,
			"pos": Vector3(-0.35, 0.22, -0.35)
		},
		{
			"id": "sun_marigold",
			"placeholder_id": "sun_marigold",
			"name": "Golden Sun Marigold",
			"category": "flower",
			"desc": "Radiant golden blossom warm to the touch",
			"heal_amount": 20,
			"gold_value": 25,
			"pos": Vector3(0.35, 0.22, -0.45)
		},
		{
			"id": "frost_lily",
			"placeholder_id": "frost_lily",
			"name": "Crystalline Frost Lily",
			"category": "flower",
			"desc": "Pale icy-white flower humming with moonlit frost",
			"heal_amount": 25,
			"gold_value": 30,
			"pos": Vector3(0.85, 0.22, -0.35)
		},
		{
			"id": "crimson_poppy",
			"placeholder_id": "crimson_poppy",
			"name": "Crimson Wild Poppy",
			"category": "flower",
			"desc": "Vibrant red poppy brimming with vitality essence (Heals 15 HP)",
			"heal_amount": 15,
			"gold_value": 15,
			"pos": Vector3(-0.60, 0.22, 0.40)
		},
		{
			"id": "violet_orchid",
			"placeholder_id": "violet_orchid",
			"name": "Mystic Violet Orchid",
			"category": "flower",
			"desc": "Enchanting purple orchid with subtle shadow mist",
			"heal_amount": 15,
			"gold_value": 20,
			"pos": Vector3(-0.10, 0.22, 0.45)
		},
		{
			"id": "sun_marigold",
			"placeholder_id": "sun_marigold",
			"name": "Golden Sun Marigold",
			"category": "flower",
			"desc": "Radiant golden blossom warm to the touch",
			"heal_amount": 20,
			"gold_value": 25,
			"pos": Vector3(0.55, 0.22, 0.35)
		},
		{
			"id": "frost_lily",
			"placeholder_id": "frost_lily",
			"name": "Crystalline Frost Lily",
			"category": "flower",
			"desc": "Pale icy-white flower humming with moonlit frost",
			"heal_amount": 25,
			"gold_value": 30,
			"pos": Vector3(0.95, 0.22, 0.38)
		}
	]
	
	for f_def in flower_defs:
		var fl = HarvestableItemScript.new()
		fl.name = "Flower_" + f_def.id
		flower_container.add_child(fl)
		fl.translation = f_def.pos + Vector3(rand_range(-0.06, 0.06), 0, rand_range(-0.06, 0.06))
		fl.rotation_degrees = Vector3(0, rand_range(0, 360), 0)
		fl.setup(f_def)
