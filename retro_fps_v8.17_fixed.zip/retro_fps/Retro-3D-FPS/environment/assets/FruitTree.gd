extends StaticBody

const HarvestableItemScript = preload("res://environment/assets/HarvestableItem.gd")
const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")

export(String, "apple", "plum", "pear") var tree_type = "apple"
export var tree_name : String = "Fruit Tree"

onready var canopy_node = $Canopy
onready var fruit_container = $FruitContainer

func _ready():
	add_to_group("fruit_trees")
	setup_tree_visuals()
	spawn_fruits()

func setup_tree_visuals():
	var foliage_color = Color(0.2, 0.55, 0.18)
	match tree_type:
		"apple":
			tree_name = "Orchard Apple Tree"
			foliage_color = Color(0.22, 0.58, 0.18)
		"plum":
			tree_name = "Midnight Plum Tree"
			foliage_color = Color(0.18, 0.44, 0.25)
		"pear":
			tree_name = "Golden Pear Tree"
			foliage_color = Color(0.28, 0.62, 0.16)
			
	# Apply foliage material to canopy mesh instances
	var foliage_mat = ItemMeshFactory.create_mat(foliage_color, 0.0, 0.85)
	for child in canopy_node.get_children():
		if child is MeshInstance:
			child.material_override = foliage_mat

func spawn_fruits():
	# Clear any existing fruits
	for child in fruit_container.get_children():
		child.queue_free()
		
	var item_def = {}
	match tree_type:
		"apple":
			item_def = {
				"id": "apple",
				"placeholder_id": "apple",
				"name": "Crisp Orchard Apple",
				"category": "fruit",
				"desc": "Fresh, sweet orchard apple (Restores 20 HP)",
				"heal_amount": 20,
				"gold_value": 15
			}
		"plum":
			item_def = {
				"id": "plum",
				"placeholder_id": "plum",
				"name": "Sweet Midnight Plum",
				"category": "fruit",
				"desc": "Juicy violet plum rich in mystical essence",
				"heal_amount": 20,
				"gold_value": 20
			}
		"pear":
			item_def = {
				"id": "pear",
				"placeholder_id": "pear",
				"name": "Golden Sunlight Pear",
				"category": "fruit",
				"desc": "Luminous ripe pear humming with sun energy",
				"heal_amount": 25,
				"gold_value": 25
			}

	# Positions around canopy branches at reachable heights (Y: 1.35m to 2.15m)
	var fruit_offsets = [
		Vector3(0.85, 1.65, 0.55),
		Vector3(-0.90, 1.80, 0.45),
		Vector3(0.50, 1.95, -0.85),
		Vector3(-0.65, 1.50, -0.75),
		Vector3(0.05, 2.10, 0.95)
	]
	
	for offset in fruit_offsets:
		var fruit = HarvestableItemScript.new()
		fruit.name = "Fruit_" + item_def.id
		fruit_container.add_child(fruit)
		fruit.translation = offset
		fruit.setup(item_def)
