extends SceneTree

# Runtime behavior test for third-person system

var player = null
var test_duration = 5.0
var elapsed = 0.0

func _init():
	print("=== Third-Person Runtime Behavior Test ===\n")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	for i in range(10):
		yield(self, "idle_frame")
	
	# Get the player
	player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("✓ Player found\n")
	
	# Test 1: Camera position relative to character
	print("--- Test 1: Camera Position ---")
	if player.third_person_camera and player.character_model:
		var cam_pos = player.third_person_camera.global_transform.origin
		var char_pos = player.character_model.global_transform.origin
		var distance = cam_pos.distance_to(char_pos)
		
		print("Camera position: ", cam_pos)
		print("Character position: ", char_pos)
		print("Distance: ", distance, " meters")
		
		if distance < 2.0:
			print("✗ FAIL: Camera too close (inside character)")
		elif distance > 10.0:
			print("✗ FAIL: Camera too far")
		else:
			print("✓ PASS: Camera at reasonable distance")
		
		# Check if camera is behind character
		var cam_dir = (cam_pos - char_pos).normalized()
		var char_forward = -player.character_model.global_transform.basis.z
		var dot = cam_dir.dot(char_forward)
		
		print("Camera behind character: ", dot > 0.5)
	else:
		print("✗ Camera or character model not found")
	
	# Test 2: Animation state when idle
	print("\n--- Test 2: Idle Animation ---")
	if player.character_anim_player:
		# Simulate standing still
		player.character_mover.velocity = Vector3.ZERO
		player.sneaking = false
		player._update_character_animation(0.016)
		
		yield(self, "idle_frame")
		yield(self, "idle_frame")
		
		var current_anim = player.current_animation
		print("Animation when standing still: ", current_anim)
		
		if current_anim == "idle" or current_anim.begins_with("idle"):
			print("✓ PASS: Idle animation playing when standing still")
		else:
			print("✗ FAIL: Wrong animation when standing still")
	
	# Test 3: Animation state when walking
	print("\n--- Test 3: Walk Animation ---")
	if player.character_anim_player:
		# Simulate walking
		player.character_mover.velocity = Vector3(3, 0, 0)
		player.sneaking = false
		player._update_character_animation(0.016)
		
		yield(self, "idle_frame")
		yield(self, "idle_frame")
		
		var current_anim = player.current_animation
		print("Animation when walking: ", current_anim)
		
		if current_anim == "walk" or current_anim.begins_with("walk"):
			print("✓ PASS: Walk animation playing when moving")
		else:
			print("✗ FAIL: Wrong animation when walking")
	
	# Test 4: Crouching/sneaking
	print("\n--- Test 4: Crouching/Sneaking ---")
	if player.character_anim_player:
		# Simulate sneaking
		player.character_mover.velocity = Vector3(2, 0, 0)
		player.sneaking = true
		player._update_character_animation(0.016)
		
		yield(self, "idle_frame")
		yield(self, "idle_frame")
		
		var current_anim = player.current_animation
		print("Animation when sneaking: ", current_anim)
		print("Sneaking flag: ", player.sneaking)
		
		if player.sneaking:
			print("✓ PASS: Sneaking state active")
		else:
			print("✗ FAIL: Sneaking state not active")
		
		if "sneak" in current_anim or "crouch" in current_anim:
			print("✓ PASS: Sneak animation playing")
		else:
			print("⚠ WARNING: No specific sneak animation (using fallback)")
	
	# Test 5: Character rotation vs camera rotation
	print("\n--- Test 5: Character vs Camera Rotation ---")
	if player.character_model and player.third_person_camera:
		# Store initial rotations
		var initial_char_rot = player.character_model.rotation_degrees.y
		var initial_cam_rot = player.third_person_camera.global_transform.basis.get_euler().y
		
		print("Initial character rotation: ", initial_char_rot)
		print("Initial camera rotation: ", rad2deg(initial_cam_rot))
		
		# Simulate camera rotation (change camera yaw)
		if player.third_person_camera.has_method("_input"):
			var mouse_event = InputEventMouseMotion.new()
			mouse_event.relative = Vector2(100, 0)  # Simulate mouse move right
			player.third_person_camera._input(mouse_event)
			
			yield(self, "idle_frame")
			yield(self, "idle_frame")
			
			var new_char_rot = player.character_model.rotation_degrees.y
			var new_cam_rot = player.third_person_camera.global_transform.basis.get_euler().y
			
			print("After camera rotation:")
			print("  Character rotation: ", new_char_rot)
			print("  Camera rotation: ", rad2deg(new_cam_rot))
			
			var char_rot_changed = abs(new_char_rot - initial_char_rot) > 1.0
			var cam_rot_changed = abs(rad2deg(new_cam_rot) - rad2deg(initial_cam_rot)) > 1.0
			
			if cam_rot_changed and !char_rot_changed:
				print("✓ PASS: Camera rotates independently of character")
			elif cam_rot_changed and char_rot_changed:
				print("✗ FAIL: Camera rotation also rotates character")
			else:
				print("⚠ WARNING: Camera didn't rotate")
	
	# Test 6: Materials/textures
	print("\n--- Test 6: Materials/Textures ---")
	if player.character_model:
		var mesh_instances = []
		_find_mesh_instances(player.character_model, mesh_instances)
		
		print("Found ", mesh_instances.size(), " MeshInstance nodes")
		
		var has_materials = false
		for mesh in mesh_instances:
			if mesh.material_override:
				has_materials = true
				break
			for i in range(mesh.get_surface_material_count()):
				var mat = mesh.get_surface_material(i)
				if mat:
					has_materials = true
					break
		
		if has_materials:
			print("✓ PASS: Character has materials")
		else:
			print("✗ FAIL: Character has no materials (no textures)")
	
	print("\n=== Runtime Tests Completed ===")
	quit(0)

func _find_mesh_instances(node, list):
	if node is MeshInstance:
		list.append(node)
	for child in node.get_children():
		_find_mesh_instances(child, list)
