extends SceneTree

# Test script to verify third-person character setup

func _init():
	print("=== Third-Person Character Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found")
	print("Is third person: ", player.is_third_person)
	print("Character model exists: ", player.character_model != null)
	print("Camera exists: ", player.camera != null)
	
	if player.character_model:
		print("Character model name: ", player.character_model.name)
		print("Character model position: ", player.character_model.global_transform.origin)
	
	if player.camera:
		print("Camera position: ", player.camera.global_transform.origin)
		print("Camera rotation: ", player.camera.rotation_degrees)
	
	# Test camera update
	print("\n--- Testing camera update ---")
	player.update_third_person_camera()
	yield(self, "idle_frame")
	
	if player.camera:
		print("Camera position after update: ", player.camera.global_transform.origin)
	
	print("\n=== Third-person test completed ===")
	quit(0)
