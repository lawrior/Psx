extends SceneTree

# Test script to verify transformation works

func _init():
	print("=== Transformation Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found")
	print("Form manager exists: ", player.form_manager != null)
	
	if player.form_manager:
		print("Current form: ", player.form_manager.get_form_name())
		
		# Test transformation to fish
		print("\n--- Transforming to Fish ---")
		player.form_manager.transform_to(player.form_manager.FORM.FISH)
		yield(self, "idle_frame")
		print("Current form after transform: ", player.form_manager.get_form_name())
		print("Is transformed: ", player.form_manager.is_transformed())
		
		# Test revert to human
		print("\n--- Reverting to Human ---")
		player.form_manager.revert_to_human()
		yield(self, "idle_frame")
		print("Current form after revert: ", player.form_manager.get_form_name())
		print("Is transformed: ", player.form_manager.is_transformed())
		
		# Test transformation to bird
		print("\n--- Transforming to Bird ---")
		player.form_manager.transform_to(player.form_manager.FORM.BIRD)
		yield(self, "idle_frame")
		print("Current form after transform: ", player.form_manager.get_form_name())
		print("Is transformed: ", player.form_manager.is_transformed())
		
		# Test revert to human
		print("\n--- Reverting to Human ---")
		player.form_manager.revert_to_human()
		yield(self, "idle_frame")
		print("Current form after revert: ", player.form_manager.get_form_name())
		print("Is transformed: ", player.form_manager.is_transformed())
		
		# Test transformation to cat
		print("\n--- Transforming to Cat ---")
		player.form_manager.transform_to(player.form_manager.FORM.CAT)
		yield(self, "idle_frame")
		print("Current form after transform: ", player.form_manager.get_form_name())
		print("Is transformed: ", player.form_manager.is_transformed())
	else:
		print("ERROR: Form manager not found!")
	
	print("\n=== Transformation test completed ===")
	quit(0)
