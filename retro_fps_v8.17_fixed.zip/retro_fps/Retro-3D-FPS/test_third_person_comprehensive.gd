extends SceneTree

# Comprehensive test for third-person character system

func _init():
	print("=== Third-Person Comprehensive Test ===\n")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	for i in range(10):
		yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("✓ Player found")
	
	# Test 1: Character model loaded
	print("\n--- Test 1: Character Model ---")
	if player.character_model:
		print("✓ Character model exists")
		print("  Name: ", player.character_model.name)
		print("  Scale: ", player.character_model.scale)
		print("  Rotation: ", player.character_model.rotation_degrees)
	else:
		print("✗ Character model NOT loaded")
	
	# Test 2: Animation player
	print("\n--- Test 2: Animation Player ---")
	if player.character_anim_player:
		print("✓ AnimationPlayer exists")
		var animations = player.character_anim_player.get_animation_list()
		print("  Available animations (", animations.size(), "):")
		for anim in animations:
			print("    - ", anim)
		print("  Current animation: ", player.current_animation)
	else:
		print("✗ AnimationPlayer NOT found")
	
	# Test 3: Third-person camera
	print("\n--- Test 3: Third-Person Camera ---")
	if player.third_person_camera:
		print("✓ Third-person camera exists")
		print("  Camera position: ", player.third_person_camera.global_transform.origin)
		print("  Camera distance: ", player.third_person_camera.distance)
		print("  Camera height offset: ", player.third_person_camera.height_offset)
		print("  Camera pitch range: ", player.third_person_camera.pitch_min, " to ", player.third_person_camera.pitch_max)
		print("  Position smoothing: ", player.third_person_camera.position_smoothing)
		print("  Rotation smoothing: ", player.third_person_camera.rotation_smoothing)
	else:
		print("✗ Third-person camera NOT set up")
	
	# Test 4: First-person weapons hidden
	print("\n--- Test 4: First-Person Weapons ---")
	var weapon_manager = player.get_node_or_null("Camera/WeaponManager")
	if weapon_manager:
		if !weapon_manager.visible:
			print("✓ First-person weapons hidden")
		else:
			print("✗ First-person weapons still visible")
	else:
		print("✓ WeaponManager not found (OK)")
	
	# Test 5: Third-person flag
	print("\n--- Test 5: Third-Person Flag ---")
	if player.is_third_person:
		print("✓ is_third_person = true")
	else:
		print("✗ is_third_person = false")
	
	# Test 6: Animation state management functions
	print("\n--- Test 6: Animation Functions ---")
	if player.has_method("_update_character_animation"):
		print("✓ _update_character_animation() exists")
	else:
		print("✗ _update_character_animation() missing")
	
	if player.has_method("_update_character_rotation"):
		print("✓ _update_character_rotation() exists")
	else:
		print("✗ _update_character_rotation() missing")
	
	# Test 7: Simulate movement and check animation
	print("\n--- Test 7: Animation Transitions ---")
	if player.character_anim_player:
		print("Simulating idle state...")
		player.character_mover.velocity = Vector3.ZERO
		player._update_character_animation(0.016)
		yield(self, "idle_frame")
		print("  Current animation: ", player.current_animation)
		
		print("Simulating walking state...")
		player.character_mover.velocity = Vector3(3, 0, 0)
		player._update_character_animation(0.016)
		yield(self, "idle_frame")
		print("  Current animation: ", player.current_animation)
		
		print("Simulating running state...")
		player.character_mover.velocity = Vector3(6, 0, 0)
		player._update_character_animation(0.016)
		yield(self, "idle_frame")
		print("  Current animation: ", player.current_animation)
		
		print("Simulating sneaking state...")
		player.sneaking = true
		player.character_mover.velocity = Vector3(2, 0, 0)
		player._update_character_animation(0.016)
		yield(self, "idle_frame")
		print("  Current animation: ", player.current_animation)
	
	print("\n=== All Tests Completed ===")
	quit(0)
