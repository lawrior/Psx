extends SceneTree

# =====================================================================
# Headless verification suite for the third person fixes.
#
#   godot --path . --no-window -s res://tests/test_third_person.gd
#
# NOTE: every yield happens at the top level of the _init coroutine.
# Yielding inside a helper function silently returns a FunctionState
# instead of pausing the caller, which quietly skips the rest of the test.
# =====================================================================

var results = []
var world = null
var player = null

func _init():
	print("=====================================================")
	print(" RETRO FPS - THIRD PERSON VERIFICATION")
	print("=====================================================")

	var packed = load("res://World.tscn")
	if !packed:
		print("FATAL: World.tscn failed to load")
		quit(1)
		return
	world = packed.instance()
	get_root().add_child(world)
	yield(self, "physics_frame")
	yield(self, "physics_frame")
	yield(self, "physics_frame")

	player = _find_player(world)
	if !player:
		print("FATAL: no node in group 'player'")
		quit(1)
		return
	print("[test] player found: ", player.get_path())

	var m = player.character_model
	var ap = player.character_anim_player
	var animator = player.animator
	var cam = player.third_person_camera

	# ---------------------------------------------------------------
	# 1. THE MODEL
	# ---------------------------------------------------------------
	check(m != null, "character model instance exists")
	if m:
		var wbox = _world_aabb(m)
		check(abs(wbox.size.y - 1.72) < 0.15,
			"model is human sized (world height " + str(stepify(wbox.size.y, 0.01)) + " m, expected ~1.72)")
		check(abs(wbox.position.y - player.global_transform.origin.y) < 0.15,
			"feet sit on the floor (model min y " + str(stepify(wbox.position.y, 0.01))
			+ " vs player origin " + str(stepify(player.global_transform.origin.y, 0.01)) + ")")
		var total = 0
		var textured = 0
		var sizes = {}
		var no_tex = []
		var skel_root = _find_skeleton(m)
		for n in _all(m, []):
			# Only the character's own skinned meshes (direct children of the
			# Skeleton). Weapons now hang off BoneAttachment sockets inside the
			# same model, and must not be counted here.
			if n is MeshInstance and n.mesh and n.get_parent() == skel_root:
				for s in range(n.mesh.get_surface_count()):
					total += 1
					var mat = n.get_surface_material(s)
					if mat == null:
						mat = n.mesh.surface_get_material(s)
					if mat and mat is SpatialMaterial and mat.albedo_texture:
						textured += 1
						sizes[str(mat.albedo_texture.get_size())] = true
					else:
						no_tex.append(n.name + "/surf" + str(s))
		check(total == 7, "character has 7 skinned mesh surfaces (" + str(total) + " found)")
		check(textured == total and total > 0,
			"every surface has an albedo texture (" + str(textured) + "/" + str(total)
			+ ", sizes " + str(sizes.keys()) + ")" + ("" if no_tex.empty() else " missing: " + str(no_tex)))

	# ---------------------------------------------------------------
	# 2. ANIMATION BINDING
	# ---------------------------------------------------------------
	check(ap != null, "AnimationPlayer found inside the model")
	if ap:
		check(ap.get_animation_list().size() >= 30,
			"AnimationPlayer exposes the GLB clips (" + str(ap.get_animation_list().size()) + " clips)")
	if animator:
		check(animator.clip_for("idle") == "idle", "idle  -> " + str(animator.clip_for("idle")))
		check(animator.clip_for("walk") == "Walk_Female", "walk  -> " + str(animator.clip_for("walk")))
		check(animator.clip_for("run") == "Run_Female", "run   -> " + str(animator.clip_for("run")))
		check(animator.clip_for("sneak_walk") == "Walk_Stealth", "sneak -> " + str(animator.clip_for("sneak_walk")))
		check(animator.clip_for("sneak_idle") == "Crouch_Idle", "crouch idle -> " + str(animator.clip_for("sneak_idle")))
		check(animator.clip_for("air") == "Jump_air", "air   -> " + str(animator.clip_for("air")))
		check(animator.clip_for("dead") == "Death_A", "dead  -> " + str(animator.clip_for("dead")))
		check(animator.clip_for("walk_back") == "Walk_Backwards", "back  -> " + str(animator.clip_for("walk_back")))
	else:
		check(false, "CharacterAnimator attached")
	if ap:
		check(ap.get_animation("idle").loop == true, "idle loops (importer shipped every clip with loop = false)")
		check(ap.get_animation("Walk_Female").loop == true, "Walk_Female loops")

	# ---------------------------------------------------------------
	# 3. DOES THE ANIMATION ACTUALLY MOVE?
	# ---------------------------------------------------------------
	if ap:
		ap.play("Walk_Female")
		yield(self, "physics_frame")
		var p0 = ap.current_animation_position
		var pose0 = _bone_pose()
		var skel = _find_skeleton(m)
		for i in range(25):
			yield(self, "physics_frame")
		var p1 = ap.current_animation_position
		var pose1 = _bone_pose()
		check(p1 != p0, "animation playhead advances (" + str(stepify(p0, 0.01)) + " -> " + str(stepify(p1, 0.01)) + ")")
		check(ap.is_playing(), "AnimationPlayer.is_playing() is true")
		check(pose0.distance_to(pose1) > 0.0005,
			"skinned bones actually deform (delta " + str(stepify(pose0.distance_to(pose1), 0.0001)) + " m)")
		if skel:
			check(skel.get_bone_count() == 68, "skeleton has 68 bones (" + str(skel.get_bone_count()) + ")")

	# ---------------------------------------------------------------
	# 4. CAMERA FRAMING
	# ---------------------------------------------------------------
	check(cam != null, "ThirdPersonCamera exists")
	if cam:
		cam.pitch = -10.0
		cam.yaw = 180.0
		cam.current_distance = cam.distance
		cam.call("_apply_transform")
		yield(self, "physics_frame")
		var cam_pos = cam.global_transform.origin
		var body = player.global_transform.origin
		var flat = Vector3(cam_pos.x - body.x, 0, cam_pos.z - body.z)
		check(flat.length() > 2.0, "camera stands back from the character (" + str(stepify(flat.length(), 0.01)) + " m)")
		check(cam_pos.y > body.y + 0.9, "camera is above the feet (y=" + str(stepify(cam_pos.y, 0.01)) + ")")
		var facing = Vector3(sin(player.rotation.y), 0, cos(player.rotation.y))
		check(facing.dot(flat.normalized()) < -0.5,
			"camera sits BEHIND the character (dot=" + str(stepify(facing.dot(flat.normalized()), 0.01)) + ")")
		var c0 = cam.global_transform.origin
		for i in range(30):
			yield(self, "physics_frame")
		var drift = cam.global_transform.origin.distance_to(c0)
		check(drift < 3.5, "camera holds station while standing still (drift " + str(stepify(drift, 0.01)) + " m)")
		cam.add_look(0, -100000)
		check(cam.pitch <= cam.pitch_max + 0.001, "pitch clamps at the top (" + str(stepify(cam.pitch, 0.1)) + ")")
		cam.add_look(0, 100000)
		check(cam.pitch >= cam.pitch_min - 0.001, "pitch clamps at the bottom (" + str(stepify(cam.pitch, 0.1)) + ")")
		cam.pitch = -10.0
		# Orbit does not spin the body (the old bug: pivot inherited body yaw)
		var yaw_before = player.rotation.y
		cam.add_look(400, 0)
		cam.call("_apply_transform")
		check(abs(player.rotation.y - yaw_before) < 0.001, "mouse look orbits the camera without turning the body")

	# ---------------------------------------------------------------
	# 5. SPRING ARM COLLISION (the reversed-raycast bug)
	# ---------------------------------------------------------------
	if cam:
		var wall = StaticBody.new()
		var cs = CollisionShape.new()
		var box = BoxShape.new()
		box.extents = Vector3(3, 3, 0.2)
		cs.shape = box
		wall.add_child(cs)
		wall.collision_layer = 1
		world.add_child(wall)
		cam.yaw = 180.0
		wall.global_transform.origin = player.global_transform.origin + Vector3(0, 1.5, -2.2)
		yield(self, "physics_frame")
		yield(self, "physics_frame")
		cam.call("_update_distance", 0.016)
		check(cam.current_distance < cam.distance - 0.3,
			"spring arm pulls in against a wall behind the camera (" + str(stepify(cam.current_distance, 0.01))
			+ " m of " + str(cam.distance) + ")")
		var cam_now = cam.global_transform.origin
		wall.queue_free()
		cam.current_distance = cam.distance
		check(cam_now.distance_to(wall.global_transform.origin) < 1.2, "camera stopped at the wall surface")

	# ---------------------------------------------------------------
	# 6. LOCOMOTION: CLIPS + CAMERA RELATIVE MOVEMENT
	# ---------------------------------------------------------------
	if animator:
		var start = player.global_transform.origin
		Input.action_press("move_forwards")
		var seen = {}
		var moving_frames = 0
		var moving_loco_frames = 0
		for i in range(90):
			yield(self, "physics_frame")
			if animator.current_clip != "":
				seen[animator.current_clip] = true
			# Once the character is actually rolling, idle must be gone.
			if player.character_mover.velocity.length() > 2.0:
				moving_frames += 1
				if animator.current_clip in ["Walk_Female", "Run_Female"]:
					moving_loco_frames += 1
		var moved = player.global_transform.origin.distance_to(start)
		check(moved > 0.5, "character travels while W is held (" + str(stepify(moved, 0.01)) + " m)")
		check(seen.has("Walk_Female") or seen.has("Run_Female"),
			"a locomotion clip plays while moving (saw " + str(seen.keys()) + ")")
		check(moving_frames > 20 and moving_loco_frames == moving_frames,
			"no idle frames once moving (" + str(moving_loco_frames) + "/" + str(moving_frames)
			+ " moving frames used a walk/run clip) - this was the original bug")
		Input.action_release("move_forwards")

		# Now point the camera 90 degrees away: W must follow the camera.
		cam.yaw = 90.0
		cam.call("_apply_transform")
		yield(self, "physics_frame")
		var s2 = player.global_transform.origin
		Input.action_press("move_forwards")
		for i in range(70):
			yield(self, "physics_frame")
		Input.action_release("move_forwards")
		var d = player.global_transform.origin - s2
		d.y = 0
		var cam_fwd = -cam.global_transform.basis.z
		cam_fwd.y = 0
		if d.length() > 0.3:
			check(d.normalized().dot(cam_fwd.normalized()) > 0.8,
				"W walks where the camera looks, not along world axes (dot="
				+ str(stepify(d.normalized().dot(cam_fwd.normalized()), 0.01)) + ")")
		else:
			check(false, "character moved while testing camera relative movement")

		# The body should have turned to face the direction of travel.
		var facing_now = Vector3(sin(player.rotation.y), 0, cos(player.rotation.y))
		if d.length() > 0.3:
			check(facing_now.dot(d.normalized()) > 0.8,
				"character turns to face the way it is walking (dot="
				+ str(stepify(facing_now.dot(d.normalized()), 0.01)) + ")")

		# Crouch
		player.set_sneaking(true)
		yield(self, "physics_frame")
		for i in range(40):
			yield(self, "physics_frame")
		check(animator.clip_for("sneak_idle") == "Crouch_Idle" and animator.state.begins_with("sneak"),
			"crouching selects the stealth animation set (state=" + str(animator.state) + ")")
		player.set_sneaking(false)

	# ---------------------------------------------------------------
	# 7. JUMPING uses the jump clips
	# ---------------------------------------------------------------
	if animator:
		for i in range(10):
			yield(self, "physics_frame")
		Input.action_press("jump")
		var air_clips = {}
		var went_airborne = false
		for i in range(90):
			yield(self, "physics_frame")
			if i == 1:
				Input.action_release("jump")
			if !player.character_mover.is_on_floor():
				went_airborne = true
			if animator.current_clip != "":
				air_clips[animator.current_clip] = true
		check(went_airborne or air_clips.has("Jump_Start") or air_clips.has("Jump_air"),
			"jumping plays a jump clip (saw " + str(air_clips.keys()) + ")")
		check(player.global_transform.origin.y > 1.0, "player is back on the ground after the jump")

	# ---------------------------------------------------------------
	# 8. ANIMAL FORMS still work (regression check for the new camera)
	# ---------------------------------------------------------------
	if player.form_manager:
		player.form_manager.transform_to(player.form_manager.FORM.CAT)
		for i in range(40):
			yield(self, "physics_frame")
		check(player.form_manager.is_transformed(), "transformation into cat form still works")
		player.form_manager.revert_to_human()
		for i in range(30):
			yield(self, "physics_frame")
		check(!player.form_manager.is_transformed(), "reverting to human still works")
		check(player.third_person_camera.current, "third person camera is active again after reverting")

	# ---------------------------------------------------------------
	# 9. CROUCHING GOES DOWN, NOT UP
	# ---------------------------------------------------------------
	var stand_top = 0.0
	var crouch_top = 0.0
	var stand_shape_y = 0.0
	var crouch_shape_y = 0.0
	var stand_origin_y = 0.0
	var crouch_origin_y = 0.0
	if m:
		# NOTE: a skinned MeshInstance keeps its bind-pose AABB forever (the
		# deformation happens on the GPU), so the animated height has to be
		# read from the skeleton's bone poses, not from mesh AABBs.
		var skel = _find_skeleton(m)
		player.set_sneaking(false)
		for i in range(40):
			yield(self, "physics_frame")
		stand_top = _bone_height(skel)
		stand_shape_y = player.get_node("CollisionShape").translation.y
		stand_origin_y = player.global_transform.origin.y

		player.set_sneaking(true)
		for i in range(50):
			yield(self, "physics_frame")
		crouch_top = _bone_height(skel)
		crouch_shape_y = player.get_node("CollisionShape").translation.y
		crouch_origin_y = player.global_transform.origin.y

		check(animator == null or animator.state == "sneak_idle",
			"crouching selects the crouch idle state (" + str(animator.state if animator else "?") + ")")
		check(crouch_top < stand_top - 0.30,
			"crouching lowers the character's head (" + str(stepify(stand_top, 0.01)) + " m -> "
			+ str(stepify(crouch_top, 0.01)) + " m above the floor)")
		check(abs(crouch_origin_y - stand_origin_y) < 0.06,
			"the body does not get pushed upward by its own capsule (origin y "
			+ str(stepify(stand_origin_y, 0.01)) + " -> " + str(stepify(crouch_origin_y, 0.01)) + ")")
		check(crouch_shape_y < stand_shape_y - 0.2,
			"crouch capsule is genuinely shorter (shape centre " + str(stepify(stand_shape_y, 0.01))
			+ " -> " + str(stepify(crouch_shape_y, 0.01)) + ")")
		var cap = player.get_node("CollisionShape").shape
		var bottom = crouch_shape_y - cap.radius - cap.height * 0.5
		check(abs(bottom) < 0.08,
			"crouch capsule bottom stays at the feet (offset " + str(stepify(bottom, 0.001)) + " m)")
		player.set_sneaking(false)
		for i in range(30):
			yield(self, "physics_frame")

	# ---------------------------------------------------------------
	# 10. PICKPOCKET PROXIMITY COMES FROM THE CHARACTER, NOT THE CAMERA
	# ---------------------------------------------------------------
	if cam:
		var ProbeScript = load("res://tests/ProximityProbe.gd")

		# (a) next to the CAMERA, far from the CHARACTER -> must stay dark.
		var far_probe = ProbeScript.new()
		far_probe.name = "ProbeNearCamera"
		far_probe.add_to_group("dropped_loot")
		world.add_child(far_probe)
		far_probe.global_transform = Transform(Basis(), cam.global_transform.origin + Vector3(0, 0, 0.4))
		yield(self, "physics_frame")
		player.scan_for_npcs()
		var cam_gap = cam.global_transform.origin.distance_to(far_probe.global_transform.origin)
		var player_gap = player.global_transform.origin.distance_to(far_probe.global_transform.origin)
		check(cam_gap < 1.5 and player_gap > 3.8,
			"probe A sits by the camera (" + str(stepify(cam_gap, 0.01)) + " m) but beyond the character's reach ("
			+ str(stepify(player_gap, 0.01)) + " m)")
		check(far_probe.last_mode <= 0,
			"probe A is NOT highlighted - out of the character's reach (mode=" + str(far_probe.last_mode) + ")")
		far_probe.queue_free()

		# (b) next to the CHARACTER, far from the camera -> must light up white.
		var near_probe = ProbeScript.new()
		near_probe.name = "ProbeNearPlayer"
		near_probe.add_to_group("dropped_loot")
		world.add_child(near_probe)
		near_probe.global_transform = Transform(Basis(), player.global_transform.origin + Vector3(0, 0, 2.2))
		yield(self, "physics_frame")
		player.scan_for_npcs()
		var player_gap2 = player.global_transform.origin.distance_to(near_probe.global_transform.origin)
		var cam_gap2 = cam.global_transform.origin.distance_to(near_probe.global_transform.origin)
		check(player_gap2 < 3.8 and cam_gap2 > 4.0,
			"probe B sits by the character (" + str(stepify(player_gap2, 0.01)) + " m) and far from the camera ("
			+ str(stepify(cam_gap2, 0.01)) + " m)")
		check(near_probe.last_mode == 1,
			"probe B IS highlighted white - within the character's reach (mode=" + str(near_probe.last_mode) + ")")
		near_probe.queue_free()
		yield(self, "physics_frame")

	# ---------------------------------------------------------------
	# 11. THE CHARACTER IS REMOVED IN ANIMAL FORM
	# ---------------------------------------------------------------
	if player.form_manager and m:
		player.form_manager.transform_to(player.form_manager.FORM.BIRD)
		for i in range(30):
			yield(self, "physics_frame")
		check(!m.visible, "the human model is hidden after transforming into a bird")
		var rig_visible = false
		if player.weapon_rig:
			for wn in player.weapon_rig.models.keys():
				var wn_node = player.weapon_rig.models[wn]
				if is_instance_valid(wn_node) and wn_node.visible:
					rig_visible = true
		check(!rig_visible, "weapons are hidden with the human model")
		player.form_manager.revert_to_human()
		for i in range(30):
			yield(self, "physics_frame")
		check(m.visible, "the human model comes back when reverting to human")

	# ---------------------------------------------------------------
	# 12. WEAPONS ARE ON THE CHARACTER
	# ---------------------------------------------------------------
	if player.weapon_rig:
		check(player.weapon_rig.ready_ok, "weapon rig attached sockets to the skeleton")
		# Unlock everything, as if every pickup had been collected.
		for i in range(4):
			player.weapon_manager.slots_unlocked[i] = true
		player.weapon_manager.switch_to_weapon_slot(0)   # machete
		yield(self, "physics_frame")
		var machete = player.weapon_rig.models.get("Machete", null)
		check(machete != null and is_instance_valid(machete), "machete model instanced onto the character")
		if machete:
			var hand_socket = player.weapon_rig.sockets["hand"]
			check(machete.get_parent() == hand_socket, "the melee weapon is parented to the RIGHT HAND bone")
			check(machete.visible, "the equipped melee weapon is visible")
			var mlen = player.weapon_rig.get_world_length("Machete")
			check(mlen > 0.3 and mlen < 0.9,
				"machete is a believable size in world units (" + str(stepify(mlen, 0.01)) + " m)")
			var hand_pos = player.weapon_rig.sockets["hand"].global_transform.origin
			var dist_to_hand = hand_pos.distance_to(player.global_transform.origin)
			check(dist_to_hand < 1.2, "hand socket rides the character (" + str(stepify(dist_to_hand, 0.01)) + " m from origin)")
		# Switch to a gun: it takes the hand, the machete goes to the back.
		player.weapon_manager.switch_to_weapon_slot(2)   # shotgun
		yield(self, "physics_frame")
		yield(self, "physics_frame")
		var shotgun = player.weapon_rig.models.get("Shotgun", null)
		if shotgun:
			check(shotgun.get_parent() == player.weapon_rig.sockets["hand"], "the active gun moves into the hand")
		if machete:
			check(machete.get_parent() == player.weapon_rig.sockets["back"], "the stowed melee weapon moves to the back socket")
			check(machete.visible, "the stowed weapon is still visible (holstered)")
		player.weapon_manager.switch_to_weapon_slot(0)
		yield(self, "physics_frame")

	# ---------------------------------------------------------------
	# 13. MELEE ATTACK ANIMATION
	# ---------------------------------------------------------------
	if animator:
		player.weapon_manager.switch_to_weapon_slot(0)
		for i in range(10):
			yield(self, "physics_frame")
		check(animator.clip_for("attack_melee") == "Chop_Tree",
			"a melee attack clip is bound (" + str(animator.clip_for("attack_melee")) + ")")
		Input.action_press("attack")
		yield(self, "physics_frame")
		Input.action_release("attack")
		var saw_attack = false
		for i in range(40):
			yield(self, "physics_frame")
			if animator.current_clip == "Chop_Tree" or animator.is_attacking():
				saw_attack = true
		check(saw_attack, "attacking with the machete plays the character swing animation")
		check(animator.current_clip != "Chop_Tree" or !animator.is_attacking(),
			"the attack animation finishes and returns to locomotion")

	# ---------------------------------------------------------------
	# 14. AIM DOWN SIGHTS (right mouse)
	# ---------------------------------------------------------------
	if cam:
		# Drive the real input action: Player._process pushes its own aim
		# state into the camera every frame, so poking set_aiming() directly
		# would simply be overwritten.
		Input.action_release("aim")
		for i in range(25):
			yield(self, "physics_frame")
		var hip_fov = cam.fov
		var hip_dist = cam.current_distance
		var hip_anchor = cam.call("_effective_anchor_height")
		Input.action_press("aim")
		for i in range(60):
			yield(self, "physics_frame")
		var aim_fov = cam.fov
		var aim_dist = cam.current_distance
		var aim_anchor = cam.call("_effective_anchor_height")
		check(aim_fov < hip_fov - 5.0,
			"aiming narrows the FOV (" + str(stepify(hip_fov, 0.1)) + " -> " + str(stepify(aim_fov, 0.1)) + ")")
		check(aim_dist < hip_dist - 0.8,
			"aiming pulls the camera in (" + str(stepify(hip_dist, 0.01)) + " m -> " + str(stepify(aim_dist, 0.01)) + " m)")
		check(aim_anchor > hip_anchor,
			"aiming raises the orbit anchor over the shoulder (" + str(stepify(hip_anchor, 0.01))
			+ " -> " + str(stepify(aim_anchor, 0.01)) + ")")

		# Zooming with the wheel must not fight the aim pose.
		var before_zoom = cam.current_distance
		cam.zoom(-3)
		yield(self, "physics_frame")
		check(abs(cam.current_distance - before_zoom) < 0.6, "mouse wheel does not fight the aim pose")

		check(player.is_aiming, "player registers the aim input while the button is held")
		Input.action_release("aim")
		for i in range(40):
			yield(self, "physics_frame")
		check(cam.fov > aim_fov + 5.0, "FOV returns to normal after releasing aim")
		check(cam.current_distance > aim_dist + 0.8, "camera distance returns after releasing aim")

	# ---------------------------------------------------------------
	# 15. NaN / ERROR SWEEP over several hundred frames
	# ---------------------------------------------------------------
	var nan_nodes = {}
	for i in range(240):
		yield(self, "physics_frame")
		for n in _all(world, []):
			if n is Spatial:
				var t = n.global_transform
				if is_nan(t.origin.x) or is_nan(t.origin.y) or is_nan(t.origin.z):
					nan_nodes[str(n.get_path())] = true
	check(nan_nodes.empty(), "no NaN transforms over 240 frames"
		+ ("" if nan_nodes.empty() else " -> " + str(nan_nodes.keys().slice(0, 8))))

	# ---------------------------------------------------------------
	print("")
	print("=====================================================")
	var passed = 0
	for r in results:
		if r[0]:
			passed += 1
		print(("  PASS  " if r[0] else "  FAIL  "), r[1])
	print("-----------------------------------------------------")
	print(" ", passed, "/", results.size(), " checks passed")
	print("=====================================================")
	quit(0 if passed == results.size() else 1)

# ---------------------------------------------------------------------
func check(ok : bool, msg : String):
	results.append([ok, msg])

func _find_player(node):
	if node.is_in_group("player"):
		return node
	for c in node.get_children():
		var r = _find_player(c)
		if r:
			return r
	return null

func _find_skeleton(node):
	if node is Skeleton:
		return node
	for c in node.get_children():
		var r = _find_skeleton(c)
		if r:
			return r
	return null

func _all(node, acc = []):
	acc.append(node)
	for c in node.get_children():
		_all(c, acc)
	return acc

func _world_aabb(root) -> AABB:
	var box = AABB()
	var first = true
	for n in _all(root, []):
		if n is MeshInstance and n.mesh:
			var wb = n.global_transform.xform(n.mesh.get_aabb())
			if first:
				box = wb
				first = false
			else:
				box = box.merge(wb)
	if first:
		return AABB(Vector3.ZERO, Vector3.ONE)
	return box

func _bone_height(skel) -> float:
	if !skel:
		return 0.0
	var idx = skel.find_bone("girl_bone_head_36")
	if idx < 0:
		return 0.0
	var world = skel.global_transform.xform(skel.get_bone_global_pose(idx).origin)
	return world.y - player.global_transform.origin.y

func _bone_pose() -> Vector3:
	var skel = _find_skeleton(player.character_model)
	if !skel:
		return Vector3.ZERO
	return skel.get_bone_global_pose(36).origin
