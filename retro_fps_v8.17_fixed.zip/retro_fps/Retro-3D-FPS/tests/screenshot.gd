extends SceneTree

# Renders the real game and dumps PNGs.
#   xvfb-run -a -s "-screen 0 1280x720x24" godot --path . -s res://tests/screenshot.gd

var world = null
var player = null
var shot = 0

func _init():
	OS.window_size = Vector2(1280, 720)
	get_root().set_size(Vector2(1280, 720))

	world = load("res://World.tscn").instance()
	get_root().add_child(world)
	yield(self, "idle_frame")
	player = _find_player(world)
	print("[shot] player=", player != null)
	for i in range(30):
		yield(self, "idle_frame")

	# Unlock every weapon so the whole loadout shows up on the character.
	for i in range(4):
		player.weapon_manager.slots_unlocked[i] = true
	player.weapon_manager.switch_to_weapon_slot(0)   # machete in hand
	player.refresh_weapon_rig()
	yield(self, "idle_frame")

	var cam = player.third_person_camera
	cam.pitch = -8.0
	cam.distance = 2.6
	cam.current_distance = 2.6

	# 1. Machete in the right hand, seen from the front
	cam.yaw = 0.0
	cam.call("_apply_transform")
	for i in range(25):
		yield(self, "idle_frame")
	_capture("10_machete_in_hand_front")

	# 2. Same, from behind (back socket: the other weapons)
	cam.yaw = 180.0
	cam.distance = 2.8
	cam.current_distance = 2.8
	cam.call("_apply_transform")
	for i in range(20):
		yield(self, "idle_frame")
	_capture("11_weapons_on_back")

	# 3. Side view of the held machete
	cam.yaw = 90.0
	cam.distance = 2.0
	cam.current_distance = 2.0
	cam.call("_apply_transform")
	for i in range(20):
		yield(self, "idle_frame")
	_capture("12_machete_side")

	# 4. Mid swing (melee attack animation)
	cam.yaw = 40.0
	cam.distance = 3.0
	cam.current_distance = 3.0
	cam.call("_apply_transform")
	yield(self, "idle_frame")
	player.animator.play_attack(true)
	for i in range(14):
		yield(self, "idle_frame")
	_capture("13_melee_swing")

	# 5. A gun in the hand
	player.weapon_manager.switch_to_weapon_slot(2)   # shotgun
	yield(self, "idle_frame")
	cam.yaw = 30.0
	cam.call("_apply_transform")
	for i in range(20):
		yield(self, "idle_frame")
	_capture("14_shotgun_in_hand")
	player.weapon_manager.switch_to_weapon_slot(0)

	# 6. Crouching
	cam.yaw = 0.0
	cam.distance = 3.0
	cam.current_distance = 3.0
	player.set_sneaking(true)
	for i in range(40):
		yield(self, "idle_frame")
	_capture("15_crouch_down")
	player.set_sneaking(false)
	for i in range(30):
		yield(self, "idle_frame")

	# 7. Aim down sights, and the same moment with the FOV narrowed
	cam.yaw = 0.0
	cam.distance = 4.2
	cam.current_distance = 4.2
	yield(self, "idle_frame")
	_capture("16_hip")
	Input.action_press("aim")
	for i in range(50):
		yield(self, "idle_frame")
	_capture("17_aim_down_sights")
	Input.action_release("aim")
	for i in range(40):
		yield(self, "idle_frame")

	# 8. Animal form: the human must be gone
	player.form_manager.transform_to(player.form_manager.FORM.CAT)
	for i in range(40):
		yield(self, "idle_frame")
	_capture("18_cat_form_no_human")
	player.form_manager.revert_to_human()
	for i in range(30):
		yield(self, "idle_frame")

	print("[shot] done, captured ", shot, " frames")
	quit()

func _capture(name : String):
	var img = get_root().get_texture().get_data()
	if img == null:
		print("[shot] no image data for ", name)
		return
	img.flip_y()
	var dir = "user://shots"
	var d = Directory.new()
	if !d.dir_exists(dir):
		d.make_dir_recursive(dir)
	var path = dir + "/" + name + ".png"
	var err = img.save_png(path)
	if err != OK:
		print("[shot] failed to save ", path, " err=", err)
	else:
		shot += 1
		print("[shot] saved ", ProjectSettings.globalize_path(path))

func _find_player(node):
	if node.is_in_group("player"):
		return node
	for c in node.get_children():
		var r = _find_player(c)
		if r:
			return r
	return null
