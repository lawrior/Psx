extends SceneTree

# Minimal repro: a KinematicBody capsule standing on a flat box floor, driven
# by the project's own CharacterMover.gd. Nothing else exists in this scene.
# If the velocity grows here, the instability is inside CharacterMover itself.

func _init():
	var root = Spatial.new()
	root.name = "ReproRoot"
	get_root().add_child(root)

	# Floor: 100 x 2 x 100 box, exactly like World.tscn's ground (top at y = 1).
	var floor_body = StaticBody.new()
	var floor_shape = CollisionShape.new()
	var box = BoxShape.new()
	box.extents = Vector3(50, 1, 50)
	floor_shape.shape = box
	floor_body.add_child(floor_shape)
	floor_body.collision_layer = 1
	root.add_child(floor_body)
	floor_body.global_transform.origin = Vector3(0, 0, 0)

	# Body
	var body = KinematicBody.new()
	var cs = CollisionShape.new()
	var cap = CapsuleShape.new()
	cap.radius = 0.5
	cap.height = 2.0
	cs.shape = cap
	cs.translation = Vector3(0, 1.0, 0)
	body.add_child(cs)
	body.collision_layer = 2
	body.collision_mask = 1
	root.add_child(body)
	body.global_transform.origin = Vector3(0, 1.0015, 0)

	# The project's own mover
	var mover = load("res://characters/CharacterMover.gd").new()
	mover.name = "CharacterMover"
	body.add_child(mover)
	mover.init(body)
	mover.ignore_rotation = true
	yield(self, "physics_frame")

	print("=== mover values: accel=", mover.move_accel, " max_speed=", mover.max_speed,
		" drag=", mover.drag, " jump_force=", mover.jump_force, " gravity=", mover.gravity)
	print("=== idle on a flat floor, zero input ===")
	var v = []
	for i in range(30):
		yield(self, "physics_frame")
		v.append(body.global_transform.origin.x)
	print("x positions: ", v)
	var max_x = 0.0
	for x in v:
		max_x = max(max_x, abs(x))
	print("max |x| drift after 30 frames = ", max_x)

	# Now walk forwards
	print("=== with input (move_vec = +X) ===")
	mover.set_move_vec(Vector3(1, 0, 0))
	var v2 = []
	for i in range(40):
		yield(self, "physics_frame")
		v2.append([stepify(body.global_transform.origin.x, 0.001), stepify(mover.velocity.x, 0.001)])
	print("x / vx: ", v2.slice(0, 12))
	print("x / vx end: ", v2.slice(v2.size() - 4, v2.size()))
	print("REPRO_DONE")
	quit()
