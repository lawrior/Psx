extends Area

# Minimal stand-in for DroppedLootItem, used only by the headless test suite.
# It implements just enough of the interface that Player.scan_for_npcs() and
# update_interact_prompt() touch, so the highlight-distance logic can be
# exercised without constructing a real loot drop.

var item_data : Dictionary = {"name": "Proximity Probe", "value": 0}
var last_mode : int = -1
var highlight_calls : int = 0

func set_highlight(mode : int):
	last_mode = mode
	highlight_calls += 1

func get_item_name() -> String:
	return "Proximity Probe"
