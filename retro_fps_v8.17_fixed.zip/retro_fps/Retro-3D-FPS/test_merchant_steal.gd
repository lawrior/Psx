extends SceneTree

# Test script to debug stealing from merchant

func _init():
	print("=== Merchant Steal Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found")
	
	# Get merchant node
	var merchants = current_scene.get_tree().get_nodes_in_group("merchant")
	if merchants.empty():
		print("ERROR: No merchant found in world!")
		quit(1)
		return
	
	var merchant = merchants[0]
	print("Merchant found: ", merchant.name)
	print("Merchant script: ", merchant.get_script())
	
	# Check if merchant has pickpocket methods
	print("\n--- Checking merchant methods ---")
	print("Has perform_pickpocket: ", merchant.has_method("perform_pickpocket"))
	print("Has catch_pickpocket: ", merchant.has_method("catch_pickpocket"))
	print("Has is_player_behind: ", merchant.has_method("is_player_behind"))
	print("Has get_pocket_count: ", merchant.has_method("get_pocket_count"))
	
	# Check if merchant has visual_placeholders
	print("Has visual_placeholders: ", "visual_placeholders" in merchant)
	if "visual_placeholders" in merchant:
		print("visual_placeholders: ", merchant.visual_placeholders)
	
	# Try to steal (this should fail gracefully, not crash)
	print("\n--- Attempting to steal from merchant ---")
	player.target_npc = merchant
	player.is_behind_target = true
	player.sneaking = true
	
	print("Calling perform_steal_action()...")
	player.perform_steal_action()
	
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	print("\n=== Steal test completed ===")
	quit(0)
