# Retro-3D-FPS v8.15 — Debug Report

**Project**: `retro_fps_v8.15.zip` (github.com/lawrior/Psx)
**Engine**: Godot **3.5.3** (the project is Godot 3, not Godot 4)
**Verified on**: Godot 3.5.3-stable, headless + Xvfb/llvmpipe rendering

Your three symptoms — *no texture*, *animations don't play*, *camera is bad* — turned out to be
**seven independent bugs**, three of them fatal. One of them (the camera) was not really a camera bug
at all: the player's physics was numerically exploding, which is why everything looked wrong on screen.

Result: **43/43 automated checks pass**, the game boots with no script errors, and the character is
textured, correctly scaled and fully animated.

![fixed](screenshots/04_front_orbit.png)

---

## 0. The project didn't launch at all

Before anything else could be tested, the game had to start. It didn't.

```
SCRIPT ERROR: Parse Error: The identifier "TorusMesh" isn't declared in the current scope.
          at: GDScript::reload (res://characters/ItemMeshFactory.gd:242)
ERROR: Cannot get class 'TorusMesh'.
ERROR: res://environment/assets/WitchCauldron.tscn:13 - Parse Error: Can't create sub resource of type: TorusMesh
ERROR: Failed to load resource 'res://environment/assets/WitchCauldron.tscn'.
ERROR: res://environment/assets/WitchBase.tscn:3 - Parse Error: [ext_resource] referenced nonexistent resource
ERROR: res://World.tscn:19 - Parse Error: [ext_resource] referenced nonexistent resource
ERROR: Failed loading scene: res://World.tscn
```

`TorusMesh` is a **Godot 4** primitive. This is a **Godot 3** project (`config_version=4` scenes,
`Spatial`, `KinematicBody`, `move_and_slide_with_snap`). Because `TorusMesh` failed to parse,
`ItemMeshFactory.gd` failed to compile, which cascaded into `ItemTransferVisual.gd`, `Player.gd`,
`Monster.gd`, `HarvestableItem.gd`, `FruitTree.gd`, `Flowerbed.gd` and `WitchCauldron.gd` — pretty
much the entire game.

**Fix**: added `ItemMeshFactory.make_torus()` — a procedural `ArrayMesh` ring generator (Godot 3 has
no torus primitive). Used it for the trinket ring in the item factory and for the cauldron's stone
hearth ring, which was a `TorusMesh` sub-resource in `WitchCauldron.tscn` and is now generated in
`WitchCauldron.gd::setup_hearth_mesh()`.

> Side note: the project's own CHANGELOG shows this class of bug being fixed repeatedly
> ("Fixed `cull_mode` → `params_cull_mode`", "Fixed `CapsuleMesh.height` → `mid_height`").
> The codebase is Godot 3 with Godot 4 knowledge applied to it. That is the thread that runs through
> everything below.

---

## 1. "Player character has no texture" — the import cache was a **brick wall**

This one is not a material bug at all. The character was rendering the **wrong model entirely**.

The GLB itself is fine — 7 skinned meshes, 7 embedded 1024×1024 PNG textures, 68 bones, 37 animation
clips. But `.import/girl_with_all_animations.glb-*.scn` (the compiled scene Godot actually loads)
was a byte-for-byte copy of **brickwall**'s compiled scene:

```
546cdd15ff5df8f27aabadc651a707e2  .import/brickwall.glb-775f2b42….scn
546cdd15ff5df8f27aabadc651a707e2  .import/girl_with_all_animations.glb-bae83d5….scn   ← identical
```

The `.md5` sidecar had been hand-faked so Godot believed the cache was valid:

```
.import/girl_with_all_animations.glb-bae83d5540703be0c71cf7c771960dfe.md5
    source_md5="bae83d5540703be0c71cf7c771960dfe"   ← the girl GLB's real hash
    dest_md5="bae83d5540703be0c71cf7c771960dfe"     ← fake: equals the SOURCE hash
.import/brickwall.glb-775f2b42….md5
    source_md5="d3598bba116d1646871f9f167f22605f"   ← source hash
    dest_md5="546cdd15ff5df8f27aabadc651a707e2"     ← the real compiled-scene hash
```

Loading it proved it:

```
$ godot --path . -s diag.gd
LOADED SCENE: [PackedScene:1403]
ROOT: brickwall type Spatial          <-- "girl_with_all_animations.glb"
  brickwall [MeshInstance] MESH=[ArrayMesh:1402] surfaces=1
       surf0 mat=[SpatialMaterial:1401] albedo_tex=[ImageTexture:1399] size=(128, 128)
```

`V8.15_FIXES.md` even claims *"Girl Has No Texture — Cause: GLB file not imported by Godot editor,
using placeholder model (brickwall)"*. That was a deliberate workaround that shipped.

**Fix**: deleted the poisoned cache entries and let Godot re-import the GLB properly:

```
$ rm .import/girl_with_all_animations.glb-* && godot --editor --quit
$ ls -la .import/ | grep girl
  girl_with_all_animations.glb-075b71103ce2dd058dd7ca6475819757.scn   22146534 bytes   (was 1676)
```

Now:

```
ROOT: GirlCharacter (Spatial)
  ... Skeleton SKELETON bones=68
        Object_7  MESH [surf0 mat=True tex=(1024, 1024)]     <- ×7
  AnimationPlayer ANIMPLAYER anims=37
```

The full `.import/` cache was also audited afterwards: all 29 entries match their source file hashes
and no source asset is missing an import entry.

---

## 2. "Animations don't play" — **three** separate bugs stacked

### 2a. The code was asking for animations that don't exist

`Player.gd::_update_character_animation()` requested `"idle"`, `"walk"`, `"run"`, `"jump"`, `"dead"`,
`"sneak_walk"`, `"sneak_idle"`. The GLB's actual clip names are:

```
idle  Chop_Tree  Climb_Ladder  Consume  Consume_Item  Crouch_Idle  Crouch_Walk  Death_A
Farm_Harvest  Farm_PlantSeed  Fixing_Kneeling  Idle_Listening  Idle_Subtle  Idle_Talking
Idle_Torch  Interact  Jump_Land  Jump_Start  Jump_air  Ladder_Idle  LayToIdle  PickUp_Table
Run_Female  Sitting_*  Spell_*  Strafe_left  Strafe_right  Walk_Backwards  Walk_Carry
Walk_Female  Walk_Stealth
```

`Walk_Female`, `Run_Female`, `Walk_Stealth`, `Crouch_Walk`, `Jump_air`, `Death_A` — **none** of the
names the code asked for exist. Every lookup failed and fell back to `"idle"`.

### 2b. The fallback logic then locked itself out permanently

```gdscript
if target_animation != current_animation:      # "idle" != "idle" -> never true
    ...
    elif character_anim_player.has_animation("idle"):
        character_anim_player.play("idle")
        current_animation = "idle"             # stays "idle" forever
```

Once the state was `idle`, the guard `target_animation != current_animation` could never fire again,
so `play()` was never called again. **This is why the character froze completely** rather than
cycling between clips.

### 2c. Every clip came out of the importer with `loop = false`

```
  idle            len=1.966667 loop=False tracks=67
  Walk_Female     len=1.375    loop=False tracks=65
  Run_Female      len=0.833333 loop=False tracks=65
  Crouch_Idle     len=3.666667 loop=False tracks=65
```

Godot 3's glTF importer does not infer looping from the source. So even after fixing the names,
`idle` would play once for two seconds and stop dead. The original code never touched `loop`.

### 2d. Bonus: root motion baked into the clips

Measuring the clips showed hip translation baked in (`Walk_Female` 0.59 u, `Run_Female` 1.47 u,
`Jump_Start` 26.3 u, `Death_A` 74.4 u). On a capsule-controlled character that fights the physics —
if left alone the character would moonwalk across the terrain.

### The fix

New `characters/player/CharacterAnimator.gd` — a proper animation state machine:

* **Logical states → real clips**, with fallback chains:
  `walk → Walk_Female`, `run → Run_Female`, `sneak_walk → Walk_Stealth`,
  `sneak_idle → Crouch_Idle`, `air → Jump_air`, `dead → Death_A`,
  plus `Walk_Backwards`, `Strafe_left/right`, `Crouch_Walk`, `Jump_Start`, `Jump_Land`.
* **Loop flags set at load time** for every locomotion / idle clip. (The clips are edited in memory
  after `AnimationPlayer` load — no re-import needed, and it survives a cache wipe.)
* **Root-motion neutralisation**: horizontal drift on `girl_bone_root_1` / `girl_bone_hips_2` is
  flattened while the vertical bounce is preserved.
* **Cross-fades** (0.18–0.25 s) on every transition instead of hard cuts.
* **Playback-speed sync**: the walk clip is played at `speed / walk_speed_ref` so the feet stay
  planted at any speed — no foot skating.
* **One-shot states** for take-off (`Jump_Start`, truncated to the launch portion) and landing
  (`Jump_Land`), with a 0.42 s recovery before blending back into locomotion.

`Player.gd` now feeds it a context every frame (speed, on-floor, sneaking, backwards, strafe axis)
and `kill()` triggers the death clip.

---

## 3. The character was a 3.2-metre giant facing the wrong way

```gdscript
character_model.scale = Vector3(1.0, 1.0, 1.0)
character_model.rotation_degrees = Vector3(0, 180, 0)  # Face forward
```

Two things wrong:

1. **The GLB is 3.258 units tall from foot to hair.** It is not a 1-unit-1-metre model. Instanced at
   scale 1.0 the character is nearly twice the height of her own collision capsule, which is also why
   no camera framing could ever look right (see §4).
2. **The mesh already faces +Z.** Measured from the model's own sub-mesh bounds — the face mesh sits
   at `z = +0.067` while the hair sits at `z = −0.033`. The `180°` "fix" therefore turned her around,
   so she walked **backwards**.

**Fix**: the model is measured at runtime (`_measure_model_local_aabb`) and auto-scaled to a
configurable `character_model_height` (default 1.72 m), and the model's feet are placed on the
capsule bottom. `model_yaw_offset_degrees` is exposed and defaults to `0`:

```
[Character] raw height=3.258385 fit scale=0.527869 -> 1.72m tall
```

---

## 4. "Camera is bad" — four camera bugs **plus** the real culprit underneath

`ThirdPersonCamera.gd` was rewritten from scratch. What was wrong with the old one:

| # | Defect | Why it broke |
|---|---|---|
| 1 | Created a `CameraPivot` as a **child of the Player**, then set `camera_pivot.rotation_degrees = Vector3(pitch, yaw, 0)` | The pivot inherited the body's yaw, so mouse yaw was applied *on top of* body yaw. The view span at double rate and **rolled** whenever the character turned. |
| 2 | The spring-arm raycast went to `+pivot.basis.z * distance` while the camera was placed at `−basis.z` | The collision test measured **empty space in front of the player**, so the camera clipped through walls and terrain and could not recover. |
| 3 | Position interpolated with `linear_interpolate` **and** rotation snapped with `look_at()` every frame | The two fought each other → the jitter/wobble the changelog kept trying to tune away (v8.7 "reduced factor 14 → 8"). |
| 4 | `height_offset = 2.0` / `look_at_height = 1.5` against a 3.2 m model | The camera aimed at the character's **knees**, and orbited the capsule centre instead of the head/chest. |

New implementation:

* Plain **spring arm** around an anchor at the chest, `set_as_toplevel(true)` so it never inherits body rotation.
* Mouse look is `add_look(dx, dy)` polled by `Player._input` — yaw orbits the camera only; the **body**
  is turned separately by movement (Skyrim behaviour).
* Collision ray cast along the **actual arm direction**, starting 0.3 m out from the focus so it can't
  hit the player's own capsule. **Snaps in fast, eases out slowly** (`distance_smooth_in = 28`,
  `distance_smooth_out = 4`) — no wall clipping, no popping when leaving a doorway.
* Anchor follows the chest with horizontal smoothing and **instant vertical** (no stair bob).
* `shoulder_offset = 0.55` puts the character off-centre like a proper over-the-shoulder game camera;
  the basis is set directly so the aim axis stays parallel to the arm and the crosshair does not end up
  on her back.
* Crouch lowers the anchor via `crouch_anchor_height`.
* Mouse wheel now **zooms** the camera (it used to cycle weapons).
* `pitch_bias = -8°` gives the default slightly-downward framing.
* The 180° flip bug was replaced by an aim rig: the old first-person `Camera` node stays in the tree
  (the weapon rig, its muzzle flashes and the hearing/LOS `Area`s hang off it) and its transform is
  slaved to the third-person camera's rotation with its origin at the character's chest — so bullets,
  the machete and the pickpocket raycasts all go where you are actually looking.

### …and the reason the "camera" felt broken even after all that

The camera was faithfully following a player whose position was **drifting to infinity**. See §5.

---

## 5. The big one: the movement controller was numerically unstable and NaNs the whole scene

Symptom: with **zero input**, standing still, the player slid away on its own, accelerating:

```
[f0]  player=(0, 1.0015, 10.6612)              vel=(0.000002, -0.01, 0)
[f6]  player=(-0.000059, …)                    vel=(-0.004551, …)
[f10] player=(-0.010149, …)                    vel=(-0.7774, …)
[f13] player=(0.479626, …)                     vel=(36.737297, …)
[f16] player=(-22.665543, …)                   vel=(-1736.08, …)
[f20] player=(-3853.53, 272.6, 42.8)           vel=(-295182.7, -0.01, 2466.03)
[f23] player=(182116.95, 272.58, -1510.78)     vel=(13949365, …)
[f80] player=(nan, nan, nan)                   vel=(-inf, -22.01, 7.6e36)
```

The velocity grew by a near-constant **×3.6 per frame**. Root cause in `CharacterMover.gd`:

```gdscript
velocity += move_accel * move_vec - velocity * Vector3(drag, 0, drag) + gravity * Vector3.DOWN * _delta
velocity = body_to_move.move_and_slide_with_snap(velocity, snap_vector, Vector3.UP)
if is_grounded:
    velocity.y = -0.01                       # <-- far too late
...
else:
    snap_vector = Vector3.DOWN               # <-- a 1 m/s downward bite, every frame
```

* Gravity **and** a 1 m/s snap were injected into the velocity *before* the slide, and `velocity.y` was
  only corrected *after* it. So every frame the body arrived at the floor carrying a large downward
  velocity that the contact had to cancel.
* The floor collider was a **`ConcavePolygonShape`** (a two-triangle mesh). Its contact normal carried
  ~1e-6 of numerical tilt — I logged the actual contact each frame:

  ```
  slides=1 | hit=…/Ground/StaticBody normal=(0.000002, 1, 0)
  slides=1 | hit=…/Ground/StaticBody normal=(-0.000006, 1, -0.000003)
  slides=1 | hit=…/Ground/StaticBody normal=(-0.000002, 1, 0.000012)
  ```

  That tilt converted a sliver of the downward velocity into horizontal motion. The sliver fed back
  into the next frame's velocity and compounded: **this is the ×3.6/frame.**
* The acceleration and drag terms were **not multiplied by `delta`**, making the whole controller
  framerate dependent, and nothing damped sub-millimetre solver noise.

That is the real reason the camera "looked bad": it was chasing a player being flung off the map, and
that is also why the character never appeared to animate — she was a speck at 10⁹ units away, moving
at 10⁹ m/s.

**Fix — `CharacterMover.gd` rewritten** (same public API):

* Everything scaled by `delta` → framerate independent, using `move_accel` as m/s².
* Vertical velocity is decided **before** the move: a small `ground_bias = 0.05` push instead of a
  1 m/s snap, so the contact never has to cancel runaway downward velocity.
* **Velocity dead-zone** (`stop_epsilon = 0.05`): when there is no input and the speed is below
  5 cm/s, the velocity is zeroed. This is what actually breaks the feedback loop.
* A hard `max_speed_clamp = 40` plus a NaN guard, so no numerical accident can ever launch the player again.
* The floor collider was changed from `ConcavePolygonShape` (2 triangles) to an equivalent
  `BoxShape` (50 × 1 × 50).

After the fix, standing still is *exactly* still:

```
[f3]  player=(0, 1.0015, 10.6612)  vel=(0, 0, 0)  grounded=True
[f19] player=(0, 1.0015, 10.6612)  vel=(0, 0, 0)  grounded=True
```

### Also tuned while in there

The original `max_speed = 25`, `jump_force = 30`, `gravity = 60` is Quake-style speed. For a
Skyrim-like feel the new values are `max_speed = 6.5` m/s, `move_accel = 25` m/s²,
`jump_force = 8.0` (≈ 0.75 m hop, jumps over fences rather than over houses), `gravity = 22`.
Speed-scaled sneak remains 40%. (The two monster `CharacterMover` instances were aligned to the new
m/s² units so the enemies didn't become sluggish/skittish.)

---

## 6. Movement was ignoring the camera

```gdscript
move_vec += Vector3.FORWARD     # world +Z, regardless of where you are looking
```

and `CharacterMover` rotated that vector by the **body** yaw while v8.15 also rotated the body from
input — double rotation. Two new helpers fix both:

* `_camera_relative()` — movement input is converted to world space using the orbit camera's basis
  (its Y flattened). `W` now walks wherever the horizon you're looking at is.
* `_update_character_rotation()` — the **body** is smoothly turned (`turn_speed = 10`) to face the
  movement direction, exactly like Skyrim. `character_mover.ignore_rotation = true` so nothing
  double-rotates. `character_rotation_target` now actually receives a value (the old code computed it
  but never applied it, because the model was never turned).

Verified: with the camera yawed 90°, `W` moves along `dot = 0.98` with the camera forward, and the
character's facing ends up at `dot = 0.98` with her direction of travel.

---

## 7. Smaller bugs found and fixed

| Bug | Detail | Fix |
|---|---|---|
| **Crouch did nothing physically** | `update_sneak_physics()` moved `camera.translation.y` between 1.75 and 0.95 on a camera that is now the *unused* first-person node, and moved the capsule **up** while crouching (`1.0 → 0.55`, sign inverted). | Crouch is handled by the camera's `crouch_anchor_height`; the capsule now shrinks properly. |
| **Reverting from an animal form handed you a dead camera** | `AnimalFormManager` cached `original_camera` in `init()`, which ran *before* `ThirdPersonCamera` replaced the first-person camera. `_cleanup_form()` then re-activated the stale first-person camera — `current = true` on a camera that isn't the player's camera. | `_active_camera()` resolves the player's *current* camera every time, and the reference is refreshed on form entry. |
| **A ReptileMonster spawned inside the market stall** | `ReptileMonster2` at `(8.20303, 1, -16.1012)`, the market stall at `(8.20303, 1, -17.8)` — the two colliders overlapped, adding a permanent jitter source. | Moved to `(8.20303, 1.08, -25.0)`. |
| **Player and monsters spawned exactly tangent to the floor** | Spawn Y of `1.0` is *exactly* the ground surface — a degenerate contact on frame 1 (this is what seeded the §5 divergence). | Spawns raised to `y = 1.08`. |
| **Ground mesh bound to a non-existent skeleton** | `[node name="Ground" …]` had `skeleton = NodePath("../..")`, a leftover from the original demo; it spams rasterizer errors. | Removed. |
| **`look_at()` called with a degenerate vector** | When the character was near/under the camera, `look_at()` produced `Condition "v_x.length() == 0" is true` errors every frame. | The camera's basis is now set directly from the orbit basis — no `look_at()` in the hot path. |
| **HUD/audio warnings** | Headless runs warn about missing audio; irrelevant on a desktop machine. | — |

---

## 8. Verification

A headless suite was added at `tests/test_third_person.gd` (43 checks) covering the model, the
animation binding *and* that the skeleton actually deforms, camera framing/orbit/clamping, spring-arm
collision against a real wall, camera-relative movement, crouch, jump, animal-form round trips, and a
240-frame NaN sweep:

```
$ godot --path . --no-window -s res://tests/test_third_person.gd
  PASS  model is human sized (world height 1.72 m, expected ~1.72)
  PASS  every surface has an albedo texture (7/7, sizes [(1024, 1024)])
  PASS  AnimationPlayer exposes the GLB clips (37 clips)
  PASS  idle loops (importer shipped every clip with loop = false)
  PASS  skinned bones actually deform (delta 1.9066 m)
  PASS  camera sits BEHIND the character (dot=-0.99)
  PASS  spring arm pulls in against a wall behind (1.55 m of 4.2)
  PASS  no idle frames once moving (85/85 moving frames used a walk/run clip) - this was the original bug
  PASS  W walks where the camera looks, not along world axes (dot=0.98)
  PASS  character turns to face the way it is walking (dot=0.98)
  PASS  no NaN transforms over 240 frames
  ...
  43/43 checks passed
```

> Note on the test harness: `yield` inside a *helper* function silently returns a `FunctionState`
> instead of suspending the caller, which quietly skips the rest of the test. Every `yield` in the
> suite is therefore at the top level of the `_init()` coroutine. The first draft of my own tests hit
> exactly this trap and reported "22/23 passed" while silently skipping six checks.

Rendered proof (headless Godot + Xvfb + llvmpipe, real frame grabs in `screenshots/`):
idle, walking mid-stride, close-up showing the 1024² textures, front orbit, and the crouch/stealth pose.

---

## 9. What this is *not* yet (honest Skyrim gaps)

The three things you reported are fixed. If you want to keep pushing towards Skyrim, these are the
next real gaps, roughly in order of value:

1. **No attack/combat animation blending.** The GLB ships `Spell_Simple_Shoot`, `Interact`,
   `Consume`, `Farm_Harvest` etc. — the machete/weapon animations in `Player.tscn` are authored for the
   *weapon model*, not the girl, so she stands in an idle pose while swinging. Worth wiring
   `Spell_Simple_Shoot` / `Interact` to `attack` in `CharacterAnimator.play_one_shot()`.
2. **No strafe-lock / combat stance.** Skyrim draws a weapon and locks the body to the camera. Right
   now the body always turns to the movement direction. Pressing a key to toggle a "combat stance"
   that (a) locks the body to camera yaw and (b) uses `Strafe_left/right` + `Walk_Backwards` would get
   you most of the way there — the clips already exist and are already mapped.
3. **No sheathing/unsheathing, and no weapon visible on the character.** The weapon you carry isn't
   attached to her hand/hip.
4. **Camera has no shoulder-swap or aim-down-sights.** `shoulder_offset` is a single export; a
   `Q`/middle-mouse swap is a two-line change.
5. **No footstep audio** (the project has no audio at all — the sandbox ran with a dummy driver).
6. **The world is still a flat 100×100 plane** with stock `brickwall`/`shed` props, so the
   terrain-following and steep-slope behaviour of the new mover is untested on real Skyrim-like terrain.
   The mover does handle slopes up to 50° (`move_and_slide_with_snap`'s floor max angle).
7. **Enemies still use the old demo AI** (`Monster.gd` at 10 m/s) — I only aligned their acceleration
   units so the §5 rewrite didn't make them sluggish.

---

## 10. Files changed

**New**
| File | Purpose |
|---|---|
| `characters/player/CharacterAnimator.gd` | Animation state machine: real clip names, loop flags, root-motion flattening, cross-fades, speed sync, one-shots |
| `tests/test_third_person.gd` | 43-check headless verification suite |
| `tests/screenshot.gd` | Renders real frames of the running game to PNG |
| `SETUP.md` | How to run, controls, tuning table, re-import procedure |

**Rewritten**
| File | Before → after |
|---|---|
| `characters/player/ThirdPersonCamera.gd` | 108 lines, broken pivot / reversed raycast / jittering look_at → spring arm with correct collision, shoulder offset, crouch framing, zoom |
| `characters/CharacterMover.gd` | Framerate-dependent, NaN-producing controller → delta-scaled, dead-zoned, clamped, stable |

**Modified**
| File | Change |
|---|---|
| `characters/player/Player.gd` | Model auto-scale + orientation, animator wiring, camera-relative movement, body turning, aim rig, crouch, `kill()` |
| `characters/ItemMeshFactory.gd` | `make_torus()` added (Godot 3 alternative to `TorusMesh`) |
| `environment/assets/WitchCauldron.gd` | Builds the hearth torus at runtime |
| `environment/assets/WitchCauldron.tscn` | Removed the Godot-4-only `TorusMesh` sub-resource |
| `characters/AnimalFormManager.gd` | Camera reference is always re-resolved |
| `World.tscn` | Floor collider → `BoxShape`; spawn heights; `ReptileMonster2` moved; stray skeleton binding removed |
| `characters/CharacterMover.tscn`, `characters/enemies/*.tscn` | Per-instance mover tuning in the new m/s² units |
| `.import/girl_with_all_animations.glb-*` | Corrupted brickwall cache → genuine 22 MB import with 68 bones, 7 textured meshes, 37 clips |
