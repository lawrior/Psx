extends SceneTree

# Test script to debug merchant selling

func _init():
	print("=== Merchant Sell Test ===")
	
	# Load and change to the main scene
	var world = ResourceLoader.load("res://World.tscn")
	if !world:
		print("ERROR: Could not load World.tscn")
		quit(1)
		return
	
	change_scene_to(world)
	
	# Wait for scene to be ready
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	yield(self, "idle_frame")
	
	# Get the player
	var player = get_root().get_node_or_null("World/Player")
	if !player:
		print("ERROR: Player not found!")
		quit(1)
		return
	
	print("Player found")
	
	# Check if systems are initialized
	if !player.inventory_manager:
		print("ERROR: inventory_manager is null!")
		quit(1)
		return
	
	if !player.merchant_manager:
		print("ERROR: merchant_manager is null!")
		quit(1)
		return
	
	print("Systems initialized")
	
	# Add some test items to inventory
	print("\n--- Adding test items to inventory ---")
	player.inventory_manager.add_item("apple", 3)
	player.inventory_manager.add_item("plum", 2)
	player.inventory_manager.add_item("trinkets", 1)
	print("Added: 3 apples, 2 plums, 1 trinket")
	
	# Get merchant node
	var merchants = current_scene.get_tree().get_nodes_in_group("merchant")
	if merchants.empty():
		print("ERROR: No merchant found in world!")
		quit(1)
		return
	
	var merchant = merchants[0]
	print("Merchant found: ", merchant.name)
	
	# Open merchant
	print("\n--- Opening merchant ---")
	player.merchant_manager.open_merchant(merchant)
	yield(self, "idle_frame")
	print("Merchant opened")
	
	# Try to sell an apple
	print("\n--- Attempting to sell 1 apple ---")
	var sell_price = player.merchant_manager.get_sell_price("apple")
	print("Sell price for apple: ", sell_price, "g")
	
	if sell_price <= 0:
		print("ERROR: Sell price is 0 or negative!")
		quit(1)
		return
	
	print("Player gold before sell: ", player.gold)
	print("Apple quantity before sell: ", player.inventory_manager.get_item_quantity("apple"))
	
	# Attempt the sell
	print("Calling sell_item()...")
	var success = player.merchant_manager.sell_item("apple", player, merchant)
	
	if !success:
		print("ERROR: sell_item() returned false!")
		quit(1)
		return
	
	yield(self, "idle_frame")
	
	print("Player gold after sell: ", player.gold)
	print("Apple quantity after sell: ", player.inventory_manager.get_item_quantity("apple"))
	
	# Try to sell a trinket
	print("\n--- Attempting to sell 1 trinket ---")
	sell_price = player.merchant_manager.get_sell_price("trinkets")
	print("Sell price for trinkets: ", sell_price, "g")
	
	print("Player gold before sell: ", player.gold)
	print("Trinket quantity before sell: ", player.inventory_manager.get_item_quantity("trinkets"))
	
	success = player.merchant_manager.sell_item("trinkets", player, merchant)
	
	if !success:
		print("ERROR: sell_item() returned false for trinkets!")
		quit(1)
		return
	
	yield(self, "idle_frame")
	
	print("Player gold after sell: ", player.gold)
	print("Trinket quantity after sell: ", player.inventory_manager.get_item_quantity("trinkets"))
	
	print("\n=== All sell tests completed successfully! ===")
	quit(0)
