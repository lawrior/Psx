extends KinematicBody

const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")

onready var aimer = $AimAtObject
onready var anim_player = $Graphics/AnimationPlayer
onready var health_manager = $HealthManager
onready var character_mover = $CharacterMover
onready var nav : Navigation = get_parent()

enum STATES {IDLE, WANDER, SUSPICIOUS, AWARE, BUSINESS, ALERTED, PANIC, DEAD}
var cur_state = STATES.BUSINESS

var player = null
var path = []
var path_ind = 0

export var npc_name : String = ""
export var npc_title : String = "Citizen"

export var sight_angle : float = 55.0
export var turn_speed : float = 240.0
export var sight_distance : float = 22.0
export var sneak_sight_distance : float = 8.5
export var wander_radius : float = 4.0
export var stroll_speed_scale : float = 0.35
export var flee_speed_scale : float = 0.85

var spawn_pos : Vector3
var state_timer : float = 0.0
var bark_timer : float = 0.0
var suspicious_target_pos : Vector3 = Vector3.ZERO
var flee_dir : Vector3 = Vector3.ZERO

# Business & Work Station Data
var home_pos : Vector3
var business_facing_dir : Vector3 = Vector3(0, 0, -1) # Default facing North toward wares/post
var business_name : String = "General Business"
var business_barks : Array = []
var return_to_business_barks : Array = []
var business_idle_timer : float = 0.0

# Interest & Attention Tracking
var lose_interest_timer : float = 0.0
var idle_player_timer : float = 0.0
var last_player_pos : Vector3 = Vector3.ZERO
var last_player_still_pos : Vector3 = Vector3.ZERO
var ignoring_idle_player : bool = false
const IN_FACE_DIST : float = 1.6
const AWARE_MAX_DIST : float = 4.5

# Overhead 3D UI
var overhead_label : Label3D = null
var current_bark : String = ""

# Pockets inventory for pickpocketing & 3D visual placeholders
var pockets : Array = []
var visual_placeholders : Array = [] # Array of {"item": Dictionary, "node": Spatial, "placeholder_id": String}

# Merchant-specific variables
var is_merchant : bool = false
var steal_penalty_timer : float = 0.0
const PENALTY_DURATION : float = 30.0
const PENALTY_RESET_DISTANCE : float = 15.0

# Backward-compatibility signals
signal attack

func _ready():
	add_to_group("npc")
	add_to_group("enemies") # Keep for existing systems querying enemies
	
	spawn_pos = global_transform.origin
	home_pos = global_transform.origin
	var p_nodes = get_tree().get_nodes_in_group("player")
	if !p_nodes.empty():
		player = p_nodes[0]
	
	var bone_attachments = $Graphics/Armature/Skeleton.get_children()
	for bone_attachment in bone_attachments:
		for child in bone_attachment.get_children():
			if child is HitBox:
				child.connect("hurt", self, "hurt")
				
	health_manager.connect("dead", self, "set_state_dead")
	health_manager.connect("gibbed", $Graphics, "hide")
	character_mover.init(self)
	
	init_npc_identity()
	init_overhead_ui()
	setup_item_placeholders()
	
	# Add to merchant group if this is a merchant NPC
	if is_merchant:
		add_to_group("merchant")
		add_merchant_items()
	
	# Start facing business/wares
	rotation.y = atan2(business_facing_dir.x, business_facing_dir.z)
	set_state_business()

func init_npc_identity():
	var n = name.to_lower()
	if npc_name == "":
		if "bird" in n:
			npc_name = "Barnaby"
			npc_title = "Avian Scout"
			business_name = "Lookout & Horizon Watch"
			business_facing_dir = Vector3(0, 0, -1)
			return_to_business_barks = [
				"Nothing to say? Back to my lookout.",
				"Traveler has moved on. Eyes back on the skies.",
				"Suit yourself. Duty calls.",
				"Back to scanning the horizon."
			]
			business_barks = [
				"Clear skies to the north.",
				"Wind's picking up from the mountains.",
				"Keeping watch from my perch.",
				"Horizon looks clear today."
			]
		elif "reptilemonster2" in n or "merchant" in n:
			npc_name = "Vesh"
			npc_title = "Reptilian Merchant"
			business_name = "Tending Market Table & Wares"
			business_facing_dir = Vector3(0, 0, -1) # Faces North toward market table
			is_merchant = true
			return_to_business_barks = [
				"Just browsing, then? Back to my wares.",
				"No sale? Back to counting my coins.",
				"Suit yourself. Where was I? Ah, the ledger.",
				"Off they go... back to arranging the merchandise.",
				"Nothing to buy? Back to tending the stall."
			]
			business_barks = [
				"Checking the wares on the table... looking fine.",
				"Forty machine gun rounds, two rockets... good stock.",
				"Must keep the gold coins safe in my purse.",
				"Tallying the ledger... seventy-five gold, very good.",
				"Finest goods in the realm, if anyone's buying."
			]
		elif "reptile" in n:
			npc_name = "Grokk"
			npc_title = "Reptilian Townsman"
			business_name = "Perimeter Watch"
			business_facing_dir = Vector3(0, 0, -1) # Faces North toward perimeter wall
			return_to_business_barks = [
				"Nothing to report? Back to my post.",
				"Suit yourself, stranger. Minding my business.",
				"All clear on this side. Resuming watch.",
				"They've moved along. Back to duty."
			]
			business_barks = [
				"Perimeter secure. Quiet day.",
				"Brick walls look sturdy today.",
				"Watching the perimeter... all clear.",
				"No troublemakers around. Just how I like it."
			]
		else:
			npc_name = "Townsfolk"
			npc_title = "Citizen"
			business_name = "General Work"
			business_facing_dir = Vector3(0, 0, -1)
			return_to_business_barks = ["Back to business.", "Minding my own affairs."]
			business_barks = ["Another day, another chore."]

	# Initialize pocket contents with 3D placeholder items if empty
	if pockets.empty():
		if "bird" in n:
			pockets = [
				{"name": "Small Money Bag (50 Gold)", "type": "gold", "amount": 50, "desc": "50 Gold Coins", "placeholder_id": "money_bag"},
				{"name": "Small Tools & Scout Kit", "type": "tools", "amount": 40, "desc": "Miniature precision tools & lockpicks", "placeholder_id": "small_tools"},
				{"name": "Machine Gun Ammo Pouch (35)", "type": "ammo", "ammo_type": Pickup.PICKUP_TYPES.MACHINE_GUN_AMMO, "amount": 35, "desc": "35 MG Bullets", "placeholder_id": "ammo_pouch"},
				{"name": "Shiny Brass Pocket Watch", "type": "trinket", "amount": 55, "desc": "Antique heirloom worth 55 Gold", "placeholder_id": "trinket"}
			]
		elif "reptilemonster2" in n or "merchant" in n:
			pockets = [
				{"name": "Merchant's Small Money Bag (75 Gold)", "type": "gold", "amount": 75, "desc": "75 Shiny Gold Coins", "placeholder_id": "money_bag"},
				{"name": "Merchant's Small Tools & Scale", "type": "tools", "amount": 50, "desc": "Precision crafting tools & picks", "placeholder_id": "small_tools"},
				{"name": "Heavy Ammo Pouch (Rocket & Bullets)", "type": "ammo", "ammo_type": Pickup.PICKUP_TYPES.ROCKET_LAUNCHER_AMMO, "amount": 2, "desc": "2 High-Explosive Rockets", "placeholder_id": "ammo_pouch"},
				{"name": "Rare Cut Emerald", "type": "trinket", "amount": 100, "desc": "Precious Gem worth 100 Gold", "placeholder_id": "trinket"}
			]
		else:
			pockets = [
				{"name": "Townsman's Small Money Bag (40 Gold)", "type": "gold", "amount": 40, "desc": "40 Gold Coins", "placeholder_id": "money_bag"},
				{"name": "Set of Small Tools & Chisels", "type": "tools", "amount": 35, "desc": "Handy repair tools and lockpicks", "placeholder_id": "small_tools"},
				{"name": "Shotgun Shell Ammo Pouch (12)", "type": "ammo", "ammo_type": Pickup.PICKUP_TYPES.SHOTGUN_AMMO, "amount": 12, "desc": "12 Shotgun Shells", "placeholder_id": "ammo_pouch"},
				{"name": "Carved Bone Talisman", "type": "trinket", "amount": 45, "desc": "Tribal Trinket worth 45 Gold", "placeholder_id": "trinket"}
			]

func setup_item_placeholders():
	var parent_node = get_node_or_null("Graphics/Armature/Skeleton/Hip")
	if !parent_node:
		parent_node = $Graphics
		
	# Clear any old placeholders
	for ph in visual_placeholders:
		if is_instance_valid(ph.get("node", null)):
			ph.node.queue_free()
	visual_placeholders = []
	
	for item in pockets:
		var ph_id = item.get("placeholder_id", "money_bag")
		var ph_mesh = ItemMeshFactory.create_mesh(ph_id)
		if !ph_mesh:
			continue
			
		match ph_id:
			"money_bag":
				ph_mesh.translation = Vector3(0.38, -0.05, 0.05)
				ph_mesh.rotation_degrees = Vector3(0, 0, -10)
			"small_tools":
				ph_mesh.translation = Vector3(-0.38, -0.05, 0.05)
				ph_mesh.rotation_degrees = Vector3(0, 0, 10)
			"ammo_pouch":
				ph_mesh.translation = Vector3(0.0, -0.05, -0.38)
				ph_mesh.rotation_degrees = Vector3(0, 180, 0)
			"trinket":
				ph_mesh.translation = Vector3(0.28, -0.08, -0.22)
				ph_mesh.rotation_degrees = Vector3(0, 45, 0)
			_:
				ph_mesh.translation = Vector3(0.35, -0.05, 0.0)
				
		parent_node.add_child(ph_mesh)
		visual_placeholders.push_back({
			"item": item,
			"node": ph_mesh,
			"placeholder_id": ph_id
		})

func get_visible_items_summary() -> String:
	if visual_placeholders.empty():
		return "None"
	var names = []
	for ph in visual_placeholders:
		var ph_id = ph.get("placeholder_id", "")
		if ph_id == "money_bag":
			names.push_back("Money Bag")
		elif ph_id == "small_tools":
			names.push_back("Small Tools")
		elif ph_id == "ammo_pouch":
			names.push_back("Ammo Pouch")
		elif ph_id == "trinket":
			names.push_back("Trinket")
		else:
			names.push_back(ph.item.get("name", "Item"))
	return PoolStringArray(names).join(", ")

func init_overhead_ui():
	if ClassDB.class_exists("Label3D"):
		overhead_label = Label3D.new()
		overhead_label.name = "OverheadLabel"
		overhead_label.billboard = SpatialMaterial.BILLBOARD_ENABLED
		overhead_label.pixel_size = 0.008
		overhead_label.translation = Vector3(0, 2.3, 0)
		var font_res = load("res://ui/KleintenDynFont.tres")
		if font_res:
			overhead_label.font = font_res
		add_child(overhead_label)
		update_overhead_display()

func update_overhead_display():
	if !overhead_label:
		return
	if cur_state == STATES.DEAD:
		overhead_label.text = "[ " + npc_name + " - Deceased ]\n(Loot: " + str(pockets.size()) + " items left)"
		overhead_label.modulate = Color(0.6, 0.6, 0.6, 0.8)
		return
		
	if current_bark != "":
		overhead_label.text = npc_name + ": \"" + current_bark + "\""
		overhead_label.modulate = Color(1.0, 0.9, 0.3, 1.0)
	elif cur_state == STATES.ALERTED:
		overhead_label.text = "[ ! " + npc_name + " - ALERTED ! ]\n(Guarding Items!)"
		overhead_label.modulate = Color(1.0, 0.2, 0.2, 1.0)
	elif cur_state == STATES.PANIC:
		overhead_label.text = "[ ! " + npc_name + " - PANICKING ! ]"
		overhead_label.modulate = Color(1.0, 0.3, 0.3, 1.0)
	elif cur_state == STATES.SUSPICIOUS:
		overhead_label.text = "[ ? " + npc_name + " - Suspicious ? ]"
		overhead_label.modulate = Color(1.0, 0.8, 0.2, 1.0)
	elif cur_state == STATES.BUSINESS:
		overhead_label.text = "[ " + npc_name + " (" + business_name + ") ]"
		overhead_label.modulate = Color(0.6, 0.85, 0.7, 0.85)
	else:
		overhead_label.text = "[ " + npc_name + " (" + npc_title + ") ]"
		overhead_label.modulate = Color(0.7, 0.9, 1.0, 0.9)

func show_bark(text: String, duration: float = 3.5):
	current_bark = text
	bark_timer = duration
	update_overhead_display()

func _process(delta):
	if !player:
		var p_nodes = get_tree().get_nodes_in_group("player")
		if !p_nodes.empty():
			player = p_nodes[0]
			
	if bark_timer > 0:
		bark_timer -= delta
		if bark_timer <= 0:
			current_bark = ""
			update_overhead_display()

	# Update merchant steal penalty timer
	if steal_penalty_timer > 0:
		steal_penalty_timer -= delta

	if state_timer > 0:
		state_timer -= delta
		
	match cur_state:
		STATES.BUSINESS:
			process_state_business(delta)
		STATES.IDLE:
			process_state_idle(delta)
		STATES.WANDER:
			process_state_wander(delta)
		STATES.SUSPICIOUS:
			process_state_suspicious(delta)
		STATES.AWARE:
			process_state_aware(delta)
		STATES.ALERTED:
			process_state_alerted(delta)
		STATES.PANIC:
			process_state_panic(delta)
		STATES.DEAD:
			process_state_dead(delta)

# State setters
func set_state_business():
	cur_state = STATES.BUSINESS
	character_mover.set_speed_scale(stroll_speed_scale)
	anim_player.play("idle_loop")
	business_idle_timer = rand_range(6.0, 10.0)
	update_overhead_display()

func set_state_idle():
	cur_state = STATES.IDLE
	state_timer = rand_range(2.5, 4.5)
	character_mover.set_move_vec(Vector3.ZERO)
	anim_player.play("idle_loop")
	update_overhead_display()

func set_state_wander():
	cur_state = STATES.WANDER
	character_mover.set_speed_scale(stroll_speed_scale)
	anim_player.play("walk_loop", 0.3, 0.7)
	choose_wander_target()
	update_overhead_display()

func set_state_suspicious(noise_origin: Vector3):
	cur_state = STATES.SUSPICIOUS
	suspicious_target_pos = noise_origin
	state_timer = rand_range(3.0, 4.0)
	character_mover.set_move_vec(Vector3.ZERO)
	anim_player.play("idle_loop")
	var barks = [
		"Huh? What was that noise?",
		"Did I hear footsteps?",
		"Who's sneaking around?",
		"Thought I heard something..."
	]
	show_bark(barks[randi() % barks.size()], 3.0)

func set_state_aware():
	cur_state = STATES.AWARE
	character_mover.set_move_vec(Vector3.ZERO)
	anim_player.play("idle_loop")
	lose_interest_timer = 2.5
	idle_player_timer = 2.5
	if player:
		last_player_pos = player.global_transform.origin
		last_player_still_pos = player.global_transform.origin
		
	var barks = [
		"Greetings, traveler!",
		"Nice day for a walk.",
		"Good day to you.",
		"Can I help you with something?"
	]
	if "merchant" in npc_title.to_lower():
		barks = [
			"Welcome to my stall! Interested in some wares?",
			"Looking for ammunition or supplies, traveler?",
			"Best prices in the courtyard, take a look!"
		]
	show_bark(barks[randi() % barks.size()], 2.5)

func set_state_alerted():
	cur_state = STATES.ALERTED
	state_timer = 6.0
	character_mover.set_move_vec(Vector3.ZERO)
	anim_player.play("idle_loop")
	ignoring_idle_player = false
	var barks = [
		"THIEF! Keep your hands out of my pockets!",
		"Hey! What do you think you're doing?!",
		"Pickpocket! Back off!",
		"Hands off my valuables, scum!"
	]
	show_bark(barks[randi() % barks.size()], 3.5)

func set_state_panic():
	cur_state = STATES.PANIC
	state_timer = 4.0
	character_mover.set_speed_scale(flee_speed_scale)
	anim_player.play("walk_loop", 0.2, 1.3)
	ignoring_idle_player = false
	if player:
		flee_dir = (global_transform.origin - player.global_transform.origin).normalized()
		flee_dir.y = 0
	else:
		flee_dir = Vector3(rand_range(-1, 1), 0, rand_range(-1, 1)).normalized()
	var barks = [
		"Ouch! Don't hurt me!",
		"I'm unarmed! Mercy!",
		"Help! Murderer!",
		"Why are you attacking a peaceful citizen?!"
	]
	show_bark(barks[randi() % barks.size()], 3.5)

func set_state_dead():
	cur_state = STATES.DEAD
	anim_player.play("die")
	character_mover.freeze()
	$CollisionShape.disabled = true
	update_overhead_display()

# Lose interest and return to business routine
func lose_interest_and_resume_business(_moved_away: bool):
	if !return_to_business_barks.empty():
		show_bark(return_to_business_barks[randi() % return_to_business_barks.size()], 3.0)
	set_state_business()

# State Processors
func process_state_business(delta):
	# Check if we need to walk back to our home workstation/post
	var dist_to_home = global_transform.origin.distance_to(home_pos)
	if dist_to_home > 1.8:
		var dir = (home_pos - global_transform.origin).normalized()
		dir.y = 0
		character_mover.set_move_vec(dir)
		face_dir(dir, delta)
	else:
		# Standing at business post / table
		character_mover.set_move_vec(Vector3.ZERO)
		face_dir(business_facing_dir, delta) # Turn to face wares/post
		
		# Periodic ambient business barks
		business_idle_timer -= delta
		if business_idle_timer <= 0:
			business_idle_timer = rand_range(8.0, 14.0)
			if !business_barks.empty() and randf() < 0.6:
				show_bark(business_barks[randi() % business_barks.size()], 3.0)

	# Check noise detection
	if check_noise_detection():
		ignoring_idle_player = false
		return
		
	# Player interaction checks while minding business
	if player:
		var dist_to_player = global_transform.origin.distance_to(player.global_transform.origin)
		
		if ignoring_idle_player:
			# Player stood still earlier, so we ignore them while minding our business
			# Unless they invade personal space (get in our face)
			if dist_to_player < IN_FACE_DIST:
				ignoring_idle_player = false
				show_bark("A bit close there! Give a fellow some breathing room.", 2.5)
				set_state_aware()
				return
			# If player moves far away, reset ignoring flag
			if dist_to_player > 6.0:
				ignoring_idle_player = false
		else:
			# If player is in front and within aware range
			if can_see_player() and dist_to_player <= AWARE_MAX_DIST:
				set_state_aware()
				return

func process_state_aware(delta):
	if !player:
		set_state_business()
		return
		
	var dist = global_transform.origin.distance_to(player.global_transform.origin)
	
	# Face the player while attentive
	var dir = player.global_transform.origin - global_transform.origin
	dir.y = 0
	face_dir(dir.normalized(), delta)
	
	# CONDITION 1: Player gets farther away or is not detected
	var player_far_or_hidden = dist > AWARE_MAX_DIST or !can_see_player()
	if player_far_or_hidden:
		lose_interest_timer -= delta
		if lose_interest_timer <= 0.0:
			# Lost interest because player moved away / sneaked away!
			ignoring_idle_player = false
			lose_interest_and_resume_business(true)
			return
	else:
		lose_interest_timer = 2.5 # Reset timer while player is in range and seen
		
	# CONDITION 2: Player stands still nearby and doesn't interact or get in face
	if dist < IN_FACE_DIST:
		# Player is getting right in NPC's face!
		idle_player_timer = 2.0 # Keep watching while in personal space
	else:
		# Player is at normal distance (1.6m to 4.5m)
		# Check if player is standing still
		var player_speed = 0.0
		if player.character_mover:
			player_speed = player.character_mover.velocity.length()
		var player_moved = player.global_transform.origin.distance_to(last_player_pos)
		last_player_pos = player.global_transform.origin
		
		var is_standing_still = player_speed < 0.6 and (player_moved / max(delta, 0.001)) < 0.8
		if is_standing_still:
			idle_player_timer -= delta
			if idle_player_timer <= 0.0:
				# Player has been standing still without interacting!
				# Lose interest and get back to business!
				last_player_still_pos = player.global_transform.origin
				ignoring_idle_player = true
				lose_interest_and_resume_business(false)
				return
		else:
			idle_player_timer = 2.5

func process_state_idle(_delta):
	if check_noise_detection():
		return
		
	if player and !ignoring_idle_player and can_see_player():
		set_state_aware()
		return
		
	# Return to business after brief idle
	if state_timer <= 0:
		set_state_business()

func process_state_wander(delta):
	if check_noise_detection():
		return
		
	if player and !ignoring_idle_player and can_see_player():
		set_state_aware()
		return
		
	if path.size() > 0 and path_ind < path.size():
		var goal_pos = path[path_ind]
		var our_pos = global_transform.origin
		var dir = goal_pos - our_pos
		dir.y = 0
		if dir.length() < 1.0:
			path_ind += 1
			if path_ind >= path.size():
				set_state_business()
				return
		else:
			var move_dir = dir.normalized()
			character_mover.set_move_vec(move_dir)
			face_dir(move_dir, delta)
	else:
		set_state_business()

func process_state_suspicious(delta):
	# Turn toward noise
	if suspicious_target_pos != Vector3.ZERO:
		var dir = suspicious_target_pos - global_transform.origin
		dir.y = 0
		if dir.length() > 0.1:
			face_dir(dir.normalized(), delta)
			
	# If player seen while suspicious
	if can_see_player():
		set_state_aware()
		return
		
	if state_timer <= 0:
		show_bark("Must have been my imagination. Back to business.", 2.5)
		set_state_business()

func process_state_alerted(delta):
	if player:
		var dir = player.global_transform.origin - global_transform.origin
		dir.y = 0
		face_dir(dir.normalized(), delta)
		
	if state_timer <= 0:
		show_bark("Keep your hands to yourself... back to my business.", 2.5)
		ignoring_idle_player = false
		set_state_business()

func process_state_panic(delta):
	if flee_dir != Vector3.ZERO:
		character_mover.set_move_vec(flee_dir)
		face_dir(flee_dir, delta)
		
	if state_timer <= 0:
		set_state_alerted()

func process_state_dead(_delta):
	pass

# Navigation helper
func choose_wander_target():
	var offset = Vector3(rand_range(-wander_radius, wander_radius), 0, rand_range(-wander_radius, wander_radius))
	var target = home_pos + offset
	if nav:
		var closest = nav.get_closest_point(target)
		path = nav.get_simple_path(global_transform.origin, closest)
		path_ind = 0
	else:
		path = []
		path_ind = 0

# Detection & Sensory
func check_noise_detection() -> bool:
	if !player:
		return false
	var noise_rad = 0.0
	if player.has_method("get_noise_radius"):
		noise_rad = player.get_noise_radius()
	if noise_rad > 0.0:
		var dist = global_transform.origin.distance_to(player.global_transform.origin)
		if dist <= noise_rad:
			set_state_suspicious(player.global_transform.origin)
			return true
	return false

func can_see_player() -> bool:
	if !player or cur_state == STATES.DEAD:
		return false
	var dist = global_transform.origin.distance_to(player.global_transform.origin)
	var max_dist = sight_distance
	if player.has_method("is_sneaking") and player.is_sneaking():
		max_dist = sneak_sight_distance
		
	if dist > max_dist:
		return false
	return player_within_angle(sight_angle) and has_los_player()

func player_within_angle(angle: float) -> bool:
	if !player:
		return false
	var dir_to_player = global_transform.origin.direction_to(player.global_transform.origin)
	var forwards = global_transform.basis.z
	return rad2deg(forwards.angle_to(dir_to_player)) < angle

func is_player_behind() -> bool:
	if !player:
		return false
	var dir_to_player = global_transform.origin.direction_to(player.global_transform.origin)
	var forwards = global_transform.basis.z
	return rad2deg(forwards.angle_to(dir_to_player)) > 75.0

func has_los_player() -> bool:
	if !player:
		return false
	var our_pos = global_transform.origin + Vector3.UP * 1.2
	var player_pos = player.global_transform.origin + Vector3.UP * 1.2
	var space_state = get_world().get_direct_space_state()
	var result = space_state.intersect_ray(our_pos, player_pos, [self], 1)
	return result.empty()

func face_dir(dir: Vector3, delta):
	if dir.length_squared() < 0.001:
		return
	var angle_diff = global_transform.basis.z.angle_to(dir)
	var turn_right = sign(global_transform.basis.x.dot(dir))
	if abs(angle_diff) < deg2rad(turn_speed) * delta:
		rotation.y = atan2(dir.x, dir.z)
	else:
		rotation.y += deg2rad(turn_speed) * delta * turn_right

# Hurt & Combat Reactions (Peaceful NPC: NEVER attacks back!)
func hurt(damage: int, dir: Vector3):
	health_manager.hurt(damage, dir)
	if cur_state != STATES.DEAD:
		set_state_panic()

func alert(check_los = true):
	if cur_state == STATES.DEAD or cur_state == STATES.ALERTED or cur_state == STATES.PANIC:
		return
	if check_los and !has_los_player():
		return
	set_state_suspicious(player.global_transform.origin if player else global_transform.origin)
	show_bark("Gunfire! Who's shooting?!", 3.0)

# Pickpocketing & Social API
func get_pocket_count() -> int:
	return pockets.size()

func is_alerted() -> bool:
	return cur_state == STATES.ALERTED or cur_state == STATES.PANIC

func is_dead() -> bool:
	return cur_state == STATES.DEAD

func perform_pickpocket(_player_node, specific_item = null) -> Dictionary:
	if pockets.empty():
		return {}
	var item = null
	if specific_item != null:
		var found_idx = pockets.find(specific_item)
		if found_idx != -1:
			item = pockets[found_idx]
			pockets.remove(found_idx)
	if item == null:
		item = pockets.pop_front()
	
	# Find and detach visual placeholder from NPC's body
	var start_pos = global_transform.origin + Vector3.UP * 1.0
	for i in range(visual_placeholders.size()):
		if visual_placeholders[i].item == item:
			var ph_node = visual_placeholders[i].node
			if is_instance_valid(ph_node):
				start_pos = ph_node.global_transform.origin
				ItemMeshFactory.apply_highlight(ph_node, ItemMeshFactory.HIGHLIGHT_NONE)
				ph_node.visible = false
				ph_node.queue_free()
			visual_placeholders.remove(i)
			break
			
	item["start_pos"] = start_pos
	update_overhead_display()
	
	# Oblivious murmurs on successful theft if alive
	if cur_state != STATES.DEAD:
		var murmurs = [
			"Felt a light breeze on my belt...",
			"Did my pocket just feel lighter?",
			"Must have dropped something... or did I?",
			"Hmm? Felt like something shifted."
		]
		show_bark(murmurs[randi() % murmurs.size()], 2.5)
	return item

func catch_pickpocket(player_node):
	ignoring_idle_player = false
	if player_node:
		var dir = (player_node.global_transform.origin - global_transform.origin).normalized()
		dir.y = 0
		rotation.y = atan2(dir.x, dir.z)
	set_state_alerted()
	
	# Apply merchant penalty if this is a merchant
	if is_merchant:
		steal_penalty_timer = PENALTY_DURATION
		if player_node.has_method("show_banner"):
			player_node.show_banner("CAUGHT! " + npc_name + " refuses to trade with you for " + str(int(PENALTY_DURATION)) + " seconds!", Color(1, 0.3, 0.3, 1), 4.0)
	
	var caught_barks = [
		"THIEF! Keep your hands out of my pockets!",
		"Are you trying to rob me to my face?! Get your hands back!",
		"Pickpocket! Guards! Back off!",
		"Hands off my valuables, scum!"
	]
	show_bark(caught_barks[randi() % caught_barks.size()], 4.0)

func catch_fumbled_item(player_node):
	ignoring_idle_player = false
	if player_node:
		var dir = (player_node.global_transform.origin - global_transform.origin).normalized()
		dir.y = 0
		rotation.y = atan2(dir.x, dir.z)
	set_state_alerted()
	
	# Apply merchant penalty if this is a merchant
	if is_merchant:
		steal_penalty_timer = PENALTY_DURATION
		if player_node.has_method("show_banner"):
			player_node.show_banner("FUMBLED! " + npc_name + " refuses to trade with you for " + str(int(PENALTY_DURATION)) + " seconds!", Color(1, 0.3, 0.3, 1), 4.0)
	
	var lines = [
		"CLATTER! What dropped?! Hey, that's my pouch! You thief!",
		"CLINK! Did you just drop my valuables?! Back off, thief!",
		"Hey! What was that noise?! My belt feels empty! Pickpocket!",
		"Stop right there! You fumbled my belongings on the floor!"
	]
	show_bark(lines[randi() % lines.size()], 4.0)

func catch_pickpocket_immediate(player_node):
	ignoring_idle_player = false
	if player_node:
		var dir = (player_node.global_transform.origin - global_transform.origin).normalized()
		dir.y = 0
		rotation.y = atan2(dir.x, dir.z)
	set_state_alerted()
	
	# Apply merchant penalty if this is a merchant
	if is_merchant:
		steal_penalty_timer = PENALTY_DURATION
		if player_node.has_method("show_banner"):
			player_node.show_banner("CAUGHT! " + npc_name + " refuses to trade with you for " + str(int(PENALTY_DURATION)) + " seconds!", Color(1, 0.3, 0.3, 1), 4.0)
	var lines = [
		"Hey! Keep your greasy fingers off my belt!",
		"Hands off! Did you think I wouldn't feel that?!",
		"THIEF! Caught you red-handed trying to pick my pockets!",
		"Sneaking hands! Back away from my belongings!"
	]
	show_bark(lines[randi() % lines.size()], 4.0)

# Called when player presses [E] to interact (even when undetected, which detects player!)
func interact_and_detect(player_node):
	ignoring_idle_player = false
	idle_player_timer = 3.5
	lose_interest_timer = 3.5
	
	var was_behind = is_player_behind()
	
	if player_node:
		var dir = (player_node.global_transform.origin - global_transform.origin).normalized()
		dir.y = 0
		rotation.y = atan2(dir.x, dir.z)
		
	if cur_state == STATES.ALERTED:
		show_bark("Keep away from me, thief! I'm watching you!", 3.0)
		return
		
	set_state_aware()
	
	if was_behind:
		# Player tapped shoulder while undetected from behind!
		var startled_barks = [
			"Whoa! Don't sneak up behind me like that! You startled me!",
			"Gah! Don't creep up behind people! State your business!",
			"Halt! Don't lurk in my blind spot, traveler! What do you want?",
			"Yikes! Make some noise next time! Almost had a heart attack!"
		]
		if "bird" in name.to_lower():
			startled_barks = [
				"Whoa! Don't sneak up behind me! You startled my feathers!",
				"Squawk! Lurking in my blind spot? What do you want, traveler?"
			]
		elif "merchant" in npc_title.to_lower():
			startled_barks = [
				"Gah! Don't creep up behind a merchant! State your business!",
				"Whoa there! Don't sneak up on someone counting coins! Looking to buy?"
			]
		show_bark(startled_barks[randi() % startled_barks.size()], 3.5)
	else:
		# Normal front conversation
		var friendly_lines = [
			"Greetings, traveler! Enjoying the retro world?",
			"Keep your hands where I can see them...",
			"Nice weather for a stroll, isn't it?",
			"I'm just an innocent bystander, don't mind me.",
			"I hear someone's been stealing around here...",
			"Have you seen the shed? Fine craftsmanship."
		]
		if "merchant" in npc_title.to_lower():
			friendly_lines = [
				"Welcome to my stall! Fresh ammo and supplies on the table.",
				"Everything you see on the table is for sale!",
				"Looking for rockets or ammunition? I've got you covered.",
				"No touching the merchandise without paying!"
			]
		show_bark(friendly_lines[randi() % friendly_lines.size()], 3.5)

func talk_to(player_node):
	interact_and_detect(player_node)

# =====================================================================
# MERCHANT FUNCTIONALITY - For Vesh the Reptilian Merchant
# =====================================================================

func add_merchant_items():
	# Add valuable items that can be stolen from merchant
	pockets = [
		{"name": "Merchant's Gold Pouch", "desc": "Heavy pouch of gold coins", "type": "gold", "amount": 100, "placeholder_id": "money_bag"},
		{"name": "Rare Gemstone", "desc": "Precious jewel", "type": "trinket", "amount": 75, "placeholder_id": "trinket"},
		{"name": "Master Lockpick Set", "desc": "Professional lockpicks", "type": "tools", "amount": 60, "placeholder_id": "tools"},
	]

func can_trade_with(player) -> bool:
	# Check if player can trade with merchant
	if steal_penalty_timer > 0:
		# Check if player went far away (resets penalty)
		var distance = player.global_transform.origin.distance_to(global_transform.origin)
		if distance > PENALTY_RESET_DISTANCE:
			steal_penalty_timer = 0
			return true
		return false
	return true

func get_penalty_time_remaining() -> float:
	return steal_penalty_timer

func get_interaction_prompt() -> String:
	if steal_penalty_timer > 0:
		return "[E] Merchant (Angry - " + str(ceil(steal_penalty_timer)) + "s)"
	return "[E] Trade with " + npc_name
