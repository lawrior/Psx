extends Node

# =====================================================================
# INVENTORY MANAGEMENT SYSTEM
# Tracks all collected items, ingredients, consumables, and valuables
# =====================================================================

enum CATEGORY { ALL, VALUABLES, TOOLS, INGREDIENTS, CONSUMABLES, AMMO }

var items = {
	"gold": {"name": "Gold Coins", "category": CATEGORY.VALUABLES, "quantity": 0, "desc": "Shiny gold coins for trading", "icon_color": Color(1.0, 0.85, 0.2)},
	"trinkets": {"name": "Valuable Trinkets", "category": CATEGORY.VALUABLES, "quantity": 0, "desc": "Ornate medallions and pocket watches", "icon_color": Color(0.9, 0.7, 0.3)},
	"tools": {"name": "Tools & Lockpicks", "category": CATEGORY.TOOLS, "quantity": 0, "desc": "Useful for picking locks and repairs", "icon_color": Color(0.6, 0.6, 0.65)},
	
	# Ingredients
	"apple": {"name": "Crisp Apple", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Fresh orchard apple", "icon_color": Color(0.85, 0.2, 0.15)},
	"plum": {"name": "Sugar Plum", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Sweet purple plum", "icon_color": Color(0.5, 0.2, 0.6)},
	"pear": {"name": "Sweet Pear", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Golden-green pear", "icon_color": Color(0.7, 0.8, 0.3)},
	"poppy": {"name": "Crimson Poppy", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Vibrant red wildflower", "icon_color": Color(0.9, 0.15, 0.2)},
	"orchid": {"name": "Violet Orchid", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Mystical purple blossom", "icon_color": Color(0.6, 0.3, 0.8)},
	"marigold": {"name": "Sun Marigold", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Radiant golden flower", "icon_color": Color(1.0, 0.75, 0.2)},
	"lily": {"name": "Frost Lily", "category": CATEGORY.INGREDIENTS, "quantity": 0, "desc": "Ice-blue crystalline flower", "icon_color": Color(0.5, 0.8, 0.95)},
	
	# Consumables (from cauldron)
	"vitality_elixir": {"name": "Vitality Elixir", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "Restores +65 HP, increases Max HP", "icon_color": Color(0.9, 0.3, 0.4), "usable": true},
	"haste_elixir": {"name": "Sunfire Elixir", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "+40% speed for 30s", "icon_color": Color(1.0, 0.8, 0.2), "usable": true},
	"shadow_draught": {"name": "Shadow Veil", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "Silent footsteps for 35s", "icon_color": Color(0.4, 0.2, 0.6), "usable": true},
	"frost_draught": {"name": "Moonlit Frost", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "+80 Gold, +50 HP, +15 Max HP", "icon_color": Color(0.4, 0.7, 0.95), "usable": true},
	"compote": {"name": "Orchard Compote", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "Restores +35 HP, +75 Gold", "icon_color": Color(0.95, 0.6, 0.3), "usable": true},
	"ambrosia_stew": {"name": "Grand Ambrosia", "category": CATEGORY.CONSUMABLES, "quantity": 0, "desc": "+100 HP, +30 Max HP, +150 Gold, Haste + Shadow!", "icon_color": Color(0.95, 0.85, 0.4), "usable": true},
	
	# Ammo
	"machinegun_ammo": {"name": "Machine Gun Ammo", "category": CATEGORY.AMMO, "quantity": 0, "desc": "7.62mm cartridges", "icon_color": Color(0.7, 0.65, 0.3)},
	"shotgun_ammo": {"name": "Shotgun Shells", "category": CATEGORY.AMMO, "quantity": 0, "desc": "12-gauge buckshot", "icon_color": Color(0.8, 0.3, 0.2)},
	"rocket_ammo": {"name": "Rockets", "category": CATEGORY.AMMO, "quantity": 0, "desc": "High-explosive rockets", "icon_color": Color(0.6, 0.6, 0.6)},
}

var selected_category = CATEGORY.ALL
var selected_item_key = ""

signal inventory_changed
signal item_used(item_key)

func _ready():
	# Initialize gold from player
	pass

func add_item(item_key: String, amount: int = 1):
	if item_key in items:
		items[item_key].quantity += amount
		emit_signal("inventory_changed")
		return true
	return false

func remove_item(item_key: String, amount: int = 1) -> bool:
	if item_key in items and items[item_key].quantity >= amount:
		items[item_key].quantity -= amount
		emit_signal("inventory_changed")
		return true
	return false

func get_quantity(item_key: String) -> int:
	if item_key in items:
		return items[item_key].quantity
	return 0

func get_items_by_category(category: int) -> Array:
	var result = []
	for key in items:
		var item = items[key]
		if category == CATEGORY.ALL or item.category == category:
			if item.quantity > 0:  # Only show items we have
				result.append({"key": key, "data": item})
	return result

func get_total_items() -> int:
	var total = 0
	for key in items:
		total += items[key].quantity
	return total

func get_category_name(category: int) -> String:
	match category:
		CATEGORY.ALL: return "All Items"
		CATEGORY.VALUABLES: return "Valuables"
		CATEGORY.TOOLS: return "Tools"
		CATEGORY.INGREDIENTS: return "Ingredients"
		CATEGORY.CONSUMABLES: return "Consumables"
		CATEGORY.AMMO: return "Ammo"
	return "Unknown"

func use_item(item_key: String) -> bool:
	if item_key in items and items[item_key].quantity > 0:
		if items[item_key].get("usable", false):
			remove_item(item_key, 1)
			emit_signal("item_used", item_key)
			return true
	return false

func is_usable(item_key: String) -> bool:
	if item_key in items:
		return items[item_key].get("usable", false) and items[item_key].quantity > 0
	return false

# Sync with player's existing tracking
func sync_from_player(player):
	if !player:
		return
	
	# Gold
	items["gold"].quantity = player.gold
	
	# Tools
	items["tools"].quantity = player.tools_inventory.size()
	
	# Trinkets
	items["trinkets"].quantity = player.trinkets.size()
	
	# Ingredients from pantry
	for ing in player.picked_ingredients:
		var ing_name = ing.get("name", "").to_lower()
		if "apple" in ing_name:
			add_item("apple", 1)
		elif "plum" in ing_name:
			add_item("plum", 1)
		elif "pear" in ing_name:
			add_item("pear", 1)
		elif "poppy" in ing_name:
			add_item("poppy", 1)
		elif "orchid" in ing_name:
			add_item("orchid", 1)
		elif "marigold" in ing_name:
			add_item("marigold", 1)
		elif "lily" in ing_name:
			add_item("lily", 1)

func get_item_quantity(item_key: String) -> int:
	return get_quantity(item_key)

func get_all_items() -> Dictionary:
	var result = {}
	for key in items:
		if items[key].quantity > 0:
			result[key] = items[key]
	return result
