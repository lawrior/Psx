extends Area
class_name DroppedLootItem

const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")

var item_data : Dictionary = {}
var velocity : Vector3 = Vector3.ZERO
var fall_gravity : float = 16.0
var on_ground : bool = false
var floor_y : float = 0.0
var bob_timer : float = 0.0
var base_y : float = 0.0
var mesh_node : Spatial = null

func setup(p_pos: Vector3, p_item: Dictionary):
	global_transform.origin = p_pos
	item_data = p_item
	
	# Raycast downward to find floor level
	var space_state = get_world().get_direct_space_state()
	var ray = space_state.intersect_ray(p_pos, p_pos + Vector3.DOWN * 8.0, [self], 1)
	if !ray.empty():
		floor_y = ray.position.y + 0.15
	else:
		floor_y = max(p_pos.y - 1.0, 0.15)
		
	# Initial tumble velocity
	velocity = Vector3(rand_range(-0.4, 0.4), 0.6, rand_range(-0.4, 0.4))
	
	# Spawn 3D mesh
	var ph_id = p_item.get("placeholder_id", "money_bag")
	mesh_node = ItemMeshFactory.create_mesh(ph_id)
	if mesh_node:
		add_child(mesh_node)
		set_highlight(ItemMeshFactory.HIGHLIGHT_CLOSE)
		
	# Collision shape for pickup detection
	var col = CollisionShape.new()
	var sphere = SphereShape.new()
	sphere.radius = 0.75
	col.shape = sphere
	add_child(col)
	
	add_to_group("dropped_loot")
	connect("body_entered", self, "on_body_entered")
	connect("area_entered", self, "on_area_entered")

func _physics_process(delta):
	if !on_ground:
		velocity.y -= fall_gravity * delta
		translation += velocity * delta
		rotate_x(deg2rad(180.0) * delta)
		rotate_z(deg2rad(140.0) * delta)
		if translation.y <= floor_y:
			translation.y = floor_y
			base_y = floor_y
			on_ground = true
			velocity = Vector3.ZERO
			rotation_degrees = Vector3(0, rand_range(0, 360), 0)
	else:
		# Floating bob and spin on ground
		bob_timer += delta * 2.5
		translation.y = base_y + sin(bob_timer) * 0.03
		rotate_y(deg2rad(50.0) * delta)

func set_highlight(mode: int):
	if is_instance_valid(mesh_node):
		ItemMeshFactory.apply_highlight(mesh_node, mode)

func get_item_name() -> String:
	return item_data.get("name", "Item")

func on_body_entered(body):
	if body.is_in_group("player"):
		collect(body)

func on_area_entered(area):
	var parent = area.get_parent()
	if parent and parent.is_in_group("player"):
		collect(parent)

func collect(player_node):
	if !is_instance_valid(player_node):
		return
	set_highlight(ItemMeshFactory.HIGHLIGHT_NONE)
	if player_node.has_method("apply_stolen_item"):
		player_node.apply_stolen_item(item_data, "Dropped Loot")
		if "stolen_items_count" in player_node:
			player_node.stolen_items_count += 1
		player_node.show_banner("★ RETRIEVED: Picked up dropped " + item_data.get("name", "Item") + "!", Color(0.3, 1.0, 0.5, 1.0))
		if player_node.pickup_info:
			player_node.pickup_info.add_custom_info("Retrieved dropped " + item_data.get("name", "Item") + " from the ground")
	queue_free()
