extends Reference

# =====================================================================
# CHARACTER ANIMATOR
# =====================================================================
# Drives the girl_with_all_animations.glb AnimationPlayer.
#
# WHY THIS FILE EXISTS
# The old code in Player.gd asked for animations called
#     "walk", "run", "jump", "dead", "sneak_walk", "sneak_idle"
# None of those exist in the GLB. The real clip names are
#     idle, Walk_Female, Run_Female, Walk_Stealth, Crouch_Idle,
#     Crouch_Walk, Walk_Backwards, Strafe_left, Strafe_right,
#     Jump_Start, Jump_air, Jump_Land, Death_A ...
# so every lookup failed, the code fell back to "idle", and because the
# fallback equalled the current animation the guard
# `if target_animation != current_animation` never fired again:
# the character stood frozen even while running.
#
# On top of that, every glTF clip imports with loop = false, so even idle
# played once for two seconds and then stopped dead.
#
# This class fixes both: correct clip table + looping flags + a real state
# machine with cross-fades and playback-speed sync (no foot skating).
# =====================================================================

# ---- Clip table: logical state -> candidate clip names, best first ----
const CLIPS = {
	"idle":        ["idle", "Idle_Subtle", "Idle_Listening"],
	"walk":        ["Walk_Female", "Walk_Carry", "Run_Female"],
	"run":         ["Run_Female", "Walk_Female"],
	"walk_back":   ["Walk_Backwards", "Walk_Female"],
	"strafe_left": ["Strafe_left", "Walk_Female"],
	"strafe_right":["Strafe_right", "Walk_Female"],
	"sneak_idle":  ["Crouch_Idle", "Walk_Stealth", "idle"],
	"sneak_walk":  ["Walk_Stealth", "Crouch_Walk", "Walk_Female"],
	"crouch_walk": ["Crouch_Walk", "Walk_Stealth", "Walk_Female"],
	"air":         ["Jump_air", "idle"],
	"jump_start":  ["Jump_Start", "Jump_air", "idle"],
	"land":        ["Jump_Land", "idle"],
	"dead":        ["Death_A", "LayToIdle", "idle"],

	# Attacks. The GLB has no sword swing, but it does have Chop_Tree - a
	# real two-handed overhead chop that reads perfectly for a machete.
	# Guns fall back to the spell cast, which is a decent shooting pose.
	"attack_melee":  ["Chop_Tree", "Farm_Harvest", "Spell_Simple_Shoot"],
	"attack_ranged": ["Spell_Simple_Shoot", "Spell_Simple_Enter"],
}

# Clips that must loop, and clips that are one-shots.
const LOOPING = ["idle", "Idle_Subtle", "Idle_Listening", "Idle_Talking", "Idle_Torch",
	"Walk_Female", "Run_Female", "Walk_Stealth", "Crouch_Idle", "Crouch_Walk",
	"Walk_Backwards", "Strafe_left", "Strafe_right", "Walk_Carry", "Ladder_Idle",
	"Spell_Simple_Idle", "Sitting_Idle", "Sitting_Talking", "Idle_Talking"]

# Bones whose translation carries "root motion" baked into the clip. A
# capsule-driven character must not be dragged around by its own animation,
# so horizontal drift on these bones is flattened out.
const ROOT_BONES = ["girl_bone_root_1", "girl_bone_hips_2", "_root_joint"]

# ---- Tunables ----
var walk_speed_ref : float = 2.6    # speed at which the walk clip plays 1:1
var run_speed_ref : float = 6.2     # speed at which the run clip plays 1:1
var idle_speed_threshold : float = 0.35
var run_speed_threshold : float = 3.6
var land_recovery_time : float = 0.42

# The attack clips are authored as full actions (Chop_Tree is a whole
# tree-chopping loop), so only the swing portion is used for an attack.
export var melee_attack_trim : float = 0.62
export var ranged_attack_trim : float = 0.45
export var ranged_attacks_enabled : bool = true

var ap : AnimationPlayer = null
var state : String = ""
var current_clip : String = ""
var _one_shot : String = ""
var _one_shot_time : float = 0.0
var _was_on_floor : bool = true
var _dead : bool = false
var _setup_done : bool = false
var available : Dictionary = {}

# ---------------------------------------------------------------------
func setup(animation_player : AnimationPlayer) -> bool:
	ap = animation_player
	if !ap:
		return false
	for key in CLIPS.keys():
		var found = ""
		for cand in CLIPS[key]:
			if ap.has_animation(cand):
				found = cand
				break
		available[key] = found
	_fix_loop_flags()
	_neutralise_root_motion()
	_setup_done = true
	state = ""
	return true

func _fix_loop_flags():
	for clip in LOOPING:
		if ap.has_animation(clip):
			var a = ap.get_animation(clip)
			if a:
				a.loop = true

func _neutralise_root_motion():
	# Walk/Run/Jump/Death clips carry baked hip translation. Keep the
	# vertical bounce (that is the animation), drop the horizontal travel.
	for clip in ap.get_animation_list():
		var a = ap.get_animation(clip)
		if !a:
			continue
		for t in range(a.get_track_count()):
			if a.track_get_type(t) != Animation.TYPE_TRANSFORM:
				continue
			if a.track_get_key_count(t) < 2:
				continue
			var path = str(a.track_get_path(t))
			var is_root = false
			for rb in ROOT_BONES:
				if path.ends_with(":" + rb):
					is_root = true
					break
			if !is_root:
				continue
			var keys = a.track_get_key_count(t)
			var first = a.track_get_key_value(t, 0)
			var first_loc = first["location"]
			for k in range(keys):
				var v = a.track_get_key_value(t, k)
				var loc = v["location"]
				if abs(loc.x - first_loc.x) < 0.0001 and abs(loc.z - first_loc.z) < 0.0001:
					continue
				v["location"] = Vector3(first_loc.x, loc.y, first_loc.z)
				a.track_set_key_value(t, k, v)

# ---------------------------------------------------------------------
# PUBLIC API
# ---------------------------------------------------------------------
func has(key : String) -> bool:
	return available.get(key, "") != ""

func clip_for(key : String) -> String:
	return available.get(key, "")

func set_dead(value : bool):
	if value and !_dead:
		_dead = true
		_play_clip(available.get("dead", "idle"), 0.15, 1.0)
	elif !value and _dead:
		_dead = false
		state = ""

# Called when the active weapon actually fires/swings.
func play_attack(melee : bool, blend : float = 0.08, speed : float = 1.0) -> bool:
	if !_setup_done or _dead:
		return false
	if !melee and !ranged_attacks_enabled:
		return false
	var key = "attack_melee" if melee else "attack_ranged"
	var clip = available.get(key, "")
	if clip == "":
		return false
	_one_shot = clip
	var trim = melee_attack_trim if melee else ranged_attack_trim
	var nat_len = ap.get_animation(clip).length / max(speed, 0.01)
	_one_shot_time = min(trim, nat_len)
	# Restart even if this exact clip is already running (rapid swings).
	if clip == current_clip:
		ap.stop()
		current_clip = ""
	_play_clip(clip, blend, speed)
	return true

func is_attacking() -> bool:
	return _one_shot_time > 0.0

func play_one_shot(key : String, blend : float = 0.12, speed : float = 1.0):
	var clip = available.get(key, "")
	if clip == "":
		return
	_one_shot = clip
	_one_shot_time = ap.get_animation(clip).length / max(speed, 0.01)
	_play_clip(clip, blend, speed)

func _play_clip(clip : String, blend : float, speed : float):
	if clip == "":
		return
	if clip == current_clip and !ap.is_playing():
		ap.play(clip, blend, speed) # was stopped, restart it
		return
	if clip == current_clip:
		ap.playback_speed = speed
		return
	ap.play(clip, blend, speed)
	current_clip = clip

# ---------------------------------------------------------------------
# MAIN UPDATE
# ---------------------------------------------------------------------
# ctx keys: speed, on_floor, sneaking, backward, strafe (-1/0/1), running
func update(delta : float, ctx : Dictionary):
	if !_setup_done:
		return
	if _dead:
		return

	if _one_shot_time > 0.0:
		_one_shot_time -= delta
		if _one_shot_time > 0.0:
			return
		_one_shot_time = 0.0
		_one_shot = ""

	var on_floor = ctx.get("on_floor", true)
	var speed = ctx.get("speed", 0.0)
	var sneaking = ctx.get("sneaking", false)
	var backward = ctx.get("backward", false)
	var strafe = ctx.get("strafe", 0)
	var running = ctx.get("running", false)

	# Take-off / landing events
	if _was_on_floor and !on_floor:
		play_one_shot("jump_start", 0.08, 1.6)
		if _one_shot_time > 0.35:
			_one_shot_time = 0.35   # Jump_Start is a long clip; only the launch
		_was_on_floor = false
		return
	elif !_was_on_floor and on_floor:
		play_one_shot("land", 0.08, 1.5)
		_one_shot_time = min(land_recovery_time, _one_shot_time)
		_was_on_floor = true
		return

	var new_state = ""
	if !on_floor:
		new_state = "air"
	elif speed <= idle_speed_threshold:
		new_state = "sneak_idle" if sneaking else "idle"
	elif sneaking:
		new_state = "sneak_walk" if speed < 4.0 else "crouch_walk"
	elif backward:
		new_state = "walk_back"
	elif strafe != 0 and speed < run_speed_threshold * 0.75:
		new_state = "strafe_left" if strafe < 0 else "strafe_right"
	elif running or speed > run_speed_threshold:
		new_state = "run"
	else:
		new_state = "walk"

	state = new_state
	var clip = available.get(new_state, "")
	if clip == "":
		return

	var blend = 0.18
	if new_state == "run" or new_state == "walk":
		blend = 0.22
	elif new_state == "idle":
		blend = 0.25

	# Keep the feet planted: play the locomotion clip faster with speed.
	var spd = 1.0
	if new_state == "walk":
		spd = clamp(speed / max(walk_speed_ref, 0.1), 0.65, 1.5)
	elif new_state == "run":
		spd = clamp(speed / max(run_speed_ref, 0.1), 0.7, 1.5)
	elif new_state == "walk_back" or new_state.begins_with("strafe"):
		spd = clamp(speed / max(walk_speed_ref, 0.1), 0.65, 1.4)
	elif new_state == "sneak_walk" or new_state == "crouch_walk":
		spd = clamp(speed / max(walk_speed_ref * 0.75, 0.1), 0.65, 1.35)
	_play_clip(clip, blend, spd)

func get_debug_line() -> String:
	return "state=" + str(state) + " clip=" + str(current_clip) + " playing=" + str(ap.is_playing() if ap else false)
