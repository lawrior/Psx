extends Camera

# =====================================================================
# SKYRIM-STYLE THIRD PERSON CAMERA  (Godot 3.5 / 3.6)
# =====================================================================
# Replaces the previous implementation which had four fatal problems:
#
#   1. It created a "CameraPivot" as a child of the Player and then wrote
#      camera_pivot.rotation_degrees = (pitch, yaw, 0). Because the pivot
#      inherited the player's rotation, the mouse yaw was applied on top
#      of the body yaw -> the view span twice as fast as the mouse and
#      the world rolled when the character turned.
#   2. The collision ray was cast towards  +pivot.basis.z * distance
#      while the camera actually sat at  -basis.z  ->  the spring arm
#      tested the empty space in FRONT of the player, so the camera
#      happily clipped through walls and terrain.
#   3. The camera position was interpolated but the rotation was snapped
#      with look_at() every frame -> the two fought each other and the
#      view jittered / wobbled while walking.
#   4. No framing for the character: at height_offset 2.0 / look_at 1.5
#      against a 3.2 m tall model the camera aimed at the character's
#      knees, and it orbited the capsule centre rather than the head.
#
# This version uses a plain "spring arm" around an anchor point at the
# character's upper chest. The camera is declared top_level so it never
# inherits the body rotation.
# =====================================================================

# ---- Framing (metres) ----------------------------------------------
export var distance : float = 4.2
export var min_distance : float = 0.9
export var max_distance : float = 9.0
export var zoom_step : float = 0.5
export var anchor_height : float = 1.45      # orbit centre (upper chest)
export var look_at_height : float = 1.35     # point we aim at
export var crouch_anchor_height : float = 0.95
export var shoulder_offset : float = 0.55    # sideways offset, Skyrim-ish

# ---- Mouse -----------------------------------------------------------
export var mouse_sensitivity : float = 0.18
export var invert_y : bool = false
export var pitch_min : float = -72.0
export var pitch_max : float = 78.0

export var pitch_bias : float = -8.0         # default downward framing tilt

# ---- Aim down sights (hold right mouse) -------------------------------
# Pulls the camera in over the shoulder and narrows the FOV so you can
# actually see what is on an NPC's belt before you lift it.
export var aim_enabled : bool = true
export var aim_distance : float = 1.5        # camera distance while aiming
export var aim_shoulder_offset : float = 0.78
export var aim_anchor_height : float = 1.52
export var aim_look_height : float = 1.45
export var aim_fov : float = 40.0
export var aim_speed : float = 9.0           # blend speed in/out
export var aim_mouse_scale : float = 0.45    # finer control while aiming

# ---- Feel ------------------------------------------------------------
export var follow_smoothing : float = 12.0   # anchor lag (higher = tighter)
export var distance_smooth_in : float = 28.0 # snap in fast (no wall clip)
export var distance_smooth_out : float = 4.0 # ease out slowly (no pop)
export var min_pitch_offset : float = 0.0

# ---- Collision -------------------------------------------------------
export var collision_mask : int = 1          # "environment" layer
export var collision_margin : float = 0.25
export var collide_with_bodies : bool = true
export var collide_with_areas : bool = false

# ---- State -----------------------------------------------------------
var target : Spatial = null
var yaw : float = 0.0
var pitch : float = -12.0
var current_distance : float = 4.2
var anchor : Vector3 = Vector3.ZERO
var _anchor_initialised : bool = false
var _player = null
var aiming : bool = false
var aim_blend : float = 0.0
var _base_fov : float = 70.0

func _ready():
	# Never inherit the body transform; the camera is driven in world space.
	# (Godot 3 spells this set_as_toplevel; the "top_level" property is Godot 4.)
	set_as_toplevel(true)
	current = false
	current_distance = distance
	_base_fov = fov

func init(p_target, p_player = null):
	target = p_target
	_player = p_player
	if _player == null and target:
		_player = target
	if target:
		# Start behind whatever the character is currently facing.
		yaw = target.rotation_degrees.y + 180.0
		anchor = target.global_transform.origin
		_anchor_initialised = true
	current_distance = distance
	_apply_transform()

# ---------------------------------------------------------------------
# MOUSE LOOK
# ---------------------------------------------------------------------
func add_look(delta_x : float, delta_y : float):
	# Aiming slows the look down for precision work (pickpocketing).
	var sens = mouse_sensitivity * lerp(1.0, aim_mouse_scale, aim_blend)
	yaw -= delta_x * sens
	var pitch_delta = delta_y * sens
	if invert_y:
		pitch_delta = -pitch_delta
	pitch = clamp(pitch - pitch_delta, pitch_min, pitch_max)
	yaw = fposmod(yaw + 180.0, 360.0) - 180.0

func get_camera_yaw_rad() -> float:
	return deg2rad(yaw)

# ---------------------------------------------------------------------
# PER FRAME UPDATE
# ---------------------------------------------------------------------
func _process(delta):
	if !target or !is_instance_valid(target):
		return
	_update_aim(delta)
	_update_anchor(delta)
	_update_distance(delta)
	_apply_transform()

func _update_anchor(delta):
	# Orbit around the character's chest so the head stays in frame.
	# The orbit centre rises when aiming (over the shoulder) and drops when
	# crouching, so the framing always follows what the player is doing.
	var desired = target.global_transform.origin + Vector3(0.0, _effective_anchor_height(), 0.0)

	if !_anchor_initialised:
		anchor = desired
		_anchor_initialised = true
		return

	# Vertical follows instantly (no bobbing lag / stair wobble), horizontal
	# is smoothed so strafing does not feel glued to the hips.
	var t = clamp(follow_smoothing * delta, 0.0, 1.0)
	var flat = anchor.linear_interpolate(desired, t)
	flat.y = desired.y
	anchor = flat

# ---------------------------------------------------------------------
# AIM DOWN SIGHTS
# ---------------------------------------------------------------------
func set_aiming(value : bool):
	aiming = aim_enabled and value

func is_aiming() -> bool:
	return aiming

func _update_aim(delta : float):
	var target = 1.0 if aiming else 0.0
	aim_blend = lerp(aim_blend, target, clamp(aim_speed * delta, 0.0, 1.0))
	if abs(aim_blend - target) < 0.002:
		aim_blend = target
	fov = lerp(_base_fov, aim_fov, aim_blend)

func _effective_distance() -> float:
	return lerp(distance, min(aim_distance, distance), aim_blend)

func _effective_shoulder() -> float:
	return lerp(shoulder_offset, aim_shoulder_offset, aim_blend)

func _effective_anchor_height() -> float:
	var base = anchor_height
	if _player and _player.has_method("is_sneaking") and _player.is_sneaking():
		base = crouch_anchor_height
	return lerp(base, aim_anchor_height, aim_blend)

func _orbit_basis() -> Basis:
	# yaw around world up, pitch around the local right axis.
	# Local +Z of this basis points BEHIND the camera (the spring arm
	# direction); the camera looks along its own -Z, which is the same
	# axis reversed. Getting this backwards was the original camera bug:
	# the old code cast its wall-collision ray towards +Z while placing
	# the camera at -Z, so the spring arm measured empty space in front of
	# the character and let the camera walk through brick walls.
	return Basis(Vector3.UP, deg2rad(yaw)) * Basis(Vector3.RIGHT, deg2rad(pitch + pitch_bias))

func _arm_direction() -> Vector3:
	# Unit vector from the character towards the camera (i.e. "backwards"
	# from the camera's point of view).
	return _orbit_basis().z.normalized()

func _desired_offset() -> Vector3:
	var b = _orbit_basis()
	return b.z.normalized() * current_distance + b.x.normalized() * _effective_shoulder()

func _look_target() -> Vector3:
	var body = target.global_transform.origin
	var base = look_at_height
	if _player and _player.has_method("is_sneaking") and _player.is_sneaking():
		base = crouch_anchor_height * 0.85
	var h = lerp(base, aim_look_height, aim_blend)
	return body + Vector3(0.0, h, 0.0)

func _update_distance(delta):
	# The spring arm length is the plain camera distance normally, and the
	# tucked-in aiming distance while the aim button is held.
	var max_reach = _effective_distance()
	var focus = _look_target()
	var back = _arm_direction()
	# Start the ray just outside the character so we never clip our own body
	# or the ground the character is standing on.
	var from = focus + back * 0.3
	var to = focus + back * max_reach

	# While aiming the camera is meant to sit very close, so the enforced
	# minimum has to be able to go below the normal one.
	var floor_dist = min(min_distance, max_reach)
	var allowed = max_reach
	var space = get_world().direct_space_state
	if space:
		var exclude = []
		if _player and _player is PhysicsBody:
			exclude.append(_player)
		var hit = space.intersect_ray(from, to, exclude, collision_mask,
			collide_with_bodies, collide_with_areas)
		if hit:
			allowed = max(floor_dist, from.distance_to(hit.position) - collision_margin)

	# Snap inwards immediately (never let the wall show through), ease back
	# out slowly so the camera does not pop when a doorway is cleared.
	if allowed < current_distance:
		current_distance = allowed
	else:
		var t = clamp(distance_smooth_out * delta, 0.0, 1.0)
		current_distance = lerp(current_distance, allowed, t)

func _apply_transform():
	# Set the basis directly instead of calling look_at(). The camera aims
	# parallel to the spring arm, so a shoulder offset frames the character
	# off-centre without the crosshair ending up on her back - and there is
	# no degenerate look_at() call (and no error spam) when she is very
	# close or exactly under the camera.
	var b = _orbit_basis()
	global_transform = Transform(b, anchor + _desired_offset())

# ---------------------------------------------------------------------
# PUBLIC HELPERS
# ---------------------------------------------------------------------
func set_first_person(enabled : bool):
	visible = true
	if enabled:
		var focus = _look_target()
		global_transform.origin = focus
	else:
		_apply_transform()

func kick(delta_pitch : float):
	# Small recoil used when a weapon fires.
	pitch = clamp(pitch + delta_pitch, pitch_min, pitch_max)

func zoom(steps : float):
	# steps < 0 zooms in, > 0 zooms out (mouse wheel).
	if aiming:
		return   # the aim pose owns the distance until the button is released
	distance = clamp(distance + steps * zoom_step, min_distance, max_distance)
	if current_distance > distance:
		current_distance = distance
