extends Reference

# =====================================================================
# CHARACTER WEAPON RIG
# =====================================================================
# Before this existed, picked up weapons only ever lived as nodes under
#   Camera/WeaponManager/Weapons/...
# i.e. inside the first person camera rig. The moment the game switched to
# third person that whole rig was hidden, so picking up a shotgun changed
# nothing at all on screen: the girl kept walking around empty handed.
#
# This class hangs real copies of the weapon models off the character's
# skeleton using BoneAttachment sockets:
#
#     hand  -> girl_bone_right_hand_42   the weapon currently in use
#     back  -> girl_bone_spine_2_10      everything else, holstered
#
# Scale is computed, not guessed. The GLB's skeleton lives in centimetres
# behind an FBX scale chain, so one bone-space unit is not one metre; the
# code measures the skeleton's real world scale and fits each weapon to a
# sensible real-world length (a machete is ~55 cm, a shotgun ~85 cm ...).
# =====================================================================

const SOCKET_HAND = "hand"
const SOCKET_BACK = "back"

const HAND_BONE = "girl_bone_right_hand_42"
const BACK_BONE = "girl_bone_spine_2_10"

# slot name (matches WeaponManager WEAPON_SLOTS order) -> resource + real size
const WEAPON_MODELS = {
	"Machete": "res://weapons/raw_assets/machete.glb",
	"MachineGun": "res://weapons/raw_assets/machinegun.glb",
	"Shotgun": "res://weapons/raw_assets/shotgun.glb",
	"RocketLauncher": "res://weapons/raw_assets/rocketlauncher.glb",
}

# Target length in metres for the weapon's longest axis.
const WEAPON_LENGTH = {
	"Machete": 0.55,
	"MachineGun": 0.84,
	"Shotgun": 0.80,
	"RocketLauncher": 0.86,
}

# The source models are not authored on a common axis, and the hand bone
# and the spine bone have completely different orientations. Rather than
# hand-tuning an Euler angle per weapon per socket (which breaks the moment
# a bone moves), each model declares which of its LOCAL axes plays which
# role, and the rig solves the rotation from the bones' actual world axes.
#
#   long : the axis that should point away from the grip
#   up   : the axis that should stay "up" (gun sights up, blade flat vertical)
#   flip : set if the model's +long end is the handle instead of the muzzle
const WEAPON_AXES = {
	"Machete":        {"long": Vector3(0, 1, 0), "up": Vector3(0, 0, 1), "flip": false},
	"MachineGun":     {"long": Vector3(0, 0, 1), "up": Vector3(0, 1, 0), "flip": false},
	"Shotgun":        {"long": Vector3(0, 0, 1), "up": Vector3(0, 1, 0), "flip": false},
	"RocketLauncher": {"long": Vector3(0, 0, 1), "up": Vector3(0, 1, 0), "flip": false},
}

# Extra roll (degrees about the weapon's own long axis) for fine tuning.
const WEAPON_ROLL = {
	"Machete": 0.0,
	"MachineGun": 0.0,
	"Shotgun": 0.0,
	"RocketLauncher": 0.0,
}

# Grip offsets, expressed in the character's own frame as
# (right, up, forward) in metres. Positive forward = out in front of her.
const HAND_OFFSET = {
	"Machete":        Vector3(0.0, 0.02, 0.05),
	"MachineGun":     Vector3(0.0, 0.02, 0.10),
	"Shotgun":        Vector3(0.0, 0.02, 0.10),
	"RocketLauncher": Vector3(0.0, 0.03, 0.10),
}
# Stowed weapons are spread out across the back rather than all pinned to
# one point: three guns sharing a single offset simply render inside each
# other. Offsets are (right, up, forward) in metres, tilt is how far the
# weapon leans off vertical, and spin rolls it about its own long axis.
# Weapons that are only ever rendered in the hand. A rocket launcher hanging
# on someone's back alongside two other long guns is neither believable nor
# readable, so it simply is not drawn until it is equipped. Everything else
# stays holstered and visible.
const STOWABLE = {
	"Machete": true,       # scabbard on the hip
	"Shotgun": true,       # slung over the shoulder
	"MachineGun": true,    # across the lower back
	"RocketLauncher": false,
}

const BACK_LAYOUT = {

	# Machete: scabbard on her LEFT hip, nearly upright.
	"Machete":        {"offset": Vector3(-0.18, -0.30, -0.14), "tilt": -8.0, "spin": 0.0},
	# Shotgun: slung over her RIGHT shoulder, leaning right.
	"Shotgun":        {"offset": Vector3( 0.13, -0.05, -0.16), "tilt":  30.0, "spin": 0.0},
	# Machine gun: across her left lower back, leaning the other way so the
	# two long guns form an X instead of occupying the same space.
	"MachineGun":     {"offset": Vector3(-0.11, -0.20, -0.24), "tilt": -34.0, "spin": 0.0},
	# Rocket launcher: the big one, diagonally across the centre of her back.
	"RocketLauncher": {"offset": Vector3( 0.01, -0.24, -0.34), "tilt":  38.0, "spin": 0.0},
}

var sockets = {}          # name -> BoneAttachment
var models = {}           # weapon name -> Spatial (instanced model)
var model_scales = {}     # weapon name -> float (fitted world scale)
var skeleton = null
var ready_ok = false
var human_visible : bool = true

# ---------------------------------------------------------------------
func setup(character_model, anim_player = null) -> bool:
	if !character_model or !is_instance_valid(character_model):
		return false
	skeleton = _find_skeleton(character_model)
	if !skeleton:
		push_warning("CharacterWeaponRig: no Skeleton found in the character model")
		return false

	sockets[SOCKET_HAND] = _make_socket(HAND_BONE)
	sockets[SOCKET_BACK] = _make_socket(BACK_BONE)
	if !sockets[SOCKET_HAND] or !sockets[SOCKET_BACK]:
		return false

	ready_ok = true
	return true

func _make_socket(bone_name : String) -> BoneAttachment:
	if skeleton.find_bone(bone_name) < 0:   # Godot 3 has no Skeleton.has_bone()
		push_warning("CharacterWeaponRig: bone '" + bone_name + "' not found")
		return null
	var attach = BoneAttachment.new()
	attach.name = "WpnSocket_" + bone_name
	attach.bone_name = bone_name
	skeleton.add_child(attach)
	return attach

# ---------------------------------------------------------------------
# PUBLIC API
# ---------------------------------------------------------------------
# slot_names: array of currently unlocked weapon names, in slot order
# active_name: the one that should be held in the hand ("" for none)
func update_loadout(slot_names : Array, active_name : String):
	if !ready_ok:
		return
	for name in slot_names:
		_ensure_model(name)

	for name in models.keys():
		var node = models[name]
		if !is_instance_valid(node):
			continue
		var in_loadout = name in slot_names
		var stowable = STOWABLE.get(name, true)
		node.visible = in_loadout and (name == active_name or stowable)
		var want_socket = sockets[SOCKET_HAND] if name == active_name else sockets[SOCKET_BACK]
		if in_loadout and node.get_parent() != want_socket:
			node.get_parent().remove_child(node)
			want_socket.add_child(node)
			_pose_model(name)

func _socket_for(name : String) -> String:
	return SOCKET_HAND if name == _held_name else SOCKET_BACK

var _held_name : String = ""

func set_held(name : String):
	_held_name = name
	if !ready_ok:
		return
	for n in models.keys():
		var node = models[n]
		if !is_instance_valid(node):
			continue
		var want = sockets[SOCKET_HAND] if n == name else sockets[SOCKET_BACK]
		if node.get_parent() != want:
			node.get_parent().remove_child(node)
			want.add_child(node)
			_pose_model(n)
		# Drawn weapons are always visible; holstered ones only if stowable.
		node.visible = (n == name) or STOWABLE.get(n, true)
		# Keep the visibility we were asked for while transformed.
		if !human_visible:
			node.visible = false

func set_visible(vis : bool):
	human_visible = vis
	for n in models.keys():
		var node = models[n]
		if is_instance_valid(node):
			node.visible = vis

# ---------------------------------------------------------------------
func _ensure_model(name : String) -> void:
	if models.has(name) and is_instance_valid(models[name]):
		return
	if !WEAPON_MODELS.has(name):
		return
	var packed = load(WEAPON_MODELS[name])
	if !packed:
		push_warning("CharacterWeaponRig: could not load " + str(WEAPON_MODELS[name]))
		return
	var inst = packed.instance()
	inst.name = "Wpn_" + name
	sockets[SOCKET_BACK].add_child(inst)
	models[name] = inst        # must exist before _pose_model() looks it up
	_fit_scale(name, inst)
	_pose_model(name)
	inst.visible = false

# Fits the weapon to a real-world length. Bone space inherits the FBX
# 0.01 chain and the character's own fit scale, so we measure the actual
# world scale of the skeleton instead of hard coding a magic number.
func _fit_scale(name : String, inst : Spatial) -> void:
	var raw_box = _local_aabb(inst)
	var raw_long = max(raw_box.size.x, max(raw_box.size.y, raw_box.size.z))
	if raw_long < 0.0001:
		return
	var bone_space_scale = skeleton.global_transform.basis.get_scale().x
	if bone_space_scale < 0.000001:
		bone_space_scale = 1.0
	var target = WEAPON_LENGTH.get(name, 0.6)
	var world_long_at_1 = raw_long * bone_space_scale
	var factor = target / max(world_long_at_1, 0.00001)
	model_scales[name] = factor
	inst.scale = Vector3(factor, factor, factor)

func _pose_model(name : String) -> void:
	var inst = models.get(name, null)
	if !is_instance_valid(inst):
		return
	var parent_socket = inst.get_parent()
	if !parent_socket:
		return
	var held = (parent_socket == sockets[SOCKET_HAND])
	var axes = WEAPON_AXES.get(name, {"long": Vector3(0, 0, 1), "up": Vector3(0, 1, 0), "flip": false})

	# ---- desired world directions for this socket ----
	var fwd = _character_forward()
	var up = _character_up()
	var right = _character_right()
	var layout = BACK_LAYOUT.get(name, {"offset": Vector3(0, -0.15, -0.25), "tilt": 30.0, "spin": 0.0})
	var want_long = up if !held else fwd      # stowed weapons stand up the back
	var want_up = right if !held else up
	if !held:
		var tilt = float(layout["tilt"])
		want_long = (want_long * cos(deg2rad(tilt)) + right * sin(deg2rad(tilt))).normalized()
		want_up = (want_up - want_long * want_up.dot(want_long)).normalized()

	# ---- express them in the socket's own space ----
	var inv = parent_socket.global_transform.basis.inverse()
	var f = inv.xform(want_long).normalized()
	var u = inv.xform(want_up).normalized()
	if f.length() < 0.001:
		f = Vector3.FORWARD
	# Gram-Schmidt so the two target axes are exactly perpendicular.
	u = (u - f * u.dot(f))
	if u.length() < 0.001:
		u = Vector3.UP
	u = u.normalized()
	var r = f.cross(u)
	if r.length() < 0.001:
		r = Vector3.RIGHT
	r = r.normalized()
	u = r.cross(f).normalized()

	# ---- solve the rotation from the model's own axes onto those targets ----
	# The basis we build must send the model's local axis that plays "long"
	# onto f, the one that plays "up" onto u, and the remaining one onto r,
	# while staying right handed (x cross y = z).
	var basis = _axis_role_basis(axes["long"], axes["up"], f, u, r)
	if axes.get("flip", false):
		# Spin 180 degrees about the "up" target so the tip points the other way.
		basis = basis * Basis(Vector3.UP, PI)
	# Optional roll about the weapon's own long axis.
	var roll = WEAPON_ROLL.get(name, 0.0) + float(layout.get("spin", 0.0))
	if abs(roll) > 0.001:
		basis = basis * Basis(axes["long"], deg2rad(roll))

	# ---- grip offset ----
	var world_offset = HAND_OFFSET.get(name, Vector3(0, 0, 0.05)) if held else layout["offset"]
	# Convert the (right, up, forward) offset into a world vector, then into
	# the socket's space. One conversion does both the rotation and the
	# bone-space scaling, so no magic scale divisor is needed.
	var world_vec = right * world_offset.x + up * world_offset.y + fwd * world_offset.z
	var local_offset = inv.xform(world_vec)

	# Re-apply the fitted scale: _pose_model() replaces the whole transform,
	# and forgetting this is what once made the machete 4 cm long.
	var fit = model_scales.get(name, 1.0)
	inst.transform = Transform(basis.scaled(Vector3(fit, fit, fit)), local_offset)

# Builds the rotation that maps the model's three local axes onto the three
# supplied target directions, honouring which local axis plays which role.
func _axis_role_basis(local_long : Vector3, local_up : Vector3, f : Vector3, u : Vector3, r : Vector3) -> Basis:
	# Identify the third local axis (the one that is neither long nor up).
	var third = local_long.cross(local_up).normalized()
	# Which standard axis is which? Work it out from the role vectors so the
	# code does not care whether a model is authored Y-up or Z-forward.
	var col_x = _image_of(Vector3(1, 0, 0), local_long, local_up, third, f, u, r)
	var col_y = _image_of(Vector3(0, 1, 0), local_long, local_up, third, f, u, r)
	var col_z = _image_of(Vector3(0, 0, 1), local_long, local_up, third, f, u, r)
	return Basis(col_x, col_y, col_z)

func _image_of(axis : Vector3, local_long : Vector3, local_up : Vector3, third : Vector3,
		f : Vector3, u : Vector3, r : Vector3) -> Vector3:
	if axis.dot(local_long) > 0.5:
		return f
	if axis.dot(local_up) > 0.5:
		return u
	return r

# ---------------------------------------------------------------------
# THE CHARACTER'S OWN AXES, TAKEN FROM THE SKELETON
# The skeleton inherits the model's yaw (and any model_yaw_offset_degrees),
# so "the way she is facing" is the skeleton's own +Z. Using the player
# node instead would point weapons the wrong way if the model is ever
# yawed to compensate for an export.
# ---------------------------------------------------------------------
func _character_forward() -> Vector3:
	var f = skeleton.global_transform.basis.z
	f.y = 0.0
	if f.length() < 0.001:
		return Vector3.FORWARD
	return f.normalized()

func _character_up() -> Vector3:
	return Vector3.UP

# NOTE: the model faces its own +Z, and for a body facing +Z with +Y up the
# character's RIGHT hand side is -X, not +X. Getting this backwards put every
# stowed weapon on the wrong shoulder and piled them on top of each other.
func _character_right() -> Vector3:
	var r = -skeleton.global_transform.basis.x
	r.y = 0.0
	if r.length() < 0.001:
		return Vector3.RIGHT
	return r.normalized()

# World size of a weapon as it currently hangs off the skeleton (debug/tests).
func get_world_length(name : String) -> float:
	var inst = models.get(name, null)
	if !is_instance_valid(inst):
		return 0.0
	var box = _world_aabb(inst)
	return max(box.size.x, max(box.size.y, box.size.z))

# ---------------------------------------------------------------------
func _local_aabb(root) -> AABB:
	var box = AABB()
	var first = true
	for n in _all(root, []):
		if n is MeshInstance and n.mesh:
			var b = n.transform.xform(n.mesh.get_aabb())
			if first:
				box = b
				first = false
			else:
				box = box.merge(b)
	if first:
		return AABB(Vector3.ZERO, Vector3.ONE)
	return box

func _world_aabb(root) -> AABB:
	var box = AABB()
	var first = true
	for n in _all(root, []):
		if n is MeshInstance and n.mesh:
			var b = n.global_transform.xform(n.mesh.get_aabb())
			if first:
				box = b
				first = false
			else:
				box = box.merge(b)
	if first:
		return AABB(Vector3.ZERO, Vector3.ONE)
	return box

func _all(node, acc : Array) -> Array:
	acc.append(node)
	for c in node.get_children():
		_all(c, acc)
	return acc

func _find_skeleton(node):
	if node is Skeleton:
		return node
	for c in node.get_children():
		var r = _find_skeleton(c)
		if r:
			return r
	return null
