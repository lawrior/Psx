extends Label

var ammo = 0
var health = 0
var gold = 0
var tools_count = 0
var pantry_count = 0
var active_buff = ""
var stance = "STANDING"
var stealth = "HIDDEN"

func update_ammo(amnt):
	ammo = amnt
	update_display()

func update_health(amnt):
	health = amnt
	update_display()

func update_gold(amnt):
	gold = amnt
	update_display()

func update_tools(amnt):
	tools_count = amnt
	update_display()

func update_pantry(count: int, buff_name: String = ""):
	pantry_count = count
	active_buff = buff_name
	update_display()

func update_stealth(p_stance: String, p_stealth: String):
	stance = p_stance
	stealth = p_stealth
	update_display()

func update_display():
	var ammo_amnt = str(ammo)
	if ammo < 0:
		ammo_amnt = "inf"
	var buff_line = ""
	if active_buff != "":
		buff_line = "\nBuff: [" + active_buff + "]"
	
	# Show simplified HUD when in animal form
	if stance.ends_with("FORM"):
		text = "Health: " + str(health) + "\nGold: " + str(gold) + "\nPantry: " + str(pantry_count) + " items\nForm: [" + stance + "]" + buff_line + "\nStatus: [" + stealth + "]"
	else:
		text = "Health: " + str(health) + "\nAmmo: " + ammo_amnt + "\nGold: " + str(gold) + "\nTools: " + str(tools_count) + "\nPantry: " + str(pantry_count) + " items\nStance: [" + stance + "]\nStealth: [" + stealth + "]" + buff_line
