extends Spatial

# =====================================================================
# CHARACTER MOVER  (rewritten)
# =====================================================================
# The original implementation was:
#
#     velocity += move_accel * move_vec - velocity * Vector3(drag, 0, drag) \
#                 + gravity * Vector3.DOWN * delta
#     velocity = body_to_move.move_and_slide_with_snap(velocity, snap_vector, Vector3.UP)
#     if is_grounded:
#         velocity.y = -0.01
#
# with drag = move_accel / max_speed. Three problems:
#
#  1. The acceleration and drag terms were NOT multiplied by delta, so the
#     whole controller was framerate dependent (a per-frame update tuned at
#     whatever fps the author happened to have).
#  2. Gravity and the -1 m/s snap vector were injected into the velocity
#     BEFORE the slide, and the grounded branch only fixed velocity.y after
#     the fact. Every single frame the body therefore arrived at the floor
#     with a large downward velocity that the contact had to cancel. On a
#     concave triangle-mesh floor the contact normal carries ~1e-6 of
#     numerical tilt, so a sliver of that downward velocity leaked into the
#     horizontal axes each frame. That leak fed back into the next frame's
#     velocity and grew by ~3.6x per frame: after ~20 frames the character
#     was moving at hundreds of m/s, and a few frames later every transform
#     in the scene was NaN. This is why the character shook, slid away on
#     its own and the camera looked broken.
#  3. A few millionths of a metre per second of solver noise could never
#     settle, because nothing damped it away at low speeds.
#
# The rewrite keeps the same public API and the same feel, but:
#   * everything is scaled by delta (framerate independent),
#   * the vertical velocity is set BEFORE the move, and the body is pushed
#     into the floor with a small bias instead of a 1 m/s snap,
#   * a velocity dead-zone zeroes out solver noise when the character is not
#     being driven, which is what breaks the feedback loop,
#   * a hard speed clamp guarantees a numerical accident can never again
#     launch the player across the map.
# =====================================================================

var body_to_move : KinematicBody = null

export var move_accel = 25.0        # m/s^2 ground acceleration
export var max_speed = 6.5          # m/s at speed_scale 1.0
export var jump_force = 8.0         # m/s instant upward
export var gravity = 22.0           # m/s^2
export var stop_epsilon = 0.05      # below this speed with no input -> stop dead
export var ground_bias = 0.05       # small downward push so slopes/steps stick
export var max_speed_clamp = 40.0   # absolute safety net for the velocity

var drag = 0.0                      # kept for compatibility (unused)
var pressed_jump = false
var move_vec : Vector3
var velocity : Vector3
var snap_vector : Vector3 = Vector3.DOWN
export var ignore_rotation = false

signal movement_info

var frozen = false
var speed_scale = 1.0
var is_grounded = false

func _ready():
	update_drag()

func init(_body_to_move: KinematicBody):
	body_to_move = _body_to_move

func update_drag():
	# Informational only: the old controller expressed damping as accel/max_speed.
	drag = float(move_accel) / max(max_speed * speed_scale, 0.001)

func set_speed_scale(scale : float):
	speed_scale = max(0.05, scale)
	update_drag()

func get_speed_scale() -> float:
	return speed_scale

func is_on_floor() -> bool:
	return is_grounded

func jump():
	pressed_jump = true

func set_move_vec(_move_vec : Vector3):
	move_vec = _move_vec.normalized() if _move_vec.length() > 0.0001 else Vector3.ZERO

func _physics_process(delta : float):
	if frozen or !body_to_move:
		return

	var cur_move_vec = move_vec
	if !ignore_rotation:
		cur_move_vec = cur_move_vec.rotated(Vector3.UP, body_to_move.rotation.y)

	# ---- horizontal ----
	var target_speed = max_speed * speed_scale
	var hv = Vector3(velocity.x, 0.0, velocity.z)
	var desired = target_speed * cur_move_vec if cur_move_vec.length() > 0.01 else Vector3.ZERO
	var step = move_accel * delta
	var diff = desired - hv
	if diff.length() <= step:
		hv = desired
	else:
		hv += diff.normalized() * step
	# Dead-zone: without this, sub-millimetre solver jitter keeps feeding back.
	if cur_move_vec.length() < 0.01 and hv.length() < stop_epsilon:
		hv = Vector3.ZERO
	velocity.x = hv.x
	velocity.z = hv.z

	# ---- vertical ----
	# Set this BEFORE the move so the contact never has to cancel a runaway
	# downward velocity (the old bug).
	if is_grounded and !pressed_jump:
		velocity.y = -ground_bias
		snap_vector = Vector3.DOWN * ground_bias
	elif pressed_jump and is_grounded:
		velocity.y = jump_force
		snap_vector = Vector3.ZERO
	else:
		velocity.y -= gravity * delta
		snap_vector = Vector3.ZERO if velocity.y > 0.0 else Vector3.DOWN * ground_bias
	pressed_jump = false

	velocity = body_to_move.move_and_slide_with_snap(velocity, snap_vector, Vector3.UP, true, 4, deg2rad(50), false)
	is_grounded = body_to_move.is_on_floor()

	# ---- safety net ----
	if velocity.length() > max_speed_clamp:
		velocity = velocity.normalized() * max_speed_clamp
	if is_nan(velocity.x) or is_nan(velocity.y) or is_nan(velocity.z):
		velocity = Vector3.ZERO

	emit_signal("movement_info", velocity, is_grounded)

func freeze():
	frozen = true
	velocity = Vector3.ZERO

func unfreeze():
	frozen = false
