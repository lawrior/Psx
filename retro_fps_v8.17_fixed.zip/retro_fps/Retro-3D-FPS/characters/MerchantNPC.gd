extends KinematicBody

# =====================================================================
# MERCHANT NPC - Interactive merchant character
# =====================================================================

signal merchant_interacted
signal caught_stealing

var npc_name = "Merchant"
var is_merchant = true
var interaction_distance = 3.0

var interaction_area = null
var name_label = null

# Pickpocket system
var visual_placeholders = []
var pockets = []
var is_alerted = false
var alert_timer = 0.0
var steal_penalty_timer = 0.0  # 30 second penalty when caught
var last_player_position = Vector3.ZERO

const PENALTY_DURATION = 30.0
const PENALTY_RESET_DISTANCE = 15.0  # Must go this far away to reset penalty

func _ready():
	# Setup interaction area
	interaction_area = get_node_or_null("InteractionArea")
	if !interaction_area:
		interaction_area = Area.new()
		interaction_area.name = "InteractionArea"
		var col_shape = CollisionShape.new()
		var shape = SphereShape.new()
		shape.radius = interaction_distance
		col_shape.shape = shape
		interaction_area.add_child(col_shape)
		add_child(interaction_area)
	
	# Setup name label
	name_label = get_node_or_null("NameLabel")
	if !name_label:
		name_label = Label.new()
		name_label.name = "NameLabel"
		name_label.text = npc_name
		name_label.align = Label.ALIGN_CENTER
		name_label.valign = Label.VALIGN_CENTER
		name_label.anchor_left = 0.5
		name_label.anchor_top = 0.0
		name_label.anchor_right = 0.5
		name_label.anchor_bottom = 0.0
		name_label.margin_left = -50
		name_label.margin_top = -80
		name_label.margin_right = 50
		name_label.margin_bottom = -50
		var font_res = load("res://ui/KleintenDynFont.tres")
		if font_res:
			name_label.add_font_override("font", font_res)
		name_label.modulate = Color(1.0, 0.9, 0.4, 1.0)
		add_child(name_label)
	
	# Add to merchant group for easy detection
	add_to_group("merchant")
	
	# Setup merchant's stealable items
	setup_merchant_items()

func can_interact(player) -> bool:
	var distance = global_transform.origin.distance_to(player.global_transform.origin)
	return distance <= interaction_distance

func interact(player):
	emit_signal("merchant_interacted", self)
	if player.has_method("open_merchant"):
		player.open_merchant(self)

func get_interaction_prompt() -> String:
	return "[E] Trade with " + npc_name

# =====================================================================
# PICKPOCKET SYSTEM - Allow stealing from merchant
# =====================================================================

func _process(delta):
	# Update alert timer
	if alert_timer > 0:
		alert_timer -= delta
		if alert_timer <= 0:
			is_alerted = false
	
	# Update steal penalty timer
	if steal_penalty_timer > 0:
		steal_penalty_timer -= delta

func setup_merchant_items():
	# Add items that can be stolen from merchant
	var ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
	
	# Clear existing placeholders
	for ph in visual_placeholders:
		if ph.has("node") and is_instance_valid(ph.node):
			ph.node.queue_free()
	visual_placeholders.clear()
	pockets.clear()
	
	# Merchant carries valuable items
	pockets = [
		{"name": "Merchant's Gold Pouch", "desc": "Heavy pouch of gold coins", "type": "gold", "amount": 100, "placeholder_id": "money_bag"},
		{"name": "Rare Gemstone", "desc": "Precious jewel", "type": "trinket", "amount": 75, "placeholder_id": "trinket"},
		{"name": "Master Lockpick Set", "desc": "Professional lockpicks", "type": "tools", "amount": 60, "placeholder_id": "tools"},
	]
	
	# Create visual placeholders
	for i in range(pockets.size()):
		var item = pockets[i]
		var placeholder = ItemMeshFactory.create_mesh(item.placeholder_id)
		if placeholder:
			placeholder.name = "MerchantItem_" + str(i)
			add_child(placeholder)
			# Position items on merchant's body
			var offset = Vector3(0, 0.5, 0)
			if i == 0:
				offset = Vector3(0.2, 0.3, 0)  # Right side
			elif i == 1:
				offset = Vector3(-0.2, 0.3, 0)  # Left side
			elif i == 2:
				offset = Vector3(0, 0.3, 0.15)  # Front
			placeholder.translation = offset
			visual_placeholders.append({"node": placeholder, "item": item})

func is_dead() -> bool:
	return false  # Merchant can't die

func is_alerted() -> bool:
	return is_alerted

func is_player_behind() -> bool:
	# Check if player is behind the merchant
	var player = get_tree().get_nodes_in_group("player")[0] if get_tree().get_nodes_in_group("player").size() > 0 else null
	if !player:
		return false
	
	var to_player = (player.global_transform.origin - global_transform.origin).normalized()
	var forward = -global_transform.basis.z
	var dot = to_player.dot(forward)
	return dot < -0.3  # Player is behind if dot product is negative

func get_pocket_count() -> int:
	return pockets.size()

func get_visible_items_summary() -> String:
	if pockets.empty():
		return "Empty"
	var names = []
	for item in pockets:
		names.append(item.name)
	return PoolStringArray(names).join(", ")

func perform_pickpocket(player, target_item = null) -> Dictionary:
	# Remove item from merchant's pockets
	if pockets.empty():
		return {}
	
	var stolen_item = {}
	if target_item and !target_item.empty():
		# Find and remove specific item
		for i in range(pockets.size()):
			if pockets[i].name == target_item.name:
				stolen_item = pockets[i]
				pockets.remove(i)
				# Remove visual placeholder
				if i < visual_placeholders.size():
					if is_instance_valid(visual_placeholders[i].node):
						visual_placeholders[i].node.queue_free()
					visual_placeholders.remove(i)
				break
	else:
		# Steal first available item
		stolen_item = pockets.pop_front()
		if visual_placeholders.size() > 0:
			if is_instance_valid(visual_placeholders[0].node):
				visual_placeholders[0].node.queue_free()
			visual_placeholders.pop_front()
	
	# Add start position for transfer visual
	stolen_item["start_pos"] = global_transform.origin + Vector3(0, 0.8, 0)
	return stolen_item

func catch_pickpocket(player):
	# Player caught stealing - apply penalty
	is_alerted = true
	alert_timer = 5.0  # Alerted for 5 seconds
	steal_penalty_timer = PENALTY_DURATION  # 30 second selling penalty
	last_player_position = player.global_transform.origin
	
	# Show banner
	if player.has_method("show_banner"):
		player.show_banner("⚠ CAUGHT! " + npc_name + " caught you stealing! Cannot trade for 30 seconds!", Color(1.0, 0.2, 0.2, 1.0), 4.0)
	
	emit_signal("caught_stealing")

func catch_pickpocket_immediate(player):
	# Same as catch_pickpocket but called immediately
	catch_pickpocket(player)

func catch_fumbled_item(player, item_data):
	# Item was fumbled and merchant caught it
	is_alerted = true
	alert_timer = 5.0
	steal_penalty_timer = PENALTY_DURATION
	last_player_position = player.global_transform.origin
	
	# Add item back to pockets
	pockets.append(item_data)
	
	if player.has_method("show_banner"):
		player.show_banner("⚠ FUMBLED! " + npc_name + " caught the item and you! Cannot trade for 30 seconds!", Color(1.0, 0.2, 0.2, 1.0), 4.0)
	
	emit_signal("caught_stealing")

func can_trade_with(player) -> bool:
	# Check if player can trade with merchant
	if steal_penalty_timer > 0:
		return false
	
	# Check if player went far away (resets penalty)
	var distance = player.global_transform.origin.distance_to(last_player_position)
	if distance > PENALTY_RESET_DISTANCE and steal_penalty_timer > 0:
		steal_penalty_timer = 0
		return true
	
	return steal_penalty_timer <= 0

func get_penalty_time_remaining() -> float:
	return steal_penalty_timer

# =====================================================================
# PICKPOCKET HIGHLIGHT SYSTEM - Show outlines on stealable items
# =====================================================================

func update_pickpocket_highlights(player_pos: Vector3, player_forward: Vector3):
	if pockets.empty() or !is_instance_valid(self):
		return
	
	var distance = global_transform.origin.distance_to(player_pos)
	var behind = is_player_behind()
	var sneaking_close = behind and distance < 2.5
	
	# Check if player is looking at any item
	var focused_index = -1
	if sneaking_close:
		var cam = get_viewport().get_camera()
		if cam:
			var from = cam.global_transform.origin
			var dir = -cam.global_transform.basis.z
			focused_index = raycast_to_items(from, dir)
	
	# Apply highlights
	for i in range(visual_placeholders.size()):
		var ph = visual_placeholders[i]
		if !is_instance_valid(ph.node):
			continue
		var ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
		if i == focused_index:
			ItemMeshFactory.apply_highlight(ph.node, ItemMeshFactory.HIGHLIGHT_FOCUSED)
		elif sneaking_close:
			ItemMeshFactory.apply_highlight(ph.node, ItemMeshFactory.HIGHLIGHT_CLOSE)
		else:
			ItemMeshFactory.apply_highlight(ph.node, ItemMeshFactory.HIGHLIGHT_NONE)

func raycast_to_items(from: Vector3, dir: Vector3) -> int:
	# Check which stealable item the player is looking at
	for i in range(visual_placeholders.size()):
		var ph = visual_placeholders[i]
		if !is_instance_valid(ph.node):
			continue
		var item_pos = ph.node.global_transform.origin
		var to_item = (item_pos - from).normalized()
		var dot = dir.dot(to_item)
		if dot < 0.96:
			continue
		# Check distance to ray
		var proj_len = (item_pos - from).dot(dir)
		if proj_len < 0 or proj_len > 3.0:
			continue
		var closest = from + dir * proj_len
		var dist = closest.distance_to(item_pos)
		if dist < 0.4:
			return i
	return -1
