class_name ItemMeshFactory
extends Reference

const HIGHLIGHT_NONE = 0
const HIGHLIGHT_CLOSE = 1
const HIGHLIGHT_FOCUSED = 2

const WHITE_OUTLINE_MAT = preload("res://characters/WhiteOutlineMat.tres")
const GOLD_OUTLINE_MAT = preload("res://characters/GoldOutlineMat.tres")

static func create_mat(col: Color, metal: float = 0.0, rough: float = 0.6) -> SpatialMaterial:
	var mat = SpatialMaterial.new()
	mat.albedo_color = col
	mat.metallic = metal
	mat.roughness = rough
	mat.emission_enabled = true
	mat.emission = Color.black
	mat.emission_energy = 0.0
	return mat

# ---------------------------------------------------------------------
# TORUS BUILDER
# Godot 3.x has no TorusMesh primitive (that class only exists in Godot 4).
# This builds the same shape as an ArrayMesh so the project loads on 3.5/3.6.
# The ring lies flat in the XZ plane, centred on the origin.
# ---------------------------------------------------------------------
static func make_torus(inner_radius: float, outer_radius: float, rings: int = 32, segments: int = 12, mat: SpatialMaterial = null) -> ArrayMesh:
	var tube_radius = max((outer_radius - inner_radius) * 0.5, 0.0005)
	var ring_radius = (outer_radius + inner_radius) * 0.5
	if rings < 3:
		rings = 3
	if segments < 3:
		segments = 3

	var verts = PoolVector3Array()
	var normals = PoolVector3Array()
	var uvs = PoolVector2Array()
	var indices = PoolIntArray()

	for i in range(rings + 1):
		var u = float(i) / float(rings)
		var theta = u * TAU
		var cx = cos(theta) * ring_radius
		var cz = sin(theta) * ring_radius
		for j in range(segments + 1):
			var v = float(j) / float(segments)
			var phi = v * TAU
			# Outward normal of the tube surface at this point
			var n = Vector3(cos(theta) * cos(phi), sin(phi), sin(theta) * cos(phi))
			verts.push_back(Vector3(cx, 0.0, cz) + n * tube_radius)
			normals.push_back(n)
			uvs.push_back(Vector2(u, v))

	for i in range(rings):
		for j in range(segments):
			var a = i * (segments + 1) + j
			var b = a + segments + 1
			indices.push_back(a)
			indices.push_back(b)
			indices.push_back(a + 1)
			indices.push_back(a + 1)
			indices.push_back(b)
			indices.push_back(b + 1)

	var arrays = []
	arrays.resize(Mesh.ARRAY_MAX)
	arrays[Mesh.ARRAY_VERTEX] = verts
	arrays[Mesh.ARRAY_NORMAL] = normals
	arrays[Mesh.ARRAY_TEX_UV] = uvs
	arrays[Mesh.ARRAY_INDEX] = indices

	var mesh = ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arrays)
	if mat:
		# Double sided: a thin ring is never worth back-face culling surprises
		mat.params_cull_mode = SpatialMaterial.CULL_DISABLED
		mesh.surface_set_material(0, mat)
	return mesh

static func apply_highlight(root_node: Spatial, mode: int):
	if !is_instance_valid(root_node):
		return
	if root_node.has_meta("hl_mode") and root_node.get_meta("hl_mode") == mode:
		return
	root_node.set_meta("hl_mode", mode)
	
	var outline_mat = null
	var emit_col = Color.black
	var emit_nrg = 0.0
	
	if mode == HIGHLIGHT_CLOSE:
		outline_mat = WHITE_OUTLINE_MAT
		emit_col = Color(0.25, 0.26, 0.3)
		emit_nrg = 0.55
	elif mode == HIGHLIGHT_FOCUSED:
		outline_mat = GOLD_OUTLINE_MAT
		emit_col = Color(0.75, 0.58, 0.1)
		emit_nrg = 1.35
		
	if root_node is MeshInstance and root_node.material_override is SpatialMaterial:
		var mat = root_node.material_override
		mat.next_pass = outline_mat
		mat.emission = emit_col
		mat.emission_energy = emit_nrg

	for child in root_node.get_children():
		if child is MeshInstance and child.material_override is SpatialMaterial:
			var mat = child.material_override
			mat.next_pass = outline_mat
			mat.emission = emit_col
			mat.emission_energy = emit_nrg

static func warmup(parent_node: Node):
	if !is_instance_valid(parent_node):
		return
	var holder = Spatial.new()
	holder.name = "ShaderWarmup"
	holder.scale = Vector3(0.0005, 0.0005, 0.0005)
	holder.translation = Vector3(0, 1.2, -0.6)
	parent_node.add_child(holder)
	
	var m1 = create_money_bag()
	var m2 = create_small_tools()
	var m3 = create_ammo_pouch()
	var m4 = create_trinket()
	var m5 = create_apple()
	var m6 = create_crimson_poppy()
	var m7 = create_potion_bottle(Color(0.2, 0.8, 0.4))
	
	holder.add_child(m1)
	holder.add_child(m2)
	holder.add_child(m3)
	holder.add_child(m4)
	holder.add_child(m5)
	holder.add_child(m6)
	holder.add_child(m7)
	
	apply_highlight(m1, HIGHLIGHT_CLOSE)
	apply_highlight(m2, HIGHLIGHT_FOCUSED)
	apply_highlight(m5, HIGHLIGHT_CLOSE)
	apply_highlight(m6, HIGHLIGHT_FOCUSED)
	
	var tree = parent_node.get_tree()
	if tree:
		yield_remove_warmup(holder, tree)
	else:
		holder.queue_free()

static func yield_remove_warmup(holder: Spatial, tree: SceneTree):
	yield(tree, "idle_frame")
	yield(tree, "idle_frame")
	if is_instance_valid(holder):
		holder.queue_free()

# -------------------------------------------------------------
# NPC Body / Pickpocket Placeholders
# -------------------------------------------------------------

static func create_money_bag() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "MoneyBag"
	
	var pouch = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.11
	sm.height = 0.20
	pouch.mesh = sm
	pouch.scale = Vector3(1.0, 1.25, 0.95)
	pouch.material_override = create_mat(Color(0.85, 0.22, 0.18), 0.0, 0.7)
	root_node.add_child(pouch)
	
	var neck = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.045
	cm.bottom_radius = 0.045
	cm.height = 0.025
	neck.mesh = cm
	neck.translation = Vector3(0, 0.08, 0)
	neck.material_override = create_mat(Color(0.95, 0.8, 0.2), 0.6, 0.4)
	root_node.add_child(neck)
	
	var ruffle = MeshInstance.new()
	var rf_mesh = CylinderMesh.new()
	rf_mesh.top_radius = 0.07
	rf_mesh.bottom_radius = 0.04
	rf_mesh.height = 0.05
	ruffle.mesh = rf_mesh
	ruffle.translation = Vector3(0, 0.11, 0)
	ruffle.material_override = create_mat(Color(0.85, 0.22, 0.18), 0.0, 0.7)
	root_node.add_child(ruffle)
	
	var charm = MeshInstance.new()
	var ch_mesh = CylinderMesh.new()
	ch_mesh.top_radius = 0.03
	ch_mesh.bottom_radius = 0.03
	ch_mesh.height = 0.01
	charm.mesh = ch_mesh
	charm.translation = Vector3(0.04, 0.05, 0.08)
	charm.rotation_degrees = Vector3(15, 0, 20)
	charm.material_override = create_mat(Color(1.0, 0.85, 0.2), 0.9, 0.2)
	root_node.add_child(charm)
	
	return root_node

static func create_small_tools() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "SmallTools"
	
	var holster = MeshInstance.new()
	var hm = CubeMesh.new()
	hm.size = Vector3(0.09, 0.16, 0.07)
	holster.mesh = hm
	holster.material_override = create_mat(Color(0.28, 0.18, 0.1), 0.0, 0.8)
	root_node.add_child(holster)
	
	var wrench_handle = MeshInstance.new()
	var whm = CylinderMesh.new()
	whm.top_radius = 0.012
	whm.bottom_radius = 0.012
	whm.height = 0.14
	wrench_handle.mesh = whm
	wrench_handle.translation = Vector3(-0.022, 0.08, 0.01)
	wrench_handle.rotation_degrees = Vector3(0, 0, -8)
	wrench_handle.material_override = create_mat(Color(0.8, 0.82, 0.86), 0.9, 0.3)
	root_node.add_child(wrench_handle)
	
	var wrench_head = MeshInstance.new()
	var whm2 = CubeMesh.new()
	whm2.size = Vector3(0.04, 0.03, 0.018)
	wrench_head.mesh = whm2
	wrench_head.translation = Vector3(-0.026, 0.15, 0.01)
	wrench_head.rotation_degrees = Vector3(0, 0, -8)
	wrench_head.material_override = create_mat(Color(0.8, 0.82, 0.86), 0.9, 0.3)
	root_node.add_child(wrench_head)
	
	var blade_handle = MeshInstance.new()
	var bhm = CylinderMesh.new()
	bhm.top_radius = 0.01
	bhm.bottom_radius = 0.01
	bhm.height = 0.15
	blade_handle.mesh = bhm
	blade_handle.translation = Vector3(0.022, 0.07, -0.01)
	blade_handle.rotation_degrees = Vector3(0, 0, 8)
	blade_handle.material_override = create_mat(Color(0.88, 0.72, 0.25), 0.8, 0.3)
	root_node.add_child(blade_handle)
	
	var pommel = MeshInstance.new()
	var pm = SphereMesh.new()
	pm.radius = 0.018
	pm.height = 0.036
	pommel.mesh = pm
	pommel.translation = Vector3(0.028, 0.145, -0.01)
	pommel.material_override = create_mat(Color(0.88, 0.72, 0.25), 0.8, 0.3)
	root_node.add_child(pommel)
	
	return root_node

static func create_ammo_pouch() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "AmmoPouch"
	
	var box = MeshInstance.new()
	var bm = CubeMesh.new()
	bm.size = Vector3(0.14, 0.12, 0.08)
	box.mesh = bm
	box.material_override = create_mat(Color(0.28, 0.36, 0.22), 0.0, 0.85)
	root_node.add_child(box)
	
	var flap = MeshInstance.new()
	var fm = CubeMesh.new()
	fm.size = Vector3(0.145, 0.055, 0.085)
	flap.mesh = fm
	flap.translation = Vector3(0, 0.035, 0.005)
	flap.material_override = create_mat(Color(0.18, 0.22, 0.15), 0.0, 0.9)
	root_node.add_child(flap)
	
	var buckle = MeshInstance.new()
	var bkm = CubeMesh.new()
	bkm.size = Vector3(0.035, 0.035, 0.012)
	buckle.mesh = bkm
	buckle.translation = Vector3(0, 0.005, 0.045)
	buckle.material_override = create_mat(Color(0.9, 0.78, 0.25), 0.85, 0.3)
	root_node.add_child(buckle)
	
	return root_node

static func create_trinket() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "Trinket"
	
	var disc = MeshInstance.new()
	var dm = CylinderMesh.new()
	dm.top_radius = 0.055
	dm.bottom_radius = 0.055
	dm.height = 0.022
	disc.mesh = dm
	disc.material_override = create_mat(Color(1.0, 0.85, 0.25), 0.95, 0.2)
	root_node.add_child(disc)
	
	var ring = MeshInstance.new()
	var rm = make_torus(0.01, 0.022, 24, 8,
		create_mat(Color(1.0, 0.85, 0.25), 0.95, 0.2))
	ring.mesh = rm
	ring.translation = Vector3(0, 0.055, 0)
	ring.material_override = create_mat(Color(1.0, 0.85, 0.25), 0.95, 0.2)
	root_node.add_child(ring)
	
	var gem = MeshInstance.new()
	var gm = SphereMesh.new()
	gm.radius = 0.025
	gm.height = 0.02
	gem.mesh = gm
	gem.translation = Vector3(0, 0.012, 0)
	gem.material_override = create_mat(Color(0.2, 0.45, 0.9), 0.5, 0.2)
	root_node.add_child(gem)
	
	return root_node

# -------------------------------------------------------------
# Fruits (Apple, Plum, Pear, Orange)
# -------------------------------------------------------------

static func create_apple() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "Apple"
	
	# Apple body
	var body = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.22
	body.mesh = sm
	body.scale = Vector3(1.05, 0.95, 1.05)
	body.material_override = create_mat(Color(0.88, 0.12, 0.14), 0.05, 0.35)
	root_node.add_child(body)
	
	# Stem
	var stem = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.012
	cm.bottom_radius = 0.014
	cm.height = 0.06
	stem.mesh = cm
	stem.translation = Vector3(0, 0.11, 0)
	stem.rotation_degrees = Vector3(0, 0, 8)
	stem.material_override = create_mat(Color(0.32, 0.18, 0.08), 0.0, 0.9)
	root_node.add_child(stem)
	
	# Green Leaf
	var leaf = MeshInstance.new()
	var lm = CubeMesh.new()
	lm.size = Vector3(0.065, 0.012, 0.038)
	leaf.mesh = lm
	leaf.translation = Vector3(0.035, 0.12, 0.01)
	leaf.rotation_degrees = Vector3(15, 25, 20)
	leaf.material_override = create_mat(Color(0.2, 0.72, 0.18), 0.0, 0.5)
	root_node.add_child(leaf)
	
	return root_node

static func create_plum() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "Plum"
	
	# Plum body
	var body = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.11
	sm.height = 0.22
	body.mesh = sm
	body.scale = Vector3(0.95, 1.15, 0.95)
	body.material_override = create_mat(Color(0.48, 0.14, 0.65), 0.1, 0.3)
	root_node.add_child(body)
	
	# Tiny Stem
	var stem = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.01
	cm.bottom_radius = 0.012
	cm.height = 0.05
	stem.mesh = cm
	stem.translation = Vector3(0, 0.115, 0)
	stem.material_override = create_mat(Color(0.3, 0.18, 0.08), 0.0, 0.9)
	root_node.add_child(stem)
	
	return root_node

static func create_pear() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "Pear"
	
	# Pear base
	var base = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.20
	base.mesh = sm
	base.translation = Vector3(0, -0.02, 0)
	base.material_override = create_mat(Color(0.88, 0.8, 0.18), 0.05, 0.4)
	root_node.add_child(base)
	
	# Pear upper neck
	var neck = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.05
	cm.bottom_radius = 0.10
	cm.height = 0.12
	neck.mesh = cm
	neck.translation = Vector3(0, 0.06, 0)
	neck.material_override = create_mat(Color(0.88, 0.8, 0.18), 0.05, 0.4)
	root_node.add_child(neck)
	
	# Stem
	var stem = MeshInstance.new()
	var stm = CylinderMesh.new()
	stm.top_radius = 0.01
	stm.bottom_radius = 0.012
	stm.height = 0.06
	stem.mesh = stm
	stem.translation = Vector3(0.01, 0.135, 0)
	stem.rotation_degrees = Vector3(0, 0, 10)
	stem.material_override = create_mat(Color(0.3, 0.18, 0.08), 0.0, 0.9)
	root_node.add_child(stem)
	
	return root_node

static func create_orange() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "Orange"
	
	var body = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.12
	sm.height = 0.22
	body.mesh = sm
	body.material_override = create_mat(Color(0.96, 0.52, 0.08), 0.05, 0.45)
	root_node.add_child(body)
	
	var calyx = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.025
	cm.bottom_radius = 0.025
	cm.height = 0.015
	calyx.mesh = cm
	calyx.translation = Vector3(0, 0.11, 0)
	calyx.material_override = create_mat(Color(0.2, 0.65, 0.15), 0.0, 0.6)
	root_node.add_child(calyx)
	
	return root_node

# -------------------------------------------------------------
# Flowers (Crimson Poppy, Violet Orchid, Sun Marigold, Frost Lily)
# -------------------------------------------------------------

static func create_crimson_poppy() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "CrimsonPoppy"
	
	# Stem
	var stem = MeshInstance.new()
	var sm = CylinderMesh.new()
	sm.top_radius = 0.01
	sm.bottom_radius = 0.012
	sm.height = 0.35
	stem.mesh = sm
	stem.translation = Vector3(0, 0.175, 0)
	stem.material_override = create_mat(Color(0.18, 0.48, 0.16), 0.0, 0.8)
	root_node.add_child(stem)
	
	# Blossom Cup (Crimson)
	var blossom = MeshInstance.new()
	var bm = CylinderMesh.new()
	bm.top_radius = 0.09
	bm.bottom_radius = 0.035
	bm.height = 0.07
	blossom.mesh = bm
	blossom.translation = Vector3(0, 0.36, 0)
	blossom.material_override = create_mat(Color(0.92, 0.12, 0.16), 0.05, 0.3)
	root_node.add_child(blossom)
	
	# Core / Stamen
	var core = MeshInstance.new()
	var cm = SphereMesh.new()
	cm.radius = 0.03
	cm.height = 0.04
	core.mesh = cm
	core.translation = Vector3(0, 0.38, 0)
	core.material_override = create_mat(Color(0.25, 0.16, 0.06), 0.0, 0.9)
	root_node.add_child(core)
	
	return root_node

static func create_violet_orchid() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "VioletOrchid"
	
	# Stem
	var stem = MeshInstance.new()
	var sm = CylinderMesh.new()
	sm.top_radius = 0.01
	sm.bottom_radius = 0.012
	sm.height = 0.38
	stem.mesh = sm
	stem.translation = Vector3(0, 0.19, 0)
	stem.material_override = create_mat(Color(0.18, 0.45, 0.18), 0.0, 0.8)
	root_node.add_child(stem)
	
	# Wide Petals (Deep Violet)
	var petals = MeshInstance.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.11
	pm.bottom_radius = 0.025
	pm.height = 0.06
	petals.mesh = pm
	petals.translation = Vector3(0, 0.39, 0)
	petals.material_override = create_mat(Color(0.55, 0.15, 0.85), 0.1, 0.3)
	root_node.add_child(petals)
	
	# Glowing Yellow / Gold Stamen
	var stamen = MeshInstance.new()
	var stm = SphereMesh.new()
	stm.radius = 0.025
	stm.height = 0.04
	stamen.mesh = stm
	stamen.translation = Vector3(0, 0.41, 0)
	var mat_glow = create_mat(Color(1.0, 0.88, 0.2), 0.6, 0.3)
	mat_glow.emission = Color(0.8, 0.7, 0.1)
	mat_glow.emission_energy = 0.8
	stamen.material_override = mat_glow
	root_node.add_child(stamen)
	
	return root_node

static func create_sun_marigold() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "SunMarigold"
	
	# Stem
	var stem = MeshInstance.new()
	var sm = CylinderMesh.new()
	sm.top_radius = 0.012
	sm.bottom_radius = 0.014
	sm.height = 0.32
	stem.mesh = sm
	stem.translation = Vector3(0, 0.16, 0)
	stem.material_override = create_mat(Color(0.2, 0.5, 0.18), 0.0, 0.8)
	root_node.add_child(stem)
	
	# Outer Yellow Petals
	var outer = MeshInstance.new()
	var om = CylinderMesh.new()
	om.top_radius = 0.10
	om.bottom_radius = 0.06
	om.height = 0.05
	outer.mesh = om
	outer.translation = Vector3(0, 0.33, 0)
	outer.material_override = create_mat(Color(1.0, 0.82, 0.08), 0.05, 0.4)
	root_node.add_child(outer)
	
	# Orange Center Core
	var core = MeshInstance.new()
	var cm = SphereMesh.new()
	cm.radius = 0.04
	cm.height = 0.05
	core.mesh = cm
	core.translation = Vector3(0, 0.35, 0)
	core.material_override = create_mat(Color(0.96, 0.45, 0.05), 0.1, 0.4)
	root_node.add_child(core)
	
	return root_node

static func create_frost_lily() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "FrostLily"
	
	# Pale Stem
	var stem = MeshInstance.new()
	var sm = CylinderMesh.new()
	sm.top_radius = 0.01
	sm.bottom_radius = 0.012
	sm.height = 0.40
	stem.mesh = sm
	stem.translation = Vector3(0, 0.20, 0)
	stem.material_override = create_mat(Color(0.35, 0.55, 0.42), 0.0, 0.8)
	root_node.add_child(stem)
	
	# Icy Petals (White / Pale Cyan)
	var petals = MeshInstance.new()
	var pm = CylinderMesh.new()
	pm.top_radius = 0.11
	pm.bottom_radius = 0.03
	pm.height = 0.08
	petals.mesh = pm
	petals.translation = Vector3(0, 0.42, 0)
	var mat_ice = create_mat(Color(0.85, 0.95, 1.0), 0.1, 0.2)
	mat_ice.emission = Color(0.3, 0.6, 0.8)
	mat_ice.emission_energy = 0.6
	petals.material_override = mat_ice
	root_node.add_child(petals)
	
	# Center Stamen
	var stamen = MeshInstance.new()
	var stm = SphereMesh.new()
	stm.radius = 0.025
	stm.height = 0.04
	stamen.mesh = stm
	stamen.translation = Vector3(0, 0.45, 0)
	stamen.material_override = create_mat(Color(0.3, 0.75, 1.0), 0.4, 0.2)
	root_node.add_child(stamen)
	
	return root_node

# -------------------------------------------------------------
# Witch Cauldron, Potions, and Cooked Dishes
# -------------------------------------------------------------

static func create_potion_bottle(brew_color: Color = Color(0.2, 0.85, 0.4)) -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "PotionBottle"
	
	# Flask body
	var body = MeshInstance.new()
	var sm = SphereMesh.new()
	sm.radius = 0.09
	sm.height = 0.16
	body.mesh = sm
	var mat_liquid = create_mat(brew_color, 0.1, 0.2)
	mat_liquid.emission = brew_color * 0.7
	mat_liquid.emission_energy = 0.8
	body.material_override = mat_liquid
	root_node.add_child(body)
	
	# Flask neck
	var neck = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.028
	cm.bottom_radius = 0.035
	cm.height = 0.07
	neck.mesh = cm
	neck.translation = Vector3(0, 0.09, 0)
	neck.material_override = create_mat(Color(0.85, 0.95, 1.0), 0.2, 0.2)
	root_node.add_child(neck)
	
	# Cork stopper
	var cork = MeshInstance.new()
	var ckm = CylinderMesh.new()
	ckm.top_radius = 0.032
	ckm.bottom_radius = 0.025
	ckm.height = 0.035
	cork.mesh = ckm
	cork.translation = Vector3(0, 0.13, 0)
	cork.material_override = create_mat(Color(0.48, 0.32, 0.18), 0.0, 0.9)
	root_node.add_child(cork)
	
	return root_node

static func create_stew_bowl() -> Spatial:
	var root_node = Spatial.new()
	root_node.name = "StewBowl"
	
	# Clay bowl
	var bowl = MeshInstance.new()
	var cm = CylinderMesh.new()
	cm.top_radius = 0.12
	cm.bottom_radius = 0.07
	cm.height = 0.08
	bowl.mesh = cm
	bowl.material_override = create_mat(Color(0.65, 0.35, 0.22), 0.0, 0.85)
	root_node.add_child(bowl)
	
	# Golden steaming stew surface
	var soup = MeshInstance.new()
	var sm = CylinderMesh.new()
	sm.top_radius = 0.11
	sm.bottom_radius = 0.11
	sm.height = 0.02
	soup.mesh = sm
	soup.translation = Vector3(0, 0.03, 0)
	var mat_soup = create_mat(Color(0.92, 0.65, 0.15), 0.0, 0.4)
	mat_soup.emission = Color(0.6, 0.4, 0.1)
	mat_soup.emission_energy = 0.6
	soup.material_override = mat_soup
	root_node.add_child(soup)
	
	return root_node

static func create_mesh(placeholder_id: String) -> Spatial:
	match placeholder_id:
		"money_bag":
			return create_money_bag()
		"small_tools":
			return create_small_tools()
		"ammo_pouch":
			return create_ammo_pouch()
		"trinket":
			return create_trinket()
		"apple":
			return create_apple()
		"plum":
			return create_plum()
		"pear":
			return create_pear()
		"orange":
			return create_orange()
		"crimson_poppy":
			return create_crimson_poppy()
		"violet_orchid":
			return create_violet_orchid()
		"sun_marigold":
			return create_sun_marigold()
		"frost_lily":
			return create_frost_lily()
		"potion":
			return create_potion_bottle()
		"stew":
			return create_stew_bowl()
		_:
			return create_apple()
