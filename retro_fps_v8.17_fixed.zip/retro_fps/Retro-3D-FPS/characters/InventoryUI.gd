extends CanvasLayer

# =====================================================================
# INVENTORY UI SYSTEM
# Visual interface for viewing and using inventory items
# =====================================================================

var inventory_manager = null
var is_open = false

# UI Elements
var main_panel = null
var category_buttons = []
var item_list = null
var details_panel = null
var item_name_label = null
var item_desc_label = null
var item_quantity_label = null
var use_button = null
var close_button = null
var header_label = null

# Styling
var panel_style = null
var button_style = null
var button_style_hover = null
var button_style_pressed = null

func _ready():
	layer = 10  # Above everything
	visible = false
	_setup_styles()
	_build_ui()

func init(manager):
	inventory_manager = manager
	if inventory_manager:
		inventory_manager.connect("inventory_changed", self, "_on_inventory_changed")

func _setup_styles():
	# Main panel style (dark semi-transparent)
	panel_style = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.08, 0.08, 0.12, 0.92)
	panel_style.border_color = Color(0.4, 0.6, 0.8, 0.8)
	panel_style.border_width_left = 2
	panel_style.border_width_top = 2
	panel_style.border_width_right = 2
	panel_style.border_width_bottom = 2
	panel_style.corner_radius_top_left = 4
	panel_style.corner_radius_top_right = 4
	panel_style.corner_radius_bottom_right = 4
	panel_style.corner_radius_bottom_left = 4
	panel_style.content_margin_left = 10
	panel_style.content_margin_top = 10
	panel_style.content_margin_right = 10
	panel_style.content_margin_bottom = 10
	
	# Button styles
	button_style = StyleBoxFlat.new()
	button_style.bg_color = Color(0.15, 0.18, 0.25, 0.9)
	button_style.border_color = Color(0.4, 0.5, 0.6, 0.6)
	button_style.border_width_left = 1
	button_style.border_width_top = 1
	button_style.border_width_right = 1
	button_style.border_width_bottom = 1
	button_style.corner_radius_top_left = 3
	button_style.corner_radius_top_right = 3
	button_style.corner_radius_bottom_right = 3
	button_style.corner_radius_bottom_left = 3
	button_style.content_margin_left = 8
	button_style.content_margin_top = 8
	button_style.content_margin_right = 8
	button_style.content_margin_bottom = 8
	
	button_style_hover = button_style.duplicate()
	button_style_hover.bg_color = Color(0.2, 0.25, 0.35, 0.95)
	button_style_hover.border_color = Color(0.5, 0.7, 0.9, 0.8)
	
	button_style_pressed = button_style.duplicate()
	button_style_pressed.bg_color = Color(0.1, 0.15, 0.2, 1.0)

func _build_ui():
	var font_res = load("res://ui/KleintenDynFont.tres")
	
	# Main container (centered)
	var container = Control.new()
	container.name = "InventoryContainer"
	container.anchor_left = 0.5
	container.anchor_top = 0.5
	container.anchor_right = 0.5
	container.anchor_bottom = 0.5
	container.margin_left = -400
	container.margin_top = -300
	container.margin_right = 400
	container.margin_bottom = 300
	add_child(container)
	
	# Main panel
	main_panel = Panel.new()
	main_panel.name = "MainPanel"
	main_panel.anchor_right = 1.0
	main_panel.anchor_bottom = 1.0
	main_panel.add_stylebox_override("panel", panel_style)
	container.add_child(main_panel)
	
	# Header
	header_label = Label.new()
	header_label.name = "Header"
	header_label.anchor_right = 1.0
	header_label.margin_bottom = 40
	header_label.align = Label.ALIGN_CENTER
	header_label.valign = Label.VALIGN_CENTER
	if font_res:
		header_label.add_font_override("font", font_res)
	header_label.text = "INVENTORY"
	header_label.modulate = Color(0.7, 0.85, 1.0, 1.0)
	main_panel.add_child(header_label)
	
	# Category tabs (left side)
	var category_container = VBoxContainer.new()
	category_container.name = "Categories"
	category_container.margin_left = 15
	category_container.margin_top = 60
	category_container.margin_right = 180
	category_container.margin_bottom = 560
	category_container.rect_min_size = Vector2(165, 0)
	main_panel.add_child(category_container)
	
	var categories = [
		{"id": 0, "name": "All Items"},
		{"id": 1, "name": "Valuables"},
		{"id": 2, "name": "Tools"},
		{"id": 3, "name": "Ingredients"},
		{"id": 4, "name": "Consumables"},
		{"id": 5, "name": "Ammo"},
	]
	
	for cat in categories:
		var btn = Button.new()
		btn.text = cat.name
		btn.add_stylebox_override("normal", button_style)
		btn.add_stylebox_override("hover", button_style_hover)
		btn.add_stylebox_override("pressed", button_style_pressed)
		if font_res:
			btn.add_font_override("font", font_res)
		btn.rect_min_size = Vector2(160, 40)
		btn.connect("pressed", self, "_on_category_selected", [cat.id])
		category_container.add_child(btn)
		category_buttons.append(btn)
	
	# Item list (center)
	item_list = ItemList.new()
	item_list.name = "ItemList"
	item_list.margin_left = 195
	item_list.margin_top = 60
	item_list.margin_right = 550
	item_list.margin_bottom = 560
	item_list.max_columns = 1
	item_list.same_column_width = true
	item_list.fixed_icon_size = Vector2(48, 48)
	item_list.icon_scale = 1.0
	if font_res:
		item_list.add_font_override("font", font_res)
	item_list.connect("item_selected", self, "_on_item_selected")
	main_panel.add_child(item_list)
	
	# Details panel (right side)
	details_panel = Panel.new()
	details_panel.name = "DetailsPanel"
	details_panel.margin_left = 565
	details_panel.margin_top = 60
	details_panel.margin_right = 785
	details_panel.margin_bottom = 560
	var details_style = panel_style.duplicate()
	details_style.bg_color = Color(0.1, 0.12, 0.18, 0.85)
	details_panel.add_stylebox_override("panel", details_style)
	main_panel.add_child(details_panel)
	
	# Item name
	item_name_label = Label.new()
	item_name_label.name = "ItemName"
	item_name_label.margin_left = 15
	item_name_label.margin_top = 15
	item_name_label.margin_right = 205
	item_name_label.margin_bottom = 60
	item_name_label.align = Label.ALIGN_CENTER
	item_name_label.valign = Label.VALIGN_CENTER
	if font_res:
		item_name_label.add_font_override("font", font_res)
	item_name_label.text = "Select an item"
	item_name_label.modulate = Color(1.0, 0.9, 0.5, 1.0)
	details_panel.add_child(item_name_label)
	
	# Item quantity
	item_quantity_label = Label.new()
	item_quantity_label.name = "ItemQuantity"
	item_quantity_label.margin_left = 15
	item_quantity_label.margin_top = 65
	item_quantity_label.margin_right = 205
	item_quantity_label.margin_bottom = 95
	item_quantity_label.align = Label.ALIGN_CENTER
	if font_res:
		item_quantity_label.add_font_override("font", font_res)
	item_quantity_label.text = ""
	item_quantity_label.modulate = Color(0.8, 0.9, 1.0, 1.0)
	details_panel.add_child(item_quantity_label)
	
	# Item description
	item_desc_label = Label.new()
	item_desc_label.name = "ItemDesc"
	item_desc_label.margin_left = 15
	item_desc_label.margin_top = 110
	item_desc_label.margin_right = 205
	item_desc_label.margin_bottom = 400
	item_desc_label.autowrap = true
	if font_res:
		item_desc_label.add_font_override("font", font_res)
	item_desc_label.text = ""
	item_desc_label.modulate = Color(0.75, 0.8, 0.85, 1.0)
	details_panel.add_child(item_desc_label)
	
	# Use button
	use_button = Button.new()
	use_button.name = "UseButton"
	use_button.margin_left = 30
	use_button.margin_top = 420
	use_button.margin_right = 190
	use_button.margin_bottom = 470
	use_button.text = "USE"
	use_button.add_stylebox_override("normal", button_style)
	use_button.add_stylebox_override("hover", button_style_hover)
	use_button.add_stylebox_override("pressed", button_style_pressed)
	if font_res:
		use_button.add_font_override("font", font_res)
	use_button.connect("pressed", self, "_on_use_pressed")
	use_button.visible = false
	details_panel.add_child(use_button)
	
	# Close button
	close_button = Button.new()
	close_button.name = "CloseButton"
	close_button.margin_left = 30
	close_button.margin_top = 480
	close_button.margin_right = 190
	close_button.margin_bottom = 530
	close_button.text = "CLOSE [I]"
	close_button.add_stylebox_override("normal", button_style)
	close_button.add_stylebox_override("hover", button_style_hover)
	close_button.add_stylebox_override("pressed", button_style_pressed)
	if font_res:
		close_button.add_font_override("font", font_res)
	close_button.connect("pressed", self, "close")
	details_panel.add_child(close_button)

func open():
	if !inventory_manager:
		return
	is_open = true
	visible = true
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_refresh_item_list()

func close():
	is_open = false
	visible = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func toggle():
	if is_open:
		close()
	else:
		open()

func _on_category_selected(category_id):
	if !inventory_manager:
		return
	inventory_manager.selected_category = category_id
	_refresh_item_list()

func _on_item_selected(index):
	if !inventory_manager:
		return
	
	var items = inventory_manager.get_items_by_category(inventory_manager.selected_category)
	if index >= 0 and index < items.size():
		var item_data = items[index]
		inventory_manager.selected_item_key = item_data.key
		
		item_name_label.text = item_data.data.name
		item_quantity_label.text = "Quantity: " + str(item_data.data.quantity)
		item_desc_label.text = item_data.data.desc
		
		# Show use button if usable
		if inventory_manager.is_usable(item_data.key):
			use_button.visible = true
			use_button.text = "USE " + item_data.data.name
		else:
			use_button.visible = false

func _on_use_pressed():
	if !inventory_manager or inventory_manager.selected_item_key == "":
		return
	
	if inventory_manager.use_item(inventory_manager.selected_item_key):
		# Emit signal for player to handle the effect
		_refresh_item_list()
		_on_item_selected(-1)  # Clear selection

func _on_inventory_changed():
	if is_open:
		_refresh_item_list()

func _refresh_item_list():
	if !item_list or !inventory_manager:
		return
	
	item_list.clear()
	var items = inventory_manager.get_items_by_category(inventory_manager.selected_category)
	
	for item_data in items:
		var item = item_data.data
		# Create icon (colored rectangle)
		var icon_img = Image.new()
		icon_img.create(48, 48, false, Image.FORMAT_RGBA8)
		icon_img.fill(item.icon_color)
		
		# Add border
		for x in range(48):
			icon_img.set_pixel(x, 0, Color(1, 1, 1, 0.5))
			icon_img.set_pixel(x, 47, Color(1, 1, 1, 0.5))
		for y in range(48):
			icon_img.set_pixel(0, y, Color(1, 1, 1, 0.5))
			icon_img.set_pixel(47, y, Color(1, 1, 1, 0.5))
		
		var tex = ImageTexture.new()
		tex.create_from_image(icon_img)
		
		# Add to list
		var display_text = item.name + " (" + str(item.quantity) + ")"
		item_list.add_item(display_text, tex)

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.scancode == KEY_I or event.scancode == KEY_TAB:
			toggle()
			get_tree().set_input_as_handled()
		elif event.scancode == KEY_ESCAPE:
			if is_open:
				close()
				get_tree().set_input_as_handled()
