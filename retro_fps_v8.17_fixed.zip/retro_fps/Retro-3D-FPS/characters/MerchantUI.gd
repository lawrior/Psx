extends CanvasLayer

# =====================================================================
# MERCHANT UI - Buy and Sell Interface
# =====================================================================

var merchant_manager = null
var player_ref = null
var is_open = false

# UI Elements
var main_panel = null
var buy_list = null
var sell_list = null
var details_panel = null
var item_name_label = null
var item_desc_label = null
var item_price_label = null
var buy_button = null
var sell_button = null
var close_button = null
var gold_label = null

var selected_item_key = ""
var selected_is_buying = true

func _ready():
	layer = 10
	visible = false
	_build_ui()

func init(manager, player):
	merchant_manager = manager
	player_ref = player
	if merchant_manager:
		merchant_manager.connect("merchant_opened", self, "_on_merchant_opened")
		merchant_manager.connect("merchant_closed", self, "_on_merchant_closed")
		merchant_manager.connect("transaction_completed", self, "_on_transaction_completed")

func _build_ui():
	var font_res = load("res://ui/KleintenDynFont.tres")
	
	# Main container
	var container = Control.new()
	container.name = "MerchantContainer"
	container.anchor_left = 0.5
	container.anchor_top = 0.5
	container.anchor_right = 0.5
	container.anchor_bottom = 0.5
	container.margin_left = -450
	container.margin_top = -320
	container.margin_right = 450
	container.margin_bottom = 320
	add_child(container)
	
	# Main panel
	main_panel = Panel.new()
	main_panel.name = "MainPanel"
	main_panel.anchor_right = 1.0
	main_panel.anchor_bottom = 1.0
	var panel_style = StyleBoxFlat.new()
	panel_style.bg_color = Color(0.08, 0.08, 0.12, 0.92)
	panel_style.border_color = Color(0.8, 0.6, 0.2, 0.8)
	panel_style.border_width_left = 2
	panel_style.border_width_top = 2
	panel_style.border_width_right = 2
	panel_style.border_width_bottom = 2
	panel_style.corner_radius_top_left = 4
	panel_style.corner_radius_top_right = 4
	panel_style.corner_radius_bottom_right = 4
	panel_style.corner_radius_bottom_left = 4
	panel_style.content_margin_left = 10
	panel_style.content_margin_top = 10
	panel_style.content_margin_right = 10
	panel_style.content_margin_bottom = 10
	main_panel.add_stylebox_override("panel", panel_style)
	container.add_child(main_panel)
	
	# Header
	var header = Label.new()
	header.anchor_right = 1.0
	header.margin_bottom = 40
	header.align = Label.ALIGN_CENTER
	header.valign = Label.VALIGN_CENTER
	if font_res:
		header.add_font_override("font", font_res)
	header.text = "MERCHANT"
	header.modulate = Color(1.0, 0.85, 0.3, 1.0)
	main_panel.add_child(header)
	
	# Gold display
	gold_label = Label.new()
	gold_label.anchor_right = 1.0
	gold_label.margin_top = 45
	gold_label.margin_bottom = 70
	gold_label.align = Label.ALIGN_CENTER
	if font_res:
		gold_label.add_font_override("font", font_res)
	gold_label.text = "Gold: 0"
	gold_label.modulate = Color(1.0, 0.9, 0.4, 1.0)
	main_panel.add_child(gold_label)
	
	# Buy section (left)
	var buy_label = Label.new()
	buy_label.margin_left = 15
	buy_label.margin_top = 80
	buy_label.margin_right = 200
	buy_label.margin_bottom = 100
	if font_res:
		buy_label.add_font_override("font", font_res)
	buy_label.text = "BUY"
	buy_label.modulate = Color(0.4, 0.9, 0.4, 1.0)
	main_panel.add_child(buy_label)
	
	buy_list = ItemList.new()
	buy_list.name = "BuyList"
	buy_list.margin_left = 15
	buy_list.margin_top = 105
	buy_list.margin_right = 420
	buy_list.margin_bottom = 580
	buy_list.max_columns = 1
	if font_res:
		buy_list.add_font_override("font", font_res)
	buy_list.connect("item_selected", self, "_on_buy_item_selected")
	main_panel.add_child(buy_list)
	
	# Sell section (right)
	var sell_label = Label.new()
	sell_label.margin_left = 440
	sell_label.margin_top = 80
	sell_label.margin_right = 625
	sell_label.margin_bottom = 100
	if font_res:
		sell_label.add_font_override("font", font_res)
	sell_label.text = "SELL"
	sell_label.modulate = Color(0.9, 0.4, 0.4, 1.0)
	main_panel.add_child(sell_label)
	
	sell_list = ItemList.new()
	sell_list.name = "SellList"
	sell_list.margin_left = 440
	sell_list.margin_top = 105
	sell_list.margin_right = 865
	sell_list.margin_bottom = 580
	sell_list.max_columns = 1
	if font_res:
		sell_list.add_font_override("font", font_res)
	sell_list.connect("item_selected", self, "_on_sell_item_selected")
	main_panel.add_child(sell_list)
	
	# Details panel (bottom)
	details_panel = Panel.new()
	details_panel.margin_left = 15
	details_panel.margin_top = 590
	details_panel.margin_right = 885
	details_panel.margin_bottom = 625
	var details_style = StyleBoxFlat.new()
	details_style.bg_color = Color(0.1, 0.12, 0.18, 0.85)
	details_style.border_color = Color(0.4, 0.5, 0.6, 0.6)
	details_style.border_width_left = 1
	details_style.border_width_top = 1
	details_style.border_width_right = 1
	details_style.border_width_bottom = 1
	details_panel.add_stylebox_override("panel", details_style)
	main_panel.add_child(details_panel)
	
	# Item details labels
	item_name_label = Label.new()
	item_name_label.margin_left = 10
	item_name_label.margin_top = 5
	item_name_label.margin_right = 300
	item_name_label.margin_bottom = 25
	if font_res:
		item_name_label.add_font_override("font", font_res)
	item_name_label.text = "Select an item"
	item_name_label.modulate = Color(1.0, 0.9, 0.5, 1.0)
	details_panel.add_child(item_name_label)
	
	item_desc_label = Label.new()
	item_desc_label.margin_left = 10
	item_desc_label.margin_top = 25
	item_desc_label.margin_right = 500
	item_desc_label.margin_bottom = 45
	if font_res:
		item_desc_label.add_font_override("font", font_res)
	item_desc_label.text = ""
	item_desc_label.modulate = Color(0.75, 0.8, 0.85, 1.0)
	details_panel.add_child(item_desc_label)
	
	item_price_label = Label.new()
	item_price_label.margin_left = 510
	item_price_label.margin_top = 5
	item_price_label.margin_right = 700
	item_price_label.margin_bottom = 25
	if font_res:
		item_price_label.add_font_override("font", font_res)
	item_price_label.text = ""
	item_price_label.modulate = Color(1.0, 0.9, 0.4, 1.0)
	details_panel.add_child(item_price_label)
	
	# Buttons
	var button_style = StyleBoxFlat.new()
	button_style.bg_color = Color(0.15, 0.18, 0.25, 0.9)
	button_style.border_color = Color(0.4, 0.5, 0.6, 0.6)
	button_style.border_width_left = 1
	button_style.border_width_top = 1
	button_style.border_width_right = 1
	button_style.border_width_bottom = 1
	button_style.corner_radius_top_left = 3
	button_style.corner_radius_top_right = 3
	button_style.corner_radius_bottom_right = 3
	button_style.corner_radius_bottom_left = 3
	button_style.content_margin_left = 8
	button_style.content_margin_top = 8
	button_style.content_margin_right = 8
	button_style.content_margin_bottom = 8
	
	buy_button = Button.new()
	buy_button.margin_left = 710
	buy_button.margin_top = 5
	buy_button.margin_right = 790
	buy_button.margin_bottom = 35
	buy_button.text = "BUY"
	buy_button.add_stylebox_override("normal", button_style)
	if font_res:
		buy_button.add_font_override("font", font_res)
	buy_button.connect("pressed", self, "_on_buy_pressed")
	buy_button.visible = false
	details_panel.add_child(buy_button)
	
	sell_button = Button.new()
	sell_button.margin_left = 710
	sell_button.margin_top = 5
	sell_button.margin_right = 790
	sell_button.margin_bottom = 35
	sell_button.text = "SELL"
	sell_button.add_stylebox_override("normal", button_style)
	if font_res:
		sell_button.add_font_override("font", font_res)
	sell_button.connect("pressed", self, "_on_sell_pressed")
	sell_button.visible = false
	details_panel.add_child(sell_button)
	
	close_button = Button.new()
	close_button.margin_left = 800
	close_button.margin_top = 5
	close_button.margin_right = 880
	close_button.margin_bottom = 35
	close_button.text = "CLOSE"
	close_button.add_stylebox_override("normal", button_style)
	if font_res:
		close_button.add_font_override("font", font_res)
	close_button.connect("pressed", self, "close")
	details_panel.add_child(close_button)

func open():
	if !merchant_manager or !player_ref:
		return
	is_open = true
	visible = true
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_refresh_lists()

func close():
	is_open = false
	visible = false
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	if merchant_manager:
		merchant_manager.close_merchant()

func _refresh_lists():
	if !merchant_manager or !player_ref:
		return
	
	# Update gold display
	gold_label.text = "Gold: " + str(player_ref.gold)
	
	# Clear lists
	buy_list.clear()
	sell_list.clear()
	
	# Populate buy list
	var stock = merchant_manager.get_stock_list()
	for item in stock:
		if item["quantity"] > 0:
			var text = item["name"] + " - " + str(item["price"]) + "g (x" + str(item["quantity"]) + ")"
			buy_list.add_item(text)
	
	# Populate sell list
	if player_ref.inventory_manager:
		var player_items = player_ref.inventory_manager.get_all_items()
		for item_key in player_items:
			var item_data = player_items[item_key]
			if item_data["quantity"] > 0:
				var sell_price = merchant_manager.get_sell_price(item_key)
				if sell_price > 0:
					var text = item_data["name"] + " - " + str(sell_price) + "g (x" + str(item_data["quantity"]) + ")"
					sell_list.add_item(text)

func _on_buy_item_selected(index):
	if !merchant_manager:
		return
	
	var stock = merchant_manager.get_stock_list()
	var buyable_items = []
	for item in stock:
		if item["quantity"] > 0:
			buyable_items.append(item)
	
	if index >= 0 and index < buyable_items.size():
		var item = buyable_items[index]
		selected_item_key = item["key"]
		selected_is_buying = true
		
		item_name_label.text = item["name"]
		item_desc_label.text = item.get("desc", "")
		item_price_label.text = "Price: " + str(item["price"]) + "g"
		
		buy_button.visible = true
		sell_button.visible = false
		
		var can_afford = merchant_manager.can_buy(item["key"], player_ref.gold)
		buy_button.disabled = !can_afford

func _on_sell_item_selected(index):
	if !merchant_manager or !player_ref.inventory_manager:
		return
	
	var player_items = player_ref.inventory_manager.get_all_items()
	var sellable_items = []
	for item_key in player_items:
		var item_data = player_items[item_key]
		if item_data["quantity"] > 0:
			var sell_price = merchant_manager.get_sell_price(item_key)
			if sell_price > 0:
				sellable_items.append({"key": item_key, "data": item_data, "price": sell_price})
	
	if index >= 0 and index < sellable_items.size():
		var item = sellable_items[index]
		selected_item_key = item["key"]
		selected_is_buying = false
		
		item_name_label.text = item["data"]["name"]
		item_desc_label.text = item["data"].get("desc", "")
		item_price_label.text = "Sell: " + str(item["price"]) + "g"
		
		buy_button.visible = false
		sell_button.visible = true

func _on_buy_pressed():
	if !merchant_manager or selected_item_key == "":
		return
	
	if merchant_manager.buy_item(selected_item_key, player_ref):
		_refresh_lists()
		_clear_selection()

func _on_sell_pressed():
	if !merchant_manager or selected_item_key == "":
		return
	
	if merchant_manager.sell_item(selected_item_key, player_ref, merchant_manager.current_merchant):
		_refresh_lists()
		_clear_selection()

func _clear_selection():
	selected_item_key = ""
	item_name_label.text = "Select an item"
	item_desc_label.text = ""
	item_price_label.text = ""
	buy_button.visible = false
	sell_button.visible = false

func _on_merchant_opened():
	open()

func _on_merchant_closed():
	close()

func _on_transaction_completed(_item_key, _amount, _is_buying):
	_refresh_lists()

func _input(event):
	if event is InputEventKey and event.pressed:
		if event.scancode == KEY_ESCAPE and is_open:
			close()
			get_tree().set_input_as_handled()
