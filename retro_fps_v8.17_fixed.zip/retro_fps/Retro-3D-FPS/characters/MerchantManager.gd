extends Node

# =====================================================================
# MERCHANT SYSTEM - Buy and Sell Items
# =====================================================================

signal transaction_completed(item_key, amount, is_buying)
signal merchant_opened
signal merchant_closed

var is_open = false
var current_merchant = null
var merchant_inventory = {}

# Merchant stock - items available for purchase
var merchant_stock = {
	# Weapons
	"weapon_machete": {"name": "Machete", "price": 150, "category": "weapons", "desc": "Sharp blade for close combat"},
	"weapon_machinegun": {"name": "Machine Gun", "price": 400, "category": "weapons", "desc": "Rapid-fire automatic weapon"},
	"weapon_shotgun": {"name": "Shotgun", "price": 350, "category": "weapons", "desc": "Devastating at close range"},
	"weapon_rocketlauncher": {"name": "Rocket Launcher", "price": 800, "category": "weapons", "desc": "Explosive ordnance"},
	
	# Ammo
	"ammo_machinegun": {"name": "Machine Gun Ammo", "price": 30, "category": "ammo", "desc": "50 rounds", "amount": 50},
	"ammo_shotgun": {"name": "Shotgun Shells", "price": 40, "category": "ammo", "desc": "20 shells", "amount": 20},
	"ammo_rocket": {"name": "Rockets", "price": 100, "category": "ammo", "desc": "5 rockets", "amount": 5},
	
	# Health
	"health_small": {"name": "Small Health Pack", "price": 50, "category": "health", "desc": "Restores 25 HP", "heal": 25},
	"health_large": {"name": "Large Health Pack", "price": 120, "category": "health", "desc": "Restores 75 HP", "heal": 75},
	
	# Tools
	"tool_lockpick": {"name": "Lockpick Set", "price": 80, "category": "tools", "desc": "For opening locked containers"},
	"tool_repair": {"name": "Repair Kit", "price": 100, "category": "tools", "desc": "Fixes equipment"},
}

# Sell prices (percentage of buy price)
var sell_multiplier = 0.5  # 50% of buy price

func _ready():
	# Initialize merchant inventory from stock
	for item_key in merchant_stock:
		merchant_inventory[item_key] = merchant_stock[item_key].duplicate()
		merchant_inventory[item_key]["quantity"] = 10  # Default stock

func open_merchant(merchant_node = null):
	if is_open:
		return
	is_open = true
	current_merchant = merchant_node
	emit_signal("merchant_opened")

func close_merchant():
	if !is_open:
		return
	is_open = false
	current_merchant = null
	emit_signal("merchant_closed")

func get_stock_list() -> Array:
	var items = []
	for key in merchant_inventory:
		var item = merchant_inventory[key].duplicate()
		item["key"] = key
		items.append(item)
	return items

func get_sell_price(item_key: String) -> int:
	# If item is in merchant stock, use 50% of buy price
	if merchant_stock.has(item_key):
		return int(merchant_stock[item_key]["price"] * sell_multiplier)
	
	# Default sell prices for items not in stock
	var default_prices = {
		# Ingredients
		"apple": 15,
		"plum": 18,
		"pear": 20,
		"poppy": 12,
		"orchid": 25,
		"marigold": 15,
		"lily": 30,
		# Stolen items
		"gold": 1,  # Gold can't really be sold, but just in case
		"trinkets": 40,
		"tools": 35,
		# Consumables (player-made)
		"vitality_elixir": 60,
		"haste_elixir": 70,
		"shadow_draught": 65,
		"frost_draught": 80,
		"compote": 45,
		"ambrosia_stew": 150,
	}
	
	if default_prices.has(item_key):
		return default_prices[item_key]
	
	# Unknown items get a base price of 5g
	return 5

func can_buy(item_key: String, player_gold: int) -> bool:
	if !merchant_inventory.has(item_key):
		return false
	if merchant_inventory[item_key]["quantity"] <= 0:
		return false
	if player_gold < merchant_inventory[item_key]["price"]:
		return false
	return true

func buy_item(item_key: String, player) -> bool:
	if !can_buy(item_key, player.gold):
		return false
	
	var item = merchant_inventory[item_key]
	player.add_gold(-item["price"])
	merchant_inventory[item_key]["quantity"] -= 1
	
	# Apply item effects
	_apply_item_effect(item_key, item, player)
	
	emit_signal("transaction_completed", item_key, 1, true)
	return true

func sell_item(item_key: String, player, merchant_node = null) -> bool:
	var sell_price = get_sell_price(item_key)
	if sell_price <= 0:
		return false
	
	# Check if player has the item
	var has_item = false
	var quantity = 0
	
	# Check inventory
	if player.inventory_manager:
		quantity = player.inventory_manager.get_item_quantity(item_key)
		has_item = quantity > 0
	
	if !has_item:
		return false
	
	# Create visual transfer effect
	if merchant_node and is_instance_valid(merchant_node):
		_create_sell_transfer(item_key, player, merchant_node)
	
	# Remove item from player inventory
	if player.inventory_manager:
		player.inventory_manager.remove_item(item_key, 1)
	
	# Add gold
	player.add_gold(sell_price)
	
	# Add back to merchant stock
	if merchant_inventory.has(item_key):
		merchant_inventory[item_key]["quantity"] += 1
	
	emit_signal("transaction_completed", item_key, 1, false)
	return true

func _create_sell_transfer(item_key: String, player, merchant_node):
	# Create a visual item transfer from player to merchant
	var ItemTransferVisual = preload("res://characters/ItemTransferVisual.gd")
	var transfer = ItemTransferVisual.new()
	player.get_tree().current_scene.add_child(transfer)
	
	# Get item name from inventory or use key
	var item_name = item_key
	if player.inventory_manager:
		var items = player.inventory_manager.get_all_items()
		if items.has(item_key):
			item_name = items[item_key].get("name", item_key)
	
	# Map item_key to placeholder_id for proper 3D models
	var placeholder_id = item_key
	match item_key:
		"poppy":
			placeholder_id = "crimson_poppy"
		"orchid":
			placeholder_id = "violet_orchid"
		"marigold":
			placeholder_id = "sun_marigold"
		"lily":
			placeholder_id = "frost_lily"
		"vitality_elixir", "haste_elixir":
			placeholder_id = "potion"
		"shadow_draught", "frost_draught":
			placeholder_id = "potion"
		"ambrosia_stew":
			placeholder_id = "stew"
		"trinkets":
			placeholder_id = "trinket"
		"tools":
			placeholder_id = "small_tools"
	
	var item_data = {
		"name": item_name,
		"desc": "Sold item",
		"type": "sold_item",
		"placeholder_id": placeholder_id,
		"start_pos": player.global_transform.origin + Vector3(0, 1.0, 0)
	}
	
	# Transfer to merchant's table location
	var target_pos = merchant_node.global_transform.origin + Vector3(0.5, 0.8, 0)  # On the table
	transfer.setup(item_data.start_pos, merchant_node, item_data, funcref(self, "_on_sell_transfer_complete"), false, null)

func _apply_item_effect(item_key: String, item: Dictionary, player):
	var category = item.get("category", "")
	
	match category:
		"health":
			var heal_amount = item.get("heal", 0)
			if heal_amount > 0:
				player.heal(heal_amount)
		
		"ammo":
			var ammo_amount = item.get("amount", 0)
			if ammo_amount > 0:
				# Map to weapon types
				match item_key:
					"ammo_machinegun":
						player.weapon_manager.add_ammo("machinegun", ammo_amount)
					"ammo_shotgun":
						player.weapon_manager.add_ammo("shotgun", ammo_amount)
					"ammo_rocket":
						player.weapon_manager.add_ammo("rocketlauncher", ammo_amount)
		
		"weapons":
			# Weapons are picked up as pickups
			pass
		
		"tools":
			# Add to inventory
			if player.inventory_manager:
				player.inventory_manager.add_item(item_key, 1)

func restock():
	# Restock all items
	for item_key in merchant_inventory:
		merchant_inventory[item_key]["quantity"] = 10

func _on_sell_transfer_complete(item_data: Dictionary):
	# Item transfer visual complete - create a dropped item on merchant's table
	var DroppedLootItem = preload("res://characters/DroppedLootItem.gd")
	var dropped = DroppedLootItem.new()
	
	# Position on merchant's table
	var merchant = current_merchant
	if merchant:
		var table_pos = merchant.global_transform.origin + Vector3(0.5, 0.8, 0)
		dropped.global_transform.origin = table_pos
		get_tree().current_scene.add_child(dropped)
		dropped.setup(item_data)
