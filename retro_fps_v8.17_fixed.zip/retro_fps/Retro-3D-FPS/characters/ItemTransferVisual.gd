extends Spatial

const ItemMeshFactory = preload("res://characters/ItemMeshFactory.gd")
const DroppedLootItem = preload("res://characters/DroppedLootItem.gd")

var start_pos : Vector3
var target_player = null
var target_npc = null
var duration : float = 0.45
var elapsed : float = 0.0
var item_data : Dictionary = {}
var on_complete_func = null
var arc_height : float = 0.35
var completed : bool = false
var is_fumble : bool = false

func setup(p_start: Vector3, p_player, p_item: Dictionary, p_on_complete: FuncRef, p_is_fumble: bool = false, p_npc = null):
	start_pos = p_start
	target_player = p_player
	item_data = p_item
	on_complete_func = p_on_complete
	is_fumble = p_is_fumble
	target_npc = p_npc
	global_transform.origin = p_start
	
	var ph_id = p_item.get("placeholder_id", "money_bag")
	var mesh_node = ItemMeshFactory.create_mesh(ph_id)
	if mesh_node:
		add_child(mesh_node)

func _process(delta):
	if completed:
		return
		
	elapsed += delta
	var t = clamp(elapsed / duration, 0.0, 1.0)
	var ease_t = t * t * (3.0 - 2.0 * t) # smoothstep
	
	# Check midway fumble (item slips and drops to the ground)
	if is_fumble and t >= 0.5:
		trigger_fumble()
		return
	
	var dest_pos = start_pos + Vector3(0, 1, 0)
	if is_instance_valid(target_player):
		# Check if target has a camera property
		if "camera" in target_player and target_player.camera:
			var cam = target_player.camera
			dest_pos = cam.global_transform.origin - cam.global_transform.basis.z * 0.45 - cam.global_transform.basis.y * 0.15
		else:
			# Target doesn't have camera, use target's position
			dest_pos = target_player.global_transform.origin + Vector3(0, 0.5, 0)
	
	var cur_pos = start_pos.linear_interpolate(dest_pos, ease_t)
	cur_pos.y += sin(t * PI) * arc_height
	global_transform.origin = cur_pos
	
	rotate_y(deg2rad(400.0) * delta)
	rotate_x(deg2rad(200.0) * delta)
	
	var cur_scale = lerp(1.1, 0.55, t)
	scale = Vector3(cur_scale, cur_scale, cur_scale)
	
	if t >= 1.0 and !completed:
		completed = true
		if on_complete_func:
			on_complete_func.call_func(item_data)
		queue_free()

func trigger_fumble():
	completed = true
	var drop_pos = global_transform.origin
	var dropped_item = DroppedLootItem.new()
	get_tree().current_scene.add_child(dropped_item)
	dropped_item.setup(drop_pos, item_data)
	
	# 50% chance the enemy detects you then!
	var detected = randf() < 0.5
	var n_name = item_data.get("npc_source", "NPC")
	
	if is_instance_valid(target_npc) and !target_npc.is_dead():
		if detected:
			target_npc.catch_fumbled_item(target_player)
			if is_instance_valid(target_player):
				target_player.show_banner("⚠ FUMBLE! " + item_data.name + " dropped & " + n_name + " heard the noise!", Color(1.0, 0.3, 0.2, 1.0), 4.0)
				if target_player.pickup_info:
					target_player.pickup_info.add_custom_info("Fumbled " + item_data.name + " - " + n_name + " HEARD the drop!")
		else:
			# NPC did not notice! Murmur
			var murmurs = [
				"Thought I heard something drop... must be mice.",
				"Did a coin just roll? Bah, nothing.",
				"Felt a draft... probably just the wind."
			]
			target_npc.show_bark(murmurs[randi() % murmurs.size()], 2.5)
			if is_instance_valid(target_player):
				target_player.show_banner("⚠ FUMBLE! " + item_data.name + " dropped to ground! Pick it up before you're seen!", Color(1.0, 0.85, 0.2, 1.0), 4.5)
				if target_player.pickup_info:
					target_player.pickup_info.add_custom_info("Fumbled " + item_data.name + " to the ground! Undetected - Pick it up!")
	else:
		if is_instance_valid(target_player):
			target_player.show_banner("⚠ Item slipped and dropped to the ground! Pick it up.", Color(1.0, 0.85, 0.2, 1.0), 3.5)
			
	queue_free()
