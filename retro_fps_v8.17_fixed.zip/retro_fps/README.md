# Retro 3D FPS - Stealth, Pickpocket & Living NPC Edition

An expanded retro 3D FPS built in Godot Engine featuring peaceful living NPCs, attention & interest dynamics, sneaking mechanics, physical 3D item placeholders on NPC bodies, camera midpoint pickpocket targeting with dynamic glow/outline feedback (closeness white glow, precise focus golden glow), dedicated stealing `[F]` and interaction `[E]` controls, visual 3D item transfers, realistic pickpocket failure & loot fumble drop mechanics, floor loot golden outline aiming feedback, and a stutter-free zero-compilation shader architecture.

---

## Key Features

### 1. Camera Midpoint Pickpocketing & Precision Targeting
Pickpocketing targets **the exact item the player is looking at** near the camera midpoint/crosshair:
- **Individual Item Targeting**: Instead of popping from an abstract list, the player aims their view at any of the distinct items attached to an NPC's body (e.g. Small Money Bag on right hip, Small Tools on left hip, Ammo Pouch on back waist, Trinket on rear-right waist).
- **Steal with `[F]`**: Pressing `[F]` steals the specific targeted item!
  - Aiming at the Small Money Bag -> steals the Money Bag (+50 Gold)!
  - Aiming at the Small Tools -> steals the Tools (+1 Toolbelt item, +40 Value)!
  - Aiming at the Ammo Pouch -> steals the ammunition cartridges!
- **Dynamic HUD Feedback**:
  - The HUD updates in real-time with the name and description of the item in the crosshairs:
    `[ F ] Steal: Small Money Bag [GOLD FOCUS ★] (Silent - 99% Success, 1% Risk)`
    `[ F ] Steal: Small Tools & Lockpicks [GOLD FOCUS ★] (Silent - 80% Success, 20% Fumble Risk)`

---

### 2. Closeness White Outline & Precise Focus Golden Glow
All pickpocketable 3D items feature an inverted-hull outline and emission highlight system (`ItemMeshFactory.apply_highlight`):
- **Closeness Threshold (<= 3.2m)**:
  - When the player is within pickpocketing reach of an NPC, all reachable items on their body light up with a **subtle, clean White Outline and soft white emission glow** (`HIGHLIGHT_CLOSE`).
  - This immediately signals to the player that items are within reach and eligible for theft.
- **Precise Focus (Camera Midpoint Alignment)**:
  - When the player directs their crosshair / camera center precisely towards an item (`dot >= 0.94`, within ~20° of camera gaze vector), that specific item's outline and glow transition into a **radiant, vibrant Golden Outline and warm golden emission** (`HIGHLIGHT_FOCUSED`).
  - Other nearby items on the body remain illuminated with the soft white outline.
  - As the player sweeps their gaze from one item to another (e.g., from the Money Bag on the right hip to the Small Tools on the left hip), the golden highlight smoothly tracks to the new targeted item while the previous item reverts to white.
- **Distance Exit (> 3.2m)**:
  - When moving away, all item highlights automatically turn off (`HIGHLIGHT_NONE`).

---

### 3. Dropped Floor Loot Golden Edges & Ground Targeting
When an item failure drops loot onto the floor:
- **Closeness White Outline**: When within pickup reach (<= 3.8m), the dropped loot displays a soft white outline and gentle floating bob.
- **Golden Edges on Look-At**:
  - Directing your crosshairs / camera midpoint directly at the dropped item on the floor (`dot >= 0.88`, line-of-sight clear) causes its edges to transition into **radiant golden edges** (`HIGHLIGHT_FOCUSED`)!
  - The HUD prompt immediately turns gleaming gold:
    `[ E / F ] Retrieve Dropped: Small Money Bag (50 Gold) [GOLD FOCUS ★]`
  - Looking away smoothly reverts the item to the white outline, and moving away turns it off cleanly.
- **Retrieval**: Pressing **`[E]`** or **`[F]`** while aiming at it (or walking directly over it) collects the dropped item into your inventory.

---

### 3. Dropped Floor Loot Golden Edges & Ground Targeting
When an item failure drops loot onto the floor:
- **Closeness White Outline**: When within pickup reach (<= 3.8m), the dropped loot displays a soft white outline and gentle floating bob.
- **Golden Edges on Look-At**:
  - Directing your crosshairs / camera midpoint directly at the dropped item on the floor (`dot >= 0.88`, line-of-sight clear) causes its edges to transition into **radiant golden edges** (`HIGHLIGHT_FOCUSED`)!
  - The HUD prompt immediately turns gleaming gold:
    `[ E / F ] Retrieve Dropped: Small Money Bag (50 Gold) [GOLD FOCUS ★]`
  - Looking away smoothly reverts the item to the white outline, and moving away turns it off cleanly.
- **Retrieval**: Pressing **`[E]`** or **`[F]`** while aiming at it (or walking directly over it) collects the dropped item into your inventory.

---

### 4. Fruit Trees, Flowerbed & Foraging System (Update 6)
The world now features living vegetation and harvestable resources complete with dynamic white/golden highlight targeting and 3D parabolic transfer animations:
- **Diverse Fruit Trees (`FruitTree.tscn` / `FruitTree.gd`)**:
  - **Apple Tree**: Spawns procedural crimson **Crisp Orchard Apples** (`apple`) hanging among the canopy leaves with stems and green leaf accents.
  - **Plum Tree**: Spawns deep purple/indigo **Sugar Plums** (`plum`) nestled across the branches.
  - **Pear Tree**: Spawns tapered golden-green **Sweet Orchard Pears** (`pear`).
  - Trees feature realistic organic bark texturing and multi-volume foliage canopies.
- **Ornamental Flowerbed (`Flowerbed.tscn` / `Flowerbed.gd`)**:
  - Set within a rustic timber planter box with dark loam soil.
  - Spawns an assortment of wild blossoms with vibrant petals and central stems:
    - **Crimson Wild Poppy** (ruby red petals with dark pistil)
    - **Violet Night Orchid** (glowing amethyst petals with golden pistil)
    - **Sunburst Marigold** (radiant warm amber/yellow petals)
    - **Frost Meadow Lily** (crystalline cyan/ice-blue petals)
- **Interactive Foraging & Golden Focus Targeting**:
  - As you approach trees or the flowerbed (within 3.5m), fruits and blossoms ignite with a **soft white glow/outline** (`HIGHLIGHT_CLOSE`).
  - Aiming directly at any specific fruit or blossom transitions it into a **gleaming golden outline** (`[GOLD FOCUS ★]`).
  - Pressing **`[E]`** or **`[F]`** picks the item! The blossom or fruit detaches, smoothly arcing through 3D space directly toward your hands and tucking into your **Pantry Bag**.
  - The HUD displays your collected ingredient count in real-time (`Pantry: X items`).

---

### 5. Witch Base & Cauldron Cooking System (Update 6)
Hidden in the forest corner stands a mystical **Witch Base** (`WitchBase.tscn`) and interactive **Cooking Cauldron** (`WitchCauldron.tscn`):
- **Witch Base Architecture**:
  - Crafted from sturdy timber posts, roof beams, and a thick thatched pitched roof.
  - Features an **Alchemy Workstation** with wooden trestles, glass potion decanters, scrolls, and a floating, radiant violet arcane orb casting eerie ambient illumination.
- **Interactive Witch Cauldron**:
  - Centered atop an elevated stone fire hearth surrounded by glowing, crackling embers.
  - Heavy cast iron kettle filled with bubbling magical liquid that dynamically bobs, swirls, and blends colors depending on the ingredients added!
- **Ingredient Adding & Brewing Controls**:
  - Step up to the cauldron and target it (glowing with golden focus edges).
  - Press **`[E]`** to add ingredients from your pantry one by one into the brew. The cauldron accepts up to 3 ingredients at once, updates its overhead status billboard, and blends the liquid color to reflect the concoction.
  - Press **`[F]`** to **Stir & Cook**! Steam bubbles burst, the mixture brews, and the finished 3D item (e.g., an ornate glass Potion Bottle or hearty Stew Bowl) lifts into the air and arcs to your hands!
- **Alchemy Recipes & Player Buffs**:
  - **Witch's Vitality Elixir** (*Fruit + Flower*): Restores +20 HP, permanently increases Max HP, and sells for +50 Gold.
  - **Haste Tonic** (*Orchid + Fruit*): Grants the **[HASTE SPEED]** buff (+40% movement speed for 30s) and +45 Gold.
  - **Shadow Veil Draught** (*Poppy + Orchid*): Grants the **[SHADOW VEIL]** buff (absolute silent footsteps and 50% reduced enemy detection radius for 35s) and +60 Gold.
  - **Forest Herb Medley / Stew** (*Multiple Flowers or Fruits*): Restores +15 HP, boosts weapon damage, and grants +35 Gold.
  - **Ambrosia of the Ancients** (*3 Unique Ingredients*): Massive brew granting +40 HP, +100 Gold, and dual speed/stealth empowerment!
  - Active buffs are tracked with real-time countdown timers displayed on the top HUD.

---

### 6. Zero-Stutter Material & Shader Architecture (Lag Fix)
**Root Cause of Stutter**:
1. Previous code created a new `SpatialMaterial.new()` instance on every highlight mode switch, preventing shader reuse.
2. Dynamically toggling `mat.emission_enabled` between `false` and `true` forced the graphics driver to recompile 15–30 GLSL shader pipelines in a single frame when first stepping within reach of an NPC.
3. Every frame scanned all NPCs across the entire map with matrix lookups and raycasts.

**Engine Optimizations & Fixes Applied**:
- **Pre-Compiled Shared Resources**: Created dedicated `.tres` material resources (`res://characters/WhiteOutlineMat.tres` and `res://characters/GoldOutlineMat.tres`) preloaded at script load time. All meshes share these exact instances without any runtime allocations.
- **Pre-Enabled Base Emission**: All item submesh materials are created with `emission_enabled = true` from game startup with `emission_energy = 0.0`. Toggling highlight modes is now purely uniform updates (`mat.emission = ...`, `mat.emission_energy = ...`), requiring **zero shader recompilation** on the GPU.
- **Startup Shader Warmup**: `ItemMeshFactory.warmup(self)` runs during `Player._ready()` on Frame 1, executing a 1-frame micro-draw that forces the OpenGL driver to compile and cache all outline passes before gameplay starts.
- **Spatial Pruning**: Scanning skips distant NPCs (> 4.5m) and suppresses raycasts for items behind the camera gaze (`dot <= -0.1`), eliminating wasted CPU physics cycles.

---

### 5. Pickpocket Failure Mechanics & Scaling Risk Curve
Even when perfectly undetected behind an NPC, pickpocketing carries realistic tension and failure probabilities:
- **Base 1% Failure Chance**: Even on the very first theft with optimal sneaking conditions, there is a 1% chance of fumble/failure.
- **Scaling Risk Curve**: With every item successfully stolen, NPC vigilance rises and pockets become riskier:
  - **0 items stolen**: 1% failure chance (99% success rate)
  - **1 item stolen**: 6% failure chance (94% success rate)
  - **2 items stolen**: 12% failure chance (88% success rate)
  - **3 items stolen**: 20% failure chance (80% success rate)
  - **4 items stolen**: 30% failure chance (70% success rate)
  - **5+ items stolen**: 40%+ failure chance
- **Dual Failure Modes**:
  1. **Midway Transfer Fumble & Floor Drop (~55% of failures)**:
     - The item lifts off the NPC and begins flying towards the player.
     - **Halfway through the arc transfer**, the item slips from greasy/nervous fingers and tumbles to the ground!
     - A 3D physics item (`DroppedLootItem.gd`) spawns in mid-air, tumbles with gravity, and bounces onto the floor.
     - **50% NPC Detection Roll**:
       - **50% Heard/Caught**: The NPC hears the metallic clatter/thud, immediately whirls around in `ALERTED` state, and barks (*"What was that clatter behind me?! Hey! That's mine!"*).
       - **50% Unnoticed**: The NPC remains oblivious (*"Hmm? Must have been the wind..."*).
     - **Dropped Item Retrieval**: If the NPC does not detect you (or if you escape and sneak back), the dropped item rests on the floor with golden edges on look-at. The player can target it and press **`[E]`** / **`[F]`** to pick it up, or simply **walk directly over it** to collect it!
  2. **Immediate Detection Catch (~45% of failures)**:
     - As the player reaches for the pocket, the NPC instantly catches the movement before the item can be lifted.
     - The NPC spins around enraged into `ALERTED` state (*"Hands off! Did you think I wouldn't feel that?!"*). The item remains safely on the NPC's belt.

---

### 6. Dedicated Interaction `[E]` & Stealing `[F]` Controls
- **Steal / Pickpocket (`[F]`)**:
  - **When Sneaking Behind (`[C]` crouched)**: High success rate governed by the scaling risk curve (e.g. 99% for first item, 80% after 3 items).
  - **When Standing Behind**: Uncrouched theft increases baseline failure risk significantly (50% base risk).
  - **When in Front of NPC**: Stealing directly to their face triggers immediate discovery and rage (*"Are you trying to rob me to my face?!"*).
  - **Looting Corpses**: Remaining items on deceased NPCs can be individually targeted with the crosshair (white/gold outline) and looted one by one with `[F]`.
- **Interact / Talk / Tap Shoulder (`[E]`)**:
  - **Interacting When Undetected / Behind**: If the player is behind an NPC and undetected, pressing `[E]` interacts with them (e.g. tapping shoulder or hailing). This **naturally causes the NPC to notice and detect the player**! The NPC immediately whirls around startled (*"Whoa! Don't sneak up behind me like that! You startled me!"* or *"Gah! Don't creep up behind a merchant! State your business!"*), enters `AWARE` state, and switches player stealth status to **`[! DETECTED]`**.
  - **Interacting In Front**: Friendly conversation and merchant dialogue.
  - **Interacting with Dropped Loot**: Looking at a fumbled item on the ground and pressing `[E]` retrieves it safely.

---

### 7. 3D Visual Item Placeholders on Enemies' Bodies
NPCs physically carry visible 3D item models attached to their skeleton's hip bone (`Armature/Skeleton/Hip`):
- **Small Money Bag (`ItemMeshFactory.create_money_bag`)**: Cloth pouch in rich burgundy/red with a golden cinch ring, ruffled top, and dangling gold coin medallion on the **right hip**.
- **Small Tools & Lockpicks (`ItemMeshFactory.create_small_tools`)**: Leather holster carrying miniature chrome steel wrench jaws and a brass lockpick shaft with pommel on the **left hip**.
- **Ammo Pouch (`ItemMeshFactory.create_ammo_pouch`)**: Canvas cartridge box with dark leather flap and polished brass buckle on the **rear waist**.
- **Valuable Trinket (`ItemMeshFactory.create_trinket`)**: Polished gold medallion / pocket watch disc with chain loop and gem inlay on the **rear-right waist**.

All 3D placeholders sway and animate naturally with the NPC's walking and idle animation cycles.

---

### 8. Attention Decay, "Losing Interest" & Getting Back to Business
- **Distance Decay**: Moving farther away (> 4.5m) causes NPCs to lose interest after ~2.5s and turn back to their wares/post.
- **Idle Bystander Decay**: Standing still nearby (1.6m – 4.5m) without interacting causes NPCs to lose interest after ~2.5s and turn back to their work.
- **Window of Opportunity**: Once the NPC turns back, their back is turned for sneaking with `[C]` and stealing with `[F]`.

---

### 9. Animal Transformation System (Update 7)
Press **[Z]**, **[X]**, or **[V]** to morph into an animal form. Each form switches to a **third-person camera** with unique locomotion and physics.

#### 🐟 Fish Form `[Z]`
- **Swimming**: WASD moves through water. **Space** ascends, **C** dives.
- **Water Detection**: A pond area in the world contains swimmable water. Inside water, the fish swims freely in 3D with neutral buoyancy.
- **Flopping**: Outside of water, the fish flops on the ground with gravity and limited movement.
- **Animation**: The body undulates and the tail fin sways side to side. The fish pitches up/down with vertical movement and banks into turns.
- **Camera**: Third-person follow camera positioned behind and slightly above.

#### 🦅 Bird Form `[X]`
- **Flying**: WASD controls flight direction. **Space** flaps wings to ascend. **C** dives.
- **Glide Physics**: When not flapping, the bird gently descends with reduced gravity. Hold Space continuously to gain altitude.
- **Altitude**: The HUD shows current altitude. Soar over the entire map!
- **Animation**: Wings flap rapidly when ascending, fold gently when gliding. The body banks into turns and pitches with vertical speed.
- **Camera**: Third-person follow camera positioned behind and well above for a wide aerial view.

#### 🐱 Cat Form `[V]`
- **Quadruped Running**: WASD moves on all fours at nearly **2x human speed** (18 m/s).
- **High Jump**: **Space** launches the cat to extraordinary heights (19 units of jump force — 2.5x human jump).
- **Animation**: Legs animate in a realistic trotting gait. The tail sways lazily. The body bobs with running speed. Orange tabby fur with green eyes and dark stripes.
- **Camera**: Low third-person follow camera positioned behind at cat eye level.

#### Reverting
- Press **[B]** at any time to revert to Human Form.
- Pressing the same form key again also toggles back to human.
- When reverting, the first-person camera and all weapons/interactions are restored.

#### Stealth in Animal Form
- NPCs do not recognize animal forms — you are effectively **disguised**.
- The cat is very quiet, the bird is silent while flying, and the fish makes no sound in water.

---

### 10. Inventory System (Update 8)
A comprehensive inventory system to manage all collected items, ingredients, and consumables.

#### Opening Inventory
- Press **I** or **Tab** to open/close the inventory panel
- The game continues running while inventory is open (no pause)
- Mouse cursor becomes visible for UI interaction

#### Item Categories
- **All Items**: Shows everything in your inventory
- **Valuables**: Gold coins, trinkets, and precious items
- **Tools**: Lockpicks, tools, and utility items
- **Ingredients**: Fruits and flowers for cooking
- **Consumables**: Potions, elixirs, and stews from the witch's cauldron
- **Ammo**: Bullets, shells, and rockets

#### Using Items
- Select an item from the list to view details
- Consumable items show a **USE** button
- Click **USE** to consume the item and apply its effects
- Effects include healing, buffs, gold, and stat bonuses

#### Inventory Contents
- **Gold Coins**: Accumulated wealth from stealing and cooking
- **Tools & Lockpicks**: Stolen from NPCs
- **Valuable Trinkets**: Rare collectibles from NPCs
- **Ingredients**: Apples, plums, pears, poppies, orchids, marigolds, frost lilies
- **Consumables**: Witch's brews (Vitality Elixir, Sunfire Elixir, Shadow Veil, Moonlit Frost, Orchard Compote, Grand Ambrosia)
- **Ammo**: Machine gun cartridges, shotgun shells, rockets

#### Cooking & Inventory Integration
When you cook at the witch's cauldron:
1. The recipe produces a consumable item added to your inventory
2. You receive a small immediate "taste test" bonus (20% gold, 30% healing)
3. Use the consumable from inventory later for the **full effects**
4. This allows strategic timing of powerful buffs and healing

---

## Controls Reference

| Key | Action |
| --- | --- |
| **W, A, S, D** | Movement |
| **C / Ctrl / Shift** | **Crouch / Sneak (Silent movement)** |
| **F** | **Steal targeted item / Retrieve dropped loot / Pick fruit or flower / Cook Cauldron** |
| **E** | **Interact / Talk / Tap Shoulder / Pick fruit or flower / Add ingredient to Cauldron** |
| **Space** | Jump (or Stand up from crouch) / Ascend (Fish/Bird) |
| **Mouse 1** | Attack / Fire Weapon |
| **1 – 4 / Wheel** | Switch Weapons |
| **I / Tab** | **Open/Close Inventory** |
| **Z** | **Transform into Fish (swimming, third-person view)** |
| **X** | **Transform into Bird (flying, third-person view)** |
| **V** | **Transform into Cat (quadruped running, third-person view)** |
| **B** | **Revert to Human Form** |
| **R** | Restart Scene |
| **Esc** | Quit Game (or Close Inventory) |

---

## Technical Architecture

- **Engine**: Godot Engine 3.x (compatible with 3.4, 3.5, 3.6)
- **Key Files**:
  - `characters/ItemMeshFactory.gd`: Factory providing procedural 3D models, shared outline materials, warmup routines, and outline modes (`HIGHLIGHT_NONE`, `HIGHLIGHT_CLOSE` white outline/glow, `HIGHLIGHT_FOCUSED` gold outline/glow).
  - `characters/WhiteOutlineMat.tres`: Preloaded inverted-hull white outline material resource.
  - `characters/GoldOutlineMat.tres`: Preloaded inverted-hull gold outline material resource.
  - `characters/ItemTransferVisual.gd`: In-world 3D transfer entity that animates stolen items flying from NPC hips to the player's view, with midway fumble detection.
  - `characters/DroppedLootItem.gd`: Dropped item physics entity with downward floor raycast, tumbling gravity, ground bob, outline highlighting, and pickup triggers.
  - `characters/AnimalFormManager.gd`: **Animal transformation system** managing Fish/Bird/Cat forms with third-person camera, unique physics per form, procedural animal meshes, and smooth transitions.
  - `characters/enemies/Monster.gd`: NPC AI managing business stations, 3D body placeholders, attention decay, [E] shoulder taps, `catch_fumbled_item`, and `catch_pickpocket_immediate`.
  - `characters/player/Player.gd`: Camera midpoint item scanning, dynamic outline state management, scaling failure chance calculations, midway fumble handling, `[F]` stealing, `[E]` interaction, `[Z/X/V/B]` animal transformation, and HUD prompt rendering.
  - `characters/player/StatsDisplay.gd`: Real-time HUD showing Health, Ammo, Gold, Tools count, Stance, Stealth detection state, and current animal form.
  - `project.godot`: Input map with dedicated `sneak` (`KEY_C`), `interact` (`KEY_E`), `steal` (`KEY_F`), and animal form keys (`KEY_Z`, `KEY_X`, `KEY_V`, `KEY_B`).
